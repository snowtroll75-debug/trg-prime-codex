# TRG Prime Codex development

This repository implements the supplied TRG Prime Codex as a Foundry v14 companion module. The module ID is `trg-prime-codex`. The reference system is the separately extracted `../references/core-3.685.2/trg-prime` from the supplied ZIP. The running test world is TRG V14 (`trg-v14`), with GM Testing Dude and a blank password.

Use sourcebook anchors and executable arithmetic. Class Index uses 208 DP and complete-construction XPM uses 250 DP. Unknown valuations remain unresolved and block authoritative totals. Preserve negative costs, layer provenance and replacement relationships. The user approved Part II for Gargantuan Dexterity −3 and natural attacks relative to printed base sizes on 7 November 2026.

Reuse native core documents and automation flags. Changes to the installed core, campaign data and published compendiums require separate user authorization. Keep module work in this repository. Publish and push only when requested. No additional npm packages are authorized in this session. Native Foundry build libraries and the existing external Playwright installation are available.

Run `npm.cmd test` for deterministic DP and construction tests. `node tools/preview-live.mjs` opens visible Chrome, previews detached actors and exercises the UI without creating world documents. `npm.cmd run build` compiles module-owned packs with the installed ClassicLevel library and creates a versioned ZIP. Build outputs are immutable and retained under dist.

Update the implementation matrix, rules audit and test report with actual evidence. Preserve existing actor customisations and unrelated documents. Avoid updating embedded collections through actor.update. Do not mark any ability runtime-verified solely because its native flags exist or its DP ledger sums correctly.
