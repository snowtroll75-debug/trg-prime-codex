# Changelog

## 0.2.2 — 18 November 2026

- **Type-granted abilities are priced by the type.** An ability the published creature's own type grants, such as Returned Essence on every Eternal (Fiends & Fables 0.46.2), is part of the type ledger. It is no longer listed as an unresolved component. This is checked only after the catalogue lookup, so abilities the Codex values on their own are unchanged.
- `tests/joint-audit.test.mjs`: 10 tests.

## 0.2.1 — 18 November 2026

Graham's rulings on the joint Codex / Fiends & Fables audit. Verified with TRG Prime 3.699.0.

- **RD-02 Tiny and Diminutive reach is 0**, as in core. The builder no longer blocks Tiny and Diminutive creatures. The size ledgers are unchanged: "Reach beyond five feet" prices only reach above 5.
- **CO-02 / RD-08:** the native Ooze type copy is immune to disease and precision, matching core 3.699.0. Its DP ledger already priced both.
- **RD-01:** the Codex reading (no Death State for Eternals) is now core's too. The 0.2.0 guard stays for older published copies.
- **RD-07:** ruled as implemented in 0.2.0. A published creature's level-progression General feats are free; Codex-built designs are unchanged.
- `tests/joint-audit.test.mjs`: 9 tests.

## 0.2.0 — 18 November 2026

Joint TRG Prime Codex / Fiends & Fables audit (single register: `docs/joint-audit/CODEX_FIENDS_DEFECT_REGISTER.md`). Verified with TRG Prime 3.698.4.

- **Variants of published creatures (CX-03).** "Published creatures (start a variant)" in the toolkit, and `api.importCompendiumCreature(uuid)`, copy a compendium creature into the world with provenance (`variantOf`, `_stats.compendiumSource`). The builder never edits a compendium actor: apply refuses one.
- **Printed names (CX-04).** Tail/Tail Slap, Wing/Wings, Claws/Claw, Unarmed/Fist, Snow Vision and printed sense ranges are matched to their Codex components, so an unchanged apply leaves the creature identical and never adds second copies.
- **Provisional ledgers (CX-05, CX-06, CX-07).** A published creature's DP is valued from its own published base. Components without a Codex valuation are listed with their reason instead of blocking the ledger. Parameterised and tiered feats are valued at their base category rate, and the creature's level-progression General feats are credited back (rules decision RD-07 pending). Codex-built designs value exactly as in 0.1.5.
- **Eternal Death State (CX-01).** The Codex's Part II reading is applied only to an Eternal type the Codex placed itself; a published Eternal keeps the core's (rules decision RD-01).
- **Packs (CX-02).** The four compendiums are rebuilt with a valid LevelDB MANIFEST; every document is byte-identical to 0.1.5.
- `tests/joint-audit.test.mjs` (8 Node tests) and the shared live battery `tests/live/creature-battery.mjs` (identical in Fiends & Fables Prime 0.46.0).
- Fiends & Fables Prime is an optional `recommends`; the Codex needs nothing from it.

## 0.1.5 — 8 November 2026

Resolve effective spell capacity through native use-pool readers during Codex edits, retaining item bonuses, actor feats and Focus declarations. Preserve live availability after Refocus, daily restoration and bonus changes, retain hidden expenditure across capacity reductions/class casting, and leave shared-member counters alone. Core shared Refocus and Wild Shape configuration defects remain outside this correction.

## 0.1.4 — 8 November 2026

Generate native-default Focus spells with a blank count and the Focus trait so the core enforces one use. Preserve Focus expenditure during ordinary/repeated edits, legacy count repair and casting-mode changes, while respecting native full resets. Keep the published DP anchors unchanged. Add focused construction/resource regressions and extend the unmocked live casting suite.

## 0.1.3 — 8 November 2026

Fix Eternal's module-owned no-Death-State declaration to match Part II source block 2088, including the compendium generator and existing actors when explicitly edited. Reconcile spell innate mode, frequency and generated Focus traits while preserving manual fields, identity and spent uses. Respect native full resets even after reducing capacity. Reject unsupported optional casting; keep ignored PC casting selectors out of complete class DP. Update casting controls to reflect supported and fixed class rules. The intermediate 0.1.2 build is retained; 0.1.3 adds the reduced-capacity reset safeguard. No core changes or new dependencies.

## 0.1.1 — 8 November 2026

Reconcile native grants before actor creation succeeds and before the editor captures its post-edit baseline. Await native queues without fixed delays. Remove incomplete actors if initial grant reconciliation fails. Recheck stale actors after asynchronous preview preparation. Retain strict stale-edit rejection and native grant provenance. All 36 local tests and 16 installed live checks passed in TRG V14 as Testing Dude. Core files were unchanged.

## 0.1.0

Initial development build. Added exact XPM boundary arithmetic, DP source data, twelve type ledgers, sixteen creature/NPC class ledgers, 114 ability valuations, size and natural attack costs, layered package components and a Foundry ApplicationV2 GM toolkit. Reused native core item data and effects. Added project storage, actor preview, creation and guarded editing paths. Runtime and audit status are recorded separately.
