# Codex automation report

**0.2.0 cross-check with Fiends & Fables Prime.** The Codex native copies match core 3.698.4, except Eternal `noDeathState` (RD-01). The Codex packs declare no `extends`, so they take no part in core inheritance and cannot alter a Fiends creature. Classifications below are unchanged by 0.2.0. Published creatures' abilities are classified in docs/joint-audit/FIENDS_ABILITY_AND_FEAT_AUDIT.md.

Latest resource follow-up: actual native Refocus and shared-pool workflows passed 43/51 assertions. Selection/cancellation, base Refocus, declared restore-all, shared casting and Extra Wildshape work in the tested cases. Codex bonus editing, core shared-member Refocus and core zero-use Wild Shape reconfiguration remain defective. See [report](docs/refocus-pools-test-report.md). This does not establish complete automation for other listed abilities or in-combat/timed behavior.

Native content and automation declarations were inspected against the supplied 3.685.2 core. All entries below are conservatively C until their complete workflow is driven live. A native flag or a correct DP total alone does not establish complete automation. The source data is retained so each case can be audited without losing its existing core behavior.

| Ability | DP | Native data | Classification | Evidence and remaining test |
|---|---|---|---|---|
| Absorb Minerals | 4 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Abyssal Healing | 16 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Acute Sense | 2 | conditionals | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Alien Mind | 7 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| All Round Vision | 3 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Amorphous Split | 25 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Arcadian Caster | 18 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Ashen Aura | 14 | creatureAbility, auras | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Aura of Confusion | 19 | creatureAbility, auras | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Aura of Death | 12 | creatureAbility, auras | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Aura of Decay | 13 | creatureAbility, auras | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Aura of Despair | 22 | creatureAbility, auras | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Aura of Fire | 12 | creatureAbility, auras | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Aura of Heat | 11 | creatureAbility, auras | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Aura of Ruin | 6 | creatureAbility, auras | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Aura of Tranquility | 6 | creatureAbility, auras | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Blight Sense | 2 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Blood Scent | 5 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Clinging Breath | 6 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Constrict | 8 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Corrode | 5 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Crush | 16 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Detect Magic | 6 | conditionals, untrainedActions | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Dispelling Strike | 9 | creatureAbility, afterStrikes | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Diving Strike | 5 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Double Strike | 7 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Draconic Assault | 6 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Draconic Roar | 8 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Draconic Shifting | 4 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Drink Blood | 9 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Earth Pass | 4 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Echolocation | 7 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Elemental Grasp | 8 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Elemental Aura | 10 | creatureAbility, auras | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Elemental Blood | 4 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Elemental Strikes | 7 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Elusive Movement | 6 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Endless Hunger | 0 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Entangling Vines | 12 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Eternal Essence | 12 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Eternal Summons | 27 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Faultless Casting | 3 | creatureAbility, defensiveCasting | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Fear of Water | -1 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Fearful Strength | 2 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Fire Healing | 12 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Flyby Attack | 4 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Frightful Aura | 18 | creatureAbility, auras | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Gallop | 3 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Garlic Repulsion | -3 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Grave-Touched Presence | 2 | creatureAbility, conditionals | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Hold Breath | 1 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Hover | 5 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Howl | 8 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Ice Climb | 5 | creatureAbility, ignoresDifficultTerrain | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Ice Stride | 2 | creatureAbility, ignoresDifficultTerrain | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Infestation | 8 | creatureAbility, auras | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Keen Sense | 4 | creatureAbility, conditionals | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Life Drain | 12 | creatureAbility, afterStrikes | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Life Sense | 8 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Magic Dispelling | 5 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Monstrous Grab | 9 | conditionals, creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Monstrous Knockdown | 9 | conditionals, creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Natural Camouflage | 2 | creatureAbility, conditionals | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Natural Leaper | 7 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Pack Attack | 4 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Paralysing Gaze | 22 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Penetrating Breath | 5 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Penetrating Strikes | 3 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Persistent | 2/profile | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Plant Resistance | 5 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Pouncing Assault | 7 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Powerful Charge | 7 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Reactive Disarm | 4 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Reflective Scales | 14 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Regeneration | 20 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Rend | 8 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Secondary Critical | 4/profile | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Shadow Breath | 9 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Shadow Hand | 5/profile | creatureAbility, afterStrikes | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Shadowy | 5 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Skewering Strikes | 2 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Slow I | -8 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Slow II | -15 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Slowing Breath | 10 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Smoke Form | 6 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Smokevision | 3 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Snowvision | 2 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Sonar Sense | 6 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Sonic Moan | 9 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Souldrinker | 10 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Soulless Aura | 10 | creatureAbility, auras | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Spell Resilience | 18 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Stench | 7 | creatureAbility, auras | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Sunlight Vulnerability | -15 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Sunlight Weakness | -7 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Surge of Speed | 3 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Survival Instinct | 20 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Swallow | 15 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Swimby Attack | 4 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Tear Flesh | 8 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Telepathy | 2 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Torrent of Strikes | 20 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Trample | 10 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| True Caster | 12 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Undead Fortitude | 12 | creatureAbility, deathGuard | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Undead Spawn | 6 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Vibration Sense | 8 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Vorpal Weapons | 10 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Water Glide | 3 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Whirlpool | 8 | creatureAbility, auras | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Whirlwind | 6 | creatureAbility, auras | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Whispers of the Grave | 2 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Wing Buffet | 13 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |
| Wingless Flight | 6 | creatureAbility | C | Published ledger arithmetic checked. Complete activation, resources, target outcomes and cleanup await an installed runtime case. |

## Additional domains

DP worked-example and threshold arithmetic is A for the executed functions and inputs recorded in the test report. Installed CRUD, native grants, spell resource edits, all tested class/type choices and Eternal zero-HP handling have direct evidence in 0.1.3; see docs/four-fixes-test-report.md. The four earlier expanded-matrix failures are fixed. These results do not promote individual ability combat workflows above C or establish every spell's effects. Full feat prerequisites and aligned control retain C pending specific tests. Narrative-only source features can become D only after an individual source-based review.

Actual casting now has direct native-workflow evidence for the tested learned and numeric-innate resource cases, including real rolls, refusal, rest and Daily Preparation. Codex Focus generation and spent-use editing fail the native control tests and remain incomplete. This supersedes any broader inference from earlier field-only Focus tests; see docs/actual-casting-test-report.md.

Follow-up in 0.1.4: both Focus failures are corrected and the expanded native Focus regressions pass. This verifies the tested base Focus use, edit and preparation lifecycle, not the separate Refocus action, bonus/shared pools or every spell effect. See docs/focus-fixes-test-report.md.
