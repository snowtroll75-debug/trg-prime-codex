# Core dependencies

**0.2.0 (18 November 2026).** Verified with TRG Prime 3.698.4; the minimum stays 3.685.2. The joint Codex / Fiends & Fables audit recorded two proposed core changes; neither is applied, and neither is needed for 0.2.0 to work. CO-01: the grant workflow should hold printed-range senses ("Darkvision (60 ft.)") under their base name, so later grant passes stop adding a generic duplicate. CO-02: the Ooze type lacks precision immunity. The Tiny/Diminutive reach question below is now rules decision RD-02. Full list: docs/joint-audit/CODEX_FIENDS_CORE_DEPENDENCIES.md.

The reference core is the supplied trg-prime-3.685.2.zip. Runtime previews used Foundry 14.367 and the installed TRG Prime 3.685.2. The companion module uses native Actor/Item classes, type records, class progressions, creature attack metadata, transfer effects and existing ability declarations. The original system source and installed core were not edited during this module work.

One confirmed sourcebook compatibility issue needs a core extension. In module/config.mjs, SIZE_TABLE.diminutive.reach and SIZE_TABLE.tiny.reach are 0, while the Codex tables specify 5 feet. module/documents/actor.mjs assigns combat.reach from SIZE_TABLE during prepareCombat. A supported module override or an approved core correction is required to generate those sizes with the specified reach. The module preview reports this and its create/apply paths block mismatched values.

The prior investigation’s core compendium IDs, snapshot label and combat-cleanup concurrency findings remain separate from this module. Module content has stable valid IDs and preserves native automation declarations. It does not rewrite the installed core packs to repair them.

Full native ability and feat coverage, High Magic interactions, PC XPM relevel behavior and custom-class export need additional runtime tests or API review. Record any necessary core changes as separate patches for approval. The current module supplies no competing combat or spellcasting engine.
