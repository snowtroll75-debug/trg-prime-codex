# Creature Builder

**Variants of published creatures (0.2.0).** "Published creatures (start a variant)" lists NPC actors in installed module compendiums, such as Fiends & Fables Prime. Choosing one makes a world copy flagged `variantOf`, with `_stats.compendiumSource`; the builder works only on that copy. Apply refuses any actor that lives in a compendium. Printed component names (Tail, Wing, Claws, "Darkvision (60 ft.)"…) are matched to Codex components, so an unchanged apply leaves the actor identical. Creature-specific items the Codex cannot value are kept unchanged and listed as unresolved in the ledger. A published Eternal keeps the core's Death State (RD-01). Tiny and Diminutive creatures stay blocked by the reach mismatch (RD-02).

The GM toolkit uses Foundry v14 ApplicationV2 and HandlebarsApplicationMixin. It presents identity, type, race/heritage, size, one class, statistics, movement, attacks, abilities/feats, magic, review and actor generation in one application. The separate package view adds source-backed components to race and heritage ledgers.

Native Item sources are materialised from the supplied core ZIP, including embedded Active Effects. The module gives its own content stable IDs. Core actor and item classes perform stat derivation and all supported combat processing. Natural attacks retain the core’s printed-size metadata. The module stores the construction and DP ledger under flags.trg-prime-codex and creates NPC actors with native Items.

The actual level is stored under system.identity.level. Effective Level remains a module calculation. A preview constructs a detached core actor and reads its derived statistics. It uses the core type rule when displaying a creature with no Death State. Reach disagreement between the sourcebook and the core is surfaced and blocks a mismatched actor creation.

Creation has an implemented Actor.create path. Editing loads existing NPC designs, checks for changes since the actor was opened and updates only selected scalar fields and managed Items. Item create/update/delete calls are explicit. Unrelated Items are retained, and a rollback path records prior edited fields and documents. These persistence and rollback paths still require installed-world failure-injection tests before release acceptance.

Projects use JournalEntry flags and can be saved, loaded and duplicated. Export produces a JSON construction and ledger. Schema version 1 is explicit; future versions must migrate projects rather than silently reinterpret them.

The live preview tests exercised the actual v14 UI, selected a Large level-5 Undead, added Bite, Claw and Undead Fortitude, calculated its DP and read core statistics. They also constructed all 96 type/size combinations in memory. They did not create actors, save projects, or execute all ability workflows. Advanced affected-profile controls, complete skill allocation, manufactured-weapon selection and custom-class export remain in the matrix as outstanding work.
