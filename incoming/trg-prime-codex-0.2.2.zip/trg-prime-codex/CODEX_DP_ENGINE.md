# Development Point engine

**Imported designs (0.2.0).** A design read from a published creature (`design.imported`) is valued with a provisional ledger. Its attributes are measured from its own published base, so level increases are not purchases. Its race and heritage are valued from their declared effects where a published schedule fits. Printed feats are valued at their catalogue category rate, including parameterised printings such as "Weapon Focus (Brawling)", and its level-progression General feats are credited back (RD-07, pending). Anything else is a null row with its reason. The complete total and XPM of a Codex-built design are computed exactly as in 0.1.5; tests/joint-audit.test.mjs compares the two versions.

The pure service is module/dp.mjs. It reads generated source-linked tables in data/rules.mjs. Type, class and ability totals are summed from component rows. The source import checks their printed arithmetic. Every ledger line includes its layer, source, base DP, final DP and any absorbed or replaced component.

Class Index uses `(Class DP / 208) × 100`. Complete XPM uses the separate rounded 250-DP benchmark. The calculated 40 + 208 sum is 248 and does not replace that published rounded benchmark.

Above the inclusive 90–110% band, XPM is `0.1 × ceil((percentage −110)/20)`. Below the band it is `−0.1 × ceil((90 −percentage)/20)`. Decimal inputs are converted to integer fractions before comparison, so display rounding cannot change a band. XP Factor is `1 + XPM`, XP per level is `10,000 × factor`, equivalent XP is `actual level × XP per level`, and EL is the nonnegative floor of `actual level × factor`. The pure PC-level helper retains current XP and floors division by the new per-level requirement.

Unknown components retain null DP and a reason. Their subtotal remains inspectable, but complete DP and XPM are withheld. Negative complete totals that expose the source’s below-10% table/formula conflict also remain unresolved.

Implemented anchors include concentrated ability changes, HP, land and special movement, skills, feat categories, equipment access, defence scopes, senses, DR, CR, spells and innate availability, PP, class progressions and class spell access. The API supports explicit replacement relationships, source-linked quantities and named bundles. Wingless Flight absorbs Hover, Ice Climb absorbs Ice Stride, Sunlight Vulnerability absorbs Sunlight Weakness, and type-owned Eternal Essence and Plant Resistance are excluded from repeated ability costs.

The generic ledger can compare custom race, heritage, background and class components. It does not infer a cost from free text. A full automatic assessment of arbitrary existing content still requires extraction of that content’s mechanical declarations and review of overlap. Sourcebook conditional variants beyond the implemented choices are listed as pending in the matrix.

Tests execute the sourcebook examples, both sides of threshold boundaries, class replacement, layered packages, type/size arithmetic and overlap cases. Exact executed results are in CODEX_TEST_REPORT.md.
