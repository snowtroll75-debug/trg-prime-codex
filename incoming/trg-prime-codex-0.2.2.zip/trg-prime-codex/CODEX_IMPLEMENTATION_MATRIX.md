# Codex implementation matrix

7 November 2026. This inventory preserves every extracted paragraph and table row from the supplied sourcebook. It is a source inventory with implementation status, not a claim of completed rules or combat verification. Source block numbers refer to the DOCX body XML and remain stable for the fingerprinted input.

The source contains 2045 nonempty blocks and 166 tables. Native module content contains 12 types, 16 creature/NPC classes, 10 natural attacks and 114 abilities.

| Source block | Mechanic or source text | Representation | Status |
|---|---|---|---|
| 2 | TRG PRIME | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 3 | CODEX | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 4 | CREATURES • DEVELOPMENT POINTS • DESIGN FRAMEWORK | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 6 | A consolidated reference for constructing, balancing and running creatures in TRG Prime | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 7 | TRARIS GAMES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 9 | CREDITS & COMPILATION | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 10 | Writing  Graham Seeney | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 11 | Source Material  Creature Codex V1.6; TRG Prime Development Point Rules | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 12 | Publisher  Traris Games | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 13 | Edition  TRG Prime Codex — Working Compilation | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 14 | This working edition consolidates the existing creature-construction material and the Development Point framework into a single sourcebook. The structure is deliberately modular so further Codex material can be added without rebuilding the book from the ground up. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 15 | No rules text from the two source documents has been substantively rewritten for this compilation; the material has been reorganised and restyled for consistency. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 17 | CONTENTS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 18 | PART I — CREATURE CODEX | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 19 | Chapter 1 — The Basics | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 20 | Creature Types, Classes and Construction | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 21 | Creature Stat Blocks | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 22 | Creature Abilities | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 23 | Chapter 3 — Feats & Traits | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 24 | Appendix — Aligned Expanded | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 25 | PART II — DEVELOPMENT POINT RULES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 26 | Introduction | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 27 | Chapter 1 — Core Method | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 28 | Chapter 2 — Universal Component Costs | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 29 | Chapter 3 — Race, Heritage, and Background Packages | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 30 | Chapter 4 — Spells and Power Points | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 31 | Chapter 5 — Class Chassis | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 32 | Chapter 6 — Class Spell Access | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 33 | Chapter 7 — Worked Examples and Worksheets | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 34 | Chapter 8 — Creature and NPC Construction | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 35 | Chapter 9 — XP Multipliers and Effective Level | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 37 | PART I | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 38 | CREATURE CODEX | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 40 | Creature construction, classifications, abilities, feats and supporting rules | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 42 | CHAPTER 1 - THE BASICS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 43 | Drok charged through the wooden door sending splinters of wood flashing in all directions. Ignoring the abrasions he had taken, he lashed out at the three eyed monstrosity that stood before him. This thing was an affront to the gods and had to be crushed before it could convert these weak-minded villages to its cause. Alas it appeared that his fears were to be brought to bear as several of those very villagers shambled through what remained of the door behind him, appearing to be far less human than they were at breakfast. Drok shrugged and resigned himself to the fact that he would have to put them in the earth as well but first, the three eyed beast had to die. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 45 | Every Fantasy RPG needs creatures and monsters and TRG is no different. The fantasy worlds of TRG are occupied by numerous odd and bizarre entities ranging from foul Mind Eaters to peaceful Unicorns.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 46 | From a game mechanics perspective, monsters and NPCs are treated in a similar fashion to PCs. Each monster has a level a race which determines its core abilities.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 47 | Before we get into the core monster descriptions, we shall examine the different types of monsters that you will encounter, their abilities and how to construct them. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 48 | Throughout the text I will use the generic term ‘creature’. This term is a loose definition for any Non-Player Character (NPC) that the PCs will encounter. Some of these creatures may well be humanoid races and some of them even playable as PCs. As the GM, you must determine if you wish to create an NPC using the Creature Creation rules or using the Rules for building PCs.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 49 | There are several categories that divide all creatures and these are briefly explained here, with greater description later in the chapter. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 50 | CREATURE TYPE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 51 | A creature type is a very wide sweeping generalised category which a creature belongs to. There are twelve different creature types in the TRG game system which are: | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 52 | Aberration, Animal, Beast, Construct, Elemental, Eternal, Fey, Humanoid, Ooze, Plant, Undead and Wyrm. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 53 | A creature s type will determine several of its base abilities. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 54 | CREATURE CLASS  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 55 | Most creatures will have a Creature Class which corresponds to their Creature Type. Some creatures will have a PC or NPC class instead of a Creature Class (this is often the case with humanoids). After each Creature Type below, you will find the class details for the Creature. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 56 | CREATURE RACE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 57 | A creature will also have a race. This is sometimes referred to as a sub-type and is the equivalent of a PC race. A creature’s race will sometimes be broken down further into racial heritages just like that of a PC. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 58 | HERITAGE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 59 | A creature race may also be broken down further with a heritage. A heritage will divide races such as giants and dragons with into more detail. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 61 | CREATURE TYPE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 62 | Each creature (and npc) has a Creature Type. This type broadly defines the creatures’ abilities. In TRG, creatures are broken down into twelve different types which are Aberration, Animal, Beast, Construct, Elemental, Eternal, Fey, Humanoid, Ooze, Plant, Undead and Wyrm. Each type is detailed below. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 64 | HIT POINTS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 65 | Each creature has an amount of base hit points based upon its race type and size (see below). | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 66 | Be aware that this differs from PC’s who gain base hit points based upon race and size. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 67 | Creatures also gain an amount of hit points for every level in the same way as a PC. A creature gains a set amount of HP each level modified by Con (in the same way as a PC).  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 68 | ABILITY SCORES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 69 | Creatures begin with a default value of 1 in each ability score unless stated otherwise. Any racial modifiers for the creatures’ type will be listed here as well. Just like a PC, creatures may increase an ability score by 1 for every three levels.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 70 | TRAITS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 71 | Each creature type grants a number of specific traits. All creatures that have the specified type will have these abilities. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 72 | CREATURE CLASS  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 73 | A standard member of each creature type will use the set creature class details which are listed here. The creature class description contains the following information: | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 74 | PROFICIENCIES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 75 | Gives the armour and weapons that the creature is trained to use. The creature may expand upon these by selecting feats and may gain additional proficiencies from race and other options. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 76 | CLASS SKILLS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 77 | Your creature class will have a number of skills which gain a special bonus type called a class bonus. Your class bonus is determined by your class level. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 78 | SKILL POINTS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 79 | Like a PC, a creature gains a number of skill points each level which may be used to select skills.   | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 80 | HIT POINTS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 81 | This entry will tell you how many hit points the creature gains each time it gains a level.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 90 | BASE ATTACK/DEFENCE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 91 | Each creature class has a Base Attack Bonus (BAB) and Base Defence Bonus (BDB) which will be listed as Primary, Secondary or Tertiary. These values are displayed on the below table: | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 92 | BAB TABLE | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 92 | Level / Primary / Secondary / Tertiary | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 92 | 1 / 1 / 0 / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 92 | 2 / 2 / 1 / 1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 92 | 3 / 3 / 2 / 1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 92 | 4 / 4 / 3 / 2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 92 | 5 / 5 / 3 / 2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 92 | 6 / 6 / 4 / 3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 92 | 7 / 7 / 5 / 3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 92 | 8 / 8 / 6 / 4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 92 | 9 / 9 / 6 / 4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 92 | 10 / 10 / 7 / 5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 92 | 11 / 11 / 8 / 5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 92 | 12 / 12 / 9 / 6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 92 | 13 / 13 / 9 / 6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 92 | 14 / 14 / 10 / 7 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 92 | 15 / 15 / 11 / 7 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 92 | 16 / 16 / 12 / 8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 92 | 17 / 17 / 12 / 8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 92 | 18 / 18 / 13 / 9 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 92 | 19 / 19 / 14 / 9 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 92 | 20 / 20 / 15 / 10 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 94 | SAVING THROW MODIFIERS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 95 | This section determines the priority of a creature’s class saving throws listing whether they are primary, secondary or tertiary. Furthermore, some creatures may also gain a static modifier to these saves.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 96 | SAVING THROW TABLE | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 96 | Level / Primary / Secondary / Tertiary | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 96 | 1 / 6 / 3 / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 96 | 2 / 7 / 4 / 1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 96 | 3 / 8 / 5 / 2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 96 | 4 / 9 / 6 / 3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 96 | 5 / 10 / 7 / 4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 96 | 6 / 11 / 8 / 5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 96 | 7 / 12 / 9 / 6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 96 | 8 / 13 / 10 / 7 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 96 | 9 / 14 / 11 / 8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 96 | 10 / 15 / 12 / 9 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 96 | 11 / 16 / 13 / 10 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 96 | 12 / 17 / 14 / 11 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 96 | 13 / 18 / 15 / 12 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 96 | 14 / 19 / 16 / 13 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 96 | 15 / 20 / 17 / 14 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 96 | 16 / 21 / 18 / 15 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 96 | 17 / 22 / 19 / 16 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 96 | 18 / 23 / 20 / 17 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 96 | 19 / 24 / 21 / 18 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 96 | 20 / 25 / 22 / 19 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 99 | FEATS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 100 | A creature gains feats in a similar way to that of a PC. Like a PC, a creature will gain a General feat at 1st level and then another for every two levels thereafter (3rd, 5th, 7th etc).  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 101 | The creature may also select individual racial and class feats, but these are based upon the creature’s subtype. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 102 | MAGIC | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 103 | Some creatures will have access to magical spells. These are developed in the same way as a PCs. Any details regarding the creatures’ magic such as caster level, tradition, magical ability score, power points and spellcraft bonus will be listed here. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 104 | If a creature class has spellcasting abilities, its BSB will be listed as Primary, Secondary or Tertiary. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 105 | BSB TABLE | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 105 | Level / Primary / Secondary / Tertiary | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 105 | 1 / 1 / 0 / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 105 | 2 / 2 / 1 / 1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 105 | 3 / 3 / 2 / 1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 105 | 4 / 4 / 3 / 2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 105 | 5 / 5 / 3 / 2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 105 | 6 / 6 / 4 / 3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 105 | 7 / 7 / 5 / 3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 105 | 8 / 8 / 6 / 4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 105 | 9 / 9 / 6 / 4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 105 | 10 / 10 / 7 / 5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 105 | 11 / 11 / 8 / 5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 105 | 12 / 12 / 9 / 6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 105 | 13 / 13 / 9 / 6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 105 | 14 / 14 / 10 / 7 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 105 | 15 / 15 / 11 / 7 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 105 | 16 / 16 / 12 / 8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 105 | 17 / 17 / 12 / 8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 105 | 18 / 18 / 13 / 9 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 105 | 19 / 19 / 14 / 9 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 105 | 20 / 20 / 15 / 10 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 107 | Furthermore, if the creature class has casting abilities it will also have caster level which is Primary, Secondary or Tertiary. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 108 | CASTER LEVEL TABLE | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 108 | Level / Primary / Secondary / Tertiary | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 108 | 1 / 1 / 1 / 1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 108 | 2 / 2 / 1 / 1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 108 | 3 / 3 / 2 / 2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 108 | 4 / 4 / 3 / 2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 108 | 5 / 5 / 3 / 3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 108 | 6 / 6 / 4 / 3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 108 | 7 / 7 / 5 / 4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 108 | 8 / 8 / 6 / 4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 108 | 9 / 9 / 6 / 5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 108 | 10 / 10 / 7 / 5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 108 | 11 / 11 / 8 / 6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 108 | 12 / 12 / 9 / 6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 108 | 13 / 13 / 9 / 7 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 108 | 14 / 14 / 10 / 7 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 108 | 15 / 15 / 11 / 8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 108 | 16 / 16 / 12 / 8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 108 | 17 / 17 / 12 / 9 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 108 | 18 / 18 / 13 / 9 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 108 | 19 / 19 / 14 / 10 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 108 | 20 / 20 / 15 / 10 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 109 | Be aware that all NPC/creature casters are instinctive and will know the following spells based upon caster level:Primary: 4 per caster level and 4 cantrips; Secondary: 2 per caster level and 2 cantrips; Tertiary: 1 per caster level and 0 cantrips. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 110 | SIZE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 111 | A creature’s size comes up frequently. The below table provides modifiers based upon size.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 112 | CREATURE SIZE MODIFIERS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 112 | Size / Base HP / Str / Dex / Reach | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 112 | Diminutive / 0 / -3 / +3 / 5' | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 112 | Tiny / 10 / -2 / +2 / 5' | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 112 | Small / 20 / -1 / +1 / 5' | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 112 | Medium / 30 / 0 / 0 / 5' | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 112 | Large / 50 / +1 / -1 / 10' | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 112 | Huge / 80 / +2 / -2 / 15' | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 112 | Gargantuan / 120 / +3 / 3 / 20' | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 112 | Colossal / 250 / +4 / -4 / 25' | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 114 | CREATURE RACE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 115 | Each creature in the game will have a race (sometimes referred to as a sub-type). These sub-types are often used to differentiate between different types of creatures and to help create a more detailed and diverse game world.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 116 | Some examples of races include undead types, such as zombies or vampires; dragons, which are often depicted as powerful and intelligent creatures with magical abilities; demons, which are often associated with evil and chaos; and creatures such as efreet and salamanders, which are beings made up of one of the classical elements, such as fire or water. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 117 | Each race often has its own unique abilities, strengths, weaknesses, and lore. They may also have specific vulnerabilities or resistances to certain types of damage or spells, making them more or less challenging for players to defeat. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 118 | A creature’s race will often be broken down further with individual heritages such frost giant, cold dragon etc. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 134 | ABERRATION | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 135 | Aberrations, beings with abnormal anatomy and peculiar physiology, often sport strange or alien appearances. Possessing potent psionic or magical powers, their abilities prove challenging to resist or defend against. An encounter with Aberrations can often invoke fear and madness. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 136 | The origins of these creatures remain shrouded in mystery, lurking in the deep, dark recesses of the world, where men should tread cautiously. Unravelling their motivations proves elusive; while some serve greater powers, many are solitary entities seeking to establish their own dominion or satisfy their primal instincts. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 137 | Beware distinctive traits like numerous eyes, stalks, or tentacles, for they are telltale signs of an Aberration. Their presence in the realm adds an air of mystery and peril, urging caution when navigating the unknown. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 138 | TRAITS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 139 | Aberrations have the darkvision racial trait. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 140 | Aberrations breathe, eat, and sleep. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 141 | An Aberration gains a +2 racial modifier to Will saving throws. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 142 | An Aberration has a Death State of 4. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 143 | ABERRATION CLASS  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 144 | A standard Aberration will gain the following class features: | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 146 | PROFICIENCIES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 147 | An Aberration is only proficient with simple weapons. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 148 | CLASS SKILLS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 149 | Acrobatics, Athletics, Climbing, Deception, Intimidate, Meditation, Mental Focus, Occultism, Perception, Power Manipulation, Sense Motive, Stealth, Survival | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 150 | SKILL POINTS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 151 | 6 + Int per level   | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 152 | HIT POINTS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 153 | 8 + Con per level  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 154 | BASE ATTACK BONUS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 155 | Base Attack Bonus Secondary  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 156 | BASE DEFENCE BONUS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 157 | Base Attack Bonus Secondary  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 158 | SAVING THROW MODIFIERS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 159 | Fortitude Secondary | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 160 | Reflex Secondary | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 161 | Will Primary | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 162 | MAGIC | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 163 | Aberrations will often employ magic and prefer the use of the Ethereal Tradition. An Aberration that has magic will have the following magical attributes:BSB Secondary; Caster Level Secondary; PP 2 per level | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 168 | ANIMAL | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 169 | Animals usually operate on instinct, which is driven by natural urges such as hunger and reproduction. Most animals will avoid combat with humanoids and other creatures unless they or their young are under threat. Even animals which are considered predators will only attack when hungry and even then, will often avoid groups of humanoids seeking easier prey. Animals can be found just about anywhere in all shapes and sizes and many have adapted to living in urban environments. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 170 | ABILITY SCORES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 171 | All creatures of the Animal Type have an Intelligence racial ability modifier of -5.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 172 | TRAITS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 173 | Animals have the Nightvision racial trait. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 174 | Animals breathe, eat, and sleep. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 175 | Animals always have a Neutral alignment. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 176 | An Animal gains a +2 racial bonus to all Fortitude and Reflex saves. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 177 | An Animal has a Death State of 6. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 178 | ANIMAL CLASS  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 179 | A standard Animal will gain the following class features: | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 180 | PROFICIENCIES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 181 | An Animal is proficient with all of its natural weapons. An animal has no armour proficiency but may be trained later. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 182 | CLASS SKILLS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 183 | Acrobatics, Athletics, Climbing, Intimidate, Perception, Stealth, Survival | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 184 | SKILL POINTS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 185 | 2 + Wis per level | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 186 | HIT POINTS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 187 | 10 + Con per level  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 188 | BASE ATTACK BONUS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 189 | Base Attack Bonus Secondary  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 190 | BASE DEFENCE BONUS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 191 | Base Attack Bonus Primary  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 192 | SAVING THROW MODIFIERS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 193 | Fortitude Primary | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 194 | Reflex Primary | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 195 | Will Tertiary | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 196 | MAGIC | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 197 | Animals do not possess spellcasting abilities and will never have this variant. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 204 | BEAST | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 205 | A beast is similar to an animal but usually has a higher Intelligence. Beasts are often powerful predators or formidable opponents, with strength, speed, and agility that allow them to survive in their natural habitat.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 206 | Some beasts are capable of language and speech, and many have supernatural abilities. Their anatomies are wide and varied and beasts are very diverse in their nature and appearance.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 207 | Often these creatures are just strange in appearance and others can even be the result of magical experimentation. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 208 | TRAITS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 209 | Beasts have the Darkvision and Nightvision racial traits. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 210 | A Beast gains a +2 racial bonus to all Fortitude saves. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 211 | Beasts breathe, eat, and sleep. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 212 | A Beast has a Death State of 4. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 213 | BEAST CLASS  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 214 | A standard Beast will gain the following class features: | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 216 | PROFICIENCIES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 217 | A Beast is proficient with all of its natural attack forms. A beast is not proficient with any armour or shields. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 218 | CLASS SKILLS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 219 | Acrobatics, Athletics, Climbing, Intimidate, Perception, Stealth, Survival. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 220 | SKILL POINTS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 221 | 4 + Int per level | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 222 | HIT POINTS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 223 | 10 + Con per level  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 224 | BASE ATTACK/DEFENCE BONUS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 225 | Base Attack Bonus Primary  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 226 | SAVING THROW MODIFIERS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 227 | Fortitude Primary | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 228 | Reflex Primary | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 229 | Will Tertiary | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 230 | MAGIC | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 231 | Beasts will sometimes employ magic and have no preference towards a specific magical tradition. A Beast that has magic will have the following magical attributes:BSB Tertiary; Caster Level Tertiary; PP 1 per level. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 240 | CONSTRUCT | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 241 | A construct is an artificially created creature which is usually made from magic. Constructs are not living creatures and often have no minds or independent thought. A construct is usually made for a specific purpose although this is not always the case. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 242 | A construct can have any appearance, and this is determined by its creator. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 243 | TRAITS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 244 | Constructs have the Darkvision and Nightvision racial traits. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 245 | Constructs are immune to bleed, disease, healing, mental damage, poison, soul effects and subdual damage.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 246 | Constructs are immune to the doomed, drained, fatigued, paralyzed, sickened, and unconscious conditions. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 247 | Constructs have Critical Resistance 4. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 248 | A Construct will have natural that reduces damage against them accordingly. This DR is determined by the constructs race. When a construct is reduced to 0 hit points it is destroyed.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 249 | Constructs do not need to eat or breath. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 250 | Constructs cannot heal damage on their own but often can be repaired via exposure to a certain kind of effect (see the creature’s description for details) or through the use of the Crafting skill. Constructs can also be healed through spells such as mending. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 251 | CONSTRUCT CLASS  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 252 | A standard Construct will gain the following class features: | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 253 | PROFICIENCIES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 254 | A Construct is proficient with unarmed weapons only, although many are constructed to use specific weapons. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 255 | CLASS SKILLS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 256 | None | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 257 | SKILL POINTS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 258 | A construct gains no actual skill points as it does not have the capacity to learn. A construct will however be constructed with certain skill proficiencies and automatically gain ranks in these specific skills. All constructs gain 1 rank per level in the Acrobatics, Athletics and Perception skills. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 259 | HIT POINTS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 260 | 12 + Con per level  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 261 | BASE ATTACK/DEFENCE BONUS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 262 | Base Attack Bonus Primary  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 263 | SAVING THROW MODIFIERS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 264 | Fortitude Tertiary | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 265 | Reflex Tertiary | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 266 | Will Tertiary | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 267 | MAGIC | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 268 | Constructs do not possess spellcasting abilities and will never have this variant. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 270 | ELEMENTAL | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 271 | Elementals are creatures that are directly linked to one of the Elemental Planes. They often favour one specific element type, and this is apparent by their appearance.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 272 | Some elementals have a subtler appearance and may not immediately reveal their elemental preference by looks alone. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 273 | TRAITS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 274 | Elementals have the Darkvision and Nightvision racial traits. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 275 | Elementals do not need to breathe. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 276 | Elementals have Critical Resistance 2. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 277 | Elementals are immune to their native elemental type but often have a weakness to another elemental type.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 278 | Elementals are immune to paralysis, poison and sleep | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 279 | An elemental has no Death State and is destroyed when it reaches 0 HP. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 280 | ELEMENTAL CLASS  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 281 | A standard Elemental will gain the following class features: | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 282 | PROFICIENCIES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 283 | An Elemental is proficient in all armour and shields. It may use all simple and martial weapons. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 284 | CLASS SKILLS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 285 | Acrobatics, Athletics, Climbing, Crafting, Nature, Planes, Perception, Stealth, Survival | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 286 | SKILL POINTS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 287 | 4 + Int per level | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 288 | HIT POINTS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 289 | 10 + Con per level  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 290 | BASE ATTACK/DEFENCE BONUS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 291 | Base Attack Bonus Primary  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 292 | SAVING THROW MODIFIERS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 293 | Fortitude Primary | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 294 | Reflex Primary | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 295 | Will Secondary | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 296 | MAGIC | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 297 | Elementals will sometimes employ magic and prefer the use of the Primal Tradition. An Elemental that employs magic will have the following magical attributes:BSB Tertiary; Caster Level Tertiary; PP 1 per level. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 304 | ETERNAL | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 305 | An Eternal is a creature which is native to any plane of existence found beyond the Inner Planes. Some creatures start out as some other type and become outsiders when they attain a higher (or lower) state of spiritual existence. These creatures are often the servant of various deities and extraplanar entities. They vary in appearance and although many can have an almost humanoid appearance, some others bare no similarities with the humanoid physiology. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 306 | TRAITS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 307 | Eternals have the Darkvision and Nightvision racial traits. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 308 | Eternals gain the Eternal Essence racial trait. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 309 | Eternals do not need to eat or sleep (although they can if they choose to). | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 310 | Eternals have Critical Resistance 2. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 311 | When an Eternal is slain, its native essence returns to its home plane. This prevents such a creature from being restored to life in any way. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 312 | An Eternal gains a +2 racial bonus to all Saving Throws. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 313 | ETERNAL CLASS  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 314 | A standard Eternal will gain the following class features: | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 315 | PROFICIENCIES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 316 | An Eternal is proficient in all armour and shields. It may use all simple and martial weapons. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 317 | CLASS SKILLS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 318 | Acrobatics, Athletics, Climbing, Crafting, Deception, Diplomacy, Intimidation, Meditation, Mental Focus, Perception, Planes, Power Manipulation, Religion, Sense Motive | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 319 | SKILL POINTS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 320 | 6 + Int per level | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 321 | HIT POINTS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 322 | 10 + Con per level  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 323 | BASE ATTACK/DEFENCE BONUS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 324 | Base Attack Bonus Primary  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 325 | SAVING THROW MODIFIERS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 326 | Fortitude Primary | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 327 | Reflex Secondary | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 328 | Will Primary | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 329 | MAGIC | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 330 | Most Eternals will possess some kind of magic. Eternals usually develop magic from the Arcane or Divinity traditions. An Elemental that employs magic will have the following magical attributes:BSB Primary; Caster Level Primary; PP 4 per level. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 336 | FEY | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 337 | A Fey creature has links with the natural world, often some terrain feature or place. Fey have strong links with the First World, a chaotic plane said to have spawned life on the Prime Plane.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 338 | Some fey have an almost humanoid appearance whereas other can appear more like beasts. Both elves and gnomes, although not fey themselves, are deemed to have descended from Fey races. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 339 | TRAITS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 340 | Fey have the Nightvision racial trait. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 341 | Fey have a weakness to Cold Iron. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 342 | A Fey gains a +1 racial bonus to all Saving Throws. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 343 | Fey creatures have a Death State of 2. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 344 | FEY CLASS  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 345 | A standard Fey will gain the following class features: | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 347 | PROFICIENCIES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 348 | A Fey creature is proficient with all simple weapons and any non-metal armour. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 349 | CLASS SKILLS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 350 | Acrobatics, Athletics, Climbing, Culture, Deception, Diplomacy, Meditation, Nature, Perception, Performance, Sense Motive, Stealth, Survival | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 351 | SKILL POINTS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 352 | 8 + Int per level | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 353 | HIT POINTS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 354 | 6 + Con per level  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 355 | BASE ATTACK/DEFENCE BONUS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 356 | Base Attack Bonus Tertiary  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 357 | SAVING THROW MODIFIERS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 358 | Fortitude Tertiary | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 359 | Reflex Primary | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 360 | Will Primary | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 361 | MAGIC | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 362 | Most Fey will possess some kind of magic. Fey usually develop magic from the Ethereal or Verdant traditions. A Fey that employs magic will have the following magical attributes:BSB Primary; Caster Level Primary; PP 4 per level. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 373 | HUMANOID | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 374 | A Humanoid usually has two arms, two legs, and one head, or a humanlike torso, arms, and a head. Humanoids have few or no supernatural or extraordinary abilities, but most can speak and usually have well-developed societies. They usually are small or medium although some are much larger. Every humanoid creature also has a subtype. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 375 | TRAITS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 376 | Humanoids breathe, eat, and sleep. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 377 | Humanoid creatures will usually have a Death State of 5. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 378 | HUMANOID CLASS  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 379 | A standard Humanoid will gain the following class features: | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 380 | PROFICIENCIES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 381 | A Humanoid creature is proficient with all light armour and simple weapons. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 382 | CLASS SKILLS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 383 | Athletics, Climbing, Culture, Handle Animal, Perception, Sense Motive, Survival | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 384 | SKILL POINTS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 385 | 4 + Int per level | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 386 | HIT POINTS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 387 | 8 + Con per level  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 388 | ABILITY SCORES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 389 | The Humanoid creature type does not modify any of the creature’s ability scores.   | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 390 | BASE ATTACK/DEFENCE BONUS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 391 | Base Attack Bonus Secondary  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 392 | SAVING THROW MODIFIERS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 393 | Fortitude Secondary | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 394 | Reflex Secondary | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 395 | Will Secondary | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 396 | MAGIC | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 397 | A Humanoid that has casting ability will select a PC class or the Adept NPC class (see below). | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 398 | Be aware that most creatures of the humanoid type will have either a PC or NPC character class. NPC character classes are detailed later in this supplement. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 410 | OOZE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 411 | An Ooze creature is an amorphous creature which is either mindless or possesses very low mental ability scores. It is sometimes hard to realise that these creatures are even lifeforms at all, so alien that they are. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 412 | ABILITY SCORES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 413 | All creatures of the Ooze Type have Intelligence, Charisma, Dexterity -2 and Constitution +2.   | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 414 | TRAITS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 415 | An Ooze is immune to disease, mental effects, poison, sleep effects, paralysis, polymorph, precision damage, stunning and criticals. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 416 | An Ooze cannot be Flanked or Flat-Footed. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 417 | An Ooze does not need to breathe or sleep. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 418 | An Ooze is blind but gains the Blindsight ability. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 419 | Ooze creatures have a Death State of 8. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 420 | OOZE CLASS  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 421 | A standard Ooze will gain the following class features: | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 423 | PROFICIENCIES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 424 | An Ooze creature is proficient with natural weapons only. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 425 | CLASS SKILLS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 426 | Survival | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 427 | SKILL POINTS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 428 | 2 + Int per level | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 429 | HIT POINTS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 430 | 10 + Con per level  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 431 | BASE ATTACK/DEFENCE BONUS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 432 | Base Attack Bonus Secondary  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 433 | SAVING THROW MODIFIERS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 434 | Fortitude Tertiary | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 435 | Reflex Tertiary | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 436 | Will Tertiary | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 437 | MAGIC | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 438 | Oozes do not possess spellcasting abilities and will never have this variant. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 454 | PLANT | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 455 | A Plant creature is generally made up of vegetable matter or is some kind of fungi. These creatures differ from normal plants in that they have sentience and often mobility. Plant creatures occupy areas containing normal plants of their type as a general rule. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 456 | TRAITS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 457 | Plants have the Nightvision racial trait. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 458 | Due to its physiology, a plant is immune to all mental effects and spells. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 459 | Plants only take damage and bleed from critical injuries unless the critical description would directly affect their anatomy. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 460 | Plants eat and breath in a different way to other creatures but still need to breath and are thus affected by gas-like effects normally. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 461 | Plant creatures have a Death State of 5. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 462 | PLANT CLASS  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 463 | A standard Plant will gain the following class features: | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 464 | PROFICIENCIES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 465 | A Plant creature is proficient with natural weapons only. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 466 | CLASS SKILLS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 467 | Athletics, Climbing, Meditation, Mental Focus, Nature, Perception Stealth, Survival | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 468 | SKILL POINTS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 469 | 4 + Int per level | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 470 | HIT POINTS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 471 | 8 + Con per level  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 472 | BASE ATTACK/DEFENCE BONUS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 473 | Base Attack Bonus Secondary  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 474 | SAVING THROW MODIFIERS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 475 | Fortitude Primary | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 476 | Reflex Tertiary | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 477 | Will Secondary | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 478 | MAGIC | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 479 | Some Plants will possess magic. Plants rarely develop magic outside of the Verdant tradition.  A Plant that employs magic will have the following magical attributes:BSB Tertiary; Caster Level Tertiary; PP 1 per level. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 492 | UNDEAD | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 493 | An Undead creature was once a living creature with a different race trait. Whatever it was before, it has now been animated or recreated using foul necromantic magic and walks the land once again. Undead are naturally foul and twisted by the rituals that made them and are usually very evil as a result. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 494 | ABILITY SCORES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 495 | All creatures of the Undead gain a +1 racial bonus to Constitution.   | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 496 | TRAITS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 497 | Undead have the Darkvision racial trait. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 498 | Undead are immune to bleed, poison, sleep, disease, paralysis, soul drain, subdual damage and stunning. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 499 | Undead do not need to eat breathe or sleep. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 500 | Undead have no Death State and are destroyed when they reach 0 HP (some undead may behave in different ways at 0 HP). | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 501 | UNDEAD CLASS  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 502 | A standard Undead will gain the following class features: | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 503 | PROFICIENCIES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 504 | An undead gains proficiencies with natural weapons and all simple weapons. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 505 | CLASS SKILLS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 506 | Arcana, Athletics, Climbing, Handle Animal, Perception, Religion, Sense Motive, Stealth, Survival | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 507 | SKILL POINTS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 508 | 6 + Int per level | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 509 | HIT POINTS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 510 | 8 + Con per level  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 511 | BASE ATTACK/DEFENCE BONUS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 512 | Base Attack Bonus Secondary  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 513 | SAVING THROW MODIFIERS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 514 | Fortitude Primary | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 515 | Reflex Secondary | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 516 | Will Primary | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 517 | MAGIC | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 518 | Some Undead will possess magic. Undead can develop any tradition of magic. An Undead that employs magic will have the following magical attributes:BSB Secondary; Caster Level Secondary; PP 2 per level. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 527 | WYRM | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 528 | Wyrms are the stuff of legends. There are very few creatures that inspire the same level of awe and sometimes terror. Creatures with the wyrm type are reptilian in appearance but that is often where the similarity with an animal ends. They are intelligent and have walked the world (and often those beyond) for far longer than humanoid races. It is even believed by some scholars that some of the True Wyrm races even predate the Gods. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 529 | All Wyrms are vastly different but share the reptilian appearance and an enchanted nature. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 530 | TRAITS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 531 | Wyrms have the Darkvision and Nightvision racial traits. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 532 | Wyrms breathe, eat, and sleep. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 533 | Wyrms are immune to sleep and paralysis. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 534 | Wyrm creatures have a Death State of 6. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 535 | WYRM CLASS  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 536 | A standard Wyrm will gain the following class features: | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 537 | PROFICIENCIES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 538 | Proficient with all weapons and armour. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 539 | CLASS SKILLS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 540 | Acrobatics, Arcana, Athletics, Climbing, Culture, Deception, Diplomacy, Intimidate, Meditation, Mental Focus, Nature, Perception, Power Manipulation, Sense Motive, Survival | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 541 | SKILL POINTS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 542 | 8 + Int per level | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 543 | HIT POINTS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 544 | 12 + Con per level  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 545 | BASE ATTACK/DEFENCE BONUS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 546 | Base Attack Bonus Primary  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 547 | SAVING THROW MODIFIERS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 548 | Fortitude Primary | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 549 | Reflex Primary | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 550 | Will Primary | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 551 | MAGIC | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 552 | Most Wyrms will possess some kind of magic. Wyrms favour the Arcane and Verdant traditions but may develop others. A Wyrm that employs magic will have the following magical attributes:BSB Primary; Caster Level Secondary; PP 4 per level. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 553 | The nature of creatures of the Wyrm type can often be determined by their colouration. The more metallic the hue of the creatures’ scales, the more pleasant and amicable its nature. Whereas such creatures with more chromatic scales are likely to have a more sinister nature.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 556 | Some creatures (especially humanoids) will replace their Race Type Class with one of the below NPC classes.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 558 | CASTER CLASS  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 559 | CLASS TYPE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 560 | Adept | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 561 | A caster will gain the following class features: | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 562 | PROFICIENCIES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 563 | A caster is proficient with simple weapons and no armour. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 564 | CLASS SKILLS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 565 | Artistry, Crafting, Culture, Linguistics, Meditation, Mental Focus, Planes, Power Manipulation and their Tradition skill (Arcana, Nature, Occultism or Religion) | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 566 | SKILL POINTS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 567 | 4 + Int per level   | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 568 | HIT POINTS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 569 | 6 + Con per level  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 570 | MAGIC | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 571 | A caster must select one tradition of magic and may cast spells from that tradition as an instinctive caster.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 572 | Caster Level Primary | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 573 | Spellcraft Primary | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 574 | Power Points 4/level | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 575 | BASE ATTACK BONUS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 576 | Base Attack Bonus Tertiary  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 577 | BASE DEFENCE BONUS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 578 | Base Attack Bonus Tertiary  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 579 | SAVING THROW MODIFIERS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 580 | Fortitude Tertiary | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 581 | Reflex Tertiary | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 582 | Will Primary | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 583 | MAGIC | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 584 | A caster may select spells from their chosen tradition. A caster will have the following magical attributes:BSB Primary; Caster Level Primary; PP 4 per level. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 598 | SNEAK CLASS  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 599 | CLASS TYPE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 600 | Expert | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 601 | A sneak will gain the following class features: | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 602 | PROFICIENCIES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 603 | A sneak is proficient in the use of light armour and bucklers. They may use all simple weapons, all small weapons and shortbows. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 604 | CLASS SKILLS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 605 | Acrobatics, Artistry, Athletics, Climbing, Culture, Deception, Diplomacy, Intimidate, Linguistics, Perception, Sense Motive, Stealth, Thievery | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 606 | SKILL POINTS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 607 | 8 + Int per level   | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 608 | HIT POINTS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 609 | 8 + Con per level  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 610 | BASE ATTACK BONUS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 611 | Base Attack Bonus Secondary  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 612 | BASE DEFENCE BONUS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 613 | Base Attack Bonus Primary  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 614 | SAVING THROW MODIFIERS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 615 | Fortitude Secondary | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 616 | Reflex Primary | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 617 | Will Tertiary | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 618 | MAGIC | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 619 | They have no spell casting abilities but must select a magical tradition at 1st level.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 635 | HYBRID CLASS  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 636 | CLASS TYPE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 637 | Adept/Martial | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 638 | A hybrid will gain the following class features: | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 639 | PROFICIENCIES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 640 | A hybrid is proficient in the use of all light and medium armour and shields. They may use all simple and martial weapons. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 641 | CLASS SKILLS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 642 | Acrobatics, Athletics, Climbing, Culture, Mental Focus, Meditation, Planes and their Tradition skill (Arcana, Nature, Occultism or Religion) | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 643 | SKILL POINTS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 644 | 4 + Int per level   | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 645 | HIT POINTS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 646 | 8 + Con per level  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 647 | BASE ATTACK BONUS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 648 | Base Attack Bonus Primary  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 649 | BASE DEFENCE BONUS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 650 | Base Attack Bonus Primary  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 651 | SAVING THROW MODIFIERS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 652 | Fortitude Primary | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 653 | Reflex Secondary | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 654 | Will Tertiary | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 655 | MAGIC | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 656 | A hybrid is an instinctive caster and may select spells from their chosen tradition. A Hybrid will have the following magical attributes:BSB Secondary; Caster Level Secondary; PP 2 per level. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 680 | TOUGH CLASS  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 681 | CLASS TYPE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 682 | Martial | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 683 | A tough will gain the following class features: | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 684 | PROFICIENCIES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 685 | A tough is proficient in the use of all armour and shields (including tower shields). They may use all simple and martial weapons. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 686 | CLASS SKILLS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 687 | Athletics, Climbing, Culture, Diplomacy, Handle Animal, Intimidate, Survival | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 688 | SKILL POINTS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 689 | 4 + Int per level   | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 690 | HIT POINTS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 691 | 10 + Con per level  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 692 | BASE ATTACK BONUS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 693 | Base Attack Bonus Primary  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 694 | BASE DEFENCE BONUS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 695 | Base Attack Bonus Primary  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 696 | SAVING THROW MODIFIERS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 697 | Fortitude Primary | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 698 | Reflex Secondary | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 699 | Will Tertiary | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 700 | MAGIC | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 701 | They have no spell casting abilities but must select a magical tradition at 1st level.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 712 | HIT POINTS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 713 | Each creature has an amount of base hit points based upon its size. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 724 | CREATURE ATTACKS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 724 | Name / Price / Level / Damage / Size / FDC / Weight / Group / Traits | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 724 | Bite / - / - / 1d8 P / M / 5 / - / Brawling / Finesse | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 724 | Claw / - / - / 1d6 S / S / 5 / - / Brawling / Agile, Finesse, Versatile (P) | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 724 | Gore / - / - / 1d8 P / M / 5 / - / Brawling / Finesse | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 724 | Hoof / - / - / 1d6 B / S / 5 / - / Brawling / Finesse | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 724 | Slam / - / - / 1d8 B / M / 5 / - / Brawling / Agile, Finesse | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 724 | Sting / - / - / 1d6 P / M / 5 / - / Brawling / Agile, Finesse | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 724 | Tail Slap / - / - / 1d8 B / M / 5 / - / Brawling / Agile, Finesse | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 724 | Tentacle / - / - / 1d6 B / S / 5 / - / Brawling / Finesse | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 724 | Unarmed Strike / - / - / 1d4 N / S / 5 / - / Brawling / Agile, Finesse | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 724 | Wings / - / - / 1d6 B / S / 5 / - / Brawling / Finesse | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 728 | Note for creature damageAs for weapons the above damage values represent creatures of a medium size. The below table shows how attack damage increases  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 729 | or decreases based upon the creature’s size: | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 737 | Medium Damage Die / -3 Size / -2 Size / -1 Size / +1 Size / +2 Size / +3 Size / +4 Size | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 737 | 1d4 / 1 / 1d2 / 1d3 / 1d5 / 1d6 / 1d8 / 1d10 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 737 | 1d5 / 1d2 / 1d3 / 1d4 / 1d6 / 1d8 / 1d10 / 1d12 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 737 | 1d6 / 1d3 / 1d4 / 1d5 / 1d8 / 1d10 / 1d12 / 1d16 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 737 | 1d8 / 1d4 / 1d5 / 1d6 / 1d10 / 1d12 / 1d16 / 1d20 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 737 | 1d10 / 1d5 / 1d6 / 1d8 / 1d12 / 1d16 / 1d20 / 1d30 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 737 | 1d12 / 1d6 / 1d8 / 1d10 / 1d16 / 1d20 / 1d30 / 1d40 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 744 | Note for creature AB and DBAll creatures (NPC’s) gain another bonus to both AB and DB equal to half their level. DB is further modified with a Status bonus equal to class bonus -2. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 761 | CREATURE STAT BLOCKS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 762 | A creature's statistics, often called its stat block, offer the vital information required to manage and engage with the monster effectively. Each creature stat block is presented with the following information after its name. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 764 | TRAITS  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 765 | If a creature possesses any specific traits (such as aligned traits), they will be listed under the creature’s name.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 766 | Traits and how they are affecting creatures is expanded upon from the Core Rulebook in the Appendix. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 767 | TYPE  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 768 | A creature type is a very wide sweeping generalised category which a creature belongs to. There are twelve different creature types in the TRG game system which are described below along with any traits that a standard member of this creature type gains. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 769 | ABERRATION | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 770 | Aberrations, with abnormal anatomy and potent psionic or magical powers, possess strange and alien appearances. Often instilling fear and madness when encountered, their origins are shrouded in mystery within the deep, dark recesses of the world. Their motivations remain elusive, some serving greater powers while others seek their own dominion or primal instincts, they are identifiable by distinctive traits like numerous eyes, stalks, or tentacles. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 771 | ANIMAL | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 772 | Animals are driven by instinctual urges like hunger and reproduction. They typically avoid conflict with humanoids and other creatures unless threatened. Even predators will only attack when hungry and often avoid groups of humanoids in search of easier prey. These adaptable creatures can be found in various shapes and sizes; many having successfully adapted to urban environments. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 773 | BEAST | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 774 | Beasts are akin to animals but possess higher intelligence. They are powerful predators or formidable foes, exhibiting strength, speed, and agility to thrive in their habitats. Many can speak and wield supernatural abilities, displaying diverse anatomies and appearances, some owing to magical experimentation. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 775 | CONSTRUCT | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 776 | A construct is an artificially crafted creature, typically formed through magic, lacking life and independent thought, usually designed for a specific purpose, but not always, with its appearance determined by its creator. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 777 | ELEMENTAL | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 778 | Elementals are beings directly tied to an Elemental Plane, displaying a preference for a specific element through their appearance, though some may have a more subtle manifestation, concealing their elemental affinity at first glance. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 779 | ETERNAL | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 780 | Eternals are creature’s native to planes of existence beyond the Inner Planes, some transitioning from other types to become outsiders upon achieving a higher (or lower) state of spiritual existence, often serving deities and extraplanar entities, exhibiting a diverse range of appearances, with some appearing almost humanoid while others bearing no resemblance to humanoid physiology. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 781 | FEY | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 782 | Fey creatures are intricately tied to the natural world, often associated with specific terrains or places, and possess strong connections to the Primordial, a chaotic plane believed to be the origin of life on the Prime Plane. While some fey bear an almost humanoid appearance, others take on more beast-like forms. Additionally, although not fey themselves, elves and gnomes are considered to have descended from Fey races. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 783 | HUMANOID | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 784 | Humanoids typically possess two arms, two legs, and one head, or a humanlike torso, arms, and a head, with few or no supernatural or extraordinary abilities, but most can speak and have well-developed societies. Their size usually falls into the small or medium range, though some may be much larger. Additionally, every humanoid creature has a distinctive subtype. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 785 | OOZE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 786 | An Ooze creature is an amorphous being, often mindless or possessing extremely low mental ability scores. They are so profoundly alien that it may be difficult to recognize them as lifeforms at all. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 787 | PLANT | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 788 | A Plant creature is primarily composed of vegetable matter or fungi, standing apart from regular plants due to their sentience and occasional mobility. These beings typically dwell in areas where their corresponding normal plants thrive. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 789 | UNDEAD | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 790 | An Undead creature was once a living being with a different race trait, but it has now been revived or reconstructed through dark necromantic magic, walking the land once more. These creatures are inherently foul and twisted by the rituals that brought them back, often harbouring strong malevolence. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 791 | WYRM | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 792 | Wyrms, the stuff of legends, evoke awe and even terror, as few creatures can match their majesty. With reptilian appearances, they transcend mere animals, possessing intelligence and longevity surpassing humanoid races. Some scholars believe certain True Wyrm races even predate the Gods. While each Wyrm is distinct, they all bear reptilian features and an enchanting essence. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 793 | SUB-TYPES & HERITAGES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 794 | Some creatures may have a sub-type and heritage. These work in a similar way to that of a PC race and heritage.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 795 | A Cold Dragon has a type of Wyrm but has a sub-type of Dragon. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 798 | SIZE  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 799 | Monsters come in various sizes, ranging from Diminutive to Colossal. The Creature Size table indicates the amount of space each size occupies during combat encounters and the standard reach of each creature of that size.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 800 | CREATURE SIZE TABLE | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 800 | Size / Space / Reach | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 800 | Diminutive / 1 by 1 ft. / 5' | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 800 | Tiny / 2½ by 2½ ft.   / 5' | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 800 | Small / 5 by 5 ft. / 5' | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 800 | Medium / 5 by 5 ft. / 5' | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 800 | Large / 10 by 10 ft. / 10' | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 800 | Huge / 15 by 15 ft. / 15' | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 800 | Gargantuan / 20 by 20 ft. / 20' | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 800 | Colossal / 25 by 25 ft. / 25' | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 802 | Be aware that some creatures may occupy a different amount of space or have a different reach to the statistics presented above. If this is the case, it will be stated in the creature’s stat block. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 803 | ETHICS  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 804 | A creature's ethics provide valuable insights into its disposition and behaviour during roleplaying or combat situations. Detailed descriptions of various ethics can be found in the TRG Core Rulebook. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 805 | However, the ethics specified in a creature's stat block serve as a default, but as the Game Master, you have the flexibility to deviate from them to suit the needs of your campaign. Whether you envision a creature with virtuous ethics or malevolent ethics, you possess the creative liberty to shape their moral compass. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 806 | Some creatures may exhibit any ethics, leaving the decision entirely in your hands.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 807 | Mindless creatures or those of low intelligence lack comprehension of complex ethical choices, and their actions are governed solely by instinct. These creatures possess either the animal or mindless ethics which are described below. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 808 | Animal: Creatures with this ethic exhibit instincts and behaviours akin to those found in the animal kingdom. They are driven by primal needs, instincts, and natural inclinations. These beings lack the capacity for complex moral reasoning, and their actions are primarily governed by survival, territoriality, and the pursuit of food and safety. Such creatures may be aggressive if threatened, protective of their young, or may engage in social hierarchies common to their species. While not inherently malicious, they can pose a threat to those who encroach upon their territory or provoke them. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 809 | Mindless: Creatures with this ethic lack any discernible consciousness or self-awareness. They do not possess thoughts, emotions, or moral reasoning, rendering them devoid of intentions or motivations. Instead, they rely solely on instinctive reactions to stimuli in their environment.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 810 | DESCRIPTION & DETAILS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 811 | Here you will find a physical description of the creature and any additional information and nuances about the creature beyond its statistics and abilities. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 813 | MECHANICS  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 814 | A creature's mechanics encompass its numerical statistics, abilities, attacks, defences, and special traits that govern its interactions and actions during gameplay.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 815 | Be aware that if a creature's statistics lack a specific mechanic, it means the creature does not possess that particular ability or trait. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 816 | LEVEL | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 817 | A creature's level signifies its overall power, expertise, and proficiency, serving as a crucial factor in determining its effectiveness and challenge to the PCs. The creature's effective level (EL) is a dynamic measure that considers the interaction of its abilities and attributes, providing a more accurate assessment of its true threat. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 818 | INITIATIVE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 819 | A creature's initiative represents its alertness and readiness to act in combat. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 821 | SPEED | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 822 | A creature's speed refers to its movement capabilities, encompassing various modes of travel it can utilize during an encounter. These speeds typically include Speed, representing how quickly the creature can move on solid ground; Fly speed, indicating its ability to navigate through the air; Swim speed, denoting its movement in water; and sometimes, a Burrow or Climb speed if the creature possesses those specialized movement abilities.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 823 | SENSES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 824 | A creature's senses refer to its heightened perceptions and ability to perceive the world around it. Each sense is listed along with its range. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 825 | Darkvision 120 ft. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 826 | LANGUAGES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 827 | The languages that the creature can speak are listed in this section, and in certain cases, it may possess an understanding of a language without the ability to communicate in it. Such instances will be noted next to the respective language. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 828 | ABILITY SCORES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 829 | Just like a PC, a creature possesses the same six ability scores, which are displayed here. These ability scores influence the creature's other attributes, and all relevant adjustments are already considered and included in the stat block. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 830 | SKILLS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 831 | A creature's skills represent its specialized proficiencies and knowledge, influencing its performance and effectiveness in specific tasks or interactions. Each skill will have a bonus and if relevant, its skill ranks (for actions such as ambush).  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 832 | DEFENCE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 833 | A creature's defensive capabilities include its Defensive Bonus (DB), Damage Reduction (DR), Saving Throws, Critical Resistance (CR), Hit Points (HP), Immunity, Resistances and Weaknesses. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 837 | FEATS/SPECIAL | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 838 | A creature's feats and special abilities encompass unique talents, skills, and extraordinary traits that set it apart from others, providing additional advantages, combat manoeuvres, magical powers, or other exceptional attributes that influence its actions and interactions during gameplay.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 839 | The format of this entry lists any feats in normal case text; generic monster abilities are listed in a bold text and then any abilities which are unique to the creature are described in detail below this. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 840 | A full list of specific creature feats and common abilities is given in the appendices.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 841 | ATTACKS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 842 | A creature's attacks encompass its offensive capabilities, including physical strikes, magical spells, breath weapons, or other unique powers that it can use to engage and harm opponents during combat encounters. These attacks are detailed in the creature's stat block, indicating their damage, range, and potential special effects or traits. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 843 | MAGIC | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 844 | If a creature possesses any spells or innate spells, they will be described here along with any other casting details such as Caster Level (CL), Spellcraft bonus and Power Points (PP).   | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 845 | INNATE USAGE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 846 | Each innate spell that a creature can cast will have a value in parentheses that indicates how often it can be used as shown below.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 847 | /day / the innate spell may be used the indicated amount of times per day. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 847 | at will / the innate spell can be used as many times as the creatures’ desires. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 847 | constant / the innate spell is always running | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 847 | focus / the spell has the focus trait | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 847 | # / a numeric value indicates that the spell requires pp usage (but follows all other guidelines from the core rulebook) | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 848 | HIGH MAGICMany of the creatures with casting abilities in this game will use High Magic. High Magic is explored in depth in the upcoming Eldritch Arts sourcebook. If you do not have access to that sourcebook then use the following guidelines to apply High Magic to a creature:Can select spells from any traditionAll casting DCs are increased by 2All spells gain the benefit of the Heighten feat for no extra PP costAll Spell Fumble checks gain a +50 modifierHIGH MAGICMany of the creatures with casting abilities in this game will use High Magic. High Magic is explored in depth in the upcoming Eldritch Arts sourcebook. If you do not have access to that sourcebook then use the following guidelines to apply High Magic to a creature:Can select spells from any traditionAll casting DCs are increased by 2All spells gain the benefit of the Heighten feat for no extra PP costAll Spell Fumble checks gain a +50 modifier | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 858 | GEAR | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 859 | Any equipment carried by standard version of the creature will be listed here.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 860 | OTHER INFORMATION | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 861 | There may be additional details that are useful to run an encounter when using the creature or the creature may have some interesting variants. Such information will be found here. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 862 | CREATURES & DYING | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 863 | Like PCs, each creature will have a Death State value. Unless stated otherwise, each creature of certain type will have a Death State equal to the value shown in the below table. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 864 | CREATURE DEATH STATE TABLE | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 864 | Creature Type / Death State (DS) | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 864 | Aberration / 4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 864 | Animal / 6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 864 | Beast / 4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 864 | Construct / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 864 | Elemental / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 864 | Eternal / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 864 | Fey / 2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 864 | Humanoid / 5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 864 | Ooze / 8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 864 | Plant / 5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 864 | Undead / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 864 | Wyrm / 6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 866 | EXTRAPLANAR CREATURES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 867 | Any creature that is considered to be extraplanar (one that hails from a plane other the material plane), is immediately destroyed when it dies on the material plane and its essence returns to its home plane. What happens beyond this is determined by your campaign (GM discretion).  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 868 | WADE THROUGH THE MOOKS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 869 | If you are using this optional rule from the core rulebook, you may also assume that any creature that falls into this category dies at 0 HP and does not use the death state rules | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 883 | . | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 885 | CREATURE ABILITIES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 886 | Creatures have several special abilities which cannot be learnt by player characters. The abilities outlined below are common among numerous creatures or are notably intricate. While these provide a general guideline, specific creature statistics might modify traits, actions, or other associated rules. If there's a discrepancy between a creature's stat block and these general abilities, the stat block takes precedence. Within these descriptions, the term "creature" denotes the creature possessing the ability, distinguishing it from others it might impact. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 888 | ABSORB MINERALS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 889 | The creature heals itself whenever it inflicts damage to metal objects. Each time the creature inflicts damage to a metal object, it is healed of half the HP that it inflicts.   | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 890 | ABYSSAL HEALING | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 891 | CONCENTRATE DIVINITY FOCUS HEALING SOUL  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 892 | Action 1 AP; PP Cost 1/creature level  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 893 | Drawing upon dark energies from the Abyss, the creature channels regenerative power to heal its wounds.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 894 | Upon activation, the creature may choose one of the following effects: | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 895 | Healing the creature regains up to 1d6 HP/level. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 896 | Bleed Control Remove 1 point of Bleeding per level. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 897 | Injury Recovery Reduce the severity of the Injured condition by -1 point per 2 levels (up to a maximum of -5). | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 898 | Be aware that the creature may only spend up to its level in PP when using this ability. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 899 | ACUTE SENSE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 900 | The creature has superior sense which grants it a +2 racial bonus to any specific action related to that sense.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 901 | ALIEN MIND | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 902 | MENTAL SAVE  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 903 | If the creature is targeted with a mental effect, its mind is so alien that the creator of that effect takes 4d6 mental damage (basic Will).   | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 904 | ALL ROUND VISION | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 905 | The creatures vision allows it to see in 360 degrees. This makes the creature immune to being flanked. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 906 | AMORPHOUS SPLIT | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 907 | Whenever the creature is hit by an attack or effect that inflicts electricity, piercing or slashing damage, it splits into two identical creatures, each having half the amount of current HP. If the creature currently has a HP value of 20 or less, then this ability does not work.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 908 | ARCADIAN CASTER | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 909 | When casting spells, the creature does not provoke reactions and casts all spells as if they were Specialist. Furthermore, the creature can learn both arcane and ethereal spells and cast them as arcane. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 910 | ASHEN AURA | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 911 | AURA DIVINITY FIRE POISON SAVE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 912 | Area 20 feet emanation | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 913 | The creature is surrounded by cloud of toxic mist. All creatures within the mist become concealed, and all creatures outside the mist become concealed to creatures within it. Any creature that either begins its turn, or that moves into the mist during its turn must make a basic Fortitude save to avoid taking 4d6 poison damage. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 914 | AURA OF CONFUSION | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 915 | AURA EMOTION MAGICAL  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 916 | Area 20 feet emanation | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 917 | Any creature that begins its turn or that moves into the aura during its turn must make Will save with the following results: | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 918 | Critical The creature is unaffected and is immune to the aura for 10 minutes. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 919 | Success The targets mind is addled slightly causing them to become stunned 1. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 920 | Failure The target is confused for 1 minute. It can attempt a new save at the end of each of its turns to end the confusion. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 921 | Fumble The target is confused for 1 minute, with no save to end early.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 922 | If a target is confused by the aura, it then becomes immune for 10 minutes.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 923 | AURA OF DEATH | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 924 | AURA DIVINITY ESSENCE SOUL | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 925 | Area 30 feet emanation | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 926 | Any living creature that begins its turn or that moves into the aura during its turn must make a basic Fortitude save or take 4d6 essence damage.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 927 | AURA OF DECAY | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 928 | AURA ETHEREAL POISON SOUL | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 929 | Area 30 feet emanation | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 930 | Any creature that begins its turn or that moves into the aura during its turn must make a basic Fortitude save or take 4d8 poison damage.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 931 | AURA OF DESPAIR | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 932 | AURA DIVINITY FEAR | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 933 | Area 30 feet emanation | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 934 | Any living creature that begins its turn or that moves into the aura during its turn must make Will save with the following results: | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 935 | Heroic The creature is unaffected. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 936 | Critical The creature is frightened 1. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 937 | Success The creature is frightened 2. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 938 | Partial The creature is frightened 3. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 939 | Failure The creature is frightened 3 and paralysed for 1 round.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 940 | Fumble The creature is frightened 4 and paralysed for 1 round.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 941 | Blunder The creature collapses from fear and is reduced to 0 hit points, gaining the unconscious condition.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 942 | The creature is immune to the paralysis for 24 hours after making a save but not the fear.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 947 | AURA OF FIRE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 948 | AURA FIRE INVOCATION VERDANT | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 949 | Area 20 feet emanation | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 950 | Any creature that begins its turn or that moves into the aura during its turn must make a basic Reflex save or take 4d6 fire damage.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 951 | AURA OF HEAT | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 952 | AURA FIRE INVOCATION VERDANT | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 953 | Area 20 feet emanation | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 954 | Any creature that begins its turn or that moves into the aura during its turn must make a basic Reflex save or take 2d6 fire damage.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 955 | AURA OF RUIN | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 956 | AURA DIVINITY SAVE SOUL | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 957 | Area 30 feet emanation | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 958 | A creature that is either good or ordered aligned that begins its turn in this aura's emanation must attempt an Opposed Level based Will save or become sickened 1 or sickened 2 on a fumble.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 959 | AURA OF TRANQUILITY | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 960 | AURA DIVINITY SOUL | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 961 | Area 30 feet emanation | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 962 | Allies within the aura gain advantage to saves against fear and charm effects.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 963 | BLIGHT SENSE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 964 | The creature can sense the presence of any cursed, diseased or poisoned creature. This is classed as a tertiary sense.   | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 965 | BLOOD SCENT | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 966 | The creature can smell blood up to a mile away.   | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 967 | CLINGING BREATH | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 968 | ACID ARCANE SAVE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 969 | Action Free; Trigger a target took damage from the creature’s breath weapon on its last turn. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 970 | At the beginning of the creatures turn, it must make a basic fortitude save to avoid taking half the breath weapons dice again (round up) as acid damage. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 971 | CONSTRICT | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 972 | SAVE  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 973 | Action 1 AP  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 974 | The creature deals the listed amount of damage to any number of creatures grabbed or restrained by it. Each of those creatures can attempt a basic Fortitude save to resist. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 975 | CORRODE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 976 | Any secondary damage inflicted by the creature is also inflicted upon any metal armour that the target has. If the target uses a metal shield as part of their DB, the damage is split between armour and shield 50%. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 979 | CRUSH | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 980 | MOVEMENT SAVE  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 981 | Action 1 AP  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 982 | The creature is so big that it may land upon creatures that are at least two sizes smaller. Any creature that begins its turn in the creatures’ space must make a Reflex save with the following results. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 983 | Critical the target takes 1d10 bludgeoning damage | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 984 | Success the target takes 2d10 bludgeoning damage | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 985 | Partial the target takes 4d10 bludgeoning damage and a Minor critical | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 986 | Failure the target takes 6d10 bludgeoning damage and a Serious critical | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 987 | Fumble the target takes 8d10 bludgeoning damage and a Deadly critical | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 988 | The damage inflicted by a crush bypass all DR (but not physical resistance). | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 989 | Any target that gets a minimum partial result on the saving throw is moved to an adjacent square to the creature after taking damage. The target is immobilised and prone with any other result. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 990 | DETECT MAGIC | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 991 | The creature has an innate ability to detect the presence of active magic and gain a +2 racial bonus to all Sense Magic (Power Manipulation) checks. Additionally, they may develop the Power Manipulation skill without meeting its normal requirements and may make Sense Power (Power Manipulation) checks untrained.   | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 992 | DISPELLING STRIKE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 993 | DIVINITY FOCUS WARDING  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 994 | Action Free; Trigger The creature hits a target with a melee strike. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 995 | The creature attempts a dispel attempt using 0 PP. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 996 | DIVING STRIKE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 997 | ATTACK MOVEMENT | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 998 | Action 2 AP  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 999 | The creature moves up to twice its fly speed and must descend at least 10 feet. The movement must be in a straight line and is followed by a claw strike. The attack gains a +2-circumstance bonus. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1000 | DOUBLE STRIKE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1001 | ATTACK  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1002 | Action 1 AP  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1003 | The creature makes two separate strikes against two separate targets using different limbs or appendages. Double Strike counts towards multiple attack penalty but not until after the attacks have been resolved. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1004 | DRACONIC ASSAULT | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1005 | ATTACK  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1006 | Action 2 AP  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1007 | The dragon makes two claw attacks followed by another non-claw, natural attack. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1009 | DRACONIC ROAR | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1010 | ARCANE ELEMENTAL INVOCATION SAVE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1011 | Action 2 AP  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1012 | The dragon lets out a powerful roar. All creatures within the range of its Frightful Aura must make a basic Fort save or take breath weapon damage. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1013 | Be aware that once used, this ability cannot be used again for 1 hour. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1014 | DRACONIC SHIFTING | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1015 | ALTERATION ARCANE CONCENTRATE POLYMORPH | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1016 | Action 1 AP  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1017 | The dragon assumes the form of a Small or Medium humanoid, without altering its Speed or the modifiers for its Strikes. However, this transformation may modify the damage type delivered by its Strikes, as they would now be classed as unarmed subdual attacks.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1018 | DRINK BLOOD | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1019 | SOUL  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1020 | Action 1 AP; Requirement A target who has the grabbed, immobilised, paralyzed or unconscious condition or who is willing, is within reach. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1021 | The creature bites the target and feeds upon its blood. This is automatic for all conditions except Grabbed, which requires an Athletics check with a DC equal to the targets Fortitude DC. The target takes Soul Drain 10, and the creature is healed of an equal amount of HP.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1022 | EARTH PASS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1023 | The creature can move through dirt and stone at its full burrow Speed, leaving no tunnels or signs of its passing.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1024 | ECHOLOCATION | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1025 | AUDITORY  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1026 | Echolocation is a biological sonar used by certain creatures to locate objects, navigate, and hunt by emitting sound waves and listening to the echoes that return after these waves bounce off objects. This ability allows the creature to ‘see’ using its hearing with a range equal to half the normal for a primary sense.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1027 | ELEMENTAL AURA | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1028 | ARCANE AURA ELEMENTAL SAVE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1029 | The creature constantly emanates a 10-foot radius aura of a specific elemental energy which inflicts 2d6 damage with a basic Reflex save. The creature may as a Free Action turn the aura on or off.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1030 | Based upon the elemental type, this ability is called either Caustic (Acid), Fiery (Fire), Freezing (Cold), Shocking (Electricity) or Toxic (Poison) Aura.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1031 | ELEMENTAL BLOOD | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1032 | ELEMENTAL | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1033 | If the creature takes any recurring bleed damage, all targets take an equal amount of elemental splash damage each turn.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1034 | Based upon the elemental type, this ability is called either Caustic (Acid), Fiery (Fire), Freezing (Cold), Shocking (Electricity) or Toxic (Poison) Blood.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1035 | ELEMENTAL GRASP | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1036 | ARCANE ELEMENTAL SAVE  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1037 | Any grabbed target takes 3d6 elemental damage at the beginning of their turns. With a basic Reflex save to avoid. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1038 | Based upon the elemental type, this feat is called either Caustic (Acid), Fiery (Fire), Freezing (Cold), Shocking (Electricity) or Toxic (Poison) Aura.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1039 | ELEMENTAL STRIKES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1040 | ELEMENTAL | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1041 | The creature releases a powerful elemental infusion which causes all its physical attacks to inflict 1d6 secondary elemental damage. Any attacks that the creature already possesses which inflict secondary elemental damage, have that damage doubled.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1042 | Based upon the elemental type, this feat is called either Caustic (Acid), Fiery (Fire), Freezing (Cold), Shocking (Electricity) or Toxic (Poison) Strikes.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1043 | ELUSIVE MOVEMENT | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1044 | The creature does not provoke reactions caused by movement. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1045 | ENDLESS HUNGER | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1046 | EVIL SOUL  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1047 | The creature must eat constantly. In most cases, the creature that has this trait is mindless or undead and seeks to eat living flesh using a sense such as Life Sense. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1048 | ENTANGLING VINES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1049 | SAVE VERDANT  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1050 | Action 1 AP  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1052 | The creature creates thick thorny vines to erupt from the earth around it in a 20 ft. radius. All targets take 4d6 piercing damage with a basic Reflex save to avoid. A failed save also results in a target gaining the grabbed condition. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1053 | ETERNAL ESSENCE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1054 | ALIGNED DIVINITY WARDING  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1055 | An eternal is imbued with a powerful divine energy that enhances its combat prowess.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1056 | The eternal lowers all FDC by 1. Furthermore, any armour or shield wielded by the eternal is an extension of its will and the creature suffers no adverse effects from armour or shields such as ACP, Max Dex or Speed Penalty. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1067 | ETERNAL SUMMONS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1068 | ALIGNED CONJURED DIVINITY FOCUS TRANSLOCATION  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1069 | Action 2 AP  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1070 | The eternal channels the boundless essence of its kind, invoking a ripple across the planar veil to draw forth a lesser kindred spirit. This act of summoning is not performed lightly; it reflects the eternal's authority, purpose, or desperation while far from their celestial, infernal, or elemental origin. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1071 | Upon using this ability, the eternal may summon allies of a similar eternal subtype (e.g., agothian, angel, demon) that are at least 4 levels lower than itself. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1072 | Choose one of the following configurations: | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1073 | 1 creature exactly 4 levels lower | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1074 | 2 creatures exactly 6 levels lower | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1075 | 4 creatures exactly 8 levels lower | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1076 | The summoned creatures: | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1077 | Manifest adjacent to the summoner within 20 ft. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1078 | Act immediately after the summoner’s turn on the same initiative count. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1079 | Remain for 1 minute per 5 levels of the summoner or until dismissed (1 AP) or slain. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1080 | Cannot use their own Eternal Summons or similar planar-calling powers. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1081 | FAULTLESS CASTING | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1082 | All spells that you cast are considered as Defensive Casting. Furthermore, such checks are treated as Medium (+0) checks rather than Very Hard (DC +5).   | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1083 | FEAR OF WATER | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1084 | This creature is unable to cross running water of its own free will. Another creature may carry it across water, and it may cross using a vessel made of wood (such as a boat).  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1085 | FEARFUL STRENGTH | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1086 | The force of the creature’s physical presence and threat of violence often says more than words ever could. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1087 | When making an Intimidate skill check, the creature can choose to use their Strength modifier instead of their Charisma modifier.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1088 | FIRE HEALING | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1089 | FIRE HEALING VERDANT | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1090 | The creature is healed when exposed to fire and heat. Whilst standing within a fire (which must be at least the size of the creature), the creatures natural recovery rate is doubled. Furthermore, fire damage heals the creature of an amount of HP damage equal to half that taken. Finally, if the creature is at full HP when it takes fire damage, it may instead choose to reduce its bleeding condition by 2 or any other condition by 1. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1091 | Be aware that this ability is based upon the fire damage a creature would have taken before immunity and resistance but not DR.   | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1092 | FLYBY ATTACK | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1093 | ATTACK MOVEMENT | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1094 | Action 2 AP  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1095 | The creature Strides up to its fly speed and makes two claw attacks at any point during the move. The attacks must be made against separate targets. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1097 | FRIGHTFUL AURA | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1098 | AURA FEAR SAVE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1099 | Action Free  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1100 | Some types of unnatural creature emanate an aura of fear which has a radius equal to 5 feet x the creature’s level. A being that first enters the area must attempt a level based Will save. Regardless of the result of the saving throw, the being is temporarily immune to Frightful Aura for 1 minute. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1101 | Critical The creature is unaffected. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1102 | Success The creature is frightened 1. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1103 | Partial The creature is frightened 2. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1104 | Failure The creature is frightened 3 and fleeing for 1 round. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1105 | Fumble The creature is frightened 4 and fleeing until the frightened condition is removed.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1106 | Blunder The creature collapses from fear and is reduced to 0 hit points, gaining the unconscious condition.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1108 | GALLOP | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1109 | If the creature takes two consecutive stride actions in the same turn, it increases its speed by 10 feet for each action.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1110 | GARLIC REPULSION | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1111 | This creature dislike the smell of garlic and gains the sickened 1 condition whilst within range of such an odour. If the creature comes within 5 feet of this odour, the Sickened condition increases to 2. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1112 | Be aware that this ability overrides any immunity or resistance the creature would normally have for the Sickened condition.   | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1113 | GRAVE-TOUCHED PRESENCE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1114 | Living humanoids and intelligent undead instinctively recoil from the creature. Unless the creature conceals its nature, humanoids and intelligent undead begin one attitude step worse toward it. This penalty does not apply to creatures already familiar with the creature or to those with strong necromantic, occult, or funerary traditions. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1115 | The creature gains a +2 racial bonus to Intimidate and Sense Motive checks against undead.     | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1116 | HOLD BREATH | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1117 | The creature can hold its breath for 10 x the normal amount. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1118 | HOVER | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1119 | The creature does not have to expend an AP to remain in the air when flying. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1120 | HOWL | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1121 | AUDITORY FEAR SAVE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1122 | Action 1 AP  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1123 | The creature can emit a terrifying howl. All creatures within 30 feet must make a Will saving throw: | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1124 | Success The creature is unaffected. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1125 | Partial The creature is frightened 1. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1126 | Failure The creature is frightened 2. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1127 | Fumble The creature is frightened 3 and fleeing for 1 round.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1128 | A creature is immune to the effects of the howl for 10 minutes after making a saving throw (regardless of the result). | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1131 | ICE CLIMB | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1132 | The creature can utilize its standard land speed as a climb speed when moving across icy terrain. Furthermore, the creature may ignore both difficult and formidable terrain from snow and ice. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1133 | ICE STRIDE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1134 | The creature isn't impeded by difficult terrain caused by snow or ice, nor do they need to attempt Acrobatics checks to keep from falling on slippery ice. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1135 | INFESTATION | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1136 | AURA POISON SAVE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1137 | The creature is surrounded by a host of poisonous spiders which nest in its exoskeleton. Anything within 5 feet of the creature at the beginning of its turn must make basic Fortitude save to avoid 1d6 poison damage.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1138 | KEEN SENSE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1139 | The creature has superior senses that grant it a special +2 racial bonus to Perception skill checks. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1140 | LIFE DRAIN | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1141 | DIVINE SAVE SOUL | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1142 | Action 0 AP  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1143 | When the creature damages a living target with its unarmed attacks, the creature is healed of 3 HP, and the target must succeed at a Level Based Fortitude save or gain 5 Soul Drain. Further damage dealt by the creature increases the amount of Soul Drain by 5. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1144 | LIFE SENSE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1145 | Lifesense allows a creature to sense the vital essence of living and undead creatures as a tertiary sense. The sense can distinguish between the positive energy animating living creatures and the negative energy animating undead creatures, much as sight distinguishes colours. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1146 | MAGIC DISPELLING  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1147 | DIVINITY WARDING  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1148 | The creature can use the Dispel (Power Manipulation) action 3 times per day without using any PP. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1149 | MONSTROUS GRAB | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1150 | When making a Grapple Action, the creature gains a +4 racial bonus to the check. Additionally, the creature doesn’t suffer multiple attack penalties when making Grapple attempts. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1151 | MONSTROUS KNOCKDOWN | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1152 | When making a Trip Action, the creature gains a +4 racial bonus to the check. Additionally, the creature doesn’t suffer multiple attack penalties when making Trip attempts. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1153 | NATURAL CAMOUFLAGE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1154 | The creature is very hard to spot in areas of natural terrain and gains advantage on all Hide (Stealth) checks when in such environments.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1159 | NATURAL LEAPER | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1160 | The creature has immense leaping ability. When taking the High Jump (Athletics) check it may jump distances up to half its land Speed without making a check. When taking the Long Jump (Athletics) action it may leap up to its land Speed without taking an action. Furthermore, the creature ignores the penalty for having a running start when making such checks. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1161 | PACK ATTACK | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1162 | The creature’s attacks inflict an additional 1d6 precision damage when attacking any creature within reach of at least two of its allies. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1164 | PARALYSING GAZE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1165 | ALTERATION DIVINITY  SAVE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1166 | Action 1 AP  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1167 | Any creature within 30 feet of the creature that can see it must make a fortitude save with the following results: | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1168 | Critical the target is unaffected | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1169 | Success the target is stunned 1. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1170 | Partial the target become paralysed for 1 round.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1171 | Failure the target becomes paralysed for 1 minute. It can attempt a new save at the end of each of its turns, applying the new results immediately (even if they are worse). | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1172 | Fumble the target becomes paralysed for 1 minute.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1173 | PENETRATING BREATH | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1174 | ARCANE DRAGON | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1175 | The creature’s breath weapon completely bypasses DR (if it didn’t already) and also ignores Energy Resistance. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1176 | PENETRATING STRIKES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1177 | The creatures indicated physical attacks treat all DR as half. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1178 | PERSISTENT | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1179 | Any attack or ability with this trait enhances the recurring damage caused by the primary attack through any resulting critical injury. If the attack deals physical damage, it causes additional bleeding. For other types of attacks, they inflict their primary damage type as recurring damage.   | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1180 | PLANT RESISTANCE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1181 | Due to their unique physical nature, plants are affected by critical injuries in a slightly different way to other creatures. Creatures of the plant type always suffer additional HP damage, bleed and recurring damage results. Other critical results only affect them if the result is appropriate to their anatomy.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1182 | POUNCING ASSAULT | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1183 | ATTACK MOVEMENT | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1184 | Action 2 AP  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1185 | The creature makes a Jump (Athletics) check and them may make two claw strikes as part of the action (at any point during its movement). Any attacks made against the creature when it takes this action suffer a -4-circumstance penalty. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1189 | POWERFUL CHARGE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1190 | ATTACK MOVEMENT | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1191 | Action 2 AP  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1192 | The creature Strides twice and then makes a gore attack. The attack gains a +2 circumstance bonus and adds an additional die of base damage. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1193 | REACTIVE DISARM | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1194 | Action Reaction; Frequency 1/rnd; Trigger A target fumbles a weapon Strike against the creature. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1195 | The creature attempts a disarm attempt against the triggering attack. This action is not subject to multiple attack penalty. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1196 | REFLECTIVE SCALES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1197 | ARCANE WARDING | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1198 | Action Reaction: Trigger The creature is targeted with a spell.   | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1199 | The creature make a Dispel (Power Manipulation) check against the incoming spell. If the result of the check is a critical, then the spell is reflected upon its caster as if using the Spell Turning spell.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1200 | REGENERATION | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1201 | HEALING | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1202 | A creature with regeneration regains an amount of HP equal to its level at the beginning of its turn. A creature with active regeneration cannot die unless its Regeneration is sometimes bypassed (usually by a specific damage type) or its physical from is utterly destroyed. Regeneration also affects the creature’s ability to heal injuries. Regeneration reduces the Injured condition by its value every 10 minutes.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1203 | Be aware that regeneration is negated by a certain damage type. If a creature takes damage of an amount equal to or greater than its regeneration in a given round, its regeneration is disabled for 1 turn.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1204 | REND | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1205 | Action 0 AP; Trigger The creature strikes a target twice with the listed attack type. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1206 | The creature inflicts an additional amount of damage to their target equal to the attacks damage. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1207 | SECONDARY CRITICAL | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1208 | SAVE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1209 | On a critical hit, the indicated attack inflicts an additional critical injury of 1 degree less severity of the secondary damage type. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1210 | SHADOW BREATH | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1211 | ARCANE SAVE SOUL | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1212 | Action Free; Trigger a target takes damage from the creatures’ breath weapon. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1213 | Targets are affected by a Blindness spell using the same saving throw as their initial one against the breath weapon to determine the outcome. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1214 | Critical The target is unaffected. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1215 | Success The target is blinded until its next turn begins. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1216 | Failure The target is blinded for 1 minute. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1217 | Fumble The target is blinded permanently. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1219 | SHADOW HAND | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1220 | DIVINITY SAVE SOUL | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1221 | Action Free; Trigger The target of the creature’s soul touch strike takes a critical hit.   | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1222 | The target must make a minimum of a success on a fortitude saving throw to avoid taking 1d6 soul drain. The soul drain increases to 2d6 if the critical was serious or deadly in severity. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1223 | SHADOWY | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1224 | VISUAL | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1225 | The creature is always concealed if the light level is 6 (Twilight) or lower. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1226 | SKEWERING STRIKES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1227 | Requirement The creature makes a strike action with a weapon from the spear group. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1228 | If the attack inflicts recurring bleed damage, the amount of bleed is increased by one per severity level of the critical.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1229 | SLOW | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1230 | The creature has a less actions (AP) per turn. Slow (I) reduces the creatures AP by 1 and Slow (II) reduces the AP by 2. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1231 | SLOWING BREATH | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1232 | ALTERATION ARCANE SAVE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1233 | Action Free; Trigger a target takes damage from the creatures’ breath weapon. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1234 | Affected targets must make a fortitude saving throw with the following results: | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1235 | Partial slowed 1 for 1 round. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1236 | Failure slowed 1 for 1 minute. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1237 | Fumble slowed 2 for 1 minute. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1238 | SMOKE FORM | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1239 | The creature is insubstantial and can occupy the same space as another creature. Furthermore, the creature does not trigger reactions for movement if it moves is full speed in one action. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1240 | SMOKEVISION | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1241 | The creature’s vision is not impaired by smoke or fog, and it ignores concealment from such effects. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1242 | SNOWVISION | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1243 | The creature can see perfectly well when it is snowing, and creatures do not gain concealment or any other visual bonus during snowfall. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1244 | SONAR SENSE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1245 | AUDITORY | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1246 | Action 1 AP  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1247 | The creature can emit high-frequency sound waves, often inaudible to most beings, which then bounce off objects and return to them, providing a detailed picture of their surroundings. This ability allows them to navigate, detect prey, and avoid obstacles in the darkest depths of the ocean.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1248 | This is a primary sense and has the same range as vision. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1251 | SONIC MOAN | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1252 | AUDITORY EMOTION FOCUS SAVE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1253 | Action 2 AP  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1254 | The creature lets out a powerful moan that inflicts sonic damage. All creatures in a 30-foot radius must make a basic Will save to avoid 3d6 sonic damage. Because the moan is infrasonic, most humanoids don’t detect the source of their plight if they aren’t already aware of the creature.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1255 | SOULDRINKER | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1256 | DIVINITY HEALING SOUL | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1257 | Action Free; Trigger The creature kills a living creature which cannot be more than 4 levels lower than it.   | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1258 | The creature immediately gains healing equivalent to that of a cure or restoration spell warped to a caster level equal to the creature’s level.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1259 | SOULLESS AURA | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1260 | AURA NEGATIVE SAVE SOUL | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1261 | Action Free; Area 10 feet emanation   | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1262 | The creature emanates an aura of soulless energy. Any creature entering the aura must make a level-based Fort save to avoid taking 5 Soul Drain. A creature that makes the saving throw is immune to the effects of this specific aura for 24 hours.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1264 | SPELL RESILIENCE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1265 | The creature has an innate resistance to magic and gains a racial bonus equal to its class bonus to all saving throws and DB against magical attacks. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1266 | STENCH | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1267 | AURA OLFACTORY SAVE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1268 | Area 10 feet emanation | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1269 | Living creatures beginning their turn or entering the aura must make a fortitude saving throw. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1270 | Failure sickened 1 | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1271 | Fumble as failure but also slowed 1 for the length of the sickened. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1272 | A creature is immune for one minute after making a save.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1273 | SUNLIGHT VULNERABILITY | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1274 | If this creature begins its turn in sunlight, it takes 2 Essence damage per level and loses any ability to heal its wounds. Furthermore, it is also treated as having Sunlight Weakness (see below). | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1275 | SUNLIGHT WEAKNESS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1276 | If this creature begins its turn in sunlight, it is injured 2 and slowed 2 for as long as it remains in the sunlight. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1277 | SURGE OF SPEED | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1278 | MOVEMENT | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1279 | Action 1 AP  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1280 | The creature Strides twice. It can do this once every 10 minutes. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1281 | SURVIVAL INSTINCT | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1282 | The creature is hard to kill and gains a bonus to its Natural DR equal to its level. This ability may not work under certain circumstances (such as an eternal on its native plane). | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1283 | SWALLOW | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1284 | ATTACK  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1285 | Action 1 AP  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1286 | The creature attempts to a swallow a target who must be at least one size category lower than the creatures attack size. The target must already be grabbed by the creature who then attempts an Athletics check opposed by the targets Reflex DC. If it succeeds, the target is swallowed and takes damage. When the target is first swallowed and then at the beginning of each of their turns, they must make an Opposed Level based, basic Fortitude (Very Hard +5 DC) save to avoid Acid damage (which is equal to the creatures’ bite attack damage x2).  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1287 | A swallowed target has the Grabbed and Slowed 1 conditions and must hold their breath to avoid suffocation. The target may use the escape action to get out through the creatures’ mouth or cut their way out using an unarmed attack or small weapon (piercing/slashing). Such an attack treats the target as flat-footed, but it gains resistance to all such attacks. An amount of damage exceeding 10% of the creatures total HP must be inflicted for a target to tear free. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1288 | SWIMBY ATTACK | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1289 | ATTACK MOVEMENT | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1290 | Action 2 AP  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1291 | The creature Strides up to its swim speed and makes two bite attacks at any point during the move. The attacks must be made against separate targets. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1292 | TEAR FLESH | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1293 | Action 1 AP  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1294 | Requirement The creature inflicted damage with its bite attack on its previous action. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1295 | The creature automatically hits again, using the result of its previous attack to determine damage and criticals, which are then rolled again. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1296 | TELEPATHY | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1297 | AURA INSIGHT | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1298 | The creature can mentally communicate with sentient creatures that it can sense and that are within 100 feet. Each target must share a language with the creature to understand it.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1299 | TORRENT OF STRIKES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1300 | ATTACK  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1301 | Action 3 AP  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1302 | Harnessing its supernatural agility and coordination, the creature lashes out with all six of its arms in a whirlwind of strikes. The attacks can target one creature or be divided among multiple adjacent targets. Each attack is resolved separately, using the creatures current multiple attack penalty at -2. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1309 | TRAMPLE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1310 | MOVEMENT SAVE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1311 | Action 3 AP  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1312 | The creature moves up to twice its speed (minimum of 20 feet), moving through the spaces of targets which are at least one size smaller. Each target whose space it passes through with this action takes damage from the creatures’ slam attack (or other appropriate attack) with +1 base die. Targets can attempt a basic Reflex save to avoid damage. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1313 | Be aware that trample does not provoke reactions. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1314 | TRUE CASTER | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1315 | The creature can select its spells from any of the four traditions of magic. Its spells are cast as if they belonged to the creature’s primary tradition. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1316 | UNDEAD FORTITUDE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1317 | DIVINITY EVIL SOUL | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1318 | If damage reduces the creature to 0 hit points, it must make an opposed, level-based Fortitude saving throw, on a success, the creature drops to 1 hit point instead.   | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1319 | Be aware that this ability has no effect if the damage type is essence or one that the creature has a weakness to. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1320 | UNDEAD SPAWN | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1321 | DIVINITY EVIL SOUL | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1322 | A target slain by one of the creatures’ natural attacks that inflicts soul drain rises as an undead the following day at dusk. The exact type of undead that the target becomes is left to the GM but it usually the same as the type that killed them. A newly created undead has the Spawn trait (see traits in chapter 3).   | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1323 | VIBRATION SENSE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1324 | The creature can sense nearby motion through vibration and air current. This is a form of Blindsight. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1325 | VORPAL WEAPONS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1326 | Any of the creature’s melee weapons have the Vorpal trait. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1327 | WATER GLIDE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1328 | The creature can move across the surface of water at a speed equal to half its swim speed. It may also use the High Jump and Long Jump (Athletics) actions, using the surface of the water as if it were a solid surface. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1329 | WHIRLPOOL | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1330 | AURA INVOCATION VERDANT WATER | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1331 | Area 5 feet emanation per level | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1332 | The creature is surrounded by a swirling whirlpool of water. The aura’s radius is considered difficult terrain for any creature that does not have the Water trait.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1333 | WHIRLWIND | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1334 | AIR AURA INVOCATION VERDANT | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1335 | Area 20 feet emanation | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1336 | The creature is surrounded by a swirling torrent of wind. The aura’s radius is considered difficult terrain for any creature that does not have the Air trait.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1337 | WHISPERS OF THE GRAVE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1338 | CONCENTRATE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1339 | The creature can attempt to talk to a spirit or undead directly without the use for words. They do not to share a language with the target although this may help with certain spirits.     | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1340 | Action 1 minute | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1341 | The creature makes a Level based Meditation (opposed) check with the following results.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1342 | Critical The creature can communicate with the target spirit or sentient undead (although this does not compel the target to answer or become any friendlier). | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1343 | Success The creature can communicate with the target spirit or sentient undead (as critical) but its answers will be cryptic and possibly whimsical.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1344 | Partial The creature gains a general empathic sense of the target but nothing further. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1345 | Failure No effect. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1346 | Blunder The target spirit or sentient undead dominates the creature for 1 minute (GM discretion).  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1347 | After using this ability, the creature must make a hard (DC +2) exhaustion check. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1348 | Be aware that once a creature has been targeted by this ability, they are immune for 24 hours. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1349 | WING BUFFET | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1350 | AIR MOVEMENT SAVE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1351 | Action 2 AP; Area 30-foot cone | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1352 | The dragon beats its wings with tremendous force, creating a violent cone of buffeting air, dust, debris, and pressure. All creatures in the area must make a level-based Reflex save. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1353 | Critical The target is unaffected. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1354 | Success The target is pushed 5 feet directly away from the dragon. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1355 | Partial The target takes bludgeoning damage equal to the dragon’s wing attack damage and is pushed 5 feet directly away from the dragon. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1356 | Failure The target takes bludgeoning damage equal to the dragon’s wing attack damage, is pushed 10 feet directly away from the dragon, and falls prone. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1357 | Fumble The target takes bludgeoning damage equal to twice the dragon’s wing attack damage, is pushed 20 feet directly away from the dragon, and falls prone. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1358 | Blunder As fumble, but the target is also stunned 1. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1359 | This movement does not provoke reactions. A creature that is at least two sizes larger than the dragon treats its save result as one degree better. A flying creature that fails its save loses 10 feet of altitude; on a fumble or blunder, it loses 20 feet of altitude instead. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1360 | WINGLESS FLIGHT | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1361 | The creature flies by instinctive magic rather than wings. It has the Hover ability and does not need visible space to beat wings or make wing movements. If its magic is suppressed, it loses its Fly speed until the suppression ends. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1364 | CHAPTER 3 – FEATS & TRAITS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1365 | This chapter provides a selection of tools to enhance encounters and introduce more nuanced and challenging adversaries. It includes a handful of new creature traits to expand the abilities and behaviours of fiends, monsters, and magical beings, adding a touch of unpredictability to your encounters. Game masters will also find a small but potent collection of weapon and armour runes and some specialized feats.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1367 | FEATS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1368 | Below are several feats which are available for selection by PCs if they meet any prerequisites and trait requirements. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1369 | ABYSSAL FAMILIAR | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1370 | CLASS EVIL | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1371 | You commune with your deity or patron and draw forth a quasit which becomes your familiar. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1372 | Prerequisites Familiar, BSB +6 | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1373 | Your familiar becomes a quasit. You replace its base statistics with those of a quasit. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1374 | CRIMSON COVENANT | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1375 | CLASS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1376 | Your bond with forbidden powers deepens when you bleed. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1377 | Prerequisites Must have sworn an oath to a demon or sacrificed your own blood for power. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1378 | When you suffer a bleed result of 5 or greater, your next attack gains +4 luck bonus. If you deal a critical injury because of this attack, your bleeding stops. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1379 | EBON BIND | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1380 | ADEPT CLASS FOCUS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1381 | Your soul-tight grasp over dark entities grants you eerie control. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1382 | Prerequisites You have summoned or struck a deal with a creature from the shadescape. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1383 | You may use the Aligned Control action to bind the creature to you.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1384 | ENHANCED HEARING | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1385 | GENERAL | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1386 | Your special auditory senses are superior to those of others. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1387 | Prerequisites Any special auditory sense (Echolocation etc) | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1388 | Any special auditory senses that you possess have their range doubled. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1389 | ENHANCED SMELL | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1390 | GENERAL | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1391 | Your special olfactory senses are superior to those of others. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1392 | Prerequisites Any special auditory sense (Scent etc) | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1393 | Any special olfactory senses that you possess have their range doubled. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1394 | ENHANCED VISION | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1395 | GENERAL | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1396 | Your special visual senses are superior to those of others. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1397 | Prerequisites Any special visual sense (Darkvision, Nightvision etc) | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1398 | Any special visual senses that you possess have their range doubled. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1400 | GRAVE AUTHORITY | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1401 | RACIAL  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1402 | You impose your will upon an undead creature. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1403 | Prerequisites Undead or Mournkin | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1404 | The creature may attempt to control an undead creature as if using the Aligned Control rules (with no alignment restrictions). | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1405 | HOWLING KINSHIP | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1406 | CLASS  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1407 | You’ve bonded with the raw instincts of beasts. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1408 | Prerequisites Animal Companion, BAB +4 | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1409 | When fighting alongside an animal companion, both you and the creature gain +1 circumstance bonus to all attack rolls while within 10 feet of each other. Additionally, you gain a +1-class bonus to all Handle Animal skill checks. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1410 | NIRVANIC FAMILIAR | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1411 | CLASS GOOD | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1412 | You commune with your deity and draw forth a cherubim which becomes your familiar. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1413 | Prerequisites Familiar, Divinity Caster, BSB +6 | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1414 | Your familiar becomes a cherubim. You replace its base statistics with those of a cherubim. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1415 | SCALY RESILIENCE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1416 | CAMPAIGN CLASS FOCUS  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1417 | Draconic energy has infused your skin. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1418 | Prerequisites Toughness, Must have gained the dying condition from a dragons’ breath weapon. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1419 | Action Reaction; Trigger You take damage from a dragon breath weapon.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1420 | You secrete an oily substance that grants you Resistance against the breath weapon. Additionally, you gain a +1-circumstance bonus to either your DB or saving throw against the attack. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1433 | TRAITS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1434 | Traits are used to add additional information and detail to a specific rules’ element such as a creature, item spell or just about anything else. Some traits provide information whereas others have game mechanics which link them into specific rules and situations. These traits expand upon those found in the core rulebook. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1435 | AQUATIC  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1436 | Creatures with this trait are naturally adapted to underwater environments. Their Strikes with bludgeoning and slashing attacks do not incur the usual –2 penalty for being submerged. They can breathe water but are unable to breathe air. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1437 | AURA  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1438 | An effect that has this trait emanated from the target (usually) its creator in a predefined radius. The radius moves with the target and any creature that either begins its turn or moves into the radius is subjected to its effects.   | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1439 | Traits are used to add additional information and detail to a specific rules’ element such as a creature, item spell or just about anything else. Some traits provide information whereas others have game mechanics which link them into specific rules and situations. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1440 | ELEMENTAL  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1441 | Creatures with this trait are affiliated to one or more elemental planes of existence. The creature will be able to move around that plane without adverse effects. Creatures with this trait will often possess immunity or resistance to their elemental type. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1442 | INCORPOREAL  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1443 | The incorporeal trait represents a supernatural essence that exists beyond the physical realm, allowing a creature to pass through solid objects, resist physical harm, and interact with the material world in unique ways. An incorporeal creature possesses the following attributes: | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1444 | Insubstantial Form: Incorporeal creatures lack a solid physical body and exist as ethereal entities. They can pass through solid objects without hindrance and can move through walls, doors, and other obstacles as if they were not there. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1445 | Resistance to Physical Harm: Due to their ethereal nature, incorporeal creatures are immune to non-magical attack forms and have resistance to all damage types except force. Incorporeal creatures are also immune to precision damage. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1446 | Incorporeal creatures are often associated with ghosts, spirits, and undead and they possess a mysterious and otherworldly nature. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1447 | MINDLESS  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1448 | Mindless creatures lack independent thought and emotional responses, functioning on simple instincts or programmed commands. They take a -5 penalty to both Intelligence and Charisma and are immune to any effect with the Mental trait, including abilities or spells that rely on cognition, such as charm, fear, or mind control. Mindless creatures do not possess willpower in the traditional sense and cannot perform skills requiring complex reasoning, such as Diplomacy or Crafting.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1449 | Be aware that this trait has been revised slightly from the Core Rulebook.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1452 | SPAWN  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1453 | A creature with the Spawn trait has been forcibly reborn through dark rites or cursed transformations performed by a more powerful being (e.g., a vampire, wight, or other sinister master). This new existence leaves the Spawn weakened and bound to its creator’s influence.   | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1454 | Weakened: Upon first becoming a Spawn, the creature gains the Injured 2 condition. The Spawn can remove the Injured condition by feeding upon (or otherwise siphoning the essence of) a living creature with an Effective Level (EL) at least half that of the Spawn. This typically requires defeating and draining the target in a manner appropriate to the Spawn’s nature (e.g., a vampire Spawn drains blood, a wight Spawn inflicts soul drain). If the Spawn does not do so within 72 hours, it remains Injured 2 for another 72 hours. This cycle continues until the Spawn feeds successfully (GM discretion). | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1455 | Control Vulnerability: If the Spawn is subjected to an effect that grants direct control (such as aligned control, dominate, command, or similar abilities) originating from its creator, it treats its saving throw as one degree worse than it would normally be (a success becomes a partial, a failure becomes a fumble, etc.). This vulnerability highlights the lingering bond and subservience the Spawn has to the being that created it. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1456 | A creature can only lose this trait if their creator releases them or is destroyed. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1457 | Be aware that certain beings will prevent their progeny from feeding to force them to keep this trait. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1458 | SWARM  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1459 | A creature with the Swarm trait is not a single body, but a mass of smaller creatures acting as one creature for the purposes of combat. A swarm may represent insects, vermin, small undead, crawling horrors, animated fragments, or any similar collection of creatures too numerous to fight as individuals. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1460 | A swarm is immune to critical hits, precision damage, mental effects, and any reaction provoked by movement.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1461 | A swarm has Resistance to targeted attacks. A targeted attack is any damaging attack that requires an attack roll against the swarm’s Defensive Bonus, including weapon attacks, spell attacks, natural attacks, and similar effects. This Resistance does not apply against effects that require the swarm to make a saving throw to avoid or reduce damage. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1462 | A swarm has Weakness to area effects. Area effects include cones, lines, bursts, emanations, explosions, clouds, zones, and similar effects that damage all creatures within an area rather than targeting a single creature with an attack roll. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1463 | Swarms do not make attacks in the same manner as most creatures. Instead, a swarm harms creatures by engulfing, surrounding, biting, clawing, stinging, crawling over, or otherwise overwhelming them. When a swarm moves into or occupies an area occupied by another creature, that creature must attempt the saving throw listed in the swarm’s attack entry. On a failed save, the creature takes the swarm’s listed damage and any additional effects described by the swarm. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1464 | Damage dealt by a swarm attack treats the target’s DR as half its normal value. Apply this reduction before determining how much damage is absorbed by armour, natural armour, or similar protection.   | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1466 | ARMOUR & SHIELD RUNES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1467 | Armour runes are used to add additional information and detail to a suit of magical armour. These enchantments become symbols of power and provide essential support to adventurers as they embark on daring quests, face mighty foes, and uncover the secrets of fantastical realms. The runes detailed here expand upon those introduced in the core rulebook. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1468 | DREADCARVE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1469 | AURA ENCHANTMENT FEAR INVESTED SAVE VISUAL  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1470 | Usage inscribed into armour or a shield;  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1471 | Activate Command (1 AP); Frequency at will | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1472 | The Dreadcarve rune channels an aura of menace into the armour or shield it is etched upon, striking fear into the hearts of those who can see it.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1473 | When inscribed, this rune emanates an aura of fear which behaves as the Frightful Aura creature ability. The size of the aura and the Will Save DC are determined by the power level of the rune. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1474 | DREADCARVE I | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1475 | Level 10 Price 8,000 gp | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1476 | The aura has a 50’ radius and the save DC is 24. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1477 | DREADCARVE II | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1478 | Level 15; Price 55,000 gp | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1479 | The aura has a 75’ radius and the save DC is 29.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1480 | DREADCARVE   III | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1481 | Level 20; Price 500,000 gp | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1482 | The aura has a 100’ radius and the save DC is 34.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1484 | FLEETGUARD | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1485 | INVESTED TRANSLOCATION | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1486 | Usage varies | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1487 | Whether for battle readiness or a swift retreat, this rune is a favourite among warriors and adventurers who value efficiency and preparedness.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1488 | When inscribed upon armour, this rune empowers it with magical precision, allowing it to be donned or removed in moments. The exact specifics are determined by the power level of the rune. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1489 | FLEETGUARD I | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1490 | Level 4 Price 750 gp | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1491 | Usage light or medium armour | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1492 | The rune allows light armour to be donned in 1 round (3 AP) and medium armour to be donned in 1 minute.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1493 | FLEETGUARD II | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1494 | Level 9; Price 6,000 gp | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1495 | Usage any armour | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1496 | The rune allows light armour to be donned in for 1 AP, medium armour in 1 round (3 AP) and heavy armour in 1 minute.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1497 | FLEETGUARD III | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1498 | Level 14; Price 36,000 gp | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1499 | The rune allows light armour to be donned as a free action (0 AP), medium armour for 1 AP and heavy armour in 1 round (3 AP).  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1502 | SAVAGE JAW | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1503 | ATTACK INVESTED INVOCATION | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1504 | Level 5; Price 1,250 gp | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1505 | Usage inscribed onto a shield; | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1506 | Activate Reaction; Trigger an enemy fumbles against you whilst your shield is equipped. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1507 | Etched with the likeness of a draconic maw, the Savage Jaw Rune imbues your shield with predatory might.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1508 | When a foe fumbles a melee attack against you, you can use your Reaction to unleash a vicious bite-like counterattack. Make an Attack Check against the triggering foe (using your usual melee attack bonus). On a hit, you deal 2d6 piercing damage (plus any relevant ability modifiers). | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1509 | SHELLBACK | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1510 | INVESTED WARDING | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1511 | Level 6; Price 2,000 gp | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1512 | Usage inscribed onto a shield with a CR value. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1513 | The Shellback Rune channels the enduring power of thick-shelled creatures, causing intricate, spiralling shell motifs to spread across your shield.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1514 | A rune with this shield halves any HP damage it takes in conjunction with using the Shield Block feat. Furthermore, if you successfully reduce the severity of a critical injury by using Shield Block, you can as a Free Action (0 AP) move 5 feet away (as if using the Step action) from the attacking creature without triggering reactions, representing how the shell-like magic momentarily pushes your foe back. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1515 | SKYFEATHER | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1516 | INVESTED WARDING | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1517 | Level 7; Price 3,000 gp | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1518 | Usage inscribed into armour | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1519 | Activate Free (0 AP); Trigger you are falling. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1520 | Frequency Constant | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1521 | This rune infuses armour with a faint aura of airy magic.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1522 | The moment you begin to fall from a significant height or are forced downward, the rune wraps you in a soft current of air, slowing your descent and protecting you from impact. This acts as a Feather Fall spell. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1536 | THORNBOUND | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1537 | INVESTED INVOCATION SAVE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1538 | Usage inscribed into armour | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1539 | Activate Reaction; Trigger a creature grabs or swallows the wearer. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1540 | The Thornbound rune imbues armour with reactive magic, lashing out at any creature that dares to restrain or swallow the wearer.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1541 | When inscribed upon armour, this rune attacks any creature that attempts to grab you or restrain you in any way. The rune inflicts piercing damage (basic Reflex) based upon its level. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1542 | THORNBOUND I | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1543 | Level 5 Price 1,250 gp | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1544 | The rune activates, dealing 2d6 piercing damage.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1545 | THORNBOUND II | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1546 | Level 10; Price 8,000 gp | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1547 | The rune activates, dealing 4d6 piercing damage. The creature must make a DC 24 Fortitude save or release you immediately. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1548 | THORNBOUND III | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1549 | Level 15; Price 55,000 gp | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1550 | The rune activates, dealing 6d6 piercing damage. The creature must make a DC 29 Fortitude save or release you immediately. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1581 | WILDFORM | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1582 | ALTERATION INVESTED POLYMORPH VERDANT | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1583 | Usage inscribed into non-metal armour | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1584 | Frequency 1/day | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1585 | The rune pulses with primal energy, allowing its wearer to channel the spirit of a chosen animal and embody its strength, speed, and instincts.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1586 | When inscribed upon armour, this rune allows its wearer to change into the form of a studied animal as if using the spell Shape of the Animal. The exact specifics of what you can change into and for how long, is determined by the power level of the rune. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1587 | WILDFORM I | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1588 | Level 6 Price 2,000 gp | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1589 | The rune allows you to shift into an animal form as if using the base casting of a Shape of the Animal Spell.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1590 | WILDFORM II | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1591 | Level 10; Price 8,000 gp | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1592 | As Wildform I and you may use up to 4 PP of wrapping options.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1593 | WILDFORM III | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1594 | Level 14; Price 36,000 gp | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1595 | As Wildform I and you may use up to 8 PP of wrapping options.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1596 | WILDFORM IV | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1597 | Level 18; Price 180,000 gp | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1598 | As Wildform I and you may use up to 12 PP of wrapping options. You may also use the ability three times per day. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1599 |  This rune is especially useful when worn by druids (or any other character that has a Wildshape like ability). Rather than the above effect, a druid gains an additional daily use of Wildshape each day per power level (I-IV) of the rune.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1616 | WEAPON RUNES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1617 | Weapon runes are used to add additional information and detail to a magical weapon. These enchanted armaments become symbols of power and serve as invaluable assets to adventurers as they embark on epic quests, battling formidable foes and unravelling the mysteries of fantastical realms. These weapon runes expand upon those found in the core rulebook. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1618 | ANCIENT ECHOES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1619 | INVESTED INVOCATION WARDING | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1620 | Level 10; Price 6,000 gp | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1621 | Usage inscribed onto a weapon | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1622 | A faint chorus of whispered guidance accompanies each swing of this rune-etched weapon, resonating with the ancestral spirits who once walked the battlefield.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1623 | You need no proficiency to use a weapon inscribed with this rune as ancestral allies impart this knowledge to you. Furthermore, all attacks made with this weapon gain a +1-luck bonus to attack and damage. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1624 | SUBMERSIBLE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1625 | INVESTED WARDING | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1626 | Level 3; Price 350 gp | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1627 | Usage inscribed onto a melee weapon | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1628 | Bubbles of faint, blue-green magic course through your weapon, evoking the stillness of the ocean depths.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1629 | This weapon performs just as effectively below the surface as it does on dry land. You ignore the usual attack penalties and limitations associated with underwater combat when wielding it. If the weapon can deal fire damage, the flames remain active even while submerged. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1630 | SWARMED | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1631 | FOCUS INVESTED TRANSLOCATION | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1632 | Usage inscribed onto a thrown weapon | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1633 | Activate Command (2 AP); Frequency varies | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1634 | A sudden, unsettling buzz or skittering fills the air the moment you hurl this weapon.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1635 | As you hurl your weapon, it replicates in midair, sweeping across a 30-foot cone. Each creature in the area takes damage equal to twice the weapon’s damage dice with a basic Reflex save to avoid. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1636 | SWARMED I | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1637 | Level 9 Price 4,300 gp | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1638 | The save DC is 24. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1639 | SWARMED II | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1640 | Level 13; Price 17,000 gp | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1641 | The save DC is 28.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1642 | SWARMED   III | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1643 | Level 17; Price 90,000 gp | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1644 | The save DC is 32.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1651 | VORPAL | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1652 | INVESTED SOUL | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1653 | Level 16; Price 60,000 gp | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1654 | Usage any slashing weapon | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1655 | A vorpal effect forces attacks to strike the targets head, to decapitate.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1656 | When an attack with this trait inflicts a critical hit, the result of the injury is always increased to the next available head result. Furthermore, the minimum result for a critical injury result inflicted by an attack after modification with this trait is based upon the severity of the critical as shown below: | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1657 | Critical Severity / Minimum Result | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1657 | Minor / 10 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1657 | Serious / 30 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1657 | Deadly / 50 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1659 | A Balor attacks with its vorpal blade and inflicts a Critical Hit with a severity of serious. The Balor rolls a 14 on the d100 injury roll. Because the blade has the vorpal trait, the critical becomes 30.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1660 | The Balor’s second attack inflicts a Minor Critical and this time it rolls an 87 (so 78 after disadvantage) on the injury roll. This is above the vorpal minimum of 10 for a Minor Critical so the result of the critical is modified to the nearest head critical which is 80. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1661 | Be aware that if the result of your initial injury check strikes the head, your result is still increased to the next head critical injury result (effectively +10 to the injury result). | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1676 | APPENDIX – ALIGNED EXPANDED  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1678 | The Aligned Trait in TRG connects creatures, items, or places to a particular alignment, such as Balance, Chaos, Evil, Good, or Order. These alignments tap into outer planar energies and create a unique framework for interacting with the world. The rules around this trait emphasize interaction, resistance, and detection/control mechanics. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1680 | ALIGNED TRAITS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1681 | Each aligned trait (Balance, Chaos, Evil, Good, Order) is connected to a corresponding outer plane and its associated energies. Any creature, item, or place can carry one or more aligned traits, influencing how they interact with magic, weakness, and planar effects. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1682 | Balance: Represents neutrality, maintaining equilibrium between opposing forces. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1683 | Chaos: Represents unpredictability and destruction, fuelled by chaotic energy. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1684 | Evil: Draws from malevolent energies tied to malicious intents and corruption. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1685 | Good: Represents benevolent forces, focused on protection and growth. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1686 | Order: Associated with structure, law, and purpose, coming from planes of order. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1687 | ALIGNED WEAKNESSES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1688 | Creatures, items, or places with aligned traits are particularly vulnerable to attacks or spells from opposing alignments. The damage from an opposing alignment deals significantly more damage and is harder to resist. Many creatures of the Eternal type will have such weakness. Mortal creatures rarely possess such weakness, but this is not always the case. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1689 | ALIGNED DETECTION | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1690 | Aligned traits can be detected by individuals or spells with similar aligned traits. Characters with these traits can sense their aligned counterparts with heightened precision. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1691 | Passive Detection: If you possess an aligned trait, you may make a Perception check (opposed level based) to sense creatures or items sharing your trait within 60 feet. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1692 | Be aware that this enables you to sense that creatures are present, but not their specific location or identity. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1693 | Active Detection: If using a spell or ability like Detect Aura, you can discern creatures or objects with the same trait more precisely. You gain a +1-circumstance bonus to such detection if your trait matches that of the object or creature. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1694 | Aligned Strength: The strength of an aligned trait depends on the level of the creature, item, or spell. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1695 | Level / Aura Strength | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1695 | 0-5 / Faint | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1695 | 6-10 / Moderate | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1695 | 11-15 / Strong | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1695 | 16-20 / Powerful | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1695 | 21+ / Overwhelming | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1696 | The level of a mortal creature is five lower when determining aura strength. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1699 | ALIGNED CONTROL | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1700 | A creature with an aligned trait may exert influence over other creatures, items, or environments with the same aligned trait, provided they meet certain requirements. Controlling another creature with an aligned trait follows specific guidelines based on the controlling creature's level and type, as well as the rules for Control Levels outlined in the core rulebook. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1701 | LEVEL REQUIREMENT | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1702 | To control another creature, the controlling creature must share an aligned trait (e.g., Good, Evil, etc.) and be at least 6 levels higher than the target. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1703 | If both creatures share the same creature type (e.g., both are demons, angels, or undead), the controlling creature needs to be at least 4 levels higher than the target. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1704 | CONTROL LEVEL RESTRICTION | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1705 | These control attempts are also limited by the Control Level rules from the TRG core rulebook. A creature cannot control another if it exceeds their allowed Control Level, regardless of their level advantage. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1706 | ALIGNED CONTROL                                                  CONCENTRATE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1707 | Action 1 AP  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1708 | Requirements The controller satisfies all the above criteria.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1709 | The creature attempts to take control of an appropriate target. The target must be within visual range or be stored and in mental contact (GM discretion). The target must make an opposed level-based (the controllers’ level) Will saving throw with the following results: | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1710 | Critical The target shrugs off the attempt of control and cannot be controlled by this creature again until after their next daily preparation.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1711 | Success The target shrugs off the attempt of control. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1712 | Partial The target gains the Controlled condition for 1 minute. At the end of this time, they may make a new saving throw to resist the effects.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1713 | Failure The target gains the Controlled condition for 1 hour. At the end of this time, they may make a new saving throw to resist the effects.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1714 | Fumble The target gains the Controlled condition with a permanent duration. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1715 | The controlling creature may release a target from control at any time as a 1 AP concentrate action. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1716 | Be aware that the target may make a new saving throw to resist if the controller or any of their allies take any kind of hostile action against them.  | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1722 | PART II | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1723 | DEVELOPMENT POINT RULES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1725 | A comparative construction and balance framework for TRG Prime | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1727 | INTRODUCTION | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1728 | Development Points (DP) provide a common language for comparing mechanical benefits and drawbacks in TRG Prime. They are a design tool rather than a currency spent by players. A designer records every relevant component of a race, heritage, background, class, spell package, or other option, assigns the appropriate DP value, and compares the total with the benchmark for that type of package. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1729 | The system is comparative. It does not attempt to calculate the absolute value of every rule in isolation. Instead, it uses stable baselines, standard category costs, and consistent treatment of scaling, frequency, access, and restrictions. Where a mechanic matches an established anchor, use that anchor. Where no direct anchor exists, compare the feature with the nearest established effects and assess only the mechanical difference. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1730 | SCOPE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1731 | These rules cover race and heritage packages, backgrounds, feats, skill benefits, cantrips, normal and specialist spells, Power Points, class chassis, class spell access, class abilities, creature types, and overall package tolerances. Creature races, creature classes, NPC classes, size packages, and creature abilities use the same component anchors and are added as separate construction layers. Equipment prices, starting wealth, templates, and any rule that has no established DP anchor are assessed separately unless this document states otherwise, XP Multipliers, and Effective Level. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1732 | HOW TO USE THESE RULES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1733 | 1. Identify the package being assessed and its benchmark. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1734 | 2. List every mechanical benefit, drawback, replacement, and restriction supplied by the package. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1735 | 3. Apply the standard DP anchors before making any individual judgement. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1736 | 4. Remove overlap and double counting. A broader feature absorbs narrower benefits already contained within it. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1737 | 5. Add the remaining values and compare the total with the relevant balance band. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1738 | 6. Review practical interactions. A numerically acceptable package can still require adjustment when several benefits reinforce the same tactic or ability score. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1739 | TERMS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1740 | KEY TERMS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1740 | Term / Meaning | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1740 | Baseline / The ordinary 0-DP starting point for a particular comparison. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1740 | Package / A group of rules assessed together, such as Race + Heritage + Background or a complete class. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1740 | Anchor / A fixed DP value used whenever a mechanic matches the stated scope. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1740 | Class Index / A class total expressed as a percentage of the 208-DP class benchmark. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1740 | Stand-alone grant / A feat, spell, or ability granted outside an ordinary progression and costed at its full category value. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1740 | Progression entry / A benefit supplied as part of a complete class progression and costed by the class-specific rules. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1740 | Creature Type DP / The value of the traits granted by a creature type before race, heritage, size, class, and creature abilities are added. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1740 | Creature Class DP / The value of a default creature class or replacement NPC class before race, heritage, size, spells, natural attacks, and creature abilities are added. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1740 | Casting infrastructure / BSB, Caster Level, Power Points, tradition, and magical ability. Individual spells, cantrips, and Specialist Spells are separate unless a class explicitly grants them. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1740 | Size Package DP / The combined net value of a creature size category relative to Medium: base HP above or below the 30-HP baseline, Strength, Dexterity, reach, and the residual space and equipment effects of size. Natural-attack die scaling is costed per attack. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1740 | NPC Combat Package / The universal creature and NPC bonuses applied directly to final Attack Bonus and Defence rather than to BAB or BDB. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1740 | Natural Attack DP / The value of an innate attack profile, including its base damage and listed traits. Proficiency and special attack abilities are separate. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1740 | Complete PC benchmark / The rounded 250-DP standard used for XP Multiplier calculations. It is derived from the calculated 248-DP sum of the 40-DP pre-class package and the 208-DP class benchmark. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1740 | XP Multiplier (XPM) / A positive or negative adjustment derived from a complete DP percentage outside the inclusive 90%–110% tolerance band. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1740 | XP Factor / The full progression factor equal to 1 + XPM. It is applied to the standard 10,000 XP required per level. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1740 | Effective Level (EL) / A creature’s equivalent standard PC level after its nominal level is adjusted by its XP Factor. Effective Level has a minimum of 0. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1742 | CONTENTS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1743 | • Chapter 1 — Core Method | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1744 | • Chapter 2 — Universal Component Costs | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1745 | • Chapter 3 — Race, Heritage, and Background Packages | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1746 | • Chapter 4 — Spells and Power Points | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1747 | • Chapter 5 — Class Chassis | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1748 | • Chapter 6 — Class Spell Access | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1749 | • Chapter 7 — Worked Examples and Worksheets | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1750 | • Chapter 8 — Creature and NPC Construction | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1751 | • Chapter 9 — XP Multipliers and Effective Level | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1753 | CHAPTER 1 — CORE METHOD | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1754 | 1. DEVELOPMENT POINT LEDGERS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1755 | A DP ledger records the mechanical components of a package. Each line should identify the rule, the applicable anchor, the DP value, and any calculation required. The package total is the sum of all positive and negative entries after overlap has been removed. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1756 | DP total = benefits + drawbacks + exceptional adjustments, after removing overlap and replacements. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1757 | 2. BASELINES AND ZERO POINTS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1758 | Every comparison begins from a defined zero point. A missing optional subsystem is normally worth 0 DP rather than a negative value. For example, a non-spellcasting class receives no refund for lacking spells, BSB, Caster Level, or Power Points. A negative value applies only when a rule imposes an actual disadvantage relative to the normal baseline. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1759 | • Use the stated baseline for the package being assessed. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1760 | • Do not invent a refund for an omitted optional benefit. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1761 | • Cost an explicit restriction only when it materially limits play and can be enforced by the rules. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1762 | • Universal features shared by every option in the comparison are 0 DP. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1763 | 3. REPLACEMENTS AND REDISTRIBUTION | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1764 | A replacement is costed by its net change. Replacing one benefit with another benefit of equal value is 0 DP. Removing a drawback adds back the magnitude of that drawback. When a package adds both a bonus and a penalty, cost each line using its own anchor rather than assuming that equal numerical modifiers cancel. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1765 | REPLACEMENT EXAMPLES | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1765 | Change / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1765 | Replace one +1 ability modifier with a different +1 modifier / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1765 | Add one new +1 ability modifier and one new -1 modifier / +1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1765 | Remove an existing -1 ability penalty / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1765 | Remove an existing -2 ability penalty / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1765 | Replace a feature with a 6-DP feature / New feature DP - old feature DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1767 | 4. AVOIDABLE DRAWBACKS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1768 | A drawback normally refunds less DP than an equivalent benefit costs when the player can reduce, avoid, or build around the disadvantage. This asymmetry prevents a package from gaining full-value benefits by accepting penalties that rarely matter to the intended build. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1769 | 5. CHOICES AND MUTUALLY EXCLUSIVE OPTIONS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1770 | • A choice among options of the same category receives no flexibility premium. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1771 | • A choice among mixed feat categories is costed at the highest category available. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1772 | • When only one option can be selected, use the expected or average selected value rather than adding every unavailable option. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1773 | • Round an expected option value to the nearest whole DP. Retain half-point values elsewhere. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1774 | • A one-for-one exchange that does not increase access is normally 0 DP. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1775 | 6. DOUBLE COUNTING | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1776 | Count a mechanical benefit once. A broad proficiency absorbs contained weapons; full-list spell access replaces individual library-entry costs; a standard BAB cost already includes its normal bonus-damage thresholds; and a class spell package must not charge again for BSB, Caster Level, Power Points, or cantrips hidden inside a generic caster value. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1777 | 7. PACKAGE BENCHMARKS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1778 | PRE-CLASS CHARACTER PACKAGE | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1778 | Element / Target | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1778 | Race + Heritage / 29 DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1778 | Standard Background / 11 DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1778 | Complete pre-class package / 40 DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1780 | The 29-DP Race + Heritage target assumes an 11-DP standard background. Always assess the complete package using the background actually selected. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1781 | PRE-CLASS BALANCE BANDS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1781 | Total DP / Treatment | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1781 | Below 34 / Major low outlier; strengthen before ordinary release. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1781 | 34 to below 36 / Low review; normally strengthen. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1781 | 36 to below 38 / Acceptable lower edge. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1781 | 38 to 42 / Preferred design corridor. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1781 | Above 42 to 44 / Acceptable upper edge. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1781 | Above 44 to 46 / High review; normally reduce or apply a deliberate premium. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1781 | Above 46 / Major high outlier. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1783 | A standard Race + Heritage + Background package is normally balanced from 36 through 44 DP. The preferred corridor is 38–42 DP. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1784 | CLASS BENCHMARK | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1784 | Measure / Value | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1784 | Standard class total / 208 DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1784 | Class Index formula / (Class DP ÷ 208) × 100 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1784 | Preferred corridor / 95%–105% | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1784 | Normal tolerance / 90%–110% | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1786 | CHAPTER 2 — UNIVERSAL COMPONENT COSTS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1787 | 1. ABILITY MODIFIERS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1788 | ABILITY MODIFIER COSTS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1788 | Mechanic / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1788 | +1 ability modifier / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1788 | +2 to the same ability / +9 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1788 | -1 ability modifier / -3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1788 | -2 to the same ability / -5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1788 | Remove an existing -1 penalty / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1788 | Remove an existing -2 penalty / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1788 | Equal-value ability replacement / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1790 | A concentrated +2 bonus is worth more than two unrelated +1 bonuses because it advances the same primary statistic. Separate modifiers to separate abilities are added using their individual values. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1791 | 2. HIT POINTS, SPEED, AND SIZE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1792 | HIT POINT COSTS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1792 | Mechanic / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1792 | 5 fixed HP / +1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1792 | 10 fixed HP / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1792 | 15 fixed HP / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1792 | +1 HP per level / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1794 | LAND SPEED | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1794 | Speed / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1794 | 15 feet / -4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1794 | 20 feet / -2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1794 | 25 feet / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1794 | 30 feet / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1794 | 35 feet / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1796 | Use ±2 DP for each 5-foot change from the 25-foot land-speed baseline. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1797 | SIZE | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1797 | Size / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1797 | Small / -2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1797 | Medium / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1797 | Large or larger / Chapter 8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1799 | Small size accounts for reduced equipment access, weapon-damage limits, and hand-use restrictions, offset by lighter equipment and advantages in confined spaces. Large and larger sizes require individual assessment because reach, occupied space, equipment, movement, and manoeuvre interactions vary substantially. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1800 | 3. LANGUAGES AND SPECIALIST SKILLS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1801 | RACIAL BASELINES | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1801 | Component / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1801 | Two starting core languages / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1801 | Each language above or below two / ±0.5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1801 | One racial specialist skill / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1801 | Each specialist skill above or below one / ±1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1803 | Count only languages automatically known at 1st level. A list of languages available through Intelligence does not grant another starting language. Specialist skills are separate from Class Skills. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1804 | 4. SKILL MODIFIERS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1805 | A TRG Prime skill contains several actions. A bonus to one named action is narrower than the same bonus to every action within the skill. The wording of the rule determines the category. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1806 | SKILL BONUS COSTS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1806 | Mechanic / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1806 | +1 to one named skill action / +1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1806 | +2 to one named skill action / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1806 | +1 to an entire skill / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1806 | +2 to an entire skill / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1806 | +1 Perception / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1806 | +2 Perception / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1806 | -4 to one situational action / -2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1806 | Flexible +1 Skill Point per level outside a class chassis / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1808 | ADVANTAGE COSTS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1808 | Scope / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1808 | One narrow or situational action / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1808 | One broadly useful action / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1808 | Every action in one skill / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1808 | Whole skill in a narrow environment or subject / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1808 | Broad contextual group of checks / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1808 | One named action across several skills / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1810 | “+2 Treat Wounds” is an action bonus. “+2 Medicine” is a whole-skill bonus. “Advantage on Sneak” is action advantage. “Advantage on Stealth” applies to the complete skill. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1811 | 5. FEATS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1812 | Feat DP is an average category value. Every complete feat in the same category receives the same cost, regardless of modest differences in power, prerequisites, level, requirements, or synergy. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1813 | FEAT CATEGORY COSTS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1813 | Grant / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1813 | General feat / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1813 | Racial feat / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1813 | Class feat / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1813 | Archetype feat selected with a Class feat pick / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1813 | Archetype feat granted as an additional bonus feat / +8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1815 | • A specific feat and a selectable feat from the same category have the same value. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1816 | • Multiple feats add their category values. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1817 | • Prerequisites and progression requirements do not alter the category value. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1818 | • A temporary imitation, partial effect, or conditional access is assessed as an ordinary ability rather than a complete feat. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1819 | • Normal feat selections granted by universal level progression are 0 DP. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1820 | 6. EQUIPMENT PROFICIENCIES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1821 | Proficiency grants trained access and removes the penalties for using equipment without training. It does not itself add attack, Defence, or DR. No proficiency is the 0-DP baseline. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1822 | WEAPON PROFICIENCIES | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1822 | Package / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1822 | One specific weapon / +1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1822 | One complete weapon group / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1822 | All Simple weapons / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1822 | All Martial weapons / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1822 | All Simple and Martial weapons / +10 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1822 | Exceptional or restricted group / +1 to +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1824 | ARMOUR PROFICIENCIES | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1824 | Tier / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1824 | Light armour / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1824 | Medium armour / +2 additional | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1824 | Heavy armour / +2 additional | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1824 | All armour / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1826 | SHIELD PROFICIENCIES | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1826 | Tier / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1826 | Light shields and bucklers / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1826 | Heavy shields / +2 additional | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1826 | Tower shields / +2 additional | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1826 | Light and Heavy shields / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1826 | All shields including Tower / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1828 | • Do not add a specific weapon or group already contained in a broader proficiency. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1829 | • Use the nearest listed value for a restricted or unusual equipment package. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1830 | • Count the access actually granted by the wording. Do not assume a higher armour tier grants lower tiers unless the rules say so. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1831 | 7. COMMON DEFENSIVE AND MAGICAL ANCHORS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1832 | COMMON ANCHORS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1832 | Mechanic / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1832 | Resistance to one damage type / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1832 | Immunity to one damage type / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1832 | Weakness to one damage type / -3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1832 | Static DR +1 / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1832 | Base DR +1 / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1832 | Critical Resistance +1 / +2.5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1832 | Death State ±1 / ±2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1832 | Prohibition against one Magical Tradition / -2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1832 | Spell-fumble modifier +10 / -3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1832 | One fixed Power Point / +0.5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1832 | +1 PP per level / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1832 | -1 PP per level / -2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1834 | Apply these values only when the mechanic matches the stated scope. Chapter 8 provides the complete scope schedules for Resistance, Immunity, Weakness, static DR, Base DR, and Critical Resistance. Broader magical restrictions or more severe fumble modifiers still require comparison with the nearest anchor and an individual assessment. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1835 | 8. UNLISTED ABILITIES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1836 | When no exact anchor exists, identify the nearest established mechanic and adjust for the following factors. Record the reasoning in the ledger so the same type of feature is treated consistently in later designs. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1837 | • Action cost and opportunity cost. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1838 | • Frequency, recovery, and daily limits. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1839 | • Duration and whether the effect is persistent or temporary. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1840 | • Target count, area, range, and ease of application. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1841 | • Scaling across levels. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1842 | • Reliability, required checks, and saving throws. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1843 | • Equipment, positioning, trait, or resource requirements. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1844 | • Restrictions, codes, anathema, and consequences for violation. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1845 | • Whether the feature replaces an existing benefit or stacks with it. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1846 | CHAPTER 3 — RACE, HERITAGE, AND BACKGROUND PACKAGES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1847 | 1. PACKAGE COMPOSITION | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1848 | A standard pre-class character package consists of Race + Heritage + Background. Score each layer separately, then add the actual background selected. The package is compared with the 40-DP benchmark. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1849 | Race + Heritage target: 29 DP. Standard Background: 11 DP. Complete target: 40 DP. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1850 | 2. RACE AND HERITAGE PROCEDURE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1851 | 1. List base ability modifiers, size, Speed, HP, languages, specialist skills, senses, movement forms, resistances, DR, weaknesses, feats, spell access, and every named racial ability. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1852 | 2. Apply the universal anchors in Chapter 2. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1853 | 3. Cost racial and heritage features separately, then combine them. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1854 | 4. For a mutually exclusive heritage choice, assess the selected heritage rather than adding every heritage in the family. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1855 | 5. Apply the selected background and compare the complete package with the balance bands. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1856 | 6. Review concentrated synergies, especially multiple benefits tied to the same ability score, damage type, movement mode, or action. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1857 | 3. RACE + HERITAGE BANDS WITH A STANDARD BACKGROUND | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1858 | RACE + HERITAGE BANDS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1858 | Race + Heritage / Complete Package | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1858 | Below 23 / Below 34 — major low outlier | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1858 | 23 to below 25 / 34 to below 36 — low review | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1858 | 25 to below 27 / 36 to below 38 — acceptable lower edge | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1858 | 27 to 31 / 38 to 42 — preferred corridor | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1858 | Above 31 to 33 / Above 42 to 44 — acceptable upper edge | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1858 | Above 33 to 35 / Above 44 to 46 — high review | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1858 | Above 35 / Above 46 — major high outlier | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1860 | These translated bands apply only when the selected background costs 11 DP. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1861 | 4. BACKGROUND COMPONENTS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1862 | BACKGROUND COMPONENT COSTS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1862 | Component / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1862 | One General feat / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1862 | +1 class bonus to one complete skill / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1862 | One specialist skill / +1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1862 | One additional language / +0.5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1862 | One Spellcraft-cast cantrip / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1862 | One PP 1 Specialist Spell / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1862 | One fixed Power Point / +0.5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1864 | 5. STANDARD BACKGROUND | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1865 | STANDARD BACKGROUND PACKAGE | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1865 | Component / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1865 | One General feat / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1865 | Three complete +1 skill bonuses / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1865 | One specialist skill / +1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1865 | Total / 11 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1867 | All backgrounds using this structure cost 11 DP. The particular feat, skills, and specialist skill do not receive individual premiums or discounts. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1868 | 6. STRUCTURAL BACKGROUND EXCEPTIONS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1869 | BACKGROUND REFERENCE | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1869 | Background / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1869 | Archaeologist / 8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1869 | Diplomat / 8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1869 | Scholar / 8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1869 | Weaver / 11 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1869 | Lay Healer / 8.5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1871 | A background that does not match the standard structure is calculated from its actual components. Choice among skills does not add a flexibility premium. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1872 | 7. STARTING WEALTH | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1873 | Starting wealth is not included in background DP. It is a one-time economic benefit whose value depends on equipment prices, class wealth, campaign starting level, and the availability of purchased items. Assess starting wealth through the campaign economy rather than the background component table. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1874 | 8. CORE PC RACE PACKAGE TOTALS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1875 | This table gives the average complete Race package for each Core race. Base Race DP is combined with the mean DP of that race family’s legal heritages and the mean Core background cost. The 42 Core backgrounds average 10.73 DP: 37 standard backgrounds cost 11 DP, Archaeologist, Diplomat, and Scholar cost 8 DP, Weaver costs 11 DP, and Lay Healer costs 8.5 DP. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1876 | CORE PC RACE PACKAGE TOTALS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1876 | Race / Avg. Race + Heritage / Avg. Complete Package | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1876 | Ascendan / 31.10 / 41.83 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1876 | Dwarf / 28.80 / 39.53 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1876 | Elf / 31.67 / 42.40 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1876 | Gnome / 30.30 / 41.03 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1876 | Halfling / 29.20 / 39.93 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1876 | Human / 31.09 / 41.82 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1876 | Kornargon / 29.00 / 39.73 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1876 | Orc / 30.75 / 41.48 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1877 | These are family averages, not mandatory fixed character values. A character uses its selected heritage and selected background. Values are rounded to two decimal places. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1878 | CHAPTER 4 — SPELLS AND POWER POINTS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1879 | 1. CANTRIPS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1880 | Cantrips are PP 0 spells. A Spellcraft-cast cantrip uses the ordinary casting process. An innate cantrip can be used by a non-caster, does not require normal spell access, and automatically heightens with character level. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1881 | CANTRIP COSTS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1881 | Casting and availability / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1881 | Spellcraft-cast cantrip / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1881 | Innate, 1/day / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1881 | Innate, 2/day / +4.5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1881 | Innate, 3/day / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1881 | Innate, Focus / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1881 | Innate, at will / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1881 | Innate, constant / +8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1883 | • A fixed cantrip and a chosen cantrip have the same value. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1884 | • Individual damage, range, school, tradition, and situational usefulness are absorbed into the category average. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1885 | • Innate automatic heightening is included in the innate value. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1886 | • A passive ability that resembles a cantrip but does not grant the spell is assessed as an ordinary ability. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1887 | 2. NORMAL SPELLCRAFT SPELLS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1888 | NORMAL SPELL SCHEDULE | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1888 | PP / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1888 | 2–3 / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1888 | 4–5 / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1888 | 6–7 / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1888 | 8–9 / +7 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1888 | 10–11 / +8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1888 | 12–13 / +9 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1888 | 14–15 / +10 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1888 | 16–17 / +11 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1888 | 18–19 / +12 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1888 | 20 / +13 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1890 | Normal Spellcraft spell DP = 3 + floor(PP ÷ 2). | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1891 | 3. SPECIALIST SPELLCRAFT SPELLS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1892 | SPECIALIST SPELL SCHEDULE | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1892 | PP / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1892 | 1–2 / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1892 | 3–4 / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1892 | 5–6 / +7 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1892 | 7–8 / +8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1892 | 9–10 / +9 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1892 | 11–12 / +10 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1892 | 13–14 / +11 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1892 | 15–16 / +12 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1892 | 17–18 / +13 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1892 | 19–20 / +14 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1894 | Specialist Spellcraft spell DP = 4 + ceil(PP ÷ 2). | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1895 | The Specialist premium represents improved efficiency and the easier casting check. When a Specialist Spell is cast innately, remove the +1 easier-casting premium before adding the innate availability premium. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1896 | 4. INNATE SPELL DELIVERY | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1897 | INNATE AVAILABILITY PREMIUMS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1897 | Availability / Add to base | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1897 | 1/day / +1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1897 | 2/day / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1897 | 3/day / +2.5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1897 | Focus / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1897 | At will / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1897 | Constant / +7 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1899 | The innate premium includes universal access, no PP expenditure, no ordinary Spellcraft check, innate attack and save scaling, and automatic heightening. Interpolate unusual daily frequencies between the listed daily values and the at-will ceiling. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1900 | 5. POWER POINTS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1901 | POWER POINT COSTS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1901 | Mechanic / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1901 | One fixed Power Point / +0.5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1901 | +1 PP per level / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1901 | +2 PP per level / +8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1901 | -1 PP per level / -2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1901 | Change -1 PP/level to 0 / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1901 | Change -1 PP/level to +1 / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1903 | 6. UNIFORM SPELL RULES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1904 | • Spells with the same type, PP, casting method, and availability have the same DP value. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1905 | • A fixed spell and a chosen spell have the same value. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1906 | • A choice from a list receives no additional flexibility cost. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1907 | • A stand-alone spell that still uses Spellcraft and PP uses the normal or Specialist schedule. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1908 | • Innate availability categories are mutually exclusive unless a rule explicitly combines them. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1909 | • A complete class spellbook, repertoire, or progression uses the class spell-access rules in Chapter 6 rather than the stand-alone spell schedule. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1910 | CHAPTER 5 — CLASS CHASSIS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1911 | 1. UNIVERSAL CLASS FEATURES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1912 | Class DP compares benefits that differ between classes. Features granted to every PC class at the same levels form the universal class baseline and cost 0 DP. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1913 | UNIVERSAL CLASS BASELINE | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1913 | Feature / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1913 | Class Bonus progression / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1913 | Ability Increase progression / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1913 | Scheduled General feats / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1913 | Scheduled Class feats / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1915 | A feat granted beyond the universal schedule is a bonus feat and is costed normally. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1916 | 2. CLASS TOTAL | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1917 | Class DP = chassis + magic access + class abilities + bonus feats. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1918 | A class receives no negative DP because it lacks an optional subsystem. Record only the components actually granted and the explicit drawbacks actually imposed. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1919 | 3. CLASS TYPES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1920 | CLASS TYPE COSTS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1920 | Mechanically meaningful types / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1920 | First type / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1920 | Two types / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1920 | Three types / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1920 | Four types / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1922 | • Count only types that create feat, prerequisite, item, effect, or rules interactions. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1923 | • A descriptive label with no mechanical interaction is 0 DP. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1924 | • The type cost covers the tag only. Proficiencies, feats, spells, and abilities are separate. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1925 | 4. CLASS HIT POINTS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1926 | CLASS HP PER LEVEL | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1926 | HP/level / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1926 | 4 / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1926 | 5 / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1926 | 6 / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1926 | 7 / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1926 | 8 / +8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1926 | 9 / +10 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1926 | 10 / +12 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1926 | 11 / +14 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1926 | 12 / +16 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1926 | 13 / +18 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1926 | 14 / +20 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1928 | A class below 4 HP per level requires an individual drawback assessment. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1929 | 5. CLASS SKILLS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1930 | Each complete skill listed as a Class Skill costs +2 DP. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1931 | CLASS SKILL COSTS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1931 | Class Skills / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1931 | 1 / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1931 | 2 / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1931 | 3 / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1931 | 4 / +8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1931 | 5 / +10 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1931 | 6 / +12 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1931 | 7 / +14 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1931 | 8 / +16 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1931 | 9 / +18 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1931 | 10 / +20 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1931 | 11 / +22 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1931 | 12 / +24 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1931 | 13 / +26 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1931 | 14 / +28 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1931 | 15 / +30 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1933 | • Count each named Class Skill once. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1934 | • A choice of any two Class Skills costs +4 DP because two skills are gained. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1935 | • A specialist skill is not a Class Skill and uses the separate specialist-skill rules. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1936 | 6. CLASS SKILL POINTS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1937 | SKILL POINTS PER LEVEL | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1937 | Points/level / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1937 | 4 / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1937 | 5 / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1937 | 6 / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1937 | 7 / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1937 | 8 / +8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1937 | 9 / +10 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1937 | 10 / +12 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1939 | Class Skills and Skill Points are added separately. One determines which skills receive the Class Bonus; the other determines the ranks available. A class below 4 Skill Points per level requires an individual drawback assessment. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1940 | 7. BAB, BDB, BSB, SAVES, AND CASTER LEVEL | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1941 | Tertiary is the 0-DP baseline for each progression. BAB, BDB, BSB, Fortitude, Reflex, Will, and Caster Level are separate entries and are added independently. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1942 | CLASS PROGRESSION COSTS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1942 | Statistic / Tertiary / Secondary / Primary | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1942 | BAB / 0 / +7 / +15 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1942 | BDB / 0 / +5 / +11 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1942 | BSB / 0 / +5 / +11 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1942 | Fortitude / 0 / +3 / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1942 | Reflex / 0 / +3 / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1942 | Will / 0 / +3 / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1942 | Caster Level / 0 / +4 / +10 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1944 | • The BAB value already includes the standard bonus-damage thresholds. Do not cost them again. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1945 | • A non-spellcasting class has no BSB or Caster Level cost and receives no refund. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1946 | • BSB and Caster Level remain separate because one affects casting checks while the other governs access and scaling. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1947 | • An ability that changes a progression is costed by the net difference from the class entry. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1948 | 8. MAGICAL ABILITY SCORE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1949 | MAGICAL ABILITY COSTS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1949 | Ability / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1949 | Charisma / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1949 | Intelligence / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1949 | Wisdom / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1949 | Constitution / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1951 | Constitution casting receives a surcharge because the same ability also supports HP and physical resilience. The surcharge does not grant Constitution, HP, or saving throws; those components are costed separately. Apply the surcharge once per class. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1952 | 9. BONUS FEATS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1953 | CLASS-GRANTED BONUS FEATS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1953 | Feat granted / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1953 | General feat / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1953 | Racial feat / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1953 | Class feat / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1953 | Bonus Archetype feat / +8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1955 | An Archetype feat selected with an ordinary Class feat pick is already represented by that pick. The +8 value applies only when the class grants the Archetype feat in addition to the normal Class feat progression. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1956 | 10. CLASS ABILITIES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1957 | • Assess each class-specific ability by its actual mechanical effect. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1958 | • Reuse established feat, spell, skill, HP, ability, PP, and proficiency anchors where they match. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1959 | • Consider action cost, frequency, duration, target count, reliability, scaling, and restrictions. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1960 | • Average mutually exclusive choices rather than adding every option. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1961 | • Cost replacements by their net difference. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1962 | • Cost a scaling ability once for its complete progression. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1963 | 11. CLASS INDEX | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1964 | Class Index = (Class DP ÷ 208) × 100. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1965 | CLASS INDEX BANDS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1965 | Index / Treatment | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1965 | Below 90% / Low outlier; strengthen or justify deliberately. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1965 | 90% to below 95% / Acceptable lower edge. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1965 | 95% to 105% / Preferred class corridor. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1965 | Above 105% to 110% / Acceptable upper edge. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1965 | Above 110% / High outlier; reduce or justify deliberately. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1967 | 12. CORE PC CLASS TOTALS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1968 | The following table records the operative total DP for each completed Core PC class. Class DP includes the non-magical chassis, magic engine, named Class Abilities, and class-granted bonus feats. The Fighter’s 208 DP is the Class Index benchmark. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1969 | CORE PC CLASS TOTALS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1969 | Class / Class DP / Class Index | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1969 | Fighter / 208.0 / 100.00% | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1969 | Rogue / 215.0 / 103.37% | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1969 | Ranger / 201.5 / 96.88% | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1969 | Cleric / 205.0 / 98.56% | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1969 | Druid / 219.0 / 105.29% | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1969 | Wizard / 222.0 / 106.73% | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1969 | Bard / 201.5 / 96.88% | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1969 | Crusader / 206.5 / 99.28% | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1969 | Roster average / 209.81 / 100.87% | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1970 | The preferred class corridor is 95–105% of Fighter. Druid and Wizard sit slightly above that corridor but remain inside the broader ±10% tolerance. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1971 | CHAPTER 6 — CLASS SPELL ACCESS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1972 | 1. SEPARATE MAGIC COMPONENTS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1973 | A class magical package is not represented by one generic caster value. Add only the components that actually appear in the class. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1974 | MAGIC COMPONENT LOCATIONS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1974 | Component / Costing rule | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1974 | BSB / Class progression table | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1974 | Caster Level / Class progression table | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1974 | Magical ability / Constitution surcharge only | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1974 | Power Points / +4 DP per +1 PP per level | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1974 | Tradition and acquisition / This chapter | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1974 | Ordinary spells / This chapter | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1974 | Cantrips / +4 DP each | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1974 | Specialist Spells / Specialist PP schedule | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1976 | 2. MAGICAL TRADITIONS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1977 | TRADITION ACCESS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1977 | Access / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1977 | First fixed or selectable tradition / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1977 | Each additional simultaneously usable tradition / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1977 | Arcane Learned acquisition / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1977 | Ethereal Learned self-learning / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1977 | Full common Divinity spell list / +16 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1977 | Full common Verdant spell list / +16 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1977 | Instinctive tradition modifier / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1979 | • Choosing one tradition from several permitted traditions remains the first-tradition baseline. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1980 | • Charge +4 only when the class can actually cast from an additional tradition. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1981 | • The +16 full-list value replaces individual Spell Library entry costs. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1982 | • Uncommon and Rare spells are not included unless the class explicitly overrides availability. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1983 | • A restricted Divinity or Verdant library uses the actual library-entry count instead of +16. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1984 | 3. LEARNED AND INSTINCTIVE CASTING | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1985 | CASTER STYLE | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1985 | Element / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1985 | Learned label / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1985 | Instinctive label / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1985 | Standard daily preparation / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1985 | Standard level-up spell replacement / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1985 | Extra or unrestricted exchanges / Assess as a class ability | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1987 | Learned casting gains breadth and daily reconfiguration. Instinctive casting gains immediate access to every spell in a smaller repertoire. The value of each style comes from its actual library, memorisation capacity, or repertoire size. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1988 | 4. ORDINARY CLASS SPELL ACCESS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1989 | ORDINARY CLASS SPELLS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1989 | Component / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1989 | One Learned Spell Library entry / +0.5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1989 | One Learned memorised-spell capacity / +1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1989 | One combined library entry and capacity / +1.5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1989 | One Instinctive repertoire spell / +1.5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1989 | Stand-alone normal spell outside progression / Use normal PP schedule | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1991 | • Count the complete progression from 1st through 20th level. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1992 | • Do not vary ordinary access by the selected spell or its eventual PP. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1993 | • A choice from a list receives no flexibility premium. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1994 | • A one-for-one spell replacement normally adds 0 DP. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1995 | • Full common Divinity or Verdant access uses +16 and does not also count every spell as a library entry. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1996 | • A full-list Learned class still pays +1 DP for each spell it can memorise. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1997 | 5. CLASS CANTRIPS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 1998 | CLASS CANTRIPS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1998 | Number / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1998 | 1 / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1998 | 2 / +8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1998 | 3 / +12 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1998 | 4 / +16 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 1998 | 5 / +20 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2000 | Cantrips are unlimited PP 0 spells and are not priced as ordinary library or repertoire entries. An extra delivery mechanism through a familiar, companion, implement, or similar feature is costed separately. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2001 | 6. CLASS SPECIALIST SPELLS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2002 | A Specialist Spell granted in addition to ordinary class access uses the complete Specialist PP schedule. If it occupies and replaces an ordinary library, memorised, or repertoire entry already counted, subtract the ordinary access value for that entry. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2003 | SPECIALIST SPELL QUICK TABLE | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2003 | PP / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2003 | 1–2 / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2003 | 3–4 / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2003 | 5–6 / +7 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2003 | 7–8 / +8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2003 | 9–10 / +9 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2003 | 11–12 / +10 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2003 | 13–14 / +11 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2003 | 15–16 / +12 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2003 | 17–18 / +13 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2003 | 19–20 / +14 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2005 | 7. BSB, CASTER LEVEL, AND POWER POINTS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2006 | CASTING ENGINE | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2006 | Component / Tertiary / Secondary / Primary | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2006 | BSB / 0 / +5 / +11 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2006 | Caster Level / 0 / +4 / +10 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2008 | Power Points add +4 DP for each +1 PP per level. These costs are separate from spell access. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2009 | 8. MAGIC PACKAGE EXAMPLES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2010 | LEARNED ARCANE EXAMPLE | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2010 | Component / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2010 | 24 library entries / +12 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2010 | 8 memorised capacities / +8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2010 | 3 cantrips / +12 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2010 | +3 PP per level / +12 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2010 | Primary BSB / +11 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2010 | Primary Caster Level / +10 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2010 | Total / 65 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2012 | LEARNED DIVINITY EXAMPLE | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2012 | Component / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2012 | Full common list / +16 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2012 | 8 memorised capacities / +8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2012 | 4 cantrips / +16 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2012 | +3 PP per level / +12 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2012 | Primary BSB / +11 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2012 | Primary Caster Level / +10 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2012 | Total / 73 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2014 | INSTINCTIVE EXAMPLE | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2014 | Component / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2014 | 24 repertoire spells / +36 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2014 | 3 cantrips / +12 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2014 | +4 PP per level / +16 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2014 | Primary BSB / +11 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2014 | Primary Caster Level / +10 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2014 | Total / 85 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2016 | CHAPTER 7 — WORKED EXAMPLES AND WORKSHEETS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2017 | 1. PRE-CLASS PACKAGE EXAMPLE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2018 | GENERIC PRE-CLASS PACKAGE | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2018 | Component / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2018 | Race: +1 Strength / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2018 | Race: 30-foot Speed / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2018 | Race: one extra language / +0.5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2018 | Race: one additional specialist skill / +1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2018 | Race: Resistance to one energy type / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2018 | Heritage: one Racial feat / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2018 | Heritage: +2 to one complete skill / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2018 | Heritage: one Focus innate cantrip / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2018 | Race + Heritage total / 25.5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2018 | Standard Background / +11 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2018 | Complete package / 36.5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2020 | The complete result is within the normal 36–44 DP tolerance, at the acceptable lower edge. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2021 | 2. CLASS CHASSIS EXAMPLE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2022 | GENERIC MARTIAL CHASSIS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2022 | Component / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2022 | First Class Type / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2022 | Simple and Martial weapons / +10 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2022 | All armour / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2022 | Light and Heavy shields / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2022 | Eight Class Skills / +16 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2022 | 6 Skill Points per level / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2022 | 10 HP per level / +12 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2022 | Primary BAB / +15 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2022 | Primary BDB / +11 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2022 | Primary Fortitude / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2022 | Secondary Reflex / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2022 | Tertiary Will / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2022 | Chassis total / 87 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2024 | 3. COMPLETE CLASS EXAMPLE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2025 | GENERIC CLASS TOTAL | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2025 | Category / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2025 | Class chassis / 87 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2025 | Magic access / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2025 | Class abilities / 61 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2025 | Ten bonus Class feats / +60 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2025 | Class total / 208 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2025 | Class Index / 100% | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2027 | 4. RACE + HERITAGE + BACKGROUND WORKSHEET | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2028 | PRE-CLASS WORKSHEET | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2028 | Component / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2028 | Race ability modifiers /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2028 | Race HP, Speed, and size /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2028 | Race languages and specialist skills /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2028 | Race skills, senses, and defences /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2028 | Race feats and magic /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2028 | Race unique abilities and drawbacks /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2028 | Race subtotal /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2028 | Heritage features /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2028 | Race + Heritage subtotal /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2028 | Selected Background /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2028 | Complete package total /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2028 | Balance band /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2030 | 5. CLASS WORKSHEET | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2031 | CLASS WORKSHEET — CHASSIS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2031 | Component / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2031 | Class Types /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2031 | Weapon proficiencies /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2031 | Armour and shield proficiencies /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2031 | Class Skills /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2031 | Skill Points per level /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2031 | Hit Points per level /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2031 | BAB /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2031 | BDB /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2031 | Fortitude /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2031 | Reflex /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2031 | Will /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2031 | Chassis subtotal /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2033 | CLASS WORKSHEET — MAGIC | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2033 | Component / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2033 | Magical Tradition and method /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2033 | Magical ability surcharge /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2033 | BSB /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2033 | Caster Level /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2033 | Power Points /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2033 | Ordinary spell access /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2033 | Cantrips /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2033 | Specialist Spells /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2033 | Magic subtotal /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2035 | CLASS WORKSHEET — TOTAL | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2035 | Component / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2035 | Chassis subtotal /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2035 | Magic subtotal /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2035 | Class abilities /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2035 | Bonus feats /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2035 | Class total /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2035 | Class Index /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2037 | 6. MASTER QUICK REFERENCE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2038 | COMMON DP VALUES | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2038 | Mechanic / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2038 | +1 ability / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2038 | -1 ability / -3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2038 | +1 HP/level / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2038 | +5 feet Speed / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2038 | Small size / -2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2038 | Extra language / +0.5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2038 | Extra specialist skill / +1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2038 | +1 entire skill / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2038 | +2 entire skill / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2038 | General / Racial / Class feat / +4 / +5 / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2038 | Resistance, one damage type / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2038 | Immunity, one damage type / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2038 | Weakness, one damage type / -3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2038 | Static DR +1 / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2038 | Base DR +1 / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2038 | Critical Resistance +1 / +2.5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2038 | Fixed PP / +0.5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2038 | +1 PP/level / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2041 | CLASS QUICK REFERENCE | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2041 | Mechanic / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2041 | Additional Class Type / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2041 | Specific weapon / group / +1 / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2041 | Simple / Martial weapons / +4 / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2041 | Armour or shield tier / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2041 | Each Class Skill / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2041 | Each Skill Point/level above 4 / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2041 | Each HP/level above 4 / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2041 | Constitution casting / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2041 | Additional tradition / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2041 | Learned library / memorised / +0.5 / +1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2041 | Instinctive repertoire spell / +1.5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2041 | Class cantrip / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2044 | CHAPTER 8 — CREATURE AND NPC CONSTRUCTION | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2045 | 1. CREATURE CONSTRUCTION LAYERS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2046 | Creatures and NPCs use the same Development Point language as player characters, but their rules are assembled in different layers. A creature type does not replace its race, heritage, class, size, natural attacks, or special abilities. Each layer is costed independently and then added to the complete creature. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2047 | Creature DP = Type DP + Race or Subtype DP + Heritage DP + Size DP + Class DP + NPC Combat Package + movement + senses + natural attacks + spells + Creature Abilities + exceptional equipment or template adjustments. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2048 | • Use the default creature class only when the creature actually possesses that class. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2049 | • When a creature replaces its default creature class with a PC or NPC class, add the replacement class only. Do not add both classes. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2050 | • Do not add class statistics, racial DR, natural attacks, movement forms, spell access, or optional traits to the creature type ledger. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2051 | • A statement that a type “often”, “sometimes”, or “usually” possesses a feature is not a universal type benefit. Cost it in the race, class, or individual creature where it actually appears. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2052 | Creature Type DP is not expected to equal the 29-DP Race + Heritage target used for player characters. Some creature types are deliberately minor or fragile, while others carry extensive immunity and defensive packages. Final balance is determined from the complete creature rather than the type layer alone. Once the complete Creature DP total is known, use Chapter 9 to calculate its XP Multiplier and Effective Level. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2053 | 2. CREATURE TYPE BASELINE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2054 | The Humanoid type is the 0-DP creature-type baseline. It supplies no ability modifier, uses ordinary senses, breathes, eats, and sleeps, and normally has Death State 5. Features supplied by a Humanoid race or class are costed in those later layers. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2055 | CREATURE TYPE BASELINE | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2055 | Baseline feature / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2055 | Humanoid creature type / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2055 | Ordinary senses / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2055 | Breathes, eats, and sleeps / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2055 | Death State 5 / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2055 | No type-level ability modifier / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2056 | 3. CREATURE-SPECIFIC COST ANCHORS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2057 | The following anchors extend the universal component costs to mechanics that appear frequently in creature types. Use the ordinary rules whenever an existing anchor already covers the feature. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2058 | CREATURE SENSES | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2058 | Mechanic / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2058 | Nightvision / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2058 | Darkvision / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2058 | Darkvision and Nightvision / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2058 | Blindsight or equivalent primary non-visual sense / +8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2058 | Blind while possessing equivalent Blindsight / -2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2058 | Blind with equivalent Blindsight, net package / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2058 | CREATURE SAVE BONUSES | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2058 | Mechanic / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2058 | +1 racial bonus to all saving throws / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2058 | +2 racial bonus to one saving throw / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2058 | +2 racial bonus to two saving throws / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2058 | +2 racial bonus to all saving throws / +10 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2058 | RESISTANCE, IMMUNITY, AND WEAKNESS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2058 | Scope / Resistance / Immunity / Weakness | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2058 | One weapon group / +3 / +4 / -2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2058 | One damage type / +4 / +5 / -3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2058 | Two related damage types / +7 / +9 / -5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2058 | All mundane attacks / +8 / +12 / -6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2058 | All physical damage / +10 / +15 / -7.5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2059 | Resistance halves damage from the listed source. Immunity prevents all damage or the complete effect covered by the wording. Weakness increases damage from the listed source by 50%. Multiple matching Resistances or Weaknesses do not stack unless a rule explicitly states otherwise, and a broader package absorbs any narrower entry already contained within it. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2060 | A weapon group is narrower than a damage type. “All mundane attacks” covers non-magical attacks and is bypassed by magical attacks. “All physical damage” covers bludgeoning, piercing, and slashing damage from both mundane and magical sources. Broader packages, including protection from all damage, require individual assessment. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2061 | DAMAGE REDUCTION | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2061 | DR value / Static DR DP / Effective Base DR at BDB 0 / 6 / 12 / 18 / Base DR DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2061 | 1 / +3 / 1 / 2 / 3 / 4 / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2061 | 2 / +6 / 2 / 4 / 6 / 8 / +10 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2061 | 3 / +9 / 3 / 6 / 9 / 12 / +15 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2061 | 4 / +12 / 4 / 8 / 12 / 16 / +20 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2061 | 5 / +15 / 5 / 10 / 15 / 20 / +25 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2062 | Static DR is a fixed reduction and costs +3 DP per point. Base DR costs +5 DP per point because it is multiplied by the creature’s BDB thresholds: ×1 below BDB 6, ×2 at BDB 6, ×3 at BDB 12, and ×4 at BDB 18. A creature with both forms adds the static value after calculating its effective Base DR. These costs apply to innate DR; worn equipment is assessed through the equipment rules. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2063 | CRITICAL RESISTANCE | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2063 | Critical Resistance / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2063 | CR 1 / +2.5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2063 | CR 2 / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2063 | CR 3 / +7.5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2063 | CR 4 / +10 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2064 | Critical Resistance is a static modifier that increases every Attack Value threshold required to inflict a critical by the listed CR value. It costs +2.5 DP per point. CR above 4 requires individual assessment because it approaches the practical protection of complete critical immunity. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2065 | CREATURE CONDITION AND TACTICAL DEFENCES | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2065 | Mechanic / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2065 | Immunity to one non-damage condition or effect / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2065 | Broad immunity to mental effects / +8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2065 | Immunity to critical injuries and critical effects / +8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2065 | Complete immunity to critical results, including critical damage / +12 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2065 | Immunity to precision damage / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2065 | Cannot be Flanked and cannot be Flat-Footed, bundled / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2065 | Partial anatomical filtering of critical injuries / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2065 | CREATURE NEEDS AND DEATH STATE | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2065 | Mechanic / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2065 | Does not need to breathe / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2065 | Does not need to eat / +1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2065 | Does not need to sleep / +1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2065 | Death State above or below 5 / ±2/step | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2065 | No Death State; destroyed or removed at 0 HP / -6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2065 | Cannot heal naturally or by ordinary healing, but repair or special healing remains / -5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2066 | The −6 value for removal at 0 HP is a creature-specific cap. Death State is valuable when healing, stabilisation, or recovery can return a creature to the encounter, but ordinary encounter contribution normally ends at 0 HP. It is therefore not extrapolated as a full −10 from Death State 5 to a nominal Death State 0. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2067 | Broad immunity wording is counted once. For example, poison immunity is treated as one +5 damage-channel package when it prevents both poison damage and poison afflictions. Do not divide one broad rule into several overlapping entries merely to increase its cost. Likewise, all physical Resistance already contains resistance to bludgeoning, piercing, and slashing damage. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2068 | 4. CREATURE TYPE COST SUMMARY | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2069 | CREATURE TYPE DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2069 | Creature type / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2069 | Fey / -3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2069 | Animal / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2069 | Humanoid / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2069 | Aberration / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2069 | Beast / +7 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2069 | Wyrm / +14 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2069 | Plant / +15 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2069 | Elemental / +23 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2069 | Eternal / +31 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2069 | Undead / +36 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2069 | Construct / +54 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2069 | Ooze / +55 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2070 | These values apply only to universal type traits. The high Construct and Ooze values reflect their ability to invalidate many ordinary attacks, afflictions, conditions, and critical effects. The Wyrm type remains comparatively modest because most dragon power is supplied by race, heritage, size, attacks, breath weapons, magic, and class progression rather than the type itself. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2071 | 5. CREATURE TYPE LEDGERS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2072 | ABERRATION | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2073 | ABERRATION TYPE LEDGER | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2073 | Component / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2073 | Darkvision / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2073 | +2 Will saving throws / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2073 | Death State 4 / -2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2073 | ABERRATION TYPE TOTAL / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2074 | Aberration is a minor premium type. Its unusual attacks, psychic powers, anatomy, and spellcasting are not inherent to the type and must be added elsewhere. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2075 | ANIMAL | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2076 | ANIMAL TYPE LEDGER | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2076 | Component / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2076 | Intelligence −5 and animal-level reasoning / -10 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2076 | Nightvision / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2076 | +2 Fortitude and Reflex saving throws / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2076 | Death State 6 / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2076 | Mandatory Neutral alignment / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2076 | ANIMAL TYPE TOTAL / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2077 | The Intelligence reduction includes the severe loss of language, knowledge, planning, and broad skill use. Natural attacks and the Animal class are separate layers. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2078 | BEAST | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2079 | BEAST TYPE LEDGER | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2079 | Component / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2079 | Darkvision and Nightvision / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2079 | +2 Fortitude saving throws / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2079 | Death State 4 / -2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2079 | BEAST TYPE TOTAL / +7 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2080 | A Beast receives useful senses and resilience, but supernatural powers, natural attacks, and unusual movement are supplied by race or individual abilities. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2081 | CONSTRUCT | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2082 | CONSTRUCT TYPE LEDGER | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2082 | Component / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2082 | Darkvision and Nightvision / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2082 | Bleed immunity / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2082 | Disease immunity / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2082 | Mental damage immunity / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2082 | Poison immunity / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2082 | Soul-effect immunity / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2082 | Subdual damage immunity / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2082 | Doomed, Drained, Fatigued, Paralysed, Sickened, and Unconscious immunities / +18 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2082 | Critical Resistance 4 / +10 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2082 | Does not eat or breathe / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2082 | No Death State; destroyed at 0 HP / -6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2082 | No natural or ordinary healing; repair and mending remain / -5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2082 | CONSTRUCT TYPE TOTAL / +54 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2083 | Construct racial DR is explicitly determined by construct race or model and is not included in the type total. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2084 | ELEMENTAL | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2085 | ELEMENTAL TYPE LEDGER | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2085 | Component / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2085 | Darkvision and Nightvision / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2085 | Does not breathe / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2085 | Critical Resistance 2 / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2085 | Native elemental immunity / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2085 | Paralysis immunity / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2085 | Poison immunity / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2085 | Sleep immunity / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2085 | No Death State; destroyed at 0 HP / -6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2085 | ELEMENTAL TYPE TOTAL / +23 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2086 | An opposed elemental weakness is not included because the type says that elementals often possess one rather than granting the same weakness universally. Add the actual weakness at race or heritage level. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2087 | ETERNAL | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2088 | ETERNAL TYPE LEDGER | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2088 | Component / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2088 | Darkvision and Nightvision / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2088 | Eternal Essence / +12 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2088 | Does not eat or sleep / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2088 | Critical Resistance 2 / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2088 | +2 to all saving throws / +10 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2088 | No Death State; removed at 0 HP / -6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2088 | Planar essence returns to its home plane / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2088 | ETERNAL TYPE TOTAL / +31 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2089 | Eternal Essence includes the universal reduction of all FDC by 1 and the removal of armour and shield penalties such as ACP, Maximum Dexterity, and Speed Penalty. Planar return preserves the being’s essence but does not prevent its removal from the current encounter. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2090 | FEY | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2091 | FEY TYPE LEDGER | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2091 | Component / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2091 | Nightvision / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2091 | Cold Iron weakness / -3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2091 | +1 to all saving throws / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2091 | Death State 2 / -6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2091 | FEY TYPE TOTAL / -3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2092 | Fey is a deliberately fragile type. Its characteristic magic, movement, charms, and natural powers are supplied by the Fey class and individual Fey races. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2093 | HUMANOID | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2094 | HUMANOID TYPE LEDGER | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2094 | Component / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2094 | Ordinary senses / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2094 | Breathes, eats, and sleeps / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2094 | Death State 5 / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2094 | No type-level ability modifier / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2094 | HUMANOID TYPE TOTAL / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2095 | Humanoid is the type baseline. Most of its mechanical identity comes from race, heritage, background, and a PC or NPC class. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2096 | OOZE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2097 | OOZE TYPE LEDGER | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2097 | Component / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2097 | Intelligence −2, Charisma −2, Dexterity −2, Constitution +2 / -6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2097 | Disease immunity / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2097 | Broad mental-effect immunity / +8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2097 | Poison immunity / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2097 | Sleep immunity / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2097 | Paralysis immunity / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2097 | Polymorph immunity / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2097 | Precision damage immunity / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2097 | Stunning immunity / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2097 | Critical immunity / +8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2097 | Cannot be Flanked or Flat-Footed / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2097 | Does not breathe or sleep / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2097 | Blind with Blindsight / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2097 | Death State 8 / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2097 | OOZE TYPE TOTAL / +55 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2098 | Ooze carries the highest type total because its defensive package removes numerous common offensive routes before race, class, or special abilities are considered. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2099 | PLANT | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2100 | PLANT TYPE LEDGER | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2100 | Component / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2100 | Nightvision / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2100 | Broad mental-effect immunity / +8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2100 | Anatomical filtering of critical injuries / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2100 | Death State 5 / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2100 | PLANT TYPE TOTAL / +15 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2101 | Plants still breathe and remain affected by gas-like effects. Their critical rule is not full critical immunity; it retains damage and bleed and blocks only results incompatible with plant anatomy. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2102 | UNDEAD | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2103 | UNDEAD TYPE LEDGER | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2103 | Component / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2103 | Constitution +1 / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2103 | Darkvision / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2103 | Bleed immunity / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2103 | Poison immunity / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2103 | Sleep immunity / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2103 | Disease immunity / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2103 | Paralysis immunity / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2103 | Soul Drain immunity / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2103 | Subdual damage immunity / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2103 | Stunning immunity / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2103 | Does not eat, breathe, or sleep / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2103 | No Death State; destroyed at 0 HP / -6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2103 | UNDEAD TYPE TOTAL / +36 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2104 | Subtype exceptions at 0 HP, resurrection rules, sunlight vulnerabilities, spawn mechanics, and draining attacks are not universal type benefits and are costed where they occur. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2105 | WYRM | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2106 | WYRM TYPE LEDGER | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2106 | Component / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2106 | Darkvision and Nightvision / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2106 | Sleep immunity / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2106 | Paralysis immunity / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2106 | Death State 6 / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2106 | WYRM TYPE TOTAL / +14 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2107 | Breath weapons, flight, Frightful Aura, natural attacks, size, magic, and draconic abilities belong to Wyrm races, heritages, classes, or individual creatures. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2108 | 6. APPLYING TYPE DP | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2109 | • Add the type total once, even when a race repeats the same trait for descriptive completeness. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2110 | • When a race upgrades a type trait, charge only the difference. Replacing Nightvision with Darkvision adds +2 DP, not the full +4 again. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2111 | • When a race removes a type drawback, add back the refunded value. Removing the Fey Cold Iron weakness adds +3 DP. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2112 | • When a subtype changes the 0-HP rule, replace the −6 entry with the actual subtype rule rather than adding both. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2113 | • Specific immunities, resistances, weaknesses, senses, DR, or movement forms granted by a race or heritage are added after the type total. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2114 | • Class statistics are always costed separately. The next construction layer is the default creature class or a replacement PC or NPC class. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2115 | 7. CREATURE TYPE WORKSHEET | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2116 | CREATURE TYPE WORKSHEET | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2116 | Component / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2116 | Creature type /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2116 | Ability modifiers or mental limitations /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2116 | Senses /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2116 | Saving-throw modifiers /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2116 | Critical Resistance or critical rules /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2116 | Damage immunities /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2116 | Condition and effect immunities /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2116 | Needs: breathe, eat, and sleep /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2116 | Death State or 0-HP rule /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2116 | Weaknesses and healing restrictions /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2116 | Unique type ability /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2116 | TYPE DP TOTAL /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2117 | After completing this worksheet, begin a new ledger for the creature’s default creature class or selected PC or NPC class. Do not combine the two layers until each has been independently checked for overlap. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2118 | 8. CREATURE AND NPC CLASS COSTING | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2119 | A creature class or NPC class is a structural chassis. It supplies proficiencies, Class Skills, Skill Points, Hit Points, combat and saving-throw progressions, and sometimes casting infrastructure. Race, heritage, size, natural attacks, spells, special abilities, and equipment remain separate construction layers. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2120 | Creature or NPC Class DP = Class Types + proficiencies + Class Skills + Skill Points + HP + BAB + BDB + saves + casting infrastructure + explicit class abilities. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2121 | • Do not compare a creature or NPC class directly with the 208-DP player-character class benchmark. These classes are intentionally incomplete chassis and receive much of their final power from race, heritage, size, attacks, spells, and creature abilities. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2122 | • General feats gained by the universal creature progression are not part of Class DP. Add any feat explicitly granted by a class beyond that progression. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2123 | • A default creature class and a replacement PC or NPC class are mutually exclusive. Add only the class actually used. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2124 | • When a class offers optional magic, record both the non-caster chassis and the caster variant. Add the casting package only when the creature actually possesses it. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2125 | • Casting infrastructure does not grant a defined spell list. Cost each actual spell, cantrip, Specialist Spell, repertoire, or library separately. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2126 | 9. ADDITIONAL CLASS ANCHORS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2127 | The ordinary class-chassis anchors in Chapters 5 and 6 remain controlling. The following values cover creature-class wording that does not normally appear in player-character classes. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2128 | BELOW-BASELINE SKILL POINTS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2128 | Skill Points per level / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2128 | 4 / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2128 | 3 / -2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2128 | 2 / -4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2128 | 1 / -6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2128 | 0 / -8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2128 | FIXED SKILL-RANK PROGRESSION | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2128 | Mechanic / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2128 | 1 automatic rank per level in one named skill / +1.5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2128 | Three fixed skills at 1 rank per level / +4.5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2128 | CREATURE WEAPON PROFICIENCIES | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2128 | Package / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2128 | One named unarmed or natural attack / +1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2128 | All natural weapons possessed by the creature / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2128 | All Simple and Martial weapons / +10 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2128 | All Simple, Martial, and natural weapons / +12 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2128 | CASTING INFRASTRUCTURE PACKAGES | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2128 | BSB / Caster Level / PP / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2128 | Tertiary / Tertiary / 1 PP per level / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2128 | Secondary / Secondary / 2 PP per level / +17 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2128 | Primary / Secondary / 4 PP per level / +31 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2128 | Primary / Primary / 4 PP per level / +37 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2128 | Constitution as the magical ability / +4 additional | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2129 | A fixed or selectable first tradition remains 0 DP. The Constitution surcharge is added only when Constitution is the actual magical ability. When a class can choose among traditions, record the non-Constitution total and the Constitution-casting total separately. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2130 | “All shields” is the complete Light, Heavy, and Tower package at +6 DP. Generic “shields” without explicit Tower access is treated as Light and Heavy shields at +4 DP. Buckler proficiency uses the Light-shield tier at +2 DP. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2131 | 10. CREATURE CLASS COST SUMMARY | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2132 | DEFAULT CREATURE CLASS DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2132 | Creature class / Non-caster / Magic add-on / Caster total | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2132 | Aberration / 66 / +17 / 83 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2132 | Animal / 54 / — / 54 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2132 | Beast / 66 / +4 / 70; 74 with Constitution | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2132 | Construct / 39.5 / — / 39.5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2132 | Elemental / 93 / +4 / 97; 101 with Constitution | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2132 | Eternal / 107 / +37 / 144 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2132 | Fey / 60 / +37 / 97; 101 with Constitution | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2132 | Humanoid / 49 / — / 49 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2132 | Ooze / 24 / — / 24 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2132 | Plant / 47 / +4 / 51; 55 with Constitution | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2132 | Undead / 63 / +17 / 80; 84 with Constitution | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2132 | Wyrm / 116 / +31 / 147; 151 with Constitution | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2133 | The caster total includes BSB, Caster Level, and PP but not individual spells. The Constitution total applies only where the creature uses Constitution as its magical ability. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2134 | 11. CREATURE CLASS LEDGERS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2135 | ABERRATION | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2136 | ABERRATION CLASS LEDGER | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2136 | Component / Entry / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2136 | Weapon proficiency / All Simple weapons / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2136 | Class Skills / 13 skills / +26 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2136 | Skill Points / 6 per level / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2136 | Hit Points / 8 per level / +8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2136 | BAB / BDB / Secondary / Secondary / +12 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2136 | Saving Throws / Secondary / Secondary / Primary / +12 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2136 | ABERRATION NON-CASTER TOTAL /  / 66 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2136 | Optional magic / Secondary BSB; Secondary CL; 2 PP per level / +17 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2136 | ABERRATION CASTER TOTAL /  / 83 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2137 | The preferred Ethereal tradition adds no magical-ability surcharge. Actual spells remain separate. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2138 | ANIMAL | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2139 | ANIMAL CLASS LEDGER | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2139 | Component / Entry / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2139 | Weapon proficiency / All natural weapons possessed / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2139 | Class Skills / 7 skills / +14 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2139 | Skill Points / 2 per level / -4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2139 | Skill-point ability / Wisdom instead of Intelligence / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2139 | Hit Points / 10 per level / +12 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2139 | BAB / BDB / Secondary / Primary / +18 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2139 | Saving Throws / Primary / Primary / Tertiary / +12 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2139 | ANIMAL CLASS TOTAL /  / 54 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2140 | The Wisdom-based Skill Point formula is an ability substitution rather than an additional progression. It receives no independent premium. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2141 | BEAST | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2142 | BEAST CLASS LEDGER | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2142 | Component / Entry / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2142 | Weapon proficiency / All natural attack forms / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2142 | Class Skills / 7 skills / +14 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2142 | Skill Points / 4 per level / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2142 | Hit Points / 10 per level / +12 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2142 | BAB / BDB / Primary / Primary / +26 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2142 | Saving Throws / Primary / Primary / Tertiary / +12 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2142 | BEAST NON-CASTER TOTAL /  / 66 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2142 | Optional magic / Tertiary BSB; Tertiary CL; 1 PP per level / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2142 | BEAST CASTER TOTAL / Non-Constitution / Constitution / 70 / 74 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2143 | The Beast class permits any tradition. Add the +4 Constitution surcharge only when the selected tradition uses Constitution. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2144 | CONSTRUCT | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2145 | CONSTRUCT CLASS LEDGER | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2145 | Component / Entry / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2145 | Weapon proficiency / Unarmed weapons only / +1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2145 | Class Skills / None / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2145 | Flexible Skill Points / 0 per level / -8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2145 | Fixed skill ranks / Acrobatics, Athletics, and Perception / +4.5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2145 | Hit Points / 12 per level / +16 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2145 | BAB / BDB / Primary / Primary / +26 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2145 | Saving Throws / Tertiary / Tertiary / Tertiary / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2145 | CONSTRUCT CLASS TOTAL /  / 39.5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2146 | The fixed-rank package is narrower than three flexible Skill Points and is therefore valued at +1.5 DP per named skill progression. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2147 | ELEMENTAL | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2148 | ELEMENTAL CLASS LEDGER | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2148 | Component / Entry / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2148 | Weapon proficiency / All Simple and Martial weapons / +10 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2148 | Armour proficiency / All armour / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2148 | Shield proficiency / All shields / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2148 | Class Skills / 9 skills / +18 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2148 | Skill Points / 4 per level / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2148 | Hit Points / 10 per level / +12 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2148 | BAB / BDB / Primary / Primary / +26 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2148 | Saving Throws / Primary / Primary / Secondary / +15 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2148 | ELEMENTAL NON-CASTER TOTAL /  / 93 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2148 | Optional magic / Tertiary BSB; Tertiary CL; 1 PP per level / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2148 | ELEMENTAL CASTER TOTAL / Non-Constitution / Constitution / 97 / 101 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2149 | Use the Constitution result when the elemental nature tradition uses Constitution as its magical ability. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2150 | ETERNAL | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2151 | ETERNAL CLASS LEDGER | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2151 | Component / Entry / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2151 | Weapon proficiency / All Simple and Martial weapons / +10 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2151 | Armour proficiency / All armour / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2151 | Shield proficiency / All shields / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2151 | Class Skills / 14 skills / +28 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2151 | Skill Points / 6 per level / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2151 | Hit Points / 10 per level / +12 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2151 | BAB / BDB / Primary / Primary / +26 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2151 | Saving Throws / Primary / Secondary / Primary / +15 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2151 | ETERNAL NON-CASTER TOTAL /  / 107 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2151 | Optional magic / Primary BSB; Primary CL; 4 PP per level / +37 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2151 | ETERNAL CASTER TOTAL /  / 144 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2152 | The stated Arcane or Divinity preference adds no Constitution surcharge. Eternal Essence belongs to the Eternal type ledger and is not repeated here. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2153 | FEY | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2154 | FEY CLASS LEDGER | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2154 | Component / Entry / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2154 | Weapon proficiency / All Simple weapons / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2154 | Armour proficiency / Any non-metal armour / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2154 | Class Skills / 13 skills / +26 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2154 | Skill Points / 8 per level / +8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2154 | Hit Points / 6 per level / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2154 | BAB / BDB / Tertiary / Tertiary / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2154 | Saving Throws / Tertiary / Primary / Primary / +12 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2154 | FEY NON-CASTER TOTAL /  / 60 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2154 | Optional magic / Primary BSB; Primary CL; 4 PP per level / +37 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2154 | FEY CASTER TOTAL / Ethereal / Constitution nature caster / 97 / 101 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2155 | The broad non-metal armour wording covers Light, Medium, and Heavy armour tiers while retaining the material restriction. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2156 | HUMANOID | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2157 | HUMANOID CLASS LEDGER | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2157 | Component / Entry / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2157 | Weapon proficiency / All Simple weapons / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2157 | Armour proficiency / Light armour / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2157 | Class Skills / 7 skills / +14 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2157 | Skill Points / 4 per level / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2157 | Hit Points / 8 per level / +8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2157 | BAB / BDB / Secondary / Secondary / +12 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2157 | Saving Throws / Secondary / Secondary / Secondary / +9 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2157 | HUMANOID CLASS TOTAL /  / 49 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2158 | A Humanoid with spellcasting normally replaces this default class with a PC class or the Adept NPC class. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2159 | OOZE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2160 | OOZE CLASS LEDGER | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2160 | Component / Entry / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2160 | Weapon proficiency / Natural weapons only / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2160 | Class Skills / Survival / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2160 | Skill Points / 2 per level / -4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2160 | Hit Points / 10 per level / +12 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2160 | BAB / BDB / Secondary / Secondary / +12 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2160 | Saving Throws / Tertiary / Tertiary / Tertiary / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2160 | OOZE CLASS TOTAL /  / 24 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2161 | The extensive Ooze immunities and tactical defences are already contained in the separate Ooze type total. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2162 | PLANT | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2163 | PLANT CLASS LEDGER | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2163 | Component / Entry / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2163 | Weapon proficiency / Natural weapons only / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2163 | Class Skills / 8 skills / +16 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2163 | Skill Points / 4 per level / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2163 | Hit Points / 8 per level / +8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2163 | BAB / BDB / Secondary / Secondary / +12 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2163 | Saving Throws / Primary / Tertiary / Secondary / +9 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2163 | PLANT NON-CASTER TOTAL /  / 47 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2163 | Optional magic / Tertiary BSB; Tertiary CL; 1 PP per level / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2163 | Constitution magical ability / Verdant tradition / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2163 | PLANT CASTER TOTAL /  / 55 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2164 | The class list is read as eight skills, with Perception and Stealth treated as separate entries. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2165 | UNDEAD | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2166 | UNDEAD CLASS LEDGER | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2166 | Component / Entry / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2166 | Weapon proficiency / All Simple and natural weapons / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2166 | Class Skills / 9 skills / +18 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2166 | Skill Points / 6 per level / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2166 | Hit Points / 8 per level / +8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2166 | BAB / BDB / Secondary / Secondary / +12 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2166 | Saving Throws / Primary / Secondary / Primary / +15 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2166 | UNDEAD NON-CASTER TOTAL /  / 63 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2166 | Optional magic / Secondary BSB; Secondary CL; 2 PP per level / +17 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2166 | UNDEAD CASTER TOTAL / Non-Constitution / Constitution / 80 / 84 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2167 | The Undead class permits any tradition. Add the Constitution surcharge only when the chosen tradition uses Constitution. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2168 | WYRM | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2169 | WYRM CLASS LEDGER | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2169 | Component / Entry / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2169 | Weapon proficiency / All Simple, Martial, and natural weapons / +12 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2169 | Armour proficiency / All armour / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2169 | Class Skills / 15 skills / +30 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2169 | Skill Points / 8 per level / +8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2169 | Hit Points / 12 per level / +16 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2169 | BAB / BDB / Primary / Primary / +26 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2169 | Saving Throws / Primary / Primary / Primary / +18 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2169 | WYRM NON-CASTER TOTAL /  / 116 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2169 | Optional magic / Primary BSB; Secondary CL; 4 PP per level / +31 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2169 | WYRM CASTER TOTAL / Arcane / Constitution nature caster / 147 / 151 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2170 | “All weapons” is treated as broader than the ordinary Simple-and-Martial package and includes the creature’s natural weapons. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2171 | 12. NPC CLASS COST SUMMARY | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2172 | NPC CLASS DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2172 | NPC class / Base total / Constitution-caster total | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2172 | Adept / 69 / 73 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2172 | Expert / 81 / 81 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2172 | Hybrid / 96 / 100 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2172 | Martial / 83 / 83 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2173 | Adept and Hybrid totals include casting infrastructure but not actual spells. Their Constitution totals apply only when Constitution is the magical ability. Expert and Martial select a tradition for rules interaction but do not gain spellcasting from the class. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2174 | 13. NPC CLASS LEDGERS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2175 | ADEPT NPC | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2176 | ADEPT NPC CLASS LEDGER | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2176 | Component / Entry / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2176 | Class Type / Adept / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2176 | Weapon proficiency / All Simple weapons / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2176 | Class Skills / 8 fixed skills plus one Tradition skill / +18 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2176 | Skill Points / 4 per level / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2176 | Hit Points / 6 per level / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2176 | BAB / BDB / Tertiary / Tertiary / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2176 | Saving Throws / Tertiary / Tertiary / Primary / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2176 | Casting infrastructure / Primary BSB; Primary CL; 4 PP per level / +37 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2176 | ADEPT CLASS TOTAL / Non-Constitution / Constitution / 69 / 73 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2177 | The chosen tradition is the first tradition and costs 0 DP. The number and identity of spells selected for the NPC are costed separately. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2178 | EXPERT NPC | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2179 | EXPERT NPC CLASS LEDGER | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2179 | Component / Entry / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2179 | Class Type / Expert / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2179 | Simple weapons / All Simple weapons / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2179 | Small-weapon supplement / Small weapons beyond Simple access / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2179 | Shortbow supplement / Shortbow family / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2179 | Armour proficiency / Light armour / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2179 | Shield proficiency / Bucklers / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2179 | Class Skills / 13 skills / +26 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2179 | Skill Points / 8 per level / +8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2179 | Hit Points / 8 per level / +8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2179 | BAB / BDB / Secondary / Primary / +18 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2179 | Saving Throws / Secondary / Primary / Tertiary / +9 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2179 | EXPERT CLASS TOTAL /  / 81 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2180 | The selected magical tradition grants no casting and therefore adds 0 DP. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2181 | HYBRID NPC | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2182 | HYBRID NPC CLASS LEDGER | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2182 | Component / Entry / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2182 | Class Types / Adept and Martial / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2182 | Weapon proficiency / All Simple and Martial weapons / +10 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2182 | Armour proficiency / Light and Medium armour / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2182 | Shield proficiency / Light and Heavy shields / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2182 | Class Skills / 7 fixed skills plus one Tradition skill / +16 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2182 | Skill Points / 4 per level / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2182 | Hit Points / 8 per level / +8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2182 | BAB / BDB / Primary / Primary / +26 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2182 | Saving Throws / Primary / Secondary / Tertiary / +9 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2182 | Casting infrastructure / Secondary BSB; Secondary CL; 2 PP per level / +17 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2182 | HYBRID CLASS TOTAL / Non-Constitution / Constitution / 96 / 100 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2183 | The Hybrid is the only NPC class carrying two mechanically meaningful Class Types. Actual spells remain separate. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2184 | MARTIAL NPC | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2185 | MARTIAL NPC CLASS LEDGER | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2185 | Component / Entry / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2185 | Class Type / Martial / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2185 | Weapon proficiency / All Simple and Martial weapons / +10 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2185 | Armour proficiency / All armour / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2185 | Shield proficiency / All shields including Tower / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2185 | Class Skills / 7 skills / +14 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2185 | Skill Points / 4 per level / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2185 | Hit Points / 10 per level / +12 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2185 | BAB / BDB / Primary / Primary / +26 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2185 | Saving Throws / Primary / Secondary / Tertiary / +9 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2185 | MARTIAL CLASS TOTAL /  / 83 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2186 | The selected magical tradition grants no casting and therefore adds 0 DP. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2187 | 14. APPLYING CLASS DP | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2188 | • Add the class total once. Never add both a default creature class and a replacement NPC or PC class. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2189 | • Add the caster variant only when the creature actually has the class casting infrastructure. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2190 | • Add every actual spell, cantrip, Specialist Spell, innate spell, High Magic benefit, or unusual casting rule separately. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2191 | • Natural attacks are not granted by natural-weapon proficiency. Cost the attacks in the race, heritage, or creature-ability layer. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2192 | • A proficiency repeated by race or another layer is counted once. Upgrades are costed by the difference between the smaller and larger packages. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2193 | • Creature and NPC Class DP has no independent target corridor. Assess the complete creature after type, race, heritage, size, class, attacks, and abilities have all been added. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2194 | 15. CREATURE OR NPC CLASS WORKSHEET | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2195 | CREATURE OR NPC CLASS WORKSHEET | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2195 | Component / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2195 | Class Type or Types /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2195 | Weapon proficiencies /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2195 | Armour proficiencies /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2195 | Shield proficiencies /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2195 | Class Skills /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2195 | Skill Points per level /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2195 | Fixed skill-rank progressions /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2195 | Hit Points per level /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2195 | BAB /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2195 | BDB /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2195 | Fortitude /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2195 | Reflex /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2195 | Will /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2195 | BSB /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2195 | Caster Level /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2195 | Power Points per level /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2195 | Magical ability surcharge /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2195 | Explicit class abilities or bonus feats /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2195 | CLASS DP TOTAL /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2196 | After the class ledger is complete, begin separate ledgers for spell access, natural attacks, size, race or subtype, heritage, and creature abilities. Combine the layers only after checking for repeated proficiencies, senses, immunities, and other overlap. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2197 | 16. CREATURE COMBAT COMPONENTS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2198 | After Creature Type and Class DP have been calculated, add the creature-specific components in this section. These values apply to creatures and NPCs whether they use a default creature class, an NPC class, or a PC class. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2199 | Creature Combat Components = Size Package + NPC Combat Package + movement speeds + senses + natural attacks. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2200 | • Cost every component in the layer that actually grants it. Do not repeat a sense, speed, attack, or bonus already contained in another package. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2201 | • Size supplies base HP, ability modifiers, space effects, and reach. It does not automatically grant a movement speed, sense, natural attack, or creature ability. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2202 | • Natural-attack damage changes with creature size and is therefore adjusted per attack, not hidden inside the general Size Package. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2203 | • Creature abilities that modify these components are costed later by their net effect. For example, Hover is added after Fly speed, and Earth Pass is added after Burrow speed. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2204 | 17. CREATURE SIZE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2205 | Creature size is a complete package because the Creature Codex assigns base HP and physical ability modifiers by size. Medium is the universal 0-DP size baseline, including its standard 30 base HP, 0 Strength and Dexterity modifiers, 5-foot reach, and ordinary space and equipment interactions. Every other size is costed by its net difference from that Medium baseline. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2206 | EXTENDED ABILITY MODIFIER COSTS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2206 | Modifier / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2206 | +1 / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2206 | +2 to the same ability / +9 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2206 | +3 to the same ability / +15 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2206 | +4 to the same ability / +22 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2206 | -1 / -3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2206 | -2 to the same ability / -5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2206 | -3 to the same ability / -7 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2206 | -4 to the same ability / -9 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2207 | The +3 and +4 entries continue the concentrated positive-ability progression. Negative modifiers remain less valuable as refunds because a creature can often minimise or avoid relying on a penalised ability. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2208 | RESIDUAL SIZE INTERACTION | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2208 | Size / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2208 | Diminutive / -6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2208 | Tiny / -4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2208 | Small / -2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2208 | Medium / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2208 | Large / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2208 | Huge / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2208 | Gargantuan / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2208 | Colossal / +8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2209 | This line covers occupied space, equipment scale and availability, carrying and manipulation constraints, confined-space advantages or disadvantages, and size-dependent manoeuvre interactions. It does not include ability scores, HP, reach, or natural-attack damage. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2210 | CREATURE REACH | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2210 | Reach / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2210 | 5 feet / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2210 | 10 feet / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2210 | 15 feet / +8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2210 | 20 feet / +12 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2210 | 25 feet / +16 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2211 | Use +4 DP for each 5 feet of reach beyond 5 feet. Reach expands threatened space, melee target access, and the area in which reactions and control effects can operate. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2212 | COMPLETE CREATURE SIZE PACKAGES | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2212 | Size / Base HP / Str / Dex / Reach / Size DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2212 | Diminutive / 0 / -3 / +3 / 5' / -4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2212 | Tiny / 10 / -2 / +2 / 5' / -4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2212 | Small / 20 / -1 / +1 / 5' / -3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2212 | Medium / 30 / 0 / 0 / 5' / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2212 | Large / 50 / +1 / -1 / 10' / +11 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2212 | Huge / 80 / +2 / -2 / 15' / +26 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2212 | Gargantuan / 120 / +3 / -3 / 20' / +44 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2212 | Colossal / 250 / +4 / -4 / 25' / +81 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2213 | Size Package calculation: residual size interaction + base HP difference from 30 at 1 DP per 5 HP + Strength modifier + Dexterity modifier + reach beyond 5 feet. The Gargantuan Dexterity entry is -3, following the stated size progression from Huge -2 to Colossal -4. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2214 | Do not add natural-attack die scaling to the Size Package. Apply the size step separately to every natural attack profile the creature possesses. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2215 | 18. UNIVERSAL NPC ATTACK AND DEFENCE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2216 | All creatures and NPCs receive additional scaling bonuses to their final Attack Bonus and Defence. These bonuses are not BAB or BDB and are therefore added after the selected class progression has been costed. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2217 | NPC COMBAT PACKAGE | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2217 | Component / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2217 | Other bonus to final AB equal to half level / +15 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2217 | Other bonus to final DB equal to half level / +11 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2217 | Status bonus to final DB equal to Class Bonus -2 / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2217 | COMPLETE NPC COMBAT PACKAGE / +32 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2218 | The half-level AB and DB lines are valued against the established Primary BAB and BDB progression anchors because each eventually supplies a +10 direct bonus at 20th level. The DB status line is lower because it begins below the ordinary Class Bonus and uses a typed status bonus that does not stack with a larger status bonus. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2219 | • Add the complete +32-DP package once to every creature or NPC, including one that uses a PC class. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2220 | • Do not add these values to BAB or BDB. They modify the final AB and DB totals and therefore stack with the class progressions unless another rule prevents the relevant bonus type from stacking. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2221 | • If a creature omits or replaces one of the three universal bonuses, subtract the listed component and cost the replacement normally. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2222 | 19. MOVEMENT SPEEDS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2223 | Land Speed continues to use the universal 25-foot baseline and costs 2 DP per 5-foot change. Every additional movement mode has an access premium plus 1 DP for each 5 feet of speed. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2224 | SPECIAL MOVEMENT FORMULA | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2224 | Movement mode / Access premium / Speed cost | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2224 | Climb / +4 / +1 per 5 feet | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2224 | Swim / +4 / +1 per 5 feet | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2224 | Burrow / +6 / +1 per 5 feet | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2224 | Fly / +8 / +1 per 5 feet | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2224 | COMMON SPECIAL MOVEMENT COSTS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2224 | Speed / Climb / Swim / Burrow / Fly | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2224 | 10 feet / +6 / +6 / +8 / +10 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2224 | 15 feet / +7 / +7 / +9 / +11 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2224 | 20 feet / +8 / +8 / +10 / +12 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2224 | 25 feet / +9 / +9 / +11 / +13 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2224 | 30 feet / +10 / +10 / +12 / +14 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2224 | 40 feet / +12 / +12 / +14 / +16 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2224 | 50 feet / +14 / +14 / +16 / +18 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2224 | 60 feet / +16 / +16 / +18 / +20 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2225 | Climb and Swim speeds remove most ordinary checks and grant a +4 circumstance bonus when checks remain necessary. Burrow bypasses surface terrain and barriers, but normally does not create a tunnel and may require breath and an appropriate sense. Fly receives the highest premium because it provides unrestricted three-dimensional positioning. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2226 | • A Swim speed does not include water breathing. Cost water breathing separately. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2227 | • A Fly speed does not include Hover. A creature without Hover must obey the ordinary flight rules; add Hover later as a Creature Ability. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2228 | • A Burrow speed does not include the ability to pass through worked stone, leave no trace beyond the normal rule, or see while underground. Cost those benefits separately. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2229 | • When a special speed replaces rather than supplements Land Speed, cost the special speed and separately apply the Land Speed reduction or absence. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2230 | 20. CREATURE SENSES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2231 | A special sense is costed by the quality of information it supplies, then adjusted for range. Tertiary senses provide limited awareness, Secondary senses locate valid targets under their stated conditions, and Primary senses provide the detail required to function as an ordinary primary sense. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2232 | SENSE GRADE COSTS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2232 | Sense grade / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2232 | Narrow or conditional Tertiary sense / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2232 | General Tertiary special sense / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2232 | Secondary special sense / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2232 | Primary special sense / +8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2232 | Primary sense at normal vision range / +10 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2232 | NAMED SENSE COSTS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2232 | Sense / DP / Application | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2232 | Nightvision / +2 / Normal vision range; treats light as one step higher | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2232 | Darkvision / +4 / Special visual range; treats light as two steps higher | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2232 | Perfect Darkvision / +6 / Functions in magical darkness and improves colour/detail | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2232 | Scent / +4 / Conditional Secondary sense; target must emit a scent | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2232 | Tremorsense / +5 / Secondary sense; ground or water contact and physical activity restrictions | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2232 | Blindsight / +8 / Primary-equivalent non-visual information at special-sense range | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2232 | Life Sense / +8 / Primary sense for living and undead vital essence | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2232 | Sonar or equivalent vision-range primary sense / +10 / Primary non-visual sense at normal visual range | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2232 | SENSE RANGE ADJUSTMENTS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2232 | Range relative to normal grade range / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2232 | Half or less / -1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2232 | Standard / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2232 | Double / +1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2232 | Four times / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2232 | Extreme range, such as one mile / +3 or individual | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2233 | Apply the range adjustment only when a stat block materially changes the normal range for that sense grade. A narrow sense with an extreme range may still cost less than a general Primary sense because the type of information remains limited. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2234 | • Darkvision and Nightvision may both be counted because they improve different lighting bands; the combined standard package remains +6 DP. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2235 | • Echolocation and Vibration Sense use the Blindsight value when they provide Primary-equivalent information. Use the Secondary value when the rule only locates targets without full primary detail. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2236 | • If a creature is blind but possesses equivalent Blindsight, apply the existing -2-DP blindness drawback after the sense cost, producing a normal +6-DP net package. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2237 | • Keen Sense, Acute Sense, bonuses to Perception, immunity to visual effects, Smokevision, Snowvision, and similar enhancements are separate abilities rather than additional senses. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2238 | 21. NATURAL ATTACKS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2239 | A natural attack is an innate weapon profile. Cost the attack itself separately from proficiency. The listed base values include its built-in availability, Brawling group, FDC 5, lack of price or carried weight, the printed attack size, and the Finesse trait common to the standard profiles. The attack's Size entry is the reference category for later damage-die scaling. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2240 | NATURAL ATTACK BASE DAMAGE | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2240 | Medium base damage / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2240 | 1d4 / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2240 | 1d6 / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2240 | 1d8 / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2240 | 1d10 / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2240 | 1d12 / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2240 | NATURAL ATTACK TRAIT ADJUSTMENTS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2240 | Trait or feature / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2240 | Finesse / Included in standard profile | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2240 | Agile / +1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2240 | Versatile with one additional physical damage type / +0.5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2240 | Additional meaningful attack trait / Cost by its actual effect | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2240 | STANDARD CREATURE ATTACKS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2240 | Attack / Damage / Base size / Traits beyond Finesse / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2240 | Bite / 1d8 P / M / None / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2240 | Claw / 1d6 S / S / Agile; Versatile P / +4.5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2240 | Gore / 1d8 P / M / None / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2240 | Hoof / 1d6 B / S / None / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2240 | Slam / 1d8 B / M / Agile / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2240 | Sting / 1d6 P / M / Agile / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2240 | Tail Slap / 1d8 B / M / Agile / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2240 | Tentacle / 1d6 B / S / None / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2240 | Unarmed Strike / 1d4 N / S / Agile / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2240 | Wings / 1d6 B / S / None / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2240 | NATURAL ATTACK SIZE ADJUSTMENT | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2240 | Creature size relative to listed attack size / Die steps / DP per attack | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2240 | Four categories smaller / -4 / -4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2240 | Three categories smaller / -3 / -3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2240 | Two categories smaller / -2 / -2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2240 | One category smaller / -1 / -1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2240 | Same category / 0 / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2240 | One category larger / +1 / +1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2240 | Two categories larger / +2 / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2240 | Three categories larger / +3 / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2240 | Four categories larger / +4 / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2241 | Compare the creature size with the Base size printed in the natural attack profile, then shift the damage die along the official ladder: 1, 1d2, 1d3, 1d4, 1d5, 1d6, 1d8, 1d10, 1d12, 1d16, 1d20, 1d30, 1d40. Apply one DP per die step to that attack profile. A completed natural attack cannot fall below +1 DP. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2242 | • Cost each mechanically distinct attack profile. Bite and Claw are separate; two identical claws using one profile are counted once unless another rule creates additional simultaneous attacks. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2243 | • Additional limbs do not automatically grant extra actions or attacks. Multiattack routines, Rend, Double Strike, Draconic Assault, and similar benefits are Creature Abilities and are costed later. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2244 | • Attack size, reach different from the creature, magical attacks, secondary damage, poison, Grab, Knockdown, and other riders are not contained in the standard attack cost. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2245 | • The BAB cost already includes the normal bonus-damage thresholds. Do not charge those thresholds again, but use the size-adjusted base die when the rules require it. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2246 | 22. WORKED COMPONENT EXAMPLES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2247 | WORKED EXAMPLES | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2247 | Component / Calculation / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2247 | Medium creature size / 30 HP baseline 0; abilities 0; reach 0; size interaction 0 / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2247 | Large creature size / 20 HP above Medium +4; Str +1 +4; Dex -1 -3; reach +4; size +2 / +11 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2247 | Huge creature size / 50 HP above Medium +10; Str +2 +9; Dex -2 -5; reach +8; size +4 / +26 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2247 | Fly 40 feet / Fly access +8; eight 5-foot units +8 / +16 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2247 | Tremorsense at standard range / Secondary special sense / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2247 | Large Bite / Bite +4; one larger die step +1 / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2247 | Tiny Claw / Claw +4.5; Tiny is one category below its Small base size -1 / +3.5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2247 | Universal NPC combat package / AB +15; DB +11; DB status +6 / +32 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2248 | 23. CREATURE COMBAT COMPONENT WORKSHEET | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2249 | CREATURE COMBAT COMPONENT WORKSHEET | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2249 | Component / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2249 | Residual size interaction /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2249 | Base HP difference from Medium (30 HP) /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2249 | Strength from size /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2249 | Dexterity from size /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2249 | Reach /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2249 | SIZE PACKAGE TOTAL /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2249 | Half-level AB bonus / +15 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2249 | Half-level DB bonus / +11 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2249 | Class Bonus -2 DB status bonus / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2249 | NPC COMBAT PACKAGE TOTAL / +32 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2249 | Land Speed adjustment /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2249 | Climb Speed /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2249 | Swim Speed /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2249 | Burrow Speed /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2249 | Fly Speed /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2249 | Senses /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2249 | Natural attack profiles /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2249 | Natural attack size adjustments /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2249 | CREATURE COMBAT COMPONENT TOTAL /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2250 | The completed worksheet is added to Type DP, Race or Subtype DP, Heritage DP, Class DP, spells, Creature Abilities, and any exceptional equipment or template adjustments. The next construction stage costs the Creature Abilities listed in the Creature Codex. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2252 | 24. CREATURE ABILITY COSTING | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2253 | Creature Abilities are costed by their complete mechanical effect. They do not receive one universal category value. Use the nearest established feat, spell, skill, defence, movement, sense, attack, or action-economy anchor, then adjust for delivery, frequency, action cost, area, targets, scaling, required checks, saving throws, and restrictions. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2254 | • Cost a passive or triggered ability once for its complete operation; do not charge again each time it activates. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2255 | • A level-scaling ability is costed for its complete 1st-to-20th-level progression rather than recalculated at each level. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2256 | • Spell-like effects that use the ordinary casting process use the spell schedules in Chapter 4. When no casting check is required, add the appropriate innate or automatic-delivery premium. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2257 | • A constant damaging or controlling aura normally uses the equivalent spell value plus the +7 constant-availability premium, then adjusts for radius, target restrictions, repeat exposure, and additional riders. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2258 | • Repeated auras are costed on the assumption that an eligible target can be affected again whenever it begins its turn in, or enters, the area unless the ability grants immunity. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2259 | • An ability that duplicates the creature, its actions, or its entire spell package must include the value of the duplicated action economy and cannot be priced only from its triggering damage type. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2260 | • Traits and descriptive tags are 0 DP unless they create a separate rules interaction. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2261 | CREATURE ABILITY DELIVERY GUIDANCE | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2261 | Delivery / Treatment | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2261 | Ordinary check and ordinary resource cost / Use the underlying effect value without an availability premium. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2261 | PP cost but no casting check / Use the comparable spell value and normally add +1 DP. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2261 | Limited daily, Focus, at-will, or constant use / Use the innate availability premiums in Chapter 4 as the starting adjustment. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2261 | Automatic passive trigger / Assess trigger frequency and whether it consumes a reaction, AP, or another resource. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2261 | Constant aura / Comparable spell or condition value + constant delivery, then adjust for area and repeat exposure. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2261 | Self-duplication or additional full action set / Cost the additional action economy and every duplicated offensive or utility function. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2262 | 25. CREATURE ABILITY COSTS — ABSORB MINERALS TO AURA OF TRANQUILITY | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2263 | The following values are the complete costs of the printed abilities. They assume the wording in the Creature Abilities document, including the stated action cost, area, saving throw, frequency, and target restrictions. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2264 | CREATURE ABILITY DP — FIRST ALPHABETICAL BLOCK | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2264 | Ability / DP / Costing basis | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2264 | Absorb Minerals / +4 / Situational at-will healing equal to half the actual damage dealt to metal objects. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2264 | Abyssal Healing / +16 / PP-scaled automatic healing or condition recovery with three selectable modes and 1 AP delivery. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2264 | Acute Sense / +2 / +2 racial bonus to one named action associated with a selected sense. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2264 | Alien Mind / +7 / Automatic 4d6 mental retaliation, basic Will save, whenever a mental effect targets the creature. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2264 | All Round Vision / +3 / Constant immunity to flanking; narrower than the +5 cannot-be-Flanked-and-Flat-Footed bundle. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2264 | Amorphous Split / +25 / Conserves total HP but duplicates the complete action set; includes recursive splitting above 20 HP. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2264 | Arcadian Caster / +18 / No casting reactions, universal Specialist treatment, and combined Arcane/Ethereal acquisition. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2264 | Ashen Aura / +14 / Constant 20-foot 4d6 poison aura with concealment in both directions. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2264 | Aura of Confusion / +19 / Constant repeated control aura; even a success causes Stunned 1 and failures cause Confused. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2264 | Aura of Death / +12 / Constant 30-foot 4d6 essence aura, basic Fortitude, restricted to living creatures. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2264 | Aura of Decay / +13 / Constant 30-foot 4d8 poison aura, basic Fortitude. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2264 | Aura of Despair / +22 / Constant repeated fear/paralysis aura with severe results through unconsciousness at 0 HP. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2264 | Aura of Fire / +12 / Constant 20-foot 4d6 fire aura, basic Reflex. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2264 | Aura of Heat / +11 / Constant 20-foot 2d6 fire aura, basic Reflex. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2264 | Aura of Ruin / +6 / Constant narrow alignment-targeted aura causing Sickened 1, or 2 on a fumble. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2264 | Aura of Tranquility / +6 / Constant 30-foot allied advantage against fear and charm saves. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2265 | COMPLEX ABILITY LEDGERS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2266 | COMPLEX ABILITY LEDGERS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2266 | Ability / Component / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2266 | Abyssal Healing / PP-scaled Specialist-equivalent effect through PP 20 / +14 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2266 | Abyssal Healing / Automatic 1 AP delivery without an ordinary casting check / +1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2266 | Abyssal Healing / Healing, Bleed Control, or Injury Recovery flexibility / +1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2266 | ABYSSAL HEALING TOTAL /  / +16 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2266 | Amorphous Split / Creates a second complete action set while conserving total current HP / +20 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2266 | Amorphous Split / Resulting copies may split again while above 20 HP / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2266 | AMORPHOUS SPLIT TOTAL /  / +25 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2266 | Arcadian Caster / Spellcasting does not provoke reactions / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2266 | Arcadian Caster / All spells receive universal Specialist treatment / +9 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2266 | Arcadian Caster / Additional Arcane/Ethereal tradition access / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2266 | Arcadian Caster / Ethereal Learned self-learning / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2266 | ARCADIAN CASTER TOTAL /  / +18 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2267 | AURA COSTING NOTES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2268 | Damage auras use the closest ordinary spell value and the +7 constant-availability premium. A 20-foot 4d6 basic-save aura is therefore +12 DP; 2d6 is +11 DP; increasing the damage to 4d8 or materially increasing the area normally adds +1 DP. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2269 | Ashen Aura adds +2 DP for its two-way concealment rider. Aura of Death retains +12 DP because its larger area is offset by affecting only living creatures. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2270 | Aura of Confusion and Aura of Despair are not priced as ordinary damage auras. Their repeated loss-of-action and encounter-ending results use high-PP control effects as the base before constant delivery is added. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2271 | Aura of Ruin receives a substantial reduction because it affects only good or ordered targets and imposes a modest condition. Aura of Tranquility uses the +4 broad contextual advantage anchor and adds +2 DP for constant multi-target allied delivery. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2272 | APPLICATION NOTES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2273 | • If Amorphous Split is rewritten so that each creature may split only once, reduce its cost from +25 to +20 DP. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2274 | • The Abyssal Healing value assumes the creature may choose how many levels of effect to purchase, spending 1 PP per selected level, and that no Spellcraft check is required. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2275 | • The Arcadian Caster value assumes “as if Specialist” grants the complete Specialist treatment established by the spell rules. If it only lowers the casting difficulty, reassess the +9 Specialist component. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2276 | • Aura costs must be reduced if the aura is indiscriminate and regularly harms the creature’s allies, but only when that drawback is unavoidable in ordinary play. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2277 | • Do not add separate DP for the magical traditions or traits printed on an ability unless the creature gains access or another mechanical benefit from them. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2278 | CREATURE ABILITY WORKSHEET | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2278 | Component / Mechanical basis / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2278 | Base effect /  /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2278 | Action or reaction cost /  /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2278 | Frequency and recovery /  /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2278 | Resource cost /  /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2278 | Required check or saving throw /  /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2278 | Range, area, and targets /  /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2278 | Duration and repeat exposure /  /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2278 | Scaling /  /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2278 | Restrictions and drawbacks /  /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2278 | Overlap or replacement /  /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2278 | CREATURE ABILITY TOTAL /  /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2280 | 26. CREATURE ABILITY COSTS — BLIGHT SENSE TO CORRODE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2281 | This block covers specialist senses and abilities whose value depends upon an attack, breath weapon, or secondary-damage profile. The supporting attack or breath weapon is costed separately; the Creature Ability cost represents only the additional delivery, repeat damage, targeting, or equipment-damage benefit. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2282 | CREATURE ABILITY DP — SECOND ALPHABETICAL BLOCK | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2282 | Ability / DP / Costing basis | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2282 | Blight Sense / +2 / Narrow Tertiary sense detecting creatures that are cursed, diseased, or poisoned. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2282 | Blood Scent / +5 / Narrow Tertiary blood-detection sense (+2) with extreme range of up to one mile (+3). | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2282 | Clinging Breath / +6 / Free delayed rider that repeats half the breath weapon dice as acid damage after a basic Fortitude save. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2282 | Constrict / +8 / One-action, save-based damage against any number of targets already grabbed or restrained by the creature. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2282 | Corrode / +5 / Automatic transfer of secondary damage to a target's metal armour and, where applicable, shield. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2283 | DEPENDENT ABILITY LEDGERS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2284 | DEPENDENT ABILITY LEDGERS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2284 | Ability / Component / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2284 | Blood Scent / Narrow or conditional Tertiary sense / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2284 | Blood Scent / Extreme range: up to one mile / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2284 | BLOOD SCENT TOTAL /  / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2284 | Clinging Breath / Level-scaling follow-up damage equal to half the breath dice / +7 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2284 | Clinging Breath / One-round delay and a new basic Fortitude save / -2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2284 | Clinging Breath / Free delivery to every qualifying breath target / +1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2284 | CLINGING BREATH TOTAL /  / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2284 | Constrict / Reliable 1 AP damage against held targets / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2284 | Constrict / May affect any number of targets grabbed or restrained by the creature / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2284 | CONSTRICT TOTAL /  / +8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2284 | Corrode / Automatic equipment damage equal to secondary damage inflicted / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2284 | Corrode / Restricted to metal armour; shield damage is split rather than duplicated / -1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2284 | CORRODE TOTAL /  / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2285 | APPLICATION NOTES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2286 | • Blood Scent is treated as a narrow Tertiary sense because the printed ability only states that the creature can smell blood; it does not state that the sense supplies full Scent-quality positional information. If it is intended to function as complete Scent at one-mile range, use +7 DP instead. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2287 | • Clinging Breath assumes the creature already possesses and has paid for a breath weapon. The +6 DP value covers only the delayed half-damage rider and does not include the breath weapon itself. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2288 | • Constrict assumes its listed damage is broadly comparable to one of the creature’s ordinary natural attacks. Increase or reduce the ability by 1 DP for each material base-die step by which the listed Constrict damage exceeds or falls below that attack profile. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2289 | • The Constrict requirement, 1 AP cost, and basic Fortitude save are already included in the +8 DP value. Do not apply a second discount for those restrictions. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2290 | • Corrode has no value on a creature that cannot inflict secondary damage. Add it only when at least one qualifying attack or ability is present. Multiple qualifying attacks do not increase its cost because the broad trigger is already included. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2291 | • Damage to equipment is separate from HP damage. Corrode does not increase the damage suffered by the target creature unless the equipment-damage rules create an independent consequence. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2293 | 27. CREATURE ABILITY COSTS - CRUSH TO EARTH PASS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2294 | This block covers attack routines, attack-triggered magic, movement-and-attack compression, transformation, draining, and a burrow upgrade. The creature must separately pay for every required natural attack, movement speed, breath weapon, aura, skill, or spellcasting component. The values below cost only the additional benefit created by the named ability. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2295 | CREATURE ABILITY DP - THIRD ALPHABETICAL BLOCK | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2295 | Ability / DP / Costing basis | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2295 | Crush / +16 / One-action repeatable space-control attack with severe scaling damage, automatic critical injuries, DR bypass, and movement conditions. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2295 | Detect Magic / +6 / Passive magical detection, +2 Sense Magic, and expanded access to Power Manipulation actions. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2295 | Dispelling Strike / +9 / Free 0 PP Dispel attempt whenever a melee Strike hits. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2295 | Diving Strike / +5 / Compresses two Fly Strides and one claw Strike into 2 AP and grants +2 to the attack, with strict movement requirements. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2295 | Double Strike / +7 / Two attacks for 1 AP without applying MAP between them, restricted to separate targets and different limbs. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2295 | Draconic Assault / +6 / Three fixed natural attacks for 2 AP; ordinary MAP still applies. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2295 | Draconic Roar / +8 / Once-per-hour breath-weapon damage delivered throughout the Frightful Aura area after a basic Fortitude save. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2295 | Draconic Shifting / +4 / At-will humanoid transformation with retained movement and attack modifiers but reduced attack lethality. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2295 | Drink Blood / +9 / One-action Soul Drain 10 and equal healing against a willing, helpless, or controlled adjacent target. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2295 | Earth Pass / +4 / Upgrades an existing Burrow Speed to full-speed movement through dirt and stone without leaving a tunnel or trace. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2296 | COMBAT ACTION ABILITY LEDGERS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2297 | COMBAT ACTION ABILITY LEDGERS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2297 | Ability / Component / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2297 | Crush / One-action repeatable save-based damage profile, averaging approximately 4d10 / +10 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2297 | Crush / Minor, Serious, or Deadly critical injury on poor save results / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2297 | Crush / Damage bypasses all DR / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2297 | Crush / Forced movement, Prone, and Immobilised outcomes / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2297 | Crush / Requires the target to be at least two sizes smaller and inside the creature's space / -2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2297 | CRUSH TOTAL /  / +16 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2297 | Diving Strike / One AP of action compression: two Fly Strides plus one Strike for 2 AP / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2297 | Diving Strike / +2 circumstance bonus to the claw Strike / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2297 | Diving Strike / Straight-line flight, 10-foot descent, Fly Speed, and claw restrictions / -1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2297 | DIVING STRIKE TOTAL /  / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2297 | Double Strike / Second Strike included in the same 1 AP action / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2297 | Double Strike / MAP does not apply until both Strikes are resolved / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2297 | Double Strike / Different limbs and separate targets are mandatory / -1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2297 | DOUBLE STRIKE TOTAL /  / +7 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2297 | Draconic Assault / Third Strike included in a 2 AP three-attack routine / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2297 | Draconic Assault / Fixed two-claw-then-other-natural-attack routine / -1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2297 | Draconic Assault / Broad value of retaining 1 AP after a full three-attack routine / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2297 | DRACONIC ASSAULT TOTAL /  / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2298 | MAGICAL, DRAINING, AND UTILITY ABILITY LEDGERS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2299 | MAGICAL, DRAINING, AND UTILITY ABILITY LEDGERS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2299 | Ability / Component / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2299 | Detect Magic / Passive detection of active magic as a narrow magical sense / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2299 | Detect Magic / +2 racial bonus to Sense Magic checks / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2299 | Detect Magic / May develop Power Manipulation without prerequisites and use Sense Power untrained / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2299 | DETECT MAGIC TOTAL /  / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2299 | Dispelling Strike / At-will 0 PP Dispel attempt / +7 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2299 | Dispelling Strike / Free automatic delivery after a successful melee Strike / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2299 | Dispelling Strike / Requires a melee hit and a dispellable effect on the target / -1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2299 | DISPELLING STRIKE TOTAL /  / +9 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2299 | Draconic Roar / Area delivery of the creature's existing breath-weapon damage / +8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2299 | Draconic Roar / Frightful Aura radius can substantially exceed a normal breath area / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2299 | Draconic Roar / Once per hour and requires both a breath weapon and Frightful Aura / -3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2299 | DRACONIC ROAR TOTAL /  / +8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2299 | Draconic Shifting / At-will Small or Medium humanoid transformation / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2299 | Draconic Shifting / Retains Speed and Strike modifiers but physical Strikes become subdual unarmed attacks / -1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2299 | DRACONIC SHIFTING TOTAL /  / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2299 | Drink Blood / Soul Drain 10 against a qualifying adjacent target / +7 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2299 | Drink Blood / Healing equal to the Soul Drain inflicted / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2299 | Drink Blood / 1 AP, target-state requirement, and Athletics check against a merely Grabbed target / -2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2299 | DRINK BLOOD TOTAL /  / +9 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2299 | Earth Pass / Burrow through dirt and stone rather than ordinary loose material / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2299 | Earth Pass / Leaves no tunnel or sign of passage / +1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2299 | EARTH PASS TOTAL /  / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2300 | APPLICATION NOTES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2301 | • Crush assumes that activating the ability creates or maintains the crushing position and that qualifying targets make the printed save when their turns begin. The creature's size, reach, movement, and any ability allowing it to enter another creature's space are separate costs. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2302 | • Crush is costed as printed, including DR bypass and automatic critical injuries. If critical injuries are removed, reduce the cost by 3 DP. If the damage no longer bypasses DR, reduce it by 2 DP. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2303 | • Detect Magic grants no general spellcasting, spell identification, or Dispel capability beyond the actions specifically stated. Those benefits remain separate. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2304 | • Dispelling Strike uses the creature's normal Dispel check and does not guarantee that an effect is removed. A version that automatically dispels on a hit requires a substantially higher individual assessment. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2305 | • Diving Strike and Double Strike include their action compression. Do not also cost the saved AP as a separate creature feature. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2306 | • Double Strike is valued on the assumption that both attacks use the creature's current attack bonus before MAP and that the attacks must target two different creatures. If both attacks may target one creature, increase the cost to +9 DP. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2307 | • Draconic Assault applies ordinary MAP in sequence because the printed ability does not suspend or delay it. If all three attacks ignore MAP until the routine ends, increase the cost from +6 to +10 DP. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2308 | • Draconic Roar does not include the costs of the breath weapon or Frightful Aura. If either required component is absent, the ability has no functional value. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2309 | • Drink Blood assumes that Soul Drain 10 and healing 10 occur once per successful use. It does not include the cost of the required bite attack or any Grab ability used to establish the target state. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2310 | • Earth Pass is an upgrade to an existing Burrow Speed. A creature without a Burrow Speed must first buy that movement form before adding Earth Pass. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2312 | 28. CREATURE ABILITY COSTS - ECHOLOCATION TO ETERNAL SUMMONS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2313 | This block covers special senses, automatic elemental damage, attack-wide elemental enhancement, reaction-free movement, an undefined behavioural drawback, an at-will area attack, the established Eternal Essence package, and Focus-limited summoning. Supporting Grab abilities, physical attacks, spellcasting, movement, armour, and summoned creature statistics are not added again unless the notes state otherwise. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2314 | CREATURE ABILITY DP - FOURTH ALPHABETICAL BLOCK | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2314 | Ability / DP / Costing basis | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2314 | Echolocation / +7 / Passive Primary auditory sense at half the normal range of a Primary sense. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2314 | Elemental Grasp / +8 / Automatic 3d6 elemental damage to each grabbed target at the beginning of its turn, basic Reflex save. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2314 | Elemental Aura / +10 / Toggleable constant 10-foot aura inflicting 2d6 elemental damage with a basic Reflex save. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2314 | Elemental Blood / +4 / Conditional elemental splash damage equal to persistent Bleed suffered by the creature. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2314 | Elemental Strikes / +7 / All physical attacks gain 1d6 secondary elemental damage; existing elemental secondary damage is doubled. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2314 | Elusive Movement / +6 / The creature never provokes reactions caused by movement. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2314 | Endless Hunger / 0 / Narrative compulsion without a defined check, condition, starvation schedule, or enforceable combat penalty. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2314 | Entangling Vines / +12 / At-will 1 AP, 20-foot-radius 4d6 piercing attack; failed saves also impose Grabbed. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2314 | Eternal Essence / +12 / Established package: all FDC reduced by 1 and all armour and shield penalties ignored. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2314 | Eternal Summons / +27 / Focus-limited 2 AP summoning of one or several lower-level eternals with independent actions and encounter duration. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2315 | SENSE, ELEMENTAL, AND MOVEMENT LEDGERS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2316 | SENSE, ELEMENTAL, AND MOVEMENT LEDGERS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2316 | Ability / Component / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2316 | Echolocation / Primary special sense / +8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2316 | Echolocation / Range is half the normal Primary-sense range / -1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2316 | ECHOLOCATION TOTAL /  / +7 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2316 | Elemental Grasp / Automatic repeat 3d6 elemental damage at the start of each grabbed target's turn / +8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2316 | Elemental Grasp / Can affect every target currently grabbed by the creature / +1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2316 | Elemental Grasp / Requires Grabbed and permits a basic Reflex save / -1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2316 | ELEMENTAL GRASP TOTAL /  / +8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2316 | Elemental Aura / Constant 20-foot 2d6 basic-save aura anchor / +11 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2316 | Elemental Aura / Reduced radius: 10 feet rather than 20 feet / -1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2316 | ELEMENTAL AURA TOTAL /  / +10 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2316 | Elemental Blood / Automatic elemental splash equal to the creature's persistent Bleed / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2316 | Elemental Blood / Only functions while the creature is taking persistent Bleed and may catch allies / -1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2316 | ELEMENTAL BLOOD TOTAL /  / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2316 | Elemental Strikes / 1d6 secondary elemental damage on every physical attack / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2316 | Elemental Strikes / Existing secondary elemental damage is doubled / +1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2316 | ELEMENTAL STRIKES TOTAL /  / +7 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2316 | Elusive Movement / Constant immunity to all reactions triggered by movement / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2316 | ELUSIVE MOVEMENT TOTAL /  / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2317 | CONTROL, DRAWBACK, AND ETERNAL LEDGERS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2318 | CONTROL, DRAWBACK, AND ETERNAL LEDGERS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2318 | Ability / Component / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2318 | Endless Hunger / No defined mechanical consequence, compulsory check, action restriction, or starvation interval / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2318 | ENDLESS HUNGER TOTAL /  / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2318 | Entangling Vines / At-will 1 AP, 20-foot-radius 4d6 piercing damage with a basic Reflex save / +9 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2318 | Entangling Vines / Failure also imposes Grabbed / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2318 | Entangling Vines / Indiscriminate area and requirement for vines to erupt from the earth / -1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2318 | ENTANGLING VINES TOTAL /  / +12 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2318 | Eternal Essence / Universal reduction of all FDC by 1 / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2318 | Eternal Essence / Ignore ACP, Maximum Dexterity, Speed Penalty, and comparable armour or shield drawbacks / +7 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2318 | ETERNAL ESSENCE TOTAL /  / +12 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2318 | Eternal Summons / Focus version of a scaling Conjure Eternal effect through the PP 20 ceiling / +16 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2318 | Eternal Summons / No Sustain cost; summoned creatures act independently immediately after the summoner / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2318 | Eternal Summons / Choice of one level -4, two level -6, or four level -8 allies / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2318 | Eternal Summons / Encounter-plus duration and placement adjacent within 20 feet / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2318 | Eternal Summons / 2 AP, same-subtype restriction, and summoned creatures cannot repeat the ability / -1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2318 | ETERNAL SUMMONS TOTAL /  / +27 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2319 | APPLICATION NOTES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2320 | • Echolocation uses the Primary special-sense anchor and the standard -1 DP adjustment for half range. The Auditory trait means effects that remove hearing can suppress the sense; do not apply another drawback unless the ability has an additional explicit vulnerability. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2321 | • Elemental Grasp requires the creature to establish and maintain Grabbed through another attack or ability. That enabling Grab effect is costed separately. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2322 | • Elemental Aura is compared directly with Aura of Heat. Its Free toggle does not increase the cost because the ability is already priced as a controllable constant effect. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2323 | • Elemental Blood is costed on the assumption that splash damage uses the ordinary local splash area. If “all targets” is intended to have unlimited range or to affect every enemy in the encounter, the wording must be clarified and the ability reassessed. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2324 | • Elemental Strikes is costed once for the broad attack-wide enhancement, not once per physical attack profile. The +7 DP value assumes the doubled-damage clause only doubles secondary elemental dice already present; it does not double unrelated static modifiers or primary damage. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2325 | • Endless Hunger receives no DP refund as written. A drawback must define an enforceable limitation, condition, check, resource requirement, or consequence before it can reduce a creature's total. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2326 | • Entangling Vines is treated as at will because no frequency or PP cost is listed. If it gains a recovery limit, Focus requirement, or daily limit, reduce the availability component accordingly. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2327 | • Eternal Essence is already included as a +12 DP line in the Eternal creature-type ledger. Do not add it again to an ordinary Eternal. Use the stand-alone +12 DP value only when another package independently grants the complete ability. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2328 | • Eternal Summons treats Focus according to the established Focus availability rule: one use before Refocus, renewable but not repeatable in immediate succession. The cost includes the summoned creatures and their additional action economy; do not add their individual Type, Class, Size, attack, or ability DP to the summoner. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2329 | • Eternal Summons assumes the printed creatures act without a Sustain or Command action because they act immediately after the summoner and no ongoing command cost is stated. Requiring Sustain or Command each round would reduce the ability by approximately 3 DP. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2331 | 29. CREATURE ABILITY COSTS - FAULTLESS CASTING TO HOLD BREATH | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2332 | This block covers defensive spellcasting, situational compulsions, ability-score substitution, elemental healing, movement-and-attack compression, a scaling fear aura, conditional burst movement, a condition-based repulsion, a mixed social package, and extended breath holding. Required spell access, Fly Speed, claw attacks, ordinary movement, and any independent fire immunity are not added again except where the printed ability itself necessarily supplies them. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2333 | CREATURE ABILITY DP - FIFTH ALPHABETICAL BLOCK | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2333 | Ability / DP / Costing basis | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2333 | Faultless Casting / +3 / Every spell is defensively cast at its ordinary DC; fumbles and blunders can still provoke. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2333 | Fear of Water / -1 / Cannot voluntarily cross running water, but carriage and wooden vessels provide practical bypasses. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2333 | Fearful Strength / +2 / May substitute Strength for Charisma on all Intimidate checks. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2333 | Fire Healing / +12 / Fire damage is converted into half-value healing, with recovery and condition-removal benefits. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2333 | Flyby Attack / +4 / Compresses one Fly Stride and two claw Strikes into 2 AP, with attacks during movement and separate targets. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2333 | Frightful Aura / +18 / Free scaling fear aura with severe results through fleeing and collapse at 0 HP; one-minute target immunity. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2333 | Gallop / +3 / Each of two consecutive Strides gains 10 feet of movement. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2333 | Garlic Repulsion / -3 / Garlic odour imposes Sickened 1 or 2 and bypasses immunity or resistance to Sickened. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2333 | Grave-Touched Presence / +2 / Two narrow +2 skill bonuses, offset by a broad but concealable attitude penalty. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2333 | Hold Breath / +1 / Can hold its breath for ten times the ordinary duration. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2334 | CASTING, HEALING, AND ATTACK LEDGERS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2335 | CASTING, HEALING, AND ATTACK LEDGERS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2335 | Ability / Component / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2335 | Faultless Casting / All spells automatically use Defensive Casting without the normal Very Hard (+5 DC) increase / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2335 | FAULTLESS CASTING TOTAL /  / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2335 | Fearful Strength / Strength may replace Charisma for the complete Intimidate skill / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2335 | FEARFUL STRENGTH TOTAL /  / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2335 | Fire Healing / Fire damage is negated and converted into healing equal to half the incoming damage / +9 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2335 | Fire Healing / Natural recovery rate doubles while standing in a fire at least the creature's size / +1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2335 | Fire Healing / At full HP, fire exposure may remove Bleeding 2 or reduce another condition by 1 / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2335 | FIRE HEALING TOTAL /  / +12 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2335 | Flyby Attack / One AP of compression: one Fly Stride and two claw Strikes are completed for 2 AP / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2335 | Flyby Attack / The attacks may occur at any points during the movement / +1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2335 | Flyby Attack / Requires Fly Speed and claws, and the attacks must target separate creatures / -1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2335 | FLYBY ATTACK TOTAL /  / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2336 | FEAR, MOVEMENT, AND DRAWBACK LEDGERS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2337 | FEAR, MOVEMENT, AND DRAWBACK LEDGERS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2337 | Ability / Component / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2337 | Fear of Water / Cannot voluntarily cross running water / -2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2337 | Fear of Water / May be carried across or use a wooden vessel / +1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2337 | FEAR OF WATER TOTAL /  / -1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2337 | Frightful Aura / Level-based fear effect ranging from Frightened 1 to fleeing or collapse at 0 HP / +16 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2337 | Frightful Aura / Radius scales at 5 feet per creature level / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2337 | Frightful Aura / Free activation or maintenance / +1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2337 | Frightful Aura / Each target becomes immune for 1 minute after its save / -2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2337 | FRIGHTFUL AURA TOTAL /  / +18 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2337 | Gallop / +10 feet to each of two consecutive Stride actions / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2337 | Gallop / Only applies when two Strides are taken consecutively in the same turn / -1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2337 | GALLOP TOTAL /  / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2337 | Garlic Repulsion / Sickened 1 within garlic odour and Sickened 2 within 5 feet, overriding immunity or resistance / -4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2337 | Garlic Repulsion / Situational physical trigger that can usually be avoided by distance / +1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2337 | GARLIC REPULSION TOTAL /  / -3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2337 | Grave-Touched Presence / +2 Intimidate against undead / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2337 | Grave-Touched Presence / +2 Sense Motive against undead / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2337 | Grave-Touched Presence / Living humanoids and intelligent undead begin one attitude step worse unless nature is concealed; listed exceptions apply / -2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2337 | GRAVE-TOUCHED PRESENCE TOTAL /  / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2337 | Hold Breath / Breath-holding duration multiplied by ten / +1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2337 | HOLD BREATH TOTAL /  / +1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2338 | APPLICATION NOTES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2339 | • Faultless Casting does not make spellcasting completely reaction-proof. Under the Defensive Casting rule, a fumble or blunder still provokes. The +3 DP value reflects reliable defensive casting at the spell's normal DC rather than absolute immunity to casting reactions. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2340 | • Fear of Water is a genuine but highly avoidable restriction. It receives only -1 DP because another creature can carry the creature and an ordinary wooden vessel bypasses the prohibition. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2341 | • Fearful Strength is a substitution rather than an added modifier. Use the better of Strength or Charisma for Intimidate; do not add both ability modifiers. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2342 | • Fire Healing is costed on the rules interpretation that fire damage is converted into healing and is not also suffered as damage. If the creature still takes the fire damage before healing half, reduce the ability from +12 to +8 DP. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2343 | • Fire Healing includes its effective fire immunity within the +12 DP total. Do not also add a separate Fire Immunity entry unless another rule grants a broader or independently functioning immunity. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2344 | • Flyby Attack uses ordinary MAP because the printed ability does not suspend or delay it. If both claw attacks are resolved before MAP applies, increase the cost from +4 to +7 DP. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2345 | • Frightful Aura affects each eligible creature only when it first enters the aura and then grants one minute of immunity regardless of the save result. It is therefore cheaper than Aura of Despair despite its level-scaling radius and severe failure results. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2346 | • Gallop increases the distance of the two qualifying Strides; it does not permanently increase the creature's Speed and does not reduce the AP cost of those Strides. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2347 | • Garlic Repulsion is a drawback and therefore reduces the creature's DP. The value assumes garlic is reasonably obtainable but that maintaining the odour and remaining within 5 feet require deliberate preparation and positioning. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2348 | • Grave-Touched Presence treats each +2 bonus as a whole-skill bonus narrowed to undead. The attitude penalty is reduced because the creature can conceal its nature and because familiar or culturally accustomed creatures ignore it. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2349 | • Hold Breath does not include underwater breathing or immunity to inhaled effects. A creature that does not need to breathe uses the separate +2 DP anchor instead. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2351 | 30. CREATURE ABILITY COSTS - HOVER TO MONSTROUS GRAB | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2352 | This block covers sustained flight, an activated fear effect, ice-specific movement, a close-range poison aura, Perception enhancement, on-hit draining, a primary special sense, limited dispelling, and improved Grapple attempts. Required Fly Speed, land Speed, unarmed attacks, Power Manipulation training, and ordinary Grapple access are costed separately. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2353 | CREATURE ABILITY DP - SIXTH ALPHABETICAL BLOCK | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2353 | Ability / DP / Costing basis | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2353 | Hover / +5 / Removes the recurring AP expenditure needed to remain airborne, but requires an existing Fly Speed. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2353 | Howl / +8 / One-action 30-foot fear effect with results through Frightened 3 and fleeing; each target then gains 10-minute immunity. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2353 | Ice Climb / +5 / Uses full land Speed as a Climb Speed on ice and ignores snow- and ice-based difficult or formidable terrain. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2353 | Ice Stride / +2 / Ignores snow- and ice-based difficult terrain and removes balance checks on slippery ice. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2353 | Infestation / +8 / Constant repeating 5-foot 1d6 poison aura with a basic Fortitude save. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2353 | Keen Sense / +4 / +2 racial bonus to the complete Perception skill. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2353 | Life Drain / +12 / Every damaging unarmed hit heals 3 HP and can inflict accumulating Soul Drain after a Fortitude save. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2353 | Life Sense / +8 / Primary special sense that distinguishes living and undead vital essence. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2353 | Magic Dispelling / +5 / Three ordinary Dispel attempts per day without spending PP. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2353 | Monstrous Grab / +9 / +4 racial bonus to Grapple and Grapple attempts ignore multiple attack penalty. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2354 | MOVEMENT, AURA, AND FEAR LEDGERS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2355 | MOVEMENT, AURA, AND FEAR LEDGERS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2355 | Ability / Component / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2355 | Hover / Removes the recurring 1 AP cost required to remain airborne / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2355 | Hover / Functions only while using an independently purchased Fly Speed / -1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2355 | HOVER TOTAL /  / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2355 | Howl / 30-foot multi-target Will effect with results through Frightened 3 and fleeing for 1 round / +11 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2355 | Howl / Requires 1 AP to activate / -1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2355 | Howl / Each target becomes immune for 10 minutes after attempting the save / -2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2355 | HOWL TOTAL /  / +8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2355 | Ice Climb / May use full land Speed as a Climb Speed across icy terrain / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2355 | Ice Climb / Ignores difficult and formidable terrain caused by snow and ice / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2355 | Ice Climb / Both benefits are restricted to icy or snow-covered terrain / -1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2355 | ICE CLIMB TOTAL /  / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2355 | Ice Stride / Ignores difficult terrain caused by snow or ice / +1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2355 | Ice Stride / No Acrobatics checks are required to avoid falling on slippery ice / +1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2355 | ICE STRIDE TOTAL /  / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2355 | Infestation / Constant close-range poison-damage aura with repeat exposure / +7 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2355 | Infestation / Targets beginning their turns within the aura make a basic Fortitude save against 1d6 poison damage / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2355 | Infestation / Only a 5-foot emanation and applies indiscriminately to anything in range / -1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2355 | INFESTATION TOTAL /  / +8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2356 | SENSE, DRAINING, AND DISPEL LEDGERS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2357 | SENSE, DRAINING, AND DISPEL LEDGERS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2357 | Ability / Component / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2357 | Keen Sense / +2 racial bonus to the complete Perception skill / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2357 | KEEN SENSE TOTAL /  / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2357 | Life Drain / Automatic healing of 3 HP whenever a qualifying unarmed attack damages a living target / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2357 | Life Drain / Failed Fortitude save inflicts Soul Drain 5 / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2357 | Life Drain / Further qualifying damage increases the accumulated Soul Drain by 5 / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2357 | Life Drain / Restricted to living targets damaged by unarmed attacks / -1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2357 | LIFE DRAIN TOTAL /  / +12 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2357 | Life Sense / Primary special sense detecting and distinguishing living and undead vital essence / +8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2357 | LIFE SENSE TOTAL /  / +8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2357 | Magic Dispelling / Three Dispel actions per day without PP expenditure / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2357 | MAGIC DISPELLING TOTAL /  / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2358 | MANOEUVRE LEDGER | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2359 | MANOEUVRE LEDGER | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2359 | Ability / Component / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2359 | Monstrous Grab / +4 racial bonus to the Grapple action / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2359 | Monstrous Grab / Grapple attempts are never penalised by multiple attack penalty / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2359 | MONSTROUS GRAB TOTAL /  / +9 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2360 | APPLICATION NOTES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2361 | • Hover does not grant a Fly Speed. Add the relevant Fly Speed cost first, then add +5 DP for Hover. The value assumes ordinary flight requires 1 AP each round to remain airborne. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2362 | • Howl normally affects a given target only once per encounter because every creature becomes immune for 10 minutes after attempting the save, regardless of the result. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2363 | • Ice Climb already includes the snow- and ice-terrain benefit contained in Ice Stride. A creature possessing both abilities pays only +5 DP unless the wording grants additional effects. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2364 | • Infestation is costed as an indiscriminate aura because it affects anything within 5 feet. Do not reduce its value further merely because allies can remain outside that small area. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2365 | • Keen Sense applies to the entire Perception skill. Acute Sense remains the narrower +2 DP option when the bonus applies only to one named action related to a selected sense. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2366 | • Life Drain triggers only after an unarmed attack actually deals damage. The unarmed attack, its damage, and any method of making extra attacks are separate costs. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2367 | • The Life Sense description first calls the sense Tertiary but concludes that it is Primary. The explicit final classification controls the DP assessment, producing the established +8 DP Primary-sense value. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2368 | • Magic Dispelling uses the creature's ordinary Dispel action and check. It does not guarantee success, reduce the action cost, or grant general Power Manipulation benefits beyond the three PP-free uses. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2369 | • Monstrous Grab removes MAP only from Grapple attempts. It does not remove MAP from other attacks made before or after the Grapple and does not make the Grapple automatic. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2371 | 31. CREATURE ABILITY COSTS - MONSTROUS KNOCKDOWN TO POUNCING ASSAULT | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2372 | This block covers improved Trip attempts, terrain camouflage, exceptional jumping, conditional precision damage, an at-will area paralysis effect, defence penetration, a critical-persistence attack trait, the established Plant critical-injury package, and a compressed jumping attack routine. Required attacks, movement Speeds, allies, breath weapons, and creature-type benefits are costed separately. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2373 | CREATURE ABILITY DP - SEVENTH ALPHABETICAL BLOCK | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2373 | Ability / DP / Costing basis | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2373 | Monstrous Knockdown / +9 / +4 racial bonus to Trip and Trip attempts ignore multiple attack penalty. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2373 | Natural Camouflage / +2 / Advantage on Hide checks in natural terrain. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2373 | Natural Leaper / +7 / Automatic extended jumps, no running-start penalty, and one action-free Long Jump as part of movement. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2373 | Pack Attack / +4 / All attacks gain 1d6 precision damage while the target is within reach of at least two allies. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2373 | Paralysing Gaze / +22 / At-will 1 AP, 30-foot multi-target control effect ranging from Stunned 1 to one-minute Paralysis. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2373 | Penetrating Breath / +5 / An existing breath weapon bypasses all DR and ignores Energy Resistance. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2373 | Penetrating Strikes / +3 / The indicated physical attack package treats all DR as half. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2373 | Persistent / +2/profile / Each affected attack or ability converts qualifying critical-injury persistence into its own damage type. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2373 | Plant Resistance / +5 / Established anatomical filtering of critical injuries while retaining damage, Bleed, and persistent damage. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2373 | Pouncing Assault / +7 / Jump plus two claw Strikes for 2 AP, with -4 to attacks made against the creature during the movement. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2374 | SKILL, MOVEMENT, AND DAMAGE LEDGERS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2375 | SKILL, MOVEMENT, AND DAMAGE LEDGERS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2375 | Ability / Component / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2375 | Monstrous Knockdown / +4 racial bonus to the Trip action / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2375 | Monstrous Knockdown / Trip attempts are never penalised by multiple attack penalty / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2375 | MONSTROUS KNOCKDOWN TOTAL /  / +9 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2375 | Natural Camouflage / Advantage on the broadly useful Hide action / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2375 | Natural Camouflage / Restricted to areas of natural terrain / -1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2375 | NATURAL CAMOUFLAGE TOTAL /  / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2375 | Natural Leaper / High Jump up to half land Speed without a check / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2375 | Natural Leaper / Long Jump up to land Speed without a check / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2375 | Natural Leaper / One Long Jump may be folded into movement without spending a separate AP / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2375 | Natural Leaper / Ignores the running-start penalty for jumping / +1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2375 | Natural Leaper / Benefits remain limited by the creature's existing land Speed and jump geometry / -1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2375 | NATURAL LEAPER TOTAL /  / +7 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2375 | Pack Attack / 1d6 additional damage on every qualifying attack / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2375 | Pack Attack / Precision damage and requirement for at least two allies within reach of the target / -2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2375 | PACK ATTACK TOTAL /  / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2376 | CONTROL AND DEFENCE-PENETRATION LEDGERS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2377 | CONTROL AND DEFENCE-PENETRATION LEDGERS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2377 | Ability / Component / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2377 | Paralysing Gaze / At-will 30-foot multi-target Fortitude effect / +10 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2377 | Paralysing Gaze / A Success still imposes Stunned 1 / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2377 | Paralysing Gaze / Partial imposes Paralysed for 1 round / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2377 | Paralysing Gaze / Failure imposes Paralysed for 1 minute with repeat saves / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2377 | Paralysing Gaze / Fumble removes the repeat-save escape / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2377 | Paralysing Gaze / No immunity period; eligible targets may be affected repeatedly / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2377 | Paralysing Gaze / Costs 1 AP, requires mutual sight, and may affect allies in the area / -3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2377 | PARALYSING GAZE TOTAL /  / +22 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2377 | Penetrating Breath / Existing breath weapon bypasses all DR / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2377 | Penetrating Breath / Existing breath weapon ignores Energy Resistance / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2377 | PENETRATING BREATH TOTAL /  / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2377 | Penetrating Strikes / The indicated physical attack package treats all DR as half / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2377 | PENETRATING STRIKES TOTAL /  / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2378 | CRITICAL-TRAIT AND ATTACK-ROUTINE LEDGERS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2379 | CRITICAL-TRAIT AND ATTACK-ROUTINE LEDGERS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2379 | Ability / Component / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2379 | Persistent / Enhances persistent damage generated by critical injuries and converts it to the attack's primary damage type / +2/profile | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2379 | PERSISTENT TOTAL / Apply separately to each attack or ability carrying the trait / +2/profile | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2379 | Plant Resistance / Partial anatomical filtering of critical injuries / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2379 | PLANT RESISTANCE TOTAL /  / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2379 | Pouncing Assault / One AP of compression: Jump plus two claw Strikes for 2 AP / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2379 | Pouncing Assault / Both claw Strikes may be made during the movement and may focus on one target / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2379 | Pouncing Assault / Attacks against the creature during the action suffer -4 circumstance / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2379 | Pouncing Assault / Requires a Jump check and two claw attacks; ordinary MAP applies in sequence / -1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2379 | POUNCING ASSAULT TOTAL /  / +7 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2380 | APPLICATION NOTES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2381 | • Monstrous Knockdown mirrors Monstrous Grab exactly: the bonus applies only to Trip, and only Trip attempts ignore MAP. It does not remove MAP from other attacks. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2382 | • Natural Camouflage is narrower than advantage on the complete Stealth skill. If it is rewritten to grant advantage on every Stealth action in natural terrain, use +3 DP instead. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2383 | • Natural Leaper is costed on the intended interpretation that the action-free Long Jump can be used once during a movement sequence or turn. Read literally without such a limit, repeated 0 AP Long Jumps would create unlimited movement and the rule must be rewritten rather than assigned an ordinary DP value. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2384 | • Pack Attack is costed once for the creature, not once per weapon. The +4 DP value assumes the extra die is precision damage and therefore remains subject to precision immunity. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2385 | • Paralysing Gaze is indiscriminate as written: every creature within 30 feet that can see the user is eligible. If the creature may freely exclude allies, increase the cost by 1 DP. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2386 | • Penetrating Breath ignores Energy Resistance but not Energy Immunity. The breath weapon itself, its damage, area, recovery, and saving throw remain separate costs. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2387 | • Penetrating Strikes uses +3 DP for the indicated physical attack package. Use +2 DP when only one narrow attack profile gains the benefit, or +4 DP when every physical attack the creature can make gains it. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2388 | • Persistent is an attack or ability trait rather than a global creature package. Add +2 DP to each distinct attack profile or ability carrying the trait; identical limbs sharing one attack profile are still counted once. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2389 | • Plant Resistance is already the +5 DP anatomical-filtering line in the Plant creature-type ledger. Do not add it a second time to an ordinary Plant. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2390 | • Pouncing Assault assumes the two claw Strikes use ordinary MAP in sequence. If both Strikes are resolved before MAP applies, increase the ability from +7 to +10 DP. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2392 | 32. CREATURE ABILITY COSTS - POWERFUL CHARGE TO SKEWERING STRIKES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2393 | This block covers a compressed charging routine, an opportunistic combat manoeuvre, reactive spell defence, regeneration, conditional bonus damage, secondary critical injuries, breath-weapon and critical-hit riders, environmental concealment, and improved spear bleeding. Required attacks, spellcasting checks, breath weapons, secondary damage types, light conditions, and weapon access are costed separately. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2394 | CREATURE ABILITY DP - EIGHTH ALPHABETICAL BLOCK | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2394 | Ability / DP / Costing basis | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2394 | Powerful Charge / +7 / Two Strides and a gore Strike for 2 AP, with +2 to the attack and one additional base-damage die. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2394 | Reactive Disarm / +4 / Once per round, a fumbled weapon Strike permits a reaction Disarm that ignores MAP. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2394 | Reflective Scales / +14 / Reaction Dispel against a targeted spell; a critical Dispel reflects the spell upon its caster. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2394 | Regeneration / +20 / Start-turn healing equal to level, protection from death while active, and rapid injury recovery, subject to a bypass. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2394 | Rend / +8 / After two qualifying hits, the creature automatically inflicts one additional instance of the listed attack damage. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2394 | Secondary Critical / +4/profile / A qualifying critical also inflicts a second critical injury one severity lower using the secondary damage type. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2394 | Shadow Breath / +9 / Breath-weapon damage carries a free Blindness rider using the original saving throw. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2394 | Shadow Hand / +5/profile / A critical soul-touch Strike can inflict 1d6 or 2d6 Soul Drain after a Fortitude save. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2394 | Shadowy / +5 / The creature is continuously Concealed while the prevailing light level is Twilight or darker. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2394 | Skewering Strikes / +2 / Spear criticals increase qualifying persistent Bleed by the severity of the critical. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2395 | ATTACK-ROUTINE AND REACTION LEDGERS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2396 | ATTACK-ROUTINE AND REACTION LEDGERS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2396 | Ability / Component / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2396 | Powerful Charge / One AP of compression: two Strides and one gore Strike are completed for 2 AP / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2396 | Powerful Charge / +2 circumstance bonus to the gore Strike / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2396 | Powerful Charge / One additional base-damage die / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2396 | Powerful Charge / Requires two Strides and an existing gore attack / -1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2396 | POWERFUL CHARGE TOTAL /  / +7 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2396 | Reactive Disarm / Reaction Disarm following a fumbled weapon Strike / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2396 | Reactive Disarm / The Disarm attempt ignores multiple attack penalty / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2396 | Reactive Disarm / Once per round and dependent upon a rare enemy fumble with a weapon / -2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2396 | REACTIVE DISARM TOTAL /  / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2396 | Reflective Scales / PP-free reaction Dispel against an incoming targeted spell / +10 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2396 | Reflective Scales / A critical Dispel reflects the spell upon its caster / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2396 | Reflective Scales / Consumes a reaction and does not apply to spells that do not target the creature / -1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2396 | REFLECTIVE SCALES TOTAL /  / +14 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2397 | REGENERATION AND BONUS-DAMAGE LEDGERS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2398 | REGENERATION AND BONUS-DAMAGE LEDGERS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2398 | Ability / Component / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2398 | Regeneration / Recovers HP equal to creature level at the beginning of every turn while active / +12 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2398 | Regeneration / Cannot die while regeneration remains active unless its physical form is destroyed / +8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2398 | Regeneration / Reduces the Injured condition by its regeneration value every hour / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2398 | Regeneration / A specified bypass damage type can suppress the ability for one turn after sufficient damage / -3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2398 | REGENERATION TOTAL /  / +20 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2398 | Rend / Automatic additional damage equal to the listed attack after two qualifying hits / +10 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2398 | Rend / Requires two hits against the same target with the listed attack type / -2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2398 | REND TOTAL /  / +8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2399 | CRITICAL AND BREATH-RIDER LEDGERS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2400 | CRITICAL AND BREATH-RIDER LEDGERS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2400 | Ability / Component / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2400 | Secondary Critical / Inflicts an additional critical injury using the secondary damage type / +6/profile | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2400 | Secondary Critical / Requires a qualifying critical and the second injury is one severity lower / -2/profile | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2400 | SECONDARY CRITICAL TOTAL / Apply separately to each attack profile carrying the ability / +4/profile | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2400 | Shadow Breath / Free multi-target Blindness rider using the breath weapon's original save result / +11 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2400 | Shadow Breath / Only triggers against targets damaged by an existing breath weapon / -2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2400 | SHADOW BREATH TOTAL /  / +9 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2400 | Shadow Hand / Critical soul-touch Strike can inflict 1d6 Soul Drain / +4/profile | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2400 | Shadow Hand / Serious or Deadly critical increases the Soul Drain to 2d6 / +3/profile | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2400 | Shadow Hand / Requires a qualifying critical and permits a Fortitude save / -2/profile | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2400 | SHADOW HAND TOTAL / Apply to the soul-touch attack profile / +5/profile | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2401 | CONCEALMENT AND BLEEDING LEDGERS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2402 | CONCEALMENT AND BLEEDING LEDGERS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2402 | Ability / Component / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2402 | Shadowy / Continuous Concealed condition while light level is Twilight or lower / +7 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2402 | Shadowy / Benefit is lost in brighter light / -2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2402 | SHADOWY TOTAL /  / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2402 | Skewering Strikes / Persistent Bleed increases by 1 per critical severity / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2402 | Skewering Strikes / Requires a spear-group Strike that already inflicts persistent Bleed / -1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2402 | SKEWERING STRIKES TOTAL /  / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2403 | APPLICATION NOTES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2404 | • Powerful Charge includes only the special routine. The gore attack, its base damage, and the creature's land Speed remain separate components. Ordinary MAP applies to the gore Strike. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2405 | • Reactive Disarm is triggered only by a fumbled weapon Strike. Natural attacks and spell attacks do not satisfy the printed trigger unless another rule explicitly treats them as weapon Strikes. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2406 | • Reflective Scales is costed on the interpretation that an ordinary successful Dispel negates the incoming spell and a critical success reflects it. It does not protect against area spells that merely include the creature without targeting it. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2407 | • Regeneration is +20 DP when it has a specified, reasonably obtainable bypass damage type. If no bypass exists, increase it to +25 DP. If the bypass is exceptionally common and easy to apply, reduce it to +18 DP. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2408 | • Rend is costed on the intended limit of once per turn against a given target. If every additional pair of qualifying hits can trigger Rend again during the same turn, increase the value to +12 DP. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2409 | • Secondary Critical is an attack-profile ability. A Minor critical cannot produce a critical injury one degree lower, so the secondary injury normally occurs only after a Serious or Deadly critical. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2410 | • Shadow Breath does not include the breath weapon itself. The original breath save is reused; the targets do not receive a second save against Blindness. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2411 | • Shadow Hand uses the current three-severity critical scale. The source wording “grievous or deadly” is treated as Serious or Deadly. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2412 | • Shadowy grants Concealment rather than a Stealth bonus. Add its +5 DP even when the creature has no ranks in Stealth. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2413 | • Skewering Strikes increases only persistent Bleed generated by the qualifying spear critical. It does not increase ordinary weapon damage or other persistent damage types. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2415 | 33. CREATURE ABILITY COSTS - SLOW TO SPELL RESILIENCE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2416 | This block covers permanent action-economy drawbacks, a breath-weapon control rider, smoke-based movement and vision, snow vision, an activated primary sense, a Focus sonic attack, kill-triggered recovery, a Soul Drain aura, and scaling defence against magic. Required breath weapons, movement Speeds, spell effects, and Class Bonus progression are costed separately. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2417 | CREATURE ABILITY DP - NINTH ALPHABETICAL BLOCK | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2417 | Ability / DP / Costing basis | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2417 | Slow I / Slow II / -8 / -15 / Permanent loss of one or two of the creature's three AP each turn. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2417 | Slowing Breath / +10 / Free breath-weapon rider imposing Slowed 1 or 2 after a Fortitude save. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2417 | Smoke Form / +6 / May share occupied spaces and avoids movement reactions when moving its full Speed in one action. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2417 | Smokevision / +3 / Ignores visual impairment and concealment produced by smoke or fog. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2417 | Snowvision / +2 / Ignores concealment and other visual penalties caused by snowfall. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2417 | Sonar Sense / +6 / Full-range Primary auditory sense requiring 1 AP to emit and update. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2417 | Sonic Moan / +9 / Focus, 2 AP, 30-foot 3d6 sonic effect with a basic Will save and an obscured source. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2417 | Souldrinker / +10 / Free level-scaled Cure or Restoration recovery after killing a qualifying living creature. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2417 | Soulless Aura / +10 / Ten-foot entry aura inflicting Soul Drain 5 after a level-based Fortitude save. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2417 | Spell Resilience / +18 / Class-Bonus racial bonus to all saves and DB against magical attacks. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2418 | ACTION-ECONOMY AND BREATH-RIDER LEDGERS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2419 | ACTION-ECONOMY AND BREATH-RIDER LEDGERS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2419 | Ability / Component / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2419 | Slow I / Permanently reduces the creature from 3 AP to 2 AP each turn / -8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2419 | SLOW I TOTAL /  / -8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2419 | Slow II / Permanently reduces the creature from 3 AP to 1 AP each turn / -15 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2419 | SLOW II TOTAL /  / -15 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2419 | Slowing Breath / Free multi-target rider that can impose Slowed 1 for a round or one minute, or Slowed 2 for one minute / +13 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2419 | Slowing Breath / Requires an existing breath weapon to damage the target and permits a separate Fortitude save / -3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2419 | SLOWING BREATH TOTAL /  / +10 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2420 | FORM, VISION, AND SENSE LEDGERS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2421 | FORM, VISION, AND SENSE LEDGERS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2421 | Ability / Component / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2421 | Smoke Form / May occupy the same space as another creature / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2421 | Smoke Form / Does not provoke movement reactions when it moves its full Speed in one action / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2421 | SMOKE FORM TOTAL /  / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2421 | Smokevision / Ignores smoke- and fog-based visual impairment and concealment / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2421 | SMOKEVISION TOTAL /  / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2421 | Snowvision / Ignores snowfall-based concealment and other visual bonuses / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2421 | SNOWVISION TOTAL /  / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2421 | Sonar Sense / Primary auditory sense with the same range as vision / +8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2421 | Sonar Sense / Requires 1 AP to emit and obtain or update the sensory picture / -2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2421 | SONAR SENSE TOTAL /  / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2422 | OFFENSIVE, RECOVERY, AND AURA LEDGERS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2423 | OFFENSIVE, RECOVERY, AND AURA LEDGERS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2423 | Ability / Component / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2423 | Sonic Moan / Thirty-foot 3d6 sonic area effect with a basic Will save / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2423 | Sonic Moan / Focus availability without ordinary PP expenditure / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2423 | Sonic Moan / Infrasonic delivery can conceal the source from unaware humanoids / +1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2423 | SONIC MOAN TOTAL /  / +9 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2423 | Souldrinker / Level-scaled Cure or Restoration recovery delivered as a Free action / +13 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2423 | Souldrinker / Triggers only after killing a living creature no more than four levels lower / -3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2423 | SOULDRINKER TOTAL /  / +10 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2423 | Soulless Aura / Constant ten-foot entry aura capable of inflicting Soul Drain 5 / +11 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2423 | Soulless Aura / Level-based Fortitude save; a successful target becomes immune for 24 hours / -1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2423 | SOULLESS AURA TOTAL /  / +10 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2424 | MAGICAL DEFENCE LEDGER | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2425 | MAGICAL DEFENCE LEDGER | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2425 | Ability / Component / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2425 | Spell Resilience / Scaling racial bonus equal to Class Bonus on all saving throws against magical attacks / +10 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2425 | Spell Resilience / The same scaling racial bonus applies to DB against magical attacks / +8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2425 | SPELL RESILIENCE TOTAL /  / +18 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2426 | APPLICATION NOTES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2427 | • Slow is a permanent creature drawback. Use -8 DP for Slow I and -15 DP for Slow II. Temporary applications of the Slowed condition are costed through the ability that inflicts them rather than through this drawback entry. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2428 | • Slowing Breath does not include the underlying breath weapon. It triggers only when the target actually takes breath-weapon damage and then allows the listed Fortitude save. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2429 | • Smoke Form is costed only for the explicit rules stated: sharing occupied spaces and conditionally avoiding movement reactions. The descriptive word “insubstantial” does not grant Incorporeal, damage resistance, immunity, or passage through solid objects. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2430 | • Smokevision ignores concealment caused by smoke and fog, but does not penetrate darkness, solid barriers, or unrelated visual effects. Snowvision is narrower and applies only to snowfall. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2431 | • Sonar Sense is +6 DP on the interpretation that the creature must spend 1 AP whenever it needs to obtain or update the sensory picture. If one activation enables the Primary sense continuously, use +8 DP instead. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2432 | • Sonic Moan treats Focus according to the established availability rule: one use before Refocus. The 2 AP action cost is comparable to ordinary spell delivery and therefore adds no separate adjustment. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2433 | • Souldrinker is +10 DP when the creature may select either Cure-style HP healing or Restoration-style recovery. If the ability provides only fixed HP healing, reduce it to +8 DP. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2434 | • Soulless Aura grants 24-hour immunity only after a successful save. A creature that fails can be affected again if it leaves and re-enters the aura, which is included in the +10 DP value. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2435 | • Spell Resilience applies only against magical attacks. Do not add its save component again when another broader racial feature already supplies an equal or greater bonus to the same magical saving throws. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2437 | 34. CREATURE ABILITY COSTS - STENCH TO TORRENT OF STRIKES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2438 | This block covers a short-range condition aura, two sunlight drawbacks, a limited burst of movement, scaling Damage Reduction, a swallowing attack, aquatic attack movement, a bite follow-up, limited telepathy, and a six-attack routine. Required natural attacks, Grab effects, movement Speeds, and ordinary Damage Reduction are costed separately. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2439 | CREATURE ABILITY DP - TENTH ALPHABETICAL BLOCK | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2439 | Ability / DP / Costing basis | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2439 | Stench / +7 / Ten-foot living-creature aura causing Sickened 1, with Slowed 1 on a fumble and one-minute immunity after a save. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2439 | Sunlight Vulnerability / -15 / Sunlight Weakness plus 2 essence damage per level each turn and loss of healing while exposed. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2439 | Sunlight Weakness / -7 / Injured 2 and Slowed 2 for as long as the creature remains in sunlight. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2439 | Surge of Speed / +3 / One AP to Stride twice, usable once every ten minutes. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2439 | Survival Instinct / +20 / Static Natural DR bonus equal to level; the vague circumstantial failure clause grants no discount. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2439 | Swallow / +15 / One-action conversion of a grabbed smaller target into ongoing containment, conditions, and double-bite acid damage. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2439 | Swimby Attack / +4 / Two bite attacks against separate targets during one Swim Stride for 2 AP. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2439 | Tear Flesh / +8 / One-action automatic repeat of a bite that damaged the target on the immediately preceding action. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2439 | Telepathy / +2 / One-hundred-foot mental communication with sensed sentient creatures sharing a language. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2439 | Torrent of Strikes / +20 / Six adjacent-target attacks for 3 AP, each resolved at a fixed -2 multiple attack penalty. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2440 | AURA AND SUNLIGHT DRAWBACK LEDGERS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2441 | AURA AND SUNLIGHT DRAWBACK LEDGERS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2441 | Ability / Component / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2441 | Stench / Constant ten-foot aura; failed Fortitude save imposes Sickened 1 / +7 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2441 | Stench / Fumble also imposes Slowed 1 for the duration of Sickened / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2441 | Stench / Living targets only; any save grants one minute of immunity / -2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2441 | STENCH TOTAL /  / +7 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2441 | Sunlight Weakness / Slowed 2 while exposed to sunlight / -5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2441 | Sunlight Weakness / Injured 2 while exposed to sunlight / -2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2441 | SUNLIGHT WEAKNESS TOTAL /  / -7 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2441 | Sunlight Vulnerability / Includes the complete Sunlight Weakness drawback / -7 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2441 | Sunlight Vulnerability / Takes 2 essence damage per level at the beginning of each turn in sunlight / -6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2441 | Sunlight Vulnerability / Cannot heal while exposed to sunlight / -2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2441 | SUNLIGHT VULNERABILITY TOTAL /  / -15 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2442 | MOVEMENT AND DEFENCE LEDGERS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2443 | MOVEMENT AND DEFENCE LEDGERS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2443 | Ability / Component / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2443 | Surge of Speed / Gains one additional Stride within a 1 AP action / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2443 | Surge of Speed / Usable only once every ten minutes / -2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2443 | SURGE OF SPEED TOTAL /  / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2443 | Survival Instinct / Scaling static Natural DR bonus equal to creature level / +20 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2443 | Survival Instinct / Circumstances in which the ability fails are not defined and therefore provide no refund / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2443 | SURVIVAL INSTINCT TOTAL /  / +20 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2444 | SWALLOW AND ATTACK-MOVEMENT LEDGERS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2445 | SWALLOW AND ATTACK-MOVEMENT LEDGERS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2445 | Ability / Component / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2445 | Swallow / One-action containment of a qualifying grabbed target after Athletics versus Reflex DC / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2445 | Swallow / Initial and recurring acid damage equal to twice the bite attack, resisted by a Very Hard basic Fortitude save / +8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2445 | Swallow / Target is Grabbed, Slowed 1, must hold its breath, and is constrained to Escape or cutting free / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2445 | Swallow / Requires a pre-existing Grab, a smaller target, and permits escape or internal damage to cut free / -3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2445 | SWALLOW TOTAL /  / +15 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2445 | Swimby Attack / Swim Stride and two bite attacks against separate targets for 2 AP / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2445 | Swimby Attack / Requires an existing Swim Speed and two different targets; ordinary MAP applies / -2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2445 | SWIMBY ATTACK TOTAL /  / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2446 | FOLLOW-UP, COMMUNICATION, AND MULTIATTACK LEDGERS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2447 | FOLLOW-UP, COMMUNICATION, AND MULTIATTACK LEDGERS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2447 | Ability / Component / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2447 | Tear Flesh / Automatically repeats the previous bite result, including damage and critical determination, without a new attack roll / +11 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2447 | Tear Flesh / Costs 1 AP and requires the immediately preceding action to have inflicted bite damage / -3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2447 | TEAR FLESH TOTAL /  / +8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2447 | Telepathy / Mental communication with sensed sentient creatures within 100 feet / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2447 | Telepathy / A shared language is still required for understanding / -1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2447 | TELEPATHY TOTAL /  / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2447 | Torrent of Strikes / Six separate attacks for 3 AP, allowing all attacks to focus on one adjacent target / +12 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2447 | Torrent of Strikes / Every attack is resolved at a fixed -2 MAP instead of escalating through the normal sequence / +8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2447 | TORRENT OF STRIKES TOTAL /  / +20 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2448 | APPLICATION NOTES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2449 | • Stench affects only living creatures. The one-minute immunity applies after any saving throw, regardless of result, preventing repeated exposure every round during the immunity period. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2450 | • Sunlight Vulnerability already includes Sunlight Weakness. A creature with Sunlight Vulnerability records only -15 DP and does not add the separate -7 DP weakness again. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2451 | • The sunlight entries assume ordinary natural sunlight is a commonly available but highly avoidable environmental trigger. Artificial light does not count unless another rule expressly treats it as sunlight. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2452 | • Survival Instinct is costed as a static DR bonus equal to level. It does not grant Base DR and is not multiplied at BDB 6, 12, or 18. If the intended wording grants Base DR equal to level, the ability requires a substantially higher individual assessment. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2453 | • The statement that Survival Instinct “may not work under certain circumstances” is too undefined to earn drawback DP. A specific, enforceable suppression condition can be assessed later as a reduction. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2454 | • Swallow does not include the creature’s bite attack, Grab ability, Athletics bonus, or Swim or Land Speed. Its internal acid damage tracks the qualifying bite profile and is not costed as a separate natural attack. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2455 | • Swimby Attack matches Flyby Attack in structure and therefore uses the same +4 DP value. Both attacks must target different creatures and resolve with ordinary MAP unless the stat block says otherwise. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2456 | • Tear Flesh uses the complete result of the immediately preceding bite, including its critical severity. The repeated damage and critical are rolled again, but no second attack check is made. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2457 | • Telepathy is communicative rather than coercive. It does not read thoughts, transmit images automatically, bypass language, or create a sensory link. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2458 | • Torrent of Strikes is +20 DP on the explicit interpretation that all six attacks use a fixed -2 MAP. If “current MAP at -2” is intended to mean a -2 adjustment to an otherwise escalating MAP sequence, the ability should be rewritten and rescored. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2459 | 35. CREATURE ABILITY COSTS - TRAMPLE TO WHISPERS OF THE GRAVE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2460 | This block covers a full-turn trampling routine, access to every magical tradition, two undead persistence abilities, a non-visual sense, universal Vorpal melee attacks, water-surface movement, two difficult-terrain auras, and ritual communication with spirits. Required movement Speeds, natural attacks, Soul Drain attacks, spell entries, and control effects are costed separately. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2461 | CREATURE ABILITY DP - ELEVENTH ALPHABETICAL BLOCK | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2461 | Ability / DP / Costing basis | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2461 | Trample / +10 / Three-AP double-Speed movement damaging every smaller target crossed, with +1 base die and no movement reactions. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2461 | True Caster / +12 / Access to spells from all four traditions while casting them through the creature's primary tradition. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2461 | Undead Fortitude / +12 / No-action opposed Fortitude save to remain at 1 HP whenever qualifying damage would reduce the creature to 0 HP. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2461 | Undead Spawn / +6 / Delayed creation of a weakened undead Spawn after a qualifying Soul Drain natural-attack kill, without automatic control. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2461 | Vibration Sense / +8 / Blindsight-equivalent Primary non-visual sense using vibration and air currents. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2461 | Vorpal Weapons / +10 / Every melee weapon forces stronger head critical results and applies a severity-based minimum injury result. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2461 | Water Glide / +3 / Moves across water at half Swim Speed and treats the surface as solid for High Jump and Long Jump. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2461 | Whirlpool / +8 / Constant difficult-terrain aura with a radius of 5 feet per level, excluding creatures with the Water trait. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2461 | Whirlwind / +6 / Constant 20-foot difficult-terrain aura, excluding creatures with the Air trait. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2461 | Whispers of the Grave / +2 / Risky one-minute opposed check to communicate with spirits or sentient undead without sharing a language. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2462 | MOVEMENT AND MAGIC-ACCESS LEDGERS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2463 | MOVEMENT AND MAGIC-ACCESS LEDGERS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2463 | Ability / Component / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2463 | Trample / Moves up to twice Speed and can damage every qualifying target whose space is crossed / +8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2463 | Trample / Each target suffers the appropriate attack damage with one additional base die / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2463 | Trample / Movement does not provoke reactions / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2463 | Trample / Costs all 3 AP, affects only targets at least one size smaller, and permits a basic Reflex save / -3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2463 | TRAMPLE TOTAL /  / +10 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2463 | True Caster / Three additional simultaneously accessible magical traditions at +4 DP each / +12 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2463 | True Caster / All selected spells are cast through the creature's primary tradition / 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2463 | TRUE CASTER TOTAL / Individual spell access remains separate / +12 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2464 | UNDEAD PERSISTENCE AND CREATION LEDGERS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2465 | UNDEAD PERSISTENCE AND CREATION LEDGERS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2465 | Ability / Component / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2465 | Undead Fortitude / No-action chance to remain at 1 HP whenever reduced to 0 HP / +15 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2465 | Undead Fortitude / Requires an opposed level-based Fortitude success and is bypassed by essence or weakness damage / -3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2465 | UNDEAD FORTITUDE TOTAL /  / +12 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2465 | Undead Spawn / Creates a lasting undead creature from a slain qualifying target / +10 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2465 | Undead Spawn / Requires a natural attack that inflicts Soul Drain and the transformation is delayed until the following dusk / -2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2465 | Undead Spawn / The GM determines the resulting undead, it gains Spawn and Injured 10, and the creator gains no automatic control / -2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2465 | UNDEAD SPAWN TOTAL /  / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2466 | SENSE, CRITICAL, AND WATER-MOVEMENT LEDGERS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2467 | SENSE, CRITICAL, AND WATER-MOVEMENT LEDGERS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2467 | Ability / Component / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2467 | Vibration Sense / Blindsight or equivalent Primary non-visual sense / +8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2467 | VIBRATION SENSE TOTAL /  / +8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2467 | Vorpal Weapons / A melee critical is shifted to the next available head injury result / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2467 | Vorpal Weapons / The final injury result cannot fall below the minimum established by the critical's severity / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2467 | VORPAL WEAPONS TOTAL / Applies once to the creature's complete melee-weapon package / +10 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2467 | Water Glide / Gains water-surface movement at half the creature's existing Swim Speed / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2467 | Water Glide / May use the water surface as solid ground for High Jump and Long Jump / +1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2467 | WATER GLIDE TOTAL /  / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2468 | TERRAIN-AURA AND SPIRIT-COMMUNICATION LEDGERS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2469 | TERRAIN-AURA AND SPIRIT-COMMUNICATION LEDGERS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2469 | Ability / Component / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2469 | Whirlpool / Constant difficult-terrain emanation scaling at 5 feet per creature level / +10 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2469 | Whirlpool / Does not hinder Water-trait creatures and otherwise affects allies and enemies alike / -2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2469 | WHIRLPOOL TOTAL /  / +8 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2469 | Whirlwind / Constant 20-foot difficult-terrain emanation / +7 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2469 | Whirlwind / Does not hinder Air-trait creatures and otherwise affects allies and enemies alike / -1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2469 | WHIRLWIND TOTAL /  / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2469 | Whispers of the Grave / Can communicate with spirits or sentient undead without a shared language / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2469 | Whispers of the Grave / Requires a one-minute opposed Meditation check and each target becomes immune for 24 hours / -2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2469 | Whispers of the Grave / Carries an exhaustion check and a blunder can allow the target to dominate the user / -1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2469 | WHISPERS OF THE GRAVE TOTAL /  / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2470 | APPLICATION NOTES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2471 | • Trample does not include the creature's Land Speed or the natural attack used to determine damage. It uses a basic Reflex save rather than an attack roll and therefore does not itself contribute to multiple attack penalty. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2472 | • True Caster is interpreted as access to all four magical traditions. The creature still pays separately for every actual spell, cantrip, Specialist Spell, library entry, repertoire entry, or full-list package it possesses. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2473 | • Undead Fortitude can trigger repeatedly because the printed rule has no frequency limit. Essence damage and any damage type to which the creature has Weakness bypass it completely. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2474 | • Undead Spawn grants no automatic command over the created undead. The Spawn trait begins the new undead at Injured 10 and only makes direct control originating from its creator harder to resist. If a revised version grants automatic control, add the value of that control separately. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2475 | • Vibration Sense uses the full +8 Blindsight anchor because the ability explicitly defines itself as a form of Blindsight. A stat block that restricts its range or prevents it from detecting stationary creatures should receive an individual reduction. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2476 | • Vorpal Weapons is costed once for all of the creature's melee weapons. It does not increase attack rolls or ordinary damage and has no effect until a qualifying critical hit occurs. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2477 | • Water Glide requires an existing Swim Speed and does not grant the ability to breathe underwater, remain afloat, or ignore other aquatic hazards. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2478 | • Whirlpool and Whirlwind are continuous, indiscriminate auras. Their trait exceptions reduce their value, but creatures without the matching trait receive no saving throw against the difficult terrain. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2479 | • Whispers of the Grave is primarily an information and communication ability. It does not compel truthful answers, improve the target's attitude, summon a spirit that is not present, or protect the user from the listed domination risk. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2480 | 36. CREATURE ABILITY COSTS - WING BUFFET AND WINGLESS FLIGHT | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2481 | This final block completes the supplied creature-ability list. Wing Buffet is a two-action area attack and control routine based on the creature’s existing wing attack. Wingless Flight modifies an existing Fly Speed, adding Hover and removing the physical clearance requirements of wings while introducing vulnerability to magical suppression. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2482 | CREATURE ABILITY DP - FINAL ALPHABETICAL BLOCK | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2482 | Ability / DP / Costing basis | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2482 | Wing Buffet / +13 / Two-AP 30-foot cone using a level-based Reflex save to inflict wing damage, forced movement, Prone, altitude loss, and Stunned 1 at the worst result. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2482 | Wingless Flight / +6 / Magical flight package granting Hover and wing-free manoeuvring; the existing Fly Speed is lost while magic is suppressed. | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2483 | AIR CONTROL AND MAGICAL FLIGHT LEDGERS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2484 | AIR CONTROL AND MAGICAL FLIGHT LEDGERS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2484 | Ability / Component / DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2484 | Wing Buffet / Thirty-foot cone can affect every creature in the area with one activation / +4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2484 | Wing Buffet / Wing-attack damage on Partial or worse, doubled on Fumble or Blunder / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2484 | Wing Buffet / Forced movement of 5–20 feet that does not provoke reactions / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2484 | Wing Buffet / Prone on Failure or worse, altitude loss against flying targets, and Stunned 1 on Blunder / +3 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2484 | Wing Buffet / Costs 2 AP, permits a level-based Reflex save, and creatures two sizes larger improve the result / -2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2484 | WING BUFFET TOTAL /  / +13 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2484 | Wingless Flight / Includes the complete Hover ability / +5 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2484 | Wingless Flight / Does not require wing clearance or visible wing movement / +2 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2484 | Wingless Flight / Loses the Fly Speed whenever the creature’s magic is suppressed / -1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2484 | WINGLESS FLIGHT TOTAL / Existing Fly Speed remains a separate component / +6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2485 | APPLICATION NOTES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2486 | • Wing Buffet does not include the dragon’s wing natural attack, its damage profile, or any Fly Speed. Those components are costed separately. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2487 | • Wing Buffet uses a saving throw rather than a Strike, so it does not contribute to multiple attack penalty. The +13 DP value assumes it has no recharge or frequency limit beyond its 2 AP cost. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2488 | • The size adjustment applies only when the target is at least two size categories larger than the dragon. The altitude loss is treated as a situational extension of the forced-movement package rather than a separate full control effect. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2489 | • Wingless Flight does not grant a Fly Speed. Add the appropriate Fly Speed first, then apply +6 DP for this ability. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2490 | • Wingless Flight already includes Hover. Do not add the separate +5 DP Hover ability again. If Hover has already been paid for elsewhere, Wingless Flight adds only +1 DP for wing-free movement and the magical-suppression drawback. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2491 | • The -1 DP suppression adjustment assumes anti-magic and similar effects are uncommon but enforceable. While suppression lasts, loss of flight can cause the ordinary consequences of falling. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2492 | CHAPTER 9 — XP MULTIPLIERS AND EFFECTIVE LEVEL | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2493 | XP Multipliers translate exceptional Development Point totals into a progression adjustment. For a player character, the XP Multiplier changes the cumulative XP required for each level. For a creature or NPC, the same multiplier converts its nominal level into an Effective Level used to express its equivalent threat and value. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2494 | 1. PURPOSE AND STANDARD BENCHMARK | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2495 | The default comparison point is a complete standard PC. The 40-DP pre-class package and the 208-DP class benchmark produce a calculated total of 248 DP. For XP Multiplier calculations, this is rounded to a standard benchmark of 250 DP. Use another benchmark only when a rule explicitly defines one for the construction being assessed. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2496 | STANDARD COMPLETE PC BENCHMARK | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2496 | Component / Benchmark DP | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2496 | Race + Heritage + Background / 40 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2496 | Complete Class / 208 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2496 | ROUNDED XPM BENCHMARK / 250 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2498 | • PC Actual DP includes the currently selected Race, Heritage, Background, Class, templates, and every other permanent amendment being assessed. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2499 | • Creature Actual DP is the complete total produced by Chapter 8, including Type, Race or Subtype, Heritage, Size, Class, NPC Combat Package, movement, senses, natural attacks, spells, creature abilities, templates, and exceptional adjustments. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2500 | • Do not compare only the altered template or ability with the 250-DP benchmark. Compare the completed construction after the alteration has been applied. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2501 | 2. DETERMINING DP PERCENTAGE | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2502 | Calculate the construction’s percentage of its benchmark before assigning an XP Multiplier. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2503 | DP Percentage = (Actual DP ÷ Benchmark DP) × 100 | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2504 | Use the unrounded percentage when assigning the multiplier. The displayed percentage may be rounded to two decimal places after the band has been determined. A result from 90% through 110%, inclusive, has XPM 0. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2505 | 3. XP MULTIPLIER BANDS | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2506 | The first band outside the ordinary 90%–110% tolerance changes XPM by 0.1. Each additional 20 percentage points changes it by another 0.1 in the same direction. XPM is recorded as an adjustment, such as +0.2 or -0.1; the full factor applied to XP is 1 + XPM. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2507 | XP MULTIPLIER BANDS | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2507 | DP Percentage / XPM / XP Factor / XP per Level | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2507 | Above 210% / +0.6 or higher / ×1.6 or higher / 16,000 or higher | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2507 | Above 190% to 210% / +0.5 / ×1.5 / 15,000 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2507 | Above 170% to 190% / +0.4 / ×1.4 / 14,000 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2507 | Above 150% to 170% / +0.3 / ×1.3 / 13,000 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2507 | Above 130% to 150% / +0.2 / ×1.2 / 12,000 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2507 | Above 110% to 130% / +0.1 / ×1.1 / 11,000 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2507 | 90% to 110% / 0 / ×1.0 / 10,000 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2507 | 70% to below 90% / -0.1 / ×0.9 / 9,000 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2507 | 50% to below 70% / -0.2 / ×0.8 / 8,000 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2507 | 30% to below 50% / -0.3 / ×0.7 / 7,000 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2507 | 10% to below 30% / -0.4 / ×0.6 / 6,000 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2507 | Below 10% / -0.5 / ×0.5 / 5,000 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2509 | For DP percentages above 210%, continue the same pattern: each additional 20 percentage points adds another +0.1 XPM. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2510 | For percentages above 110%: XPM = +0.1 × ceiling[(DP Percentage - 110) ÷ 20]. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2511 | For percentages below 90%: XPM = -0.1 × ceiling[(90 - DP Percentage) ÷ 20]. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2512 | 4. PC APPLICATION AND RECALCULATION | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2513 | A PC’s XPM changes the amount of cumulative XP required for each level. The PC earns and retains XP normally, but its level thresholds use the revised XP Factor. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2514 | XP Factor = 1 + XPM | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2515 | XP required per level = 10,000 × XP Factor | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2516 | Cumulative XP required for Level L = L × XP required per level | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2517 | Current Level = floor(Current accumulated XP ÷ XP required per level) | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2518 | • When a PC gains, loses, or changes a template or any other permanent DP amendment, immediately recalculate Actual DP, DP Percentage, XPM, XP Factor, and level. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2519 | • The PC keeps its current accumulated XP. Do not award or remove XP merely to preserve its previous level. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2520 | • The recalculation can raise or lower the PC’s level. Recalculate all level-derived statistics and access from the resulting level. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2521 | • A PC that returns to the 90%–110% band returns to the standard 10,000 XP per level progression. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2522 | 5. CREATURE APPLICATION AND EFFECTIVE LEVEL | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2523 | A creature does not track XP for advancement. Instead, its complete DP total produces an XPM, and that multiplier converts its nominal creature level into an Effective Level. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2524 | Equivalent XP = Creature Level × 10,000 × XP Factor | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2525 | Effective Level = floor(Equivalent XP ÷ 10,000) | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2526 | Equivalent shortcut: EL = floor(Creature Level × XP Factor) | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2527 | Minimum Effective Level = 0 | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2528 | • Effective Level does not change the creature’s actual level, class progression, BDB, BAB, Hit Points, spell access, or other level-derived statistics. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2529 | • EL is the creature’s equivalent standard level for encounter construction, comparison, and any rule that refers to Effective Level. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2530 | • Recalculate XPM and EL whenever the creature’s complete DP total changes through a template, size change, added ability, removed drawback, or other permanent revision. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2531 | 6. WORKED EXAMPLES | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2532 | XP MULTIPLIER AND EFFECTIVE LEVEL EXAMPLES | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2532 | Example / Calculation / Result | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2532 | Ordinary PC package / 260 DP ÷ 250 = 104.00% / XPM 0; 10,000 XP per level | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2532 | Templated PC / 335 DP ÷ 250 = 134.00% / XPM +0.2; 12,000 XP per level | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2532 | PC recalculation / 50,000 current XP ÷ 12,000 / Level 4 after gaining the template | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2532 | Level 1 creature at XPM +0.2 / 1 × 10,000 × 1.2 = 12,000 equivalent XP / EL 1 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2532 | Level 5 creature at XPM +0.2 / 5 × 10,000 × 1.2 = 60,000 equivalent XP / EL 6 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2532 | Level 1 creature at XPM -0.2 / 1 × 10,000 × 0.8 = 8,000 equivalent XP / EL 0 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2532 | Level 5 creature at XPM -0.2 / 5 × 10,000 × 0.8 = 40,000 equivalent XP / EL 4 | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2534 | The Level 5 creature example matches the intended conversion: a standard Level 5 creature represents 50,000 XP, while XPM +0.2 increases that equivalent value to 60,000 XP and therefore EL 6. | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2535 | 7. XPM AND EFFECTIVE LEVEL WORKSHEET | Source paragraph | Extracted; semantic/runtime audit remains in progress |
| 2536 | XPM AND EFFECTIVE LEVEL WORKSHEET | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2536 | Component / Entry | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2536 | Construction type / PC / Creature | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2536 | Actual complete DP /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2536 | Benchmark DP / 250 unless another benchmark is explicitly defined | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2536 | DP Percentage /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2536 | XP Multiplier (XPM) /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2536 | XP Factor / 1 + XPM | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2536 | XP required per level / 10,000 × XP Factor | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2536 | Current accumulated XP or Creature Level /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2536 | Equivalent XP / Creature Level × 10,000 × XP Factor | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |
| 2536 | Resulting PC Level or Effective Level /  | Source table; applicable numeric rows feed generated rules | Extracted; domain coverage below |

## Domain status

8 November follow-up: native Refocus selection/cancellation, one-use and declared-all restoration, shared casting/exhaustion and Extra Wildshape were exercised live. Bonus-use preservation on Codex edits fails; shared-member Refocus and exhausted Wild Shape reconfiguration expose core defects. Existing-actor/resource integration remains partial despite earlier base-capacity passes. See [Refocus/pools report](docs/refocus-pools-test-report.md); no runtime corrections applied.

| Domain | Implemented | Outstanding |
|---|---|---|
| Deterministic DP | Published type/class/ability ledgers; core anchors; size, attack and magic valuation; replacement and named overlap handling; exact XPM boundaries | Complete overlap review across arbitrary user-authored packages and all conditional ability variants |
| Creature builder | All 12 types, 16 creature/NPC and 8 PC choices checked; Eternal zero-HP rule and unsupported casting guard fixed and tested in 0.1.3 | Advanced per-profile parameters and full grant prerequisites |
| Project storage | Creature save/load/update/duplicate and DP package component/layer persistence verified across reloads; JSON export path implemented | Project migration and export round-trip live tests |
| Existing actors | Grant timing, class replacement, numeric and Focus expenditure/resets, legacy repairs, mode changes and manual preservation checked through 0.1.4 | Arbitrary NPC import, injected live rollback and multi-client editing |
| Package designers | Anchored layered ledgers, pre-class and Class Index assessment | Dedicated full class authoring/export, heritage-family averaging UI and complete PC relevel application |
| Creature combat | Native core item data, effects and automation flags retained | Individual workflow tests for every ability, aura, aligned control, transformation and spell variant |
| Actual casting/resources | Genuine checked casts, PP deductions, cancellation, numeric and Focus exhaustion, native rest/Daily Preparation, editing and reloads verified in 0.1.4 | Refocus, bonus/shared pools, constant continuous application and full spell outcomes |
| Rules audit | Approved size/attack decisions and identified issues recorded | Full editorial and semantic review of every source block |
| Release | Separate source tree and versioned packaging script | Production release approval and full acceptance test completion |
