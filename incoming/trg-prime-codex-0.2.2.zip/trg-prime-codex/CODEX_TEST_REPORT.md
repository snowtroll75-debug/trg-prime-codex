# Codex test report

Latest build: **Codex 0.2.0** (joint Codex / Fiends & Fables audit, 18 November 2026). `node --test tests/joint-audit.test.mjs` passes 8/8, including all 294 Fiends & Fables Prime creatures importing and valuing without error, and 0.1.5 vs 0.2.0 Codex-built ledgers being identical (set `FF_PACKS`, `CODEX_015` and `CLASSIC_LEVEL_ROOT`). Live in the Test world on core 3.698.4, using development copies: variant import, unchanged apply (identical actor), modified apply (+2 levels and Regeneration; provisional subtotal 325.5), compendium guard, published Eternal guard. The shared battery `tests/live/creature-battery.mjs` ran in four configurations; results are in docs/joint-audit/CODEX_FIENDS_REGRESSION_REPORT.md. Still owed: the same battery against the installed 0.2.0 build, and a screenshot of the new picker.

Latest installed build: **Codex 0.1.4**. Expanded Refocus and bonus/shared-pool testing passed **43/51 assertions**, exposing one Codex bonus-use edit defect and two core defects (shared-member Refocus writes the member instead of its owner; Wild Shape reconfiguration refills zero uses). See [the current report](docs/refocus-pools-test-report.md) and [evidence](docs/refocus-pools-test-evidence.json). No fixes were applied in this pass. All temporary data was removed; core and module runtime remain unchanged.

Earlier 0.1.4 verification passed **47 local tests, 53 live casting checks and 16 focused regressions** for ordinary capacity, expenditure, legacy repair, casting-mode changes and reloads. Those original two Focus defects remain corrected in their tested scope; the expanded bonus/shared cases add distinct gaps. See [the earlier report](docs/focus-fixes-test-report.md).

Earlier 0.1.3 verification passed 43 local tests, 60 creation cases, 60 reload comparisons, 26 targeted magic checks and 17 UI/persistence checks. Subsequent actual casting exposed two Focus gaps, now corrected in 0.1.4. Those [earlier reports](docs/four-fixes-test-report.md) and the [actual-casting failure report](docs/actual-casting-test-report.md) remain historical evidence. Full release acceptance is still pending.

The original 0.1.1 expanded matrix passed 58/60 creation cases and 7/14 targeted checks, exposing four distinct defects. The user subsequently approved corrections; the 0.1.3 rerun passes every original case plus resource and UI regressions. The [expanded failure report](docs/creature-magic-matrix-report.md) and its evidence remain unchanged apart from a superseded notice.

## Deterministic tests

Run `npm.cmd test` with the existing Node installation. The 47 tests cover separate 208/250 benchmarks, sourcebook examples and exact thresholds, component/overlap arithmetic, 96 type/size constructions, all 114 ability identities, native grants, Eternal consistency, casting guards, fixed PC costs, numeric expenditure/resets and native/legacy Focus representation and expenditure. Latest counts are in the current verification evidence; earlier TAP output remains historical.

## Live browser preview

The executed preview used installed Google Chrome, Foundry 14.367, TRG Prime 3.685.2 and TRG V14 as Testing Dude. A loopback server served only the development module. The browser compiled its template into the ordinary Foundry template cache because the module had not been installed on the server. No core API implementation was replaced.

The GM selected a level-5 Large Undead, Bite, Claw and Undead Fortitude. The actual core Actor class derived HP 100, BAB 3, BDB 3, final Attack 7, Defence 16, Fortitude 12, Reflex 7, Will 11 and PP 0. The core type rule displayed no Death State. Its DP ledger was 165.5, XPM −0.2 and EL 4.

All 96 type/size combinations constructed as detached actors. This checks valid model construction and retained actual level, not every combat interaction. The sourcebook/core reach discrepancy for Diminutive and Tiny remains an explicit compatibility issue. The DP Designer was exercised with two additional General feats and returned 8 DP in the race layer.

The final browser report recorded zero page errors. Actor, scene, combat and Journal counts matched before and after. Screenshots and preview-live.json are under test-results. These checks created no persistent world documents and installed no module or additional npm package.

## Corrections found during development

Runtime checks caught an unsupported Handlebars array helper, the v14 requirement for a single root element per template part, server-relative template resolution, an inactive-module flag read in the development preview and numeric select values where layer names were required. The final checked code addresses these. A display correction reads the core’s no-Death-State helper for Undead instead of quoting the unused ordinary combat field.

## Installed-runtime results

Visible Chrome tests used Foundry 14.367, TRG Prime 3.685.2 and Testing Dude. All four packs loaded all 152 documents with valid IDs. NPC creation, creature and package Journal persistence across reloads, project update and duplication, managed attack replacement, preservation of manual items/descriptions/current HP, stale-edit rejection, and repeat application after reloading a settled actor passed.

The 0.1.0 run omitted initial Darkvision grants and captured an edit baseline before asynchronous native grants finished. Version 0.1.1 fixes both by awaiting native grant reconciliation before creation/application returns. All original checks now pass. Additional regressions repair a temporary legacy actor's missing grant, immediately apply again, decrease level and immediately apply again. Genuine stale edits remain rejected without writes. The external Playwright harness remains untouched; installed tests live in tools/test-installed.mjs.

The final 0.1.1 run removed one temporary actor, three temporary Journals and two generated chat cards. Existing actors, Journals, scenes, combats and chat messages matched the pre-test snapshot. SHA-256 verification found zero changes in 2,052 non-pack core files. Live LevelDB pack databases are excluded from the byte comparison. No additional packages were installed.

## Pending runtime tests

Importing arbitrary pre-existing NPCs without Codex provenance; injected live failure and edit rollback; all class/magic variants; full feat prerequisite validation; every native creature ability’s actions and outcomes; aura entry/turn/expiry; aligned control; transformations; casting/innate frequency enforcement; multi-client permissions and cleanup; and regressions with the other TRG modules. The grant coordinator has local failure/convergence tests, but these do not establish complete live rollback coverage.

All delegated ability workflows retain partial classifications until those cases run. The module is a development checkpoint and does not satisfy the full acceptance checklist yet.
