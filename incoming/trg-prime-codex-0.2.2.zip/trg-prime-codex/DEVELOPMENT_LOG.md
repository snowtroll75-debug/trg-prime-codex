# Development log

## 8 November 2026 — Refocus and bonus/shared pools

Tested installed 0.1.4 in TRG V14 as Testing Dude with genuine native casting/Refocus rolls, rest/Daily Preparation, form feat activation, edits and reloads. Final runs passed 43/51 assertions; eight failures identify three defects: Codex bonus-use truncation on edits, core shared-member Refocus writing the member counter, and Wild Shape configuration refilling exhausted uses. Corrected exploratory harness assumptions about degree objects, per-item lockouts, native form activation and form dialogs before final runs. Existing external harness preserved.

Removed 16 temporary actors, five scenes and 303 chat cards across all runs. Final original-world comparison passed with unchanged time; every run restored targets. All 2,052 non-pack core hashes match, and 12 repository runtime files match the installed module. No runtime edits, deployment or package installation. Detailed causes, locations, recommendations, scope and artifacts: docs/refocus-pools-test-report.md and docs/refocus-pools-test-evidence.json.

## 8 November 2026 — approved Focus fixes

Changed generated Focus count to the native blank representation and preserved Focus expenditure across edits, old-format repair and class-casting round trips. DP anchors and core code are unchanged. Added four local regressions; all 47 tests pass. Built and deployed 0.1.4 with the previous module safely backed up while only TRG V14 was stopped.

As Testing Dude, reran actual native casting and daily preparation: 53/53 full checks and 16/16 focused checks, including unmodified generated Focus, actual exhausted refusal, genuine zero-use legacy repair, repeat edits, mode changes and resets. Removed all 9 temporary actors, 9 tokens, 2 scenes and 31 chat cards. Fresh audit matches the pre-deployment world snapshot; time and targets are unchanged. All 2,052 non-pack core files retain their hashes. No packages, publication or pushes. Evidence: docs/focus-fixes-test-evidence.json.

## 8 November 2026 — actual spellcasting and daily preparation

Executed unmocked native castSpell, rest and Daily Preparation workflows through visible Chrome dialogs as Testing Dude in TRG V14. Used a disposable scene and test tokens because the installed spell lacks the anticipated object-target metadata. Corrected v14 token targeting, native material-pouch setup and dialog races in the harness; retained failed exploration evidence and recovered all fixtures.

Full run: 50/53 checks, 35 operations and 19 settled events, including genuine Failure/Critical/Success casts with matching PP spend. Numeric innate limits, exhausted refusal, short/full rest gates and actual Daily Preparation passed. Native Focus control: 6/8, proving core spend/refusal/reset works with a blank count and Focus trait. Codex's literal focus count disables tracking, and an unchanged edit refills a genuinely spent Focus. No runtime fixes applied. All 41 temporary actors, 6 scenes and 30 chat cards across exploration/final runs were removed. Fresh audit matches the original pre-test world snapshot, with unchanged time and restored targets. All 2,052 non-pack core hashes match. See docs/actual-casting-test-report.md.

## 8 November 2026 — four approved corrections

Fixed the Eternal module-owned source/compendium declaration, same-source spell configuration edits, ignored fixed-PC selector DP and unsupported optional casting. Added expenditure preservation, generated Focus handling and native reset safeguards. The intermediate 0.1.2 build is retained; final 0.1.3 includes the reduced-capacity full-reset regression. Deployed by stopping only TRG V14 through Foundry setup and backing up the prior Codex folder before replacing it, including its own compiled packs. Core files were not edited.

Final verification as Testing Dude: 43/43 local tests, 60/60 creation cases and reload comparisons, 26/26 targeted magic checks and 17/17 UI/persistence checks. All four failures reproduce as corrected behavior. Final runs cleaned 63 actors, 3 Journal projects and 33 chat cards; intermediate runs cleaned their own 63 actors, 3 projects and 32 cards. Existing world document snapshots match. All 2,052 non-pack core files retain their hashes. Evidence: docs/four-fixes-test-evidence.json and the associated report. No additional packages, publishing or pushes.

## 8 November 2026 — expanded live matrix

With approval for additional tests, exercised all type/default classes, four NPC replacements, eight PC replacements, all optional casting classes, sixteen tradition/ability pairs and twelve innate spell/cantrip frequency cases. Creation matrix: 58/60; stored-source reload comparisons: 60/60. Both creation failures concern Eternal's death-state/DP mismatch. Follow-up: 7/14 checks, establishing four distinct findings including stale spell configuration on edits, ignored PC casting selection adding DP and unsupported optional casting receiving a complete ledger. Verified the Eternal zero-HP outcome on a disposable actor. Added only local test tools and documentation; no runtime fixes were made. Removed all 62 temporary actors and 30 generated chat cards; existing world document snapshots match. Hashes of all 2,052 non-pack core files remain identical. Evidence and limits are in docs/creature-magic-matrix-report.md.

## 8 November 2026

With approval, fixed both Codex native-grant defects and deployed 0.1.1 to the existing module folder. The adapter now awaits native numeric/item/aspect grant workflows until stable before returning from creation or editing. Creation removes incomplete actors on reconciliation failure. Stale-edit protection is retained and repeated after asynchronous preview. No core files or compendium databases were overwritten.

All 36 local tests passed, including native queue, descendant, failure and bounded-convergence coverage. Visible Chrome first passed all original 14 live checks, then all 16 checks after adding missing-grant legacy-actor and level-decrease regressions. Testing Dude in TRG V14 was verified on each run. Removed all temporary actors, projects and generated chat cards. Existing world document snapshots matched; all 2,052 non-pack core files retained identical hashes. No packages were added. Detailed evidence is in docs/installed-runtime-0.1.1.json and test-results/installed-0.1.1.

## 7 November 2026

Read the supplied specification and located D:\Downloads\TRG Prime Codex.docx. Extracted 2,045 nonempty source blocks and 166 tables with stable block references. Isolated the supplied 3.685.2 ZIP under the separate references directory and recorded source fingerprints. Inspected native actor preparation, class resolution, type rules, creature attacks, module registration, transferred effects and the existing Playwright setup.

The user approved Part II’s Gargantuan Dexterity −3 and natural attacks relative to printed base sizes. Those choices are recorded in the rule data and audit.

Created a separate trg-prime-codex source tree. Implemented deterministic ledger and XPM functions, generated source-linked type/class/ability data and native module compendium sources, built a v14 GM toolkit and added detached actor preview and project/edit paths. Core and installed source were preserved.

Executed deterministic tests and read-only Chrome preview tests in TRG V14 as Testing Dude. Corrected the v14 template, selector and preview integration problems those checks exposed. Recorded the demonstrated Undead workflow and all 96 detached constructions. Detailed status and remaining work are in the implementation matrix and test report.

The user subsequently authorised installation and activation in TRG V14 and temporary actor/project tests. Installed the immutable 0.1.0 ZIP under C:/FoundryData/Data/modules/trg-prime-codex, refreshed the test world's package cache through Foundry setup and enabled only Codex. Testing Dude executed visible Chrome tests: 12/14 passed. Initial type grant materialisation and the editor baseline's asynchronous native grant timing remain defects; no runtime fixes were implemented. Creation, persistence, normal editing, customisation preservation and deliberate stale-edit protection passed. Corrected harness window handling after the new actor sheet obscured the builder. Retained traces, videos, console logs, failures and final evidence under test-results/installed.

All temporary actors, project Journals and their generated grant chat cards were deleted. Existing world documents matched before/after. The 2,052 checked core files outside mutable pack databases retained identical SHA-256 hashes. All 33 deterministic tests passed again. The external working Playwright harness and the installed core were not edited. Full sourcebook semantic audit and exhaustive creature ability verification remain open.

**18 November 2026, 0.2.0: joint Codex / Fiends & Fables audit.** Audited Codex 0.1.5 and Fiends & Fables Prime 0.45.2 as one creature ecosystem on core 3.698.4, in Graham's separate Test world, with one defect register for both modules (docs/joint-audit/). The Codex native copies match core apart from Eternal. Added the Fiends adapter, variant import, printed-name matching, provisional ledgers for imported creatures, the feat valuation for imported creatures, and the published-Eternal guard. Rebuilt the packs, which shipped without a LevelDB MANIFEST; their contents are identical. Codex-built ledgers are proven unchanged against 0.1.5. Core and published compendiums were not edited; two core proposals (CO-01, CO-02) await approval. Work is on branch `joint-audit-0.2.0`; nothing was pushed or installed.
