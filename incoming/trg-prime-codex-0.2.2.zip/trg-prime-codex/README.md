# TRG Prime Codex

Version 0.2.2 is a development build for Foundry VTT 14.367, verified with TRG Prime 3.699.0 (minimum 3.685.2). It provides a GM creature construction interface, source-linked Development Point ledgers and package design tools. 0.2.0 adds variants of published creatures (for example from Fiends & Fables Prime) and provisional ledgers for them; see CHANGELOG.md and docs/joint-audit/. Earlier builds added native grant timing, Eternal, spell editing, casting valuation and Focus lifecycle corrections. See CODEX_TEST_REPORT.md for executed checks and outstanding acceptance work.

Open **Codex Creature Builder** from the Actors directory or open the module’s **Codex Toolkit** menu in Configure Settings. The API entry point is `game.modules.get('trg-prime-codex').api.open()`.

To start from a published creature, choose it under **Published creatures (start a variant)**. The builder copies it into the world and works on the copy; the compendium creature is never changed. A published creature's ledger is marked provisional and lists every component the Codex cannot yet value.

Select a creature type, actual level, size and one class. Add natural attacks, abilities, feats and spells. The core derives the actor’s statistics. The module calculates DP from the published component ledgers, then applies the separate 250-DP XPM benchmark. Effective Level is stored in module provenance and leaves actual level calculations with the core.

The toolkit contains native type, class, natural attack and ability documents copied from the supplied core archive. Their automation runs through the core’s existing workflows. The module’s stable IDs are generated independently. This includes valid module IDs for Scorching Breath and Wing Buffet. The installed core packs are separate documents.

Projects are saved as flagged Journal Entries. The toolkit can reopen and duplicate those projects. Export produces JSON with the construction and its itemised DP ledger. When editing an actor, reload it after any concurrent change and review the planned construction. Unvalued existing customisations block a complete valuation.

The DP Designer records anchored components in separate race, heritage, background, class and magic layers. Class Index uses 208 DP. Complete-construction XPM uses 250 DP. The sourcebook reference preserves source block numbers used in the matrix and audit.

After an installation is approved, extract the ZIP so that `Data/modules/trg-prime-codex/module.json` exists. Refresh Foundry’s module list and enable the module in the disposable TRG V14 test world. Review the test report before use in any campaign.

## Development

Run `npm.cmd test` in this repository. No npm install is needed. The development-only source import and packaging tools use the ClassicLevel library already bundled with the local Foundry application. Browser preview uses the existing Playwright installation at `C:\TRGPrimeTests\trpg-prime-live-tests`.

Run `node tools/preview-live.mjs` for the read-only UI and detached-actor tests. The development server binds only to loopback and closes after the test. Run `npm.cmd run build` to compile compendiums and prepare a ZIP under dist. The package root is `trg-prime-codex/`.

Review CODEX_IMPLEMENTATION_MATRIX.md, CODEX_RULES_AUDIT.md and CODEX_TEST_REPORT.md before using a development build. They distinguish executable components, delegated core workflows and pending sourcebook or runtime verification.
