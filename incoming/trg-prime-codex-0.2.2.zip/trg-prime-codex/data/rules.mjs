// Generated from source tables by tools/import-source.mjs.
export const RULES = {
  "schemaVersion": 1,
  "coreVersion": "3.685.2",
  "decisions": {
    "gargantuanDexterity": -3,
    "naturalAttackReference": "printed-size",
    "approved": "User, 7 November 2026"
  },
  "types": {
    "aberration": {
      "name": "ABERRATION",
      "entries": [
        {
          "id": "type-aberration-0",
          "label": "Darkvision",
          "dp": 4,
          "source": "TRG Prime Codex, Part II, source block 2073"
        },
        {
          "id": "type-aberration-1",
          "label": "+2 Will saving throws",
          "dp": 3,
          "source": "TRG Prime Codex, Part II, source block 2073"
        },
        {
          "id": "type-aberration-2",
          "label": "Death State 4",
          "dp": -2,
          "source": "TRG Prime Codex, Part II, source block 2073"
        }
      ],
      "printed": 5,
      "source": "TRG Prime Codex, Part II, source block 2073"
    },
    "animal": {
      "name": "ANIMAL",
      "entries": [
        {
          "id": "type-animal-0",
          "label": "Intelligence −5 and animal-level reasoning",
          "dp": -10,
          "source": "TRG Prime Codex, Part II, source block 2076"
        },
        {
          "id": "type-animal-1",
          "label": "Nightvision",
          "dp": 2,
          "source": "TRG Prime Codex, Part II, source block 2076"
        },
        {
          "id": "type-animal-2",
          "label": "+2 Fortitude and Reflex saving throws",
          "dp": 6,
          "source": "TRG Prime Codex, Part II, source block 2076"
        },
        {
          "id": "type-animal-3",
          "label": "Death State 6",
          "dp": 2,
          "source": "TRG Prime Codex, Part II, source block 2076"
        },
        {
          "id": "type-animal-4",
          "label": "Mandatory Neutral alignment",
          "dp": 0,
          "source": "TRG Prime Codex, Part II, source block 2076"
        }
      ],
      "printed": 0,
      "source": "TRG Prime Codex, Part II, source block 2076"
    },
    "beast": {
      "name": "BEAST",
      "entries": [
        {
          "id": "type-beast-0",
          "label": "Darkvision and Nightvision",
          "dp": 6,
          "source": "TRG Prime Codex, Part II, source block 2079"
        },
        {
          "id": "type-beast-1",
          "label": "+2 Fortitude saving throws",
          "dp": 3,
          "source": "TRG Prime Codex, Part II, source block 2079"
        },
        {
          "id": "type-beast-2",
          "label": "Death State 4",
          "dp": -2,
          "source": "TRG Prime Codex, Part II, source block 2079"
        }
      ],
      "printed": 7,
      "source": "TRG Prime Codex, Part II, source block 2079"
    },
    "construct": {
      "name": "CONSTRUCT",
      "entries": [
        {
          "id": "type-construct-0",
          "label": "Darkvision and Nightvision",
          "dp": 6,
          "source": "TRG Prime Codex, Part II, source block 2082"
        },
        {
          "id": "type-construct-1",
          "label": "Bleed immunity",
          "dp": 5,
          "source": "TRG Prime Codex, Part II, source block 2082"
        },
        {
          "id": "type-construct-2",
          "label": "Disease immunity",
          "dp": 3,
          "source": "TRG Prime Codex, Part II, source block 2082"
        },
        {
          "id": "type-construct-3",
          "label": "Mental damage immunity",
          "dp": 5,
          "source": "TRG Prime Codex, Part II, source block 2082"
        },
        {
          "id": "type-construct-4",
          "label": "Poison immunity",
          "dp": 5,
          "source": "TRG Prime Codex, Part II, source block 2082"
        },
        {
          "id": "type-construct-5",
          "label": "Soul-effect immunity",
          "dp": 5,
          "source": "TRG Prime Codex, Part II, source block 2082"
        },
        {
          "id": "type-construct-6",
          "label": "Subdual damage immunity",
          "dp": 5,
          "source": "TRG Prime Codex, Part II, source block 2082"
        },
        {
          "id": "type-construct-7",
          "label": "Doomed, Drained, Fatigued, Paralysed, Sickened, and Unconscious immunities",
          "dp": 18,
          "source": "TRG Prime Codex, Part II, source block 2082"
        },
        {
          "id": "type-construct-8",
          "label": "Critical Resistance 4",
          "dp": 10,
          "source": "TRG Prime Codex, Part II, source block 2082"
        },
        {
          "id": "type-construct-9",
          "label": "Does not eat or breathe",
          "dp": 3,
          "source": "TRG Prime Codex, Part II, source block 2082"
        },
        {
          "id": "type-construct-10",
          "label": "No Death State; destroyed at 0 HP",
          "dp": -6,
          "source": "TRG Prime Codex, Part II, source block 2082"
        },
        {
          "id": "type-construct-11",
          "label": "No natural or ordinary healing; repair and mending remain",
          "dp": -5,
          "source": "TRG Prime Codex, Part II, source block 2082"
        }
      ],
      "printed": 54,
      "source": "TRG Prime Codex, Part II, source block 2082"
    },
    "elemental": {
      "name": "ELEMENTAL",
      "entries": [
        {
          "id": "type-elemental-0",
          "label": "Darkvision and Nightvision",
          "dp": 6,
          "source": "TRG Prime Codex, Part II, source block 2085"
        },
        {
          "id": "type-elemental-1",
          "label": "Does not breathe",
          "dp": 2,
          "source": "TRG Prime Codex, Part II, source block 2085"
        },
        {
          "id": "type-elemental-2",
          "label": "Critical Resistance 2",
          "dp": 5,
          "source": "TRG Prime Codex, Part II, source block 2085"
        },
        {
          "id": "type-elemental-3",
          "label": "Native elemental immunity",
          "dp": 5,
          "source": "TRG Prime Codex, Part II, source block 2085"
        },
        {
          "id": "type-elemental-4",
          "label": "Paralysis immunity",
          "dp": 3,
          "source": "TRG Prime Codex, Part II, source block 2085"
        },
        {
          "id": "type-elemental-5",
          "label": "Poison immunity",
          "dp": 5,
          "source": "TRG Prime Codex, Part II, source block 2085"
        },
        {
          "id": "type-elemental-6",
          "label": "Sleep immunity",
          "dp": 3,
          "source": "TRG Prime Codex, Part II, source block 2085"
        },
        {
          "id": "type-elemental-7",
          "label": "No Death State; destroyed at 0 HP",
          "dp": -6,
          "source": "TRG Prime Codex, Part II, source block 2085"
        }
      ],
      "printed": 23,
      "source": "TRG Prime Codex, Part II, source block 2085"
    },
    "eternal": {
      "name": "ETERNAL",
      "entries": [
        {
          "id": "type-eternal-0",
          "label": "Darkvision and Nightvision",
          "dp": 6,
          "source": "TRG Prime Codex, Part II, source block 2088"
        },
        {
          "id": "type-eternal-1",
          "label": "Eternal Essence",
          "dp": 12,
          "source": "TRG Prime Codex, Part II, source block 2088"
        },
        {
          "id": "type-eternal-2",
          "label": "Does not eat or sleep",
          "dp": 2,
          "source": "TRG Prime Codex, Part II, source block 2088"
        },
        {
          "id": "type-eternal-3",
          "label": "Critical Resistance 2",
          "dp": 5,
          "source": "TRG Prime Codex, Part II, source block 2088"
        },
        {
          "id": "type-eternal-4",
          "label": "+2 to all saving throws",
          "dp": 10,
          "source": "TRG Prime Codex, Part II, source block 2088"
        },
        {
          "id": "type-eternal-5",
          "label": "No Death State; removed at 0 HP",
          "dp": -6,
          "source": "TRG Prime Codex, Part II, source block 2088"
        },
        {
          "id": "type-eternal-6",
          "label": "Planar essence returns to its home plane",
          "dp": 2,
          "source": "TRG Prime Codex, Part II, source block 2088"
        }
      ],
      "printed": 31,
      "source": "TRG Prime Codex, Part II, source block 2088"
    },
    "fey": {
      "name": "FEY",
      "entries": [
        {
          "id": "type-fey-0",
          "label": "Nightvision",
          "dp": 2,
          "source": "TRG Prime Codex, Part II, source block 2091"
        },
        {
          "id": "type-fey-1",
          "label": "Cold Iron weakness",
          "dp": -3,
          "source": "TRG Prime Codex, Part II, source block 2091"
        },
        {
          "id": "type-fey-2",
          "label": "+1 to all saving throws",
          "dp": 4,
          "source": "TRG Prime Codex, Part II, source block 2091"
        },
        {
          "id": "type-fey-3",
          "label": "Death State 2",
          "dp": -6,
          "source": "TRG Prime Codex, Part II, source block 2091"
        }
      ],
      "printed": -3,
      "source": "TRG Prime Codex, Part II, source block 2091"
    },
    "humanoid": {
      "name": "HUMANOID",
      "entries": [
        {
          "id": "type-humanoid-0",
          "label": "Ordinary senses",
          "dp": 0,
          "source": "TRG Prime Codex, Part II, source block 2094"
        },
        {
          "id": "type-humanoid-1",
          "label": "Breathes, eats, and sleeps",
          "dp": 0,
          "source": "TRG Prime Codex, Part II, source block 2094"
        },
        {
          "id": "type-humanoid-2",
          "label": "Death State 5",
          "dp": 0,
          "source": "TRG Prime Codex, Part II, source block 2094"
        },
        {
          "id": "type-humanoid-3",
          "label": "No type-level ability modifier",
          "dp": 0,
          "source": "TRG Prime Codex, Part II, source block 2094"
        }
      ],
      "printed": 0,
      "source": "TRG Prime Codex, Part II, source block 2094"
    },
    "ooze": {
      "name": "OOZE",
      "entries": [
        {
          "id": "type-ooze-0",
          "label": "Intelligence −2, Charisma −2, Dexterity −2, Constitution +2",
          "dp": -6,
          "source": "TRG Prime Codex, Part II, source block 2097"
        },
        {
          "id": "type-ooze-1",
          "label": "Disease immunity",
          "dp": 3,
          "source": "TRG Prime Codex, Part II, source block 2097"
        },
        {
          "id": "type-ooze-2",
          "label": "Broad mental-effect immunity",
          "dp": 8,
          "source": "TRG Prime Codex, Part II, source block 2097"
        },
        {
          "id": "type-ooze-3",
          "label": "Poison immunity",
          "dp": 5,
          "source": "TRG Prime Codex, Part II, source block 2097"
        },
        {
          "id": "type-ooze-4",
          "label": "Sleep immunity",
          "dp": 3,
          "source": "TRG Prime Codex, Part II, source block 2097"
        },
        {
          "id": "type-ooze-5",
          "label": "Paralysis immunity",
          "dp": 3,
          "source": "TRG Prime Codex, Part II, source block 2097"
        },
        {
          "id": "type-ooze-6",
          "label": "Polymorph immunity",
          "dp": 3,
          "source": "TRG Prime Codex, Part II, source block 2097"
        },
        {
          "id": "type-ooze-7",
          "label": "Precision damage immunity",
          "dp": 5,
          "source": "TRG Prime Codex, Part II, source block 2097"
        },
        {
          "id": "type-ooze-8",
          "label": "Stunning immunity",
          "dp": 3,
          "source": "TRG Prime Codex, Part II, source block 2097"
        },
        {
          "id": "type-ooze-9",
          "label": "Critical immunity",
          "dp": 8,
          "source": "TRG Prime Codex, Part II, source block 2097"
        },
        {
          "id": "type-ooze-10",
          "label": "Cannot be Flanked or Flat-Footed",
          "dp": 5,
          "source": "TRG Prime Codex, Part II, source block 2097"
        },
        {
          "id": "type-ooze-11",
          "label": "Does not breathe or sleep",
          "dp": 3,
          "source": "TRG Prime Codex, Part II, source block 2097"
        },
        {
          "id": "type-ooze-12",
          "label": "Blind with Blindsight",
          "dp": 6,
          "source": "TRG Prime Codex, Part II, source block 2097"
        },
        {
          "id": "type-ooze-13",
          "label": "Death State 8",
          "dp": 6,
          "source": "TRG Prime Codex, Part II, source block 2097"
        }
      ],
      "printed": 55,
      "source": "TRG Prime Codex, Part II, source block 2097"
    },
    "plant": {
      "name": "PLANT",
      "entries": [
        {
          "id": "type-plant-0",
          "label": "Nightvision",
          "dp": 2,
          "source": "TRG Prime Codex, Part II, source block 2100"
        },
        {
          "id": "type-plant-1",
          "label": "Broad mental-effect immunity",
          "dp": 8,
          "source": "TRG Prime Codex, Part II, source block 2100"
        },
        {
          "id": "type-plant-2",
          "label": "Anatomical filtering of critical injuries",
          "dp": 5,
          "source": "TRG Prime Codex, Part II, source block 2100"
        },
        {
          "id": "type-plant-3",
          "label": "Death State 5",
          "dp": 0,
          "source": "TRG Prime Codex, Part II, source block 2100"
        }
      ],
      "printed": 15,
      "source": "TRG Prime Codex, Part II, source block 2100"
    },
    "undead": {
      "name": "UNDEAD",
      "entries": [
        {
          "id": "type-undead-0",
          "label": "Constitution +1",
          "dp": 4,
          "source": "TRG Prime Codex, Part II, source block 2103"
        },
        {
          "id": "type-undead-1",
          "label": "Darkvision",
          "dp": 4,
          "source": "TRG Prime Codex, Part II, source block 2103"
        },
        {
          "id": "type-undead-2",
          "label": "Bleed immunity",
          "dp": 5,
          "source": "TRG Prime Codex, Part II, source block 2103"
        },
        {
          "id": "type-undead-3",
          "label": "Poison immunity",
          "dp": 5,
          "source": "TRG Prime Codex, Part II, source block 2103"
        },
        {
          "id": "type-undead-4",
          "label": "Sleep immunity",
          "dp": 3,
          "source": "TRG Prime Codex, Part II, source block 2103"
        },
        {
          "id": "type-undead-5",
          "label": "Disease immunity",
          "dp": 3,
          "source": "TRG Prime Codex, Part II, source block 2103"
        },
        {
          "id": "type-undead-6",
          "label": "Paralysis immunity",
          "dp": 3,
          "source": "TRG Prime Codex, Part II, source block 2103"
        },
        {
          "id": "type-undead-7",
          "label": "Soul Drain immunity",
          "dp": 3,
          "source": "TRG Prime Codex, Part II, source block 2103"
        },
        {
          "id": "type-undead-8",
          "label": "Subdual damage immunity",
          "dp": 5,
          "source": "TRG Prime Codex, Part II, source block 2103"
        },
        {
          "id": "type-undead-9",
          "label": "Stunning immunity",
          "dp": 3,
          "source": "TRG Prime Codex, Part II, source block 2103"
        },
        {
          "id": "type-undead-10",
          "label": "Does not eat, breathe, or sleep",
          "dp": 4,
          "source": "TRG Prime Codex, Part II, source block 2103"
        },
        {
          "id": "type-undead-11",
          "label": "No Death State; destroyed at 0 HP",
          "dp": -6,
          "source": "TRG Prime Codex, Part II, source block 2103"
        }
      ],
      "printed": 36,
      "source": "TRG Prime Codex, Part II, source block 2103"
    },
    "wyrm": {
      "name": "WYRM",
      "entries": [
        {
          "id": "type-wyrm-0",
          "label": "Darkvision and Nightvision",
          "dp": 6,
          "source": "TRG Prime Codex, Part II, source block 2106"
        },
        {
          "id": "type-wyrm-1",
          "label": "Sleep immunity",
          "dp": 3,
          "source": "TRG Prime Codex, Part II, source block 2106"
        },
        {
          "id": "type-wyrm-2",
          "label": "Paralysis immunity",
          "dp": 3,
          "source": "TRG Prime Codex, Part II, source block 2106"
        },
        {
          "id": "type-wyrm-3",
          "label": "Death State 6",
          "dp": 2,
          "source": "TRG Prime Codex, Part II, source block 2106"
        }
      ],
      "printed": 14,
      "source": "TRG Prime Codex, Part II, source block 2106"
    }
  },
  "classes": {
    "aberration": {
      "name": "ABERRATION",
      "coreName": "Aberration (Creature Class)",
      "uuid": "Compendium.trg-prime.creature-classes.Item.IFITdqkX7sLjWiUG",
      "entries": [
        {
          "id": "class-aberration-0",
          "label": "Weapon proficiency — All Simple weapons",
          "dp": 4,
          "source": "TRG Prime Codex, Part II, source block 2136"
        },
        {
          "id": "class-aberration-1",
          "label": "Class Skills — 13 skills",
          "dp": 26,
          "source": "TRG Prime Codex, Part II, source block 2136"
        },
        {
          "id": "class-aberration-2",
          "label": "Skill Points — 6 per level",
          "dp": 4,
          "source": "TRG Prime Codex, Part II, source block 2136"
        },
        {
          "id": "class-aberration-3",
          "label": "Hit Points — 8 per level",
          "dp": 8,
          "source": "TRG Prime Codex, Part II, source block 2136"
        },
        {
          "id": "class-aberration-4",
          "label": "BAB / BDB — Secondary / Secondary",
          "dp": 12,
          "source": "TRG Prime Codex, Part II, source block 2136"
        },
        {
          "id": "class-aberration-5",
          "label": "Saving Throws — Secondary / Secondary / Primary",
          "dp": 12,
          "source": "TRG Prime Codex, Part II, source block 2136"
        }
      ],
      "magicDP": 17,
      "source": "TRG Prime Codex, Part II, source block 2136",
      "optionalMagic": true
    },
    "animal": {
      "name": "ANIMAL",
      "coreName": "Animal (Creature Class)",
      "uuid": "Compendium.trg-prime.creature-classes.Item.Ta1Imrd3mlfLThze",
      "entries": [
        {
          "id": "class-animal-0",
          "label": "Weapon proficiency — All natural weapons possessed",
          "dp": 2,
          "source": "TRG Prime Codex, Part II, source block 2139"
        },
        {
          "id": "class-animal-1",
          "label": "Class Skills — 7 skills",
          "dp": 14,
          "source": "TRG Prime Codex, Part II, source block 2139"
        },
        {
          "id": "class-animal-2",
          "label": "Skill Points — 2 per level",
          "dp": -4,
          "source": "TRG Prime Codex, Part II, source block 2139"
        },
        {
          "id": "class-animal-3",
          "label": "Skill-point ability — Wisdom instead of Intelligence",
          "dp": 0,
          "source": "TRG Prime Codex, Part II, source block 2139"
        },
        {
          "id": "class-animal-4",
          "label": "Hit Points — 10 per level",
          "dp": 12,
          "source": "TRG Prime Codex, Part II, source block 2139"
        },
        {
          "id": "class-animal-5",
          "label": "BAB / BDB — Secondary / Primary",
          "dp": 18,
          "source": "TRG Prime Codex, Part II, source block 2139"
        },
        {
          "id": "class-animal-6",
          "label": "Saving Throws — Primary / Primary / Tertiary",
          "dp": 12,
          "source": "TRG Prime Codex, Part II, source block 2139"
        }
      ],
      "magicDP": 0,
      "source": "TRG Prime Codex, Part II, source block 2139",
      "optionalMagic": false
    },
    "beast": {
      "name": "BEAST",
      "coreName": "Beast (Creature Class)",
      "uuid": "Compendium.trg-prime.creature-classes.Item.4jj5a0DMJjNqZVND",
      "entries": [
        {
          "id": "class-beast-0",
          "label": "Weapon proficiency — All natural attack forms",
          "dp": 2,
          "source": "TRG Prime Codex, Part II, source block 2142"
        },
        {
          "id": "class-beast-1",
          "label": "Class Skills — 7 skills",
          "dp": 14,
          "source": "TRG Prime Codex, Part II, source block 2142"
        },
        {
          "id": "class-beast-2",
          "label": "Skill Points — 4 per level",
          "dp": 0,
          "source": "TRG Prime Codex, Part II, source block 2142"
        },
        {
          "id": "class-beast-3",
          "label": "Hit Points — 10 per level",
          "dp": 12,
          "source": "TRG Prime Codex, Part II, source block 2142"
        },
        {
          "id": "class-beast-4",
          "label": "BAB / BDB — Primary / Primary",
          "dp": 26,
          "source": "TRG Prime Codex, Part II, source block 2142"
        },
        {
          "id": "class-beast-5",
          "label": "Saving Throws — Primary / Primary / Tertiary",
          "dp": 12,
          "source": "TRG Prime Codex, Part II, source block 2142"
        }
      ],
      "magicDP": 4,
      "source": "TRG Prime Codex, Part II, source block 2142",
      "optionalMagic": true
    },
    "construct": {
      "name": "CONSTRUCT",
      "coreName": "Construct (Creature Class)",
      "uuid": "Compendium.trg-prime.creature-classes.Item.IoFNBVxRXWxbogdF",
      "entries": [
        {
          "id": "class-construct-0",
          "label": "Weapon proficiency — Unarmed weapons only",
          "dp": 1,
          "source": "TRG Prime Codex, Part II, source block 2145"
        },
        {
          "id": "class-construct-1",
          "label": "Class Skills — None",
          "dp": 0,
          "source": "TRG Prime Codex, Part II, source block 2145"
        },
        {
          "id": "class-construct-2",
          "label": "Flexible Skill Points — 0 per level",
          "dp": -8,
          "source": "TRG Prime Codex, Part II, source block 2145"
        },
        {
          "id": "class-construct-3",
          "label": "Fixed skill ranks — Acrobatics, Athletics, and Perception",
          "dp": 4.5,
          "source": "TRG Prime Codex, Part II, source block 2145"
        },
        {
          "id": "class-construct-4",
          "label": "Hit Points — 12 per level",
          "dp": 16,
          "source": "TRG Prime Codex, Part II, source block 2145"
        },
        {
          "id": "class-construct-5",
          "label": "BAB / BDB — Primary / Primary",
          "dp": 26,
          "source": "TRG Prime Codex, Part II, source block 2145"
        },
        {
          "id": "class-construct-6",
          "label": "Saving Throws — Tertiary / Tertiary / Tertiary",
          "dp": 0,
          "source": "TRG Prime Codex, Part II, source block 2145"
        }
      ],
      "magicDP": 0,
      "source": "TRG Prime Codex, Part II, source block 2145",
      "optionalMagic": false
    },
    "elemental": {
      "name": "ELEMENTAL",
      "coreName": "Elemental (Creature Class)",
      "uuid": "Compendium.trg-prime.creature-classes.Item.m5wJYoOpFvyy3cZB",
      "entries": [
        {
          "id": "class-elemental-0",
          "label": "Weapon proficiency — All Simple and Martial weapons",
          "dp": 10,
          "source": "TRG Prime Codex, Part II, source block 2148"
        },
        {
          "id": "class-elemental-1",
          "label": "Armour proficiency — All armour",
          "dp": 6,
          "source": "TRG Prime Codex, Part II, source block 2148"
        },
        {
          "id": "class-elemental-2",
          "label": "Shield proficiency — All shields",
          "dp": 6,
          "source": "TRG Prime Codex, Part II, source block 2148"
        },
        {
          "id": "class-elemental-3",
          "label": "Class Skills — 9 skills",
          "dp": 18,
          "source": "TRG Prime Codex, Part II, source block 2148"
        },
        {
          "id": "class-elemental-4",
          "label": "Skill Points — 4 per level",
          "dp": 0,
          "source": "TRG Prime Codex, Part II, source block 2148"
        },
        {
          "id": "class-elemental-5",
          "label": "Hit Points — 10 per level",
          "dp": 12,
          "source": "TRG Prime Codex, Part II, source block 2148"
        },
        {
          "id": "class-elemental-6",
          "label": "BAB / BDB — Primary / Primary",
          "dp": 26,
          "source": "TRG Prime Codex, Part II, source block 2148"
        },
        {
          "id": "class-elemental-7",
          "label": "Saving Throws — Primary / Primary / Secondary",
          "dp": 15,
          "source": "TRG Prime Codex, Part II, source block 2148"
        }
      ],
      "magicDP": 4,
      "source": "TRG Prime Codex, Part II, source block 2148",
      "optionalMagic": true
    },
    "eternal": {
      "name": "ETERNAL",
      "coreName": "Eternal (Creature Class)",
      "uuid": "Compendium.trg-prime.creature-classes.Item.AWSUWlUqEmh1QpHv",
      "entries": [
        {
          "id": "class-eternal-0",
          "label": "Weapon proficiency — All Simple and Martial weapons",
          "dp": 10,
          "source": "TRG Prime Codex, Part II, source block 2151"
        },
        {
          "id": "class-eternal-1",
          "label": "Armour proficiency — All armour",
          "dp": 6,
          "source": "TRG Prime Codex, Part II, source block 2151"
        },
        {
          "id": "class-eternal-2",
          "label": "Shield proficiency — All shields",
          "dp": 6,
          "source": "TRG Prime Codex, Part II, source block 2151"
        },
        {
          "id": "class-eternal-3",
          "label": "Class Skills — 14 skills",
          "dp": 28,
          "source": "TRG Prime Codex, Part II, source block 2151"
        },
        {
          "id": "class-eternal-4",
          "label": "Skill Points — 6 per level",
          "dp": 4,
          "source": "TRG Prime Codex, Part II, source block 2151"
        },
        {
          "id": "class-eternal-5",
          "label": "Hit Points — 10 per level",
          "dp": 12,
          "source": "TRG Prime Codex, Part II, source block 2151"
        },
        {
          "id": "class-eternal-6",
          "label": "BAB / BDB — Primary / Primary",
          "dp": 26,
          "source": "TRG Prime Codex, Part II, source block 2151"
        },
        {
          "id": "class-eternal-7",
          "label": "Saving Throws — Primary / Secondary / Primary",
          "dp": 15,
          "source": "TRG Prime Codex, Part II, source block 2151"
        }
      ],
      "magicDP": 37,
      "source": "TRG Prime Codex, Part II, source block 2151",
      "optionalMagic": true
    },
    "fey": {
      "name": "FEY",
      "coreName": "Fey (Creature Class)",
      "uuid": "Compendium.trg-prime.creature-classes.Item.XzAkOALzmi46o9Sl",
      "entries": [
        {
          "id": "class-fey-0",
          "label": "Weapon proficiency — All Simple weapons",
          "dp": 4,
          "source": "TRG Prime Codex, Part II, source block 2154"
        },
        {
          "id": "class-fey-1",
          "label": "Armour proficiency — Any non-metal armour",
          "dp": 6,
          "source": "TRG Prime Codex, Part II, source block 2154"
        },
        {
          "id": "class-fey-2",
          "label": "Class Skills — 13 skills",
          "dp": 26,
          "source": "TRG Prime Codex, Part II, source block 2154"
        },
        {
          "id": "class-fey-3",
          "label": "Skill Points — 8 per level",
          "dp": 8,
          "source": "TRG Prime Codex, Part II, source block 2154"
        },
        {
          "id": "class-fey-4",
          "label": "Hit Points — 6 per level",
          "dp": 4,
          "source": "TRG Prime Codex, Part II, source block 2154"
        },
        {
          "id": "class-fey-5",
          "label": "BAB / BDB — Tertiary / Tertiary",
          "dp": 0,
          "source": "TRG Prime Codex, Part II, source block 2154"
        },
        {
          "id": "class-fey-6",
          "label": "Saving Throws — Tertiary / Primary / Primary",
          "dp": 12,
          "source": "TRG Prime Codex, Part II, source block 2154"
        }
      ],
      "magicDP": 37,
      "source": "TRG Prime Codex, Part II, source block 2154",
      "optionalMagic": true
    },
    "humanoid": {
      "name": "HUMANOID",
      "coreName": "Humanoid (Creature Class)",
      "uuid": "Compendium.trg-prime.creature-classes.Item.cnnLioj7zyj3AKzi",
      "entries": [
        {
          "id": "class-humanoid-0",
          "label": "Weapon proficiency — All Simple weapons",
          "dp": 4,
          "source": "TRG Prime Codex, Part II, source block 2157"
        },
        {
          "id": "class-humanoid-1",
          "label": "Armour proficiency — Light armour",
          "dp": 2,
          "source": "TRG Prime Codex, Part II, source block 2157"
        },
        {
          "id": "class-humanoid-2",
          "label": "Class Skills — 7 skills",
          "dp": 14,
          "source": "TRG Prime Codex, Part II, source block 2157"
        },
        {
          "id": "class-humanoid-3",
          "label": "Skill Points — 4 per level",
          "dp": 0,
          "source": "TRG Prime Codex, Part II, source block 2157"
        },
        {
          "id": "class-humanoid-4",
          "label": "Hit Points — 8 per level",
          "dp": 8,
          "source": "TRG Prime Codex, Part II, source block 2157"
        },
        {
          "id": "class-humanoid-5",
          "label": "BAB / BDB — Secondary / Secondary",
          "dp": 12,
          "source": "TRG Prime Codex, Part II, source block 2157"
        },
        {
          "id": "class-humanoid-6",
          "label": "Saving Throws — Secondary / Secondary / Secondary",
          "dp": 9,
          "source": "TRG Prime Codex, Part II, source block 2157"
        }
      ],
      "magicDP": 0,
      "source": "TRG Prime Codex, Part II, source block 2157",
      "optionalMagic": false
    },
    "ooze": {
      "name": "OOZE",
      "coreName": "Ooze (Creature Class)",
      "uuid": "Compendium.trg-prime.creature-classes.Item.Co4Oh0OzeWhi8Wbi",
      "entries": [
        {
          "id": "class-ooze-0",
          "label": "Weapon proficiency — Natural weapons only",
          "dp": 2,
          "source": "TRG Prime Codex, Part II, source block 2160"
        },
        {
          "id": "class-ooze-1",
          "label": "Class Skills — Survival",
          "dp": 2,
          "source": "TRG Prime Codex, Part II, source block 2160"
        },
        {
          "id": "class-ooze-2",
          "label": "Skill Points — 2 per level",
          "dp": -4,
          "source": "TRG Prime Codex, Part II, source block 2160"
        },
        {
          "id": "class-ooze-3",
          "label": "Hit Points — 10 per level",
          "dp": 12,
          "source": "TRG Prime Codex, Part II, source block 2160"
        },
        {
          "id": "class-ooze-4",
          "label": "BAB / BDB — Secondary / Secondary",
          "dp": 12,
          "source": "TRG Prime Codex, Part II, source block 2160"
        },
        {
          "id": "class-ooze-5",
          "label": "Saving Throws — Tertiary / Tertiary / Tertiary",
          "dp": 0,
          "source": "TRG Prime Codex, Part II, source block 2160"
        }
      ],
      "magicDP": 0,
      "source": "TRG Prime Codex, Part II, source block 2160",
      "optionalMagic": false
    },
    "plant": {
      "name": "PLANT",
      "coreName": "Plant (Creature Class)",
      "uuid": "Compendium.trg-prime.creature-classes.Item.Ogk8BCNDazG1m6hP",
      "entries": [
        {
          "id": "class-plant-0",
          "label": "Weapon proficiency — Natural weapons only",
          "dp": 2,
          "source": "TRG Prime Codex, Part II, source block 2163"
        },
        {
          "id": "class-plant-1",
          "label": "Class Skills — 8 skills",
          "dp": 16,
          "source": "TRG Prime Codex, Part II, source block 2163"
        },
        {
          "id": "class-plant-2",
          "label": "Skill Points — 4 per level",
          "dp": 0,
          "source": "TRG Prime Codex, Part II, source block 2163"
        },
        {
          "id": "class-plant-3",
          "label": "Hit Points — 8 per level",
          "dp": 8,
          "source": "TRG Prime Codex, Part II, source block 2163"
        },
        {
          "id": "class-plant-4",
          "label": "BAB / BDB — Secondary / Secondary",
          "dp": 12,
          "source": "TRG Prime Codex, Part II, source block 2163"
        },
        {
          "id": "class-plant-5",
          "label": "Saving Throws — Primary / Tertiary / Secondary",
          "dp": 9,
          "source": "TRG Prime Codex, Part II, source block 2163"
        }
      ],
      "magicDP": 4,
      "source": "TRG Prime Codex, Part II, source block 2163",
      "optionalMagic": true
    },
    "undead": {
      "name": "UNDEAD",
      "coreName": "Undead (Creature Class)",
      "uuid": "Compendium.trg-prime.creature-classes.Item.8gKRcPKHGnAUNmKc",
      "entries": [
        {
          "id": "class-undead-0",
          "label": "Weapon proficiency — All Simple and natural weapons",
          "dp": 6,
          "source": "TRG Prime Codex, Part II, source block 2166"
        },
        {
          "id": "class-undead-1",
          "label": "Class Skills — 9 skills",
          "dp": 18,
          "source": "TRG Prime Codex, Part II, source block 2166"
        },
        {
          "id": "class-undead-2",
          "label": "Skill Points — 6 per level",
          "dp": 4,
          "source": "TRG Prime Codex, Part II, source block 2166"
        },
        {
          "id": "class-undead-3",
          "label": "Hit Points — 8 per level",
          "dp": 8,
          "source": "TRG Prime Codex, Part II, source block 2166"
        },
        {
          "id": "class-undead-4",
          "label": "BAB / BDB — Secondary / Secondary",
          "dp": 12,
          "source": "TRG Prime Codex, Part II, source block 2166"
        },
        {
          "id": "class-undead-5",
          "label": "Saving Throws — Primary / Secondary / Primary",
          "dp": 15,
          "source": "TRG Prime Codex, Part II, source block 2166"
        }
      ],
      "magicDP": 17,
      "source": "TRG Prime Codex, Part II, source block 2166",
      "optionalMagic": true
    },
    "wyrm": {
      "name": "WYRM",
      "coreName": "Wyrm (Creature Class)",
      "uuid": "Compendium.trg-prime.creature-classes.Item.yujTGHco3wS11sRF",
      "entries": [
        {
          "id": "class-wyrm-0",
          "label": "Weapon proficiency — All Simple, Martial, and natural weapons",
          "dp": 12,
          "source": "TRG Prime Codex, Part II, source block 2169"
        },
        {
          "id": "class-wyrm-1",
          "label": "Armour proficiency — All armour",
          "dp": 6,
          "source": "TRG Prime Codex, Part II, source block 2169"
        },
        {
          "id": "class-wyrm-2",
          "label": "Class Skills — 15 skills",
          "dp": 30,
          "source": "TRG Prime Codex, Part II, source block 2169"
        },
        {
          "id": "class-wyrm-3",
          "label": "Skill Points — 8 per level",
          "dp": 8,
          "source": "TRG Prime Codex, Part II, source block 2169"
        },
        {
          "id": "class-wyrm-4",
          "label": "Hit Points — 12 per level",
          "dp": 16,
          "source": "TRG Prime Codex, Part II, source block 2169"
        },
        {
          "id": "class-wyrm-5",
          "label": "BAB / BDB — Primary / Primary",
          "dp": 26,
          "source": "TRG Prime Codex, Part II, source block 2169"
        },
        {
          "id": "class-wyrm-6",
          "label": "Saving Throws — Primary / Primary / Primary",
          "dp": 18,
          "source": "TRG Prime Codex, Part II, source block 2169"
        }
      ],
      "magicDP": 31,
      "source": "TRG Prime Codex, Part II, source block 2169",
      "optionalMagic": true
    },
    "adept-npc": {
      "name": "ADEPT NPC",
      "coreName": "Caster (Creature Class)",
      "uuid": "Compendium.trg-prime.creature-classes.Item.dF9QyL2wkjtIWSDJ",
      "entries": [
        {
          "id": "class-adept-npc-0",
          "label": "Class Type — Adept",
          "dp": 0,
          "source": "TRG Prime Codex, Part II, source block 2176"
        },
        {
          "id": "class-adept-npc-1",
          "label": "Weapon proficiency — All Simple weapons",
          "dp": 4,
          "source": "TRG Prime Codex, Part II, source block 2176"
        },
        {
          "id": "class-adept-npc-2",
          "label": "Class Skills — 8 fixed skills plus one Tradition skill",
          "dp": 18,
          "source": "TRG Prime Codex, Part II, source block 2176"
        },
        {
          "id": "class-adept-npc-3",
          "label": "Skill Points — 4 per level",
          "dp": 0,
          "source": "TRG Prime Codex, Part II, source block 2176"
        },
        {
          "id": "class-adept-npc-4",
          "label": "Hit Points — 6 per level",
          "dp": 4,
          "source": "TRG Prime Codex, Part II, source block 2176"
        },
        {
          "id": "class-adept-npc-5",
          "label": "BAB / BDB — Tertiary / Tertiary",
          "dp": 0,
          "source": "TRG Prime Codex, Part II, source block 2176"
        },
        {
          "id": "class-adept-npc-6",
          "label": "Saving Throws — Tertiary / Tertiary / Primary",
          "dp": 6,
          "source": "TRG Prime Codex, Part II, source block 2176"
        },
        {
          "id": "class-adept-npc-7",
          "label": "Casting infrastructure — Primary BSB; Primary CL; 4 PP per level",
          "dp": 37,
          "source": "TRG Prime Codex, Part II, source block 2176"
        }
      ],
      "magicDP": 0,
      "source": "TRG Prime Codex, Part II, source block 2176",
      "optionalMagic": false
    },
    "expert-npc": {
      "name": "EXPERT NPC",
      "coreName": "Sneak (Creature Class)",
      "uuid": "Compendium.trg-prime.creature-classes.Item.HKcKRTzDHRVeGmzX",
      "entries": [
        {
          "id": "class-expert-npc-0",
          "label": "Class Type — Expert",
          "dp": 0,
          "source": "TRG Prime Codex, Part II, source block 2179"
        },
        {
          "id": "class-expert-npc-1",
          "label": "Simple weapons — All Simple weapons",
          "dp": 4,
          "source": "TRG Prime Codex, Part II, source block 2179"
        },
        {
          "id": "class-expert-npc-2",
          "label": "Small-weapon supplement — Small weapons beyond Simple access",
          "dp": 2,
          "source": "TRG Prime Codex, Part II, source block 2179"
        },
        {
          "id": "class-expert-npc-3",
          "label": "Shortbow supplement — Shortbow family",
          "dp": 2,
          "source": "TRG Prime Codex, Part II, source block 2179"
        },
        {
          "id": "class-expert-npc-4",
          "label": "Armour proficiency — Light armour",
          "dp": 2,
          "source": "TRG Prime Codex, Part II, source block 2179"
        },
        {
          "id": "class-expert-npc-5",
          "label": "Shield proficiency — Bucklers",
          "dp": 2,
          "source": "TRG Prime Codex, Part II, source block 2179"
        },
        {
          "id": "class-expert-npc-6",
          "label": "Class Skills — 13 skills",
          "dp": 26,
          "source": "TRG Prime Codex, Part II, source block 2179"
        },
        {
          "id": "class-expert-npc-7",
          "label": "Skill Points — 8 per level",
          "dp": 8,
          "source": "TRG Prime Codex, Part II, source block 2179"
        },
        {
          "id": "class-expert-npc-8",
          "label": "Hit Points — 8 per level",
          "dp": 8,
          "source": "TRG Prime Codex, Part II, source block 2179"
        },
        {
          "id": "class-expert-npc-9",
          "label": "BAB / BDB — Secondary / Primary",
          "dp": 18,
          "source": "TRG Prime Codex, Part II, source block 2179"
        },
        {
          "id": "class-expert-npc-10",
          "label": "Saving Throws — Secondary / Primary / Tertiary",
          "dp": 9,
          "source": "TRG Prime Codex, Part II, source block 2179"
        }
      ],
      "magicDP": 0,
      "source": "TRG Prime Codex, Part II, source block 2179",
      "optionalMagic": false
    },
    "hybrid-npc": {
      "name": "HYBRID NPC",
      "coreName": "Hybrid (Creature Class)",
      "uuid": "Compendium.trg-prime.creature-classes.Item.fcgEF6ZnJuJSndxb",
      "entries": [
        {
          "id": "class-hybrid-npc-0",
          "label": "Class Types — Adept and Martial",
          "dp": 2,
          "source": "TRG Prime Codex, Part II, source block 2182"
        },
        {
          "id": "class-hybrid-npc-1",
          "label": "Weapon proficiency — All Simple and Martial weapons",
          "dp": 10,
          "source": "TRG Prime Codex, Part II, source block 2182"
        },
        {
          "id": "class-hybrid-npc-2",
          "label": "Armour proficiency — Light and Medium armour",
          "dp": 4,
          "source": "TRG Prime Codex, Part II, source block 2182"
        },
        {
          "id": "class-hybrid-npc-3",
          "label": "Shield proficiency — Light and Heavy shields",
          "dp": 4,
          "source": "TRG Prime Codex, Part II, source block 2182"
        },
        {
          "id": "class-hybrid-npc-4",
          "label": "Class Skills — 7 fixed skills plus one Tradition skill",
          "dp": 16,
          "source": "TRG Prime Codex, Part II, source block 2182"
        },
        {
          "id": "class-hybrid-npc-5",
          "label": "Skill Points — 4 per level",
          "dp": 0,
          "source": "TRG Prime Codex, Part II, source block 2182"
        },
        {
          "id": "class-hybrid-npc-6",
          "label": "Hit Points — 8 per level",
          "dp": 8,
          "source": "TRG Prime Codex, Part II, source block 2182"
        },
        {
          "id": "class-hybrid-npc-7",
          "label": "BAB / BDB — Primary / Primary",
          "dp": 26,
          "source": "TRG Prime Codex, Part II, source block 2182"
        },
        {
          "id": "class-hybrid-npc-8",
          "label": "Saving Throws — Primary / Secondary / Tertiary",
          "dp": 9,
          "source": "TRG Prime Codex, Part II, source block 2182"
        },
        {
          "id": "class-hybrid-npc-9",
          "label": "Casting infrastructure — Secondary BSB; Secondary CL; 2 PP per level",
          "dp": 17,
          "source": "TRG Prime Codex, Part II, source block 2182"
        }
      ],
      "magicDP": 0,
      "source": "TRG Prime Codex, Part II, source block 2182",
      "optionalMagic": false
    },
    "martial-npc": {
      "name": "MARTIAL NPC",
      "coreName": "Tough (Creature Class)",
      "uuid": "Compendium.trg-prime.creature-classes.Item.gg3mPWzigGFbeg0Z",
      "entries": [
        {
          "id": "class-martial-npc-0",
          "label": "Class Type — Martial",
          "dp": 0,
          "source": "TRG Prime Codex, Part II, source block 2185"
        },
        {
          "id": "class-martial-npc-1",
          "label": "Weapon proficiency — All Simple and Martial weapons",
          "dp": 10,
          "source": "TRG Prime Codex, Part II, source block 2185"
        },
        {
          "id": "class-martial-npc-2",
          "label": "Armour proficiency — All armour",
          "dp": 6,
          "source": "TRG Prime Codex, Part II, source block 2185"
        },
        {
          "id": "class-martial-npc-3",
          "label": "Shield proficiency — All shields including Tower",
          "dp": 6,
          "source": "TRG Prime Codex, Part II, source block 2185"
        },
        {
          "id": "class-martial-npc-4",
          "label": "Class Skills — 7 skills",
          "dp": 14,
          "source": "TRG Prime Codex, Part II, source block 2185"
        },
        {
          "id": "class-martial-npc-5",
          "label": "Skill Points — 4 per level",
          "dp": 0,
          "source": "TRG Prime Codex, Part II, source block 2185"
        },
        {
          "id": "class-martial-npc-6",
          "label": "Hit Points — 10 per level",
          "dp": 12,
          "source": "TRG Prime Codex, Part II, source block 2185"
        },
        {
          "id": "class-martial-npc-7",
          "label": "BAB / BDB — Primary / Primary",
          "dp": 26,
          "source": "TRG Prime Codex, Part II, source block 2185"
        },
        {
          "id": "class-martial-npc-8",
          "label": "Saving Throws — Primary / Secondary / Tertiary",
          "dp": 9,
          "source": "TRG Prime Codex, Part II, source block 2185"
        }
      ],
      "magicDP": 0,
      "source": "TRG Prime Codex, Part II, source block 2185",
      "optionalMagic": false
    }
  },
  "pcClasses": {
    "fighter": {
      "name": "Fighter",
      "dp": 208,
      "source": "TRG Prime Codex, Part II, source block 1969"
    },
    "rogue": {
      "name": "Rogue",
      "dp": 215,
      "source": "TRG Prime Codex, Part II, source block 1969"
    },
    "ranger": {
      "name": "Ranger",
      "dp": 201.5,
      "source": "TRG Prime Codex, Part II, source block 1969"
    },
    "cleric": {
      "name": "Cleric",
      "dp": 205,
      "source": "TRG Prime Codex, Part II, source block 1969"
    },
    "druid": {
      "name": "Druid",
      "dp": 219,
      "source": "TRG Prime Codex, Part II, source block 1969"
    },
    "wizard": {
      "name": "Wizard",
      "dp": 222,
      "source": "TRG Prime Codex, Part II, source block 1969"
    },
    "bard": {
      "name": "Bard",
      "dp": 201.5,
      "source": "TRG Prime Codex, Part II, source block 1969"
    },
    "crusader": {
      "name": "Crusader",
      "dp": 206.5,
      "source": "TRG Prime Codex, Part II, source block 1969"
    }
  },
  "abilities": {
    "absorb-minerals": {
      "name": "Absorb Minerals",
      "dp": 4,
      "perProfile": false,
      "basis": "Situational at-will healing equal to half the actual damage dealt to metal objects.",
      "source": "TRG Prime Codex, Part II, source block 2264",
      "entries": [
        {
          "label": "Situational at-will healing equal to half the actual damage dealt to metal objects.",
          "dp": 4,
          "source": "TRG Prime Codex, Part II, source block 2264"
        }
      ]
    },
    "abyssal-healing": {
      "name": "Abyssal Healing",
      "dp": 16,
      "perProfile": false,
      "basis": "PP-scaled automatic healing or condition recovery with three selectable modes and 1 AP delivery.",
      "source": "TRG Prime Codex, Part II, source block 2264",
      "entries": [
        {
          "label": "PP-scaled Specialist-equivalent effect through PP 20",
          "dp": 14,
          "source": "TRG Prime Codex, Part II, source block 2266"
        },
        {
          "label": "Automatic 1 AP delivery without an ordinary casting check",
          "dp": 1,
          "source": "TRG Prime Codex, Part II, source block 2266"
        },
        {
          "label": "Healing, Bleed Control, or Injury Recovery flexibility",
          "dp": 1,
          "source": "TRG Prime Codex, Part II, source block 2266"
        }
      ]
    },
    "acute-sense": {
      "name": "Acute Sense",
      "dp": 2,
      "perProfile": false,
      "basis": "+2 racial bonus to one named action associated with a selected sense.",
      "source": "TRG Prime Codex, Part II, source block 2264",
      "entries": [
        {
          "label": "+2 racial bonus to one named action associated with a selected sense.",
          "dp": 2,
          "source": "TRG Prime Codex, Part II, source block 2264"
        }
      ]
    },
    "alien-mind": {
      "name": "Alien Mind",
      "dp": 7,
      "perProfile": false,
      "basis": "Automatic 4d6 mental retaliation, basic Will save, whenever a mental effect targets the creature.",
      "source": "TRG Prime Codex, Part II, source block 2264",
      "entries": [
        {
          "label": "Automatic 4d6 mental retaliation, basic Will save, whenever a mental effect targets the creature.",
          "dp": 7,
          "source": "TRG Prime Codex, Part II, source block 2264"
        }
      ]
    },
    "all-round-vision": {
      "name": "All Round Vision",
      "dp": 3,
      "perProfile": false,
      "basis": "Constant immunity to flanking; narrower than the +5 cannot-be-Flanked-and-Flat-Footed bundle.",
      "source": "TRG Prime Codex, Part II, source block 2264",
      "entries": [
        {
          "label": "Constant immunity to flanking; narrower than the +5 cannot-be-Flanked-and-Flat-Footed bundle.",
          "dp": 3,
          "source": "TRG Prime Codex, Part II, source block 2264"
        }
      ]
    },
    "amorphous-split": {
      "name": "Amorphous Split",
      "dp": 25,
      "perProfile": false,
      "basis": "Conserves total HP but duplicates the complete action set; includes recursive splitting above 20 HP.",
      "source": "TRG Prime Codex, Part II, source block 2264",
      "entries": [
        {
          "label": "Creates a second complete action set while conserving total current HP",
          "dp": 20,
          "source": "TRG Prime Codex, Part II, source block 2266"
        },
        {
          "label": "Resulting copies may split again while above 20 HP",
          "dp": 5,
          "source": "TRG Prime Codex, Part II, source block 2266"
        }
      ]
    },
    "arcadian-caster": {
      "name": "Arcadian Caster",
      "dp": 18,
      "perProfile": false,
      "basis": "No casting reactions, universal Specialist treatment, and combined Arcane/Ethereal acquisition.",
      "source": "TRG Prime Codex, Part II, source block 2264",
      "entries": [
        {
          "label": "Spellcasting does not provoke reactions",
          "dp": 3,
          "source": "TRG Prime Codex, Part II, source block 2266"
        },
        {
          "label": "All spells receive universal Specialist treatment",
          "dp": 9,
          "source": "TRG Prime Codex, Part II, source block 2266"
        },
        {
          "label": "Additional Arcane/Ethereal tradition access",
          "dp": 4,
          "source": "TRG Prime Codex, Part II, source block 2266"
        },
        {
          "label": "Ethereal Learned self-learning",
          "dp": 2,
          "source": "TRG Prime Codex, Part II, source block 2266"
        }
      ]
    },
    "ashen-aura": {
      "name": "Ashen Aura",
      "dp": 14,
      "perProfile": false,
      "basis": "Constant 20-foot 4d6 poison aura with concealment in both directions.",
      "source": "TRG Prime Codex, Part II, source block 2264",
      "entries": [
        {
          "label": "Constant 20-foot 4d6 poison aura with concealment in both directions.",
          "dp": 14,
          "source": "TRG Prime Codex, Part II, source block 2264"
        }
      ]
    },
    "aura-of-confusion": {
      "name": "Aura of Confusion",
      "dp": 19,
      "perProfile": false,
      "basis": "Constant repeated control aura; even a success causes Stunned 1 and failures cause Confused.",
      "source": "TRG Prime Codex, Part II, source block 2264",
      "entries": [
        {
          "label": "Constant repeated control aura; even a success causes Stunned 1 and failures cause Confused.",
          "dp": 19,
          "source": "TRG Prime Codex, Part II, source block 2264"
        }
      ]
    },
    "aura-of-death": {
      "name": "Aura of Death",
      "dp": 12,
      "perProfile": false,
      "basis": "Constant 30-foot 4d6 essence aura, basic Fortitude, restricted to living creatures.",
      "source": "TRG Prime Codex, Part II, source block 2264",
      "entries": [
        {
          "label": "Constant 30-foot 4d6 essence aura, basic Fortitude, restricted to living creatures.",
          "dp": 12,
          "source": "TRG Prime Codex, Part II, source block 2264"
        }
      ]
    },
    "aura-of-decay": {
      "name": "Aura of Decay",
      "dp": 13,
      "perProfile": false,
      "basis": "Constant 30-foot 4d8 poison aura, basic Fortitude.",
      "source": "TRG Prime Codex, Part II, source block 2264",
      "entries": [
        {
          "label": "Constant 30-foot 4d8 poison aura, basic Fortitude.",
          "dp": 13,
          "source": "TRG Prime Codex, Part II, source block 2264"
        }
      ]
    },
    "aura-of-despair": {
      "name": "Aura of Despair",
      "dp": 22,
      "perProfile": false,
      "basis": "Constant repeated fear/paralysis aura with severe results through unconsciousness at 0 HP.",
      "source": "TRG Prime Codex, Part II, source block 2264",
      "entries": [
        {
          "label": "Constant repeated fear/paralysis aura with severe results through unconsciousness at 0 HP.",
          "dp": 22,
          "source": "TRG Prime Codex, Part II, source block 2264"
        }
      ]
    },
    "aura-of-fire": {
      "name": "Aura of Fire",
      "dp": 12,
      "perProfile": false,
      "basis": "Constant 20-foot 4d6 fire aura, basic Reflex.",
      "source": "TRG Prime Codex, Part II, source block 2264",
      "entries": [
        {
          "label": "Constant 20-foot 4d6 fire aura, basic Reflex.",
          "dp": 12,
          "source": "TRG Prime Codex, Part II, source block 2264"
        }
      ]
    },
    "aura-of-heat": {
      "name": "Aura of Heat",
      "dp": 11,
      "perProfile": false,
      "basis": "Constant 20-foot 2d6 fire aura, basic Reflex.",
      "source": "TRG Prime Codex, Part II, source block 2264",
      "entries": [
        {
          "label": "Constant 20-foot 2d6 fire aura, basic Reflex.",
          "dp": 11,
          "source": "TRG Prime Codex, Part II, source block 2264"
        }
      ]
    },
    "aura-of-ruin": {
      "name": "Aura of Ruin",
      "dp": 6,
      "perProfile": false,
      "basis": "Constant narrow alignment-targeted aura causing Sickened 1, or 2 on a fumble.",
      "source": "TRG Prime Codex, Part II, source block 2264",
      "entries": [
        {
          "label": "Constant narrow alignment-targeted aura causing Sickened 1, or 2 on a fumble.",
          "dp": 6,
          "source": "TRG Prime Codex, Part II, source block 2264"
        }
      ]
    },
    "aura-of-tranquility": {
      "name": "Aura of Tranquility",
      "dp": 6,
      "perProfile": false,
      "basis": "Constant 30-foot allied advantage against fear and charm saves.",
      "source": "TRG Prime Codex, Part II, source block 2264",
      "entries": [
        {
          "label": "Constant 30-foot allied advantage against fear and charm saves.",
          "dp": 6,
          "source": "TRG Prime Codex, Part II, source block 2264"
        }
      ]
    },
    "blight-sense": {
      "name": "Blight Sense",
      "dp": 2,
      "perProfile": false,
      "basis": "Narrow Tertiary sense detecting creatures that are cursed, diseased, or poisoned.",
      "source": "TRG Prime Codex, Part II, source block 2282",
      "entries": [
        {
          "label": "Narrow Tertiary sense detecting creatures that are cursed, diseased, or poisoned.",
          "dp": 2,
          "source": "TRG Prime Codex, Part II, source block 2282"
        }
      ]
    },
    "blood-scent": {
      "name": "Blood Scent",
      "dp": 5,
      "perProfile": false,
      "basis": "Narrow Tertiary blood-detection sense (+2) with extreme range of up to one mile (+3).",
      "source": "TRG Prime Codex, Part II, source block 2282",
      "entries": [
        {
          "label": "Narrow or conditional Tertiary sense",
          "dp": 2,
          "source": "TRG Prime Codex, Part II, source block 2284"
        },
        {
          "label": "Extreme range: up to one mile",
          "dp": 3,
          "source": "TRG Prime Codex, Part II, source block 2284"
        }
      ]
    },
    "clinging-breath": {
      "name": "Clinging Breath",
      "dp": 6,
      "perProfile": false,
      "basis": "Free delayed rider that repeats half the breath weapon dice as acid damage after a basic Fortitude save.",
      "source": "TRG Prime Codex, Part II, source block 2282",
      "entries": [
        {
          "label": "Level-scaling follow-up damage equal to half the breath dice",
          "dp": 7,
          "source": "TRG Prime Codex, Part II, source block 2284"
        },
        {
          "label": "One-round delay and a new basic Fortitude save",
          "dp": -2,
          "source": "TRG Prime Codex, Part II, source block 2284"
        },
        {
          "label": "Free delivery to every qualifying breath target",
          "dp": 1,
          "source": "TRG Prime Codex, Part II, source block 2284"
        }
      ]
    },
    "constrict": {
      "name": "Constrict",
      "dp": 8,
      "perProfile": false,
      "basis": "One-action, save-based damage against any number of targets already grabbed or restrained by the creature.",
      "source": "TRG Prime Codex, Part II, source block 2282",
      "entries": [
        {
          "label": "Reliable 1 AP damage against held targets",
          "dp": 6,
          "source": "TRG Prime Codex, Part II, source block 2284"
        },
        {
          "label": "May affect any number of targets grabbed or restrained by the creature",
          "dp": 2,
          "source": "TRG Prime Codex, Part II, source block 2284"
        }
      ]
    },
    "corrode": {
      "name": "Corrode",
      "dp": 5,
      "perProfile": false,
      "basis": "Automatic transfer of secondary damage to a target's metal armour and, where applicable, shield.",
      "source": "TRG Prime Codex, Part II, source block 2282",
      "entries": [
        {
          "label": "Automatic equipment damage equal to secondary damage inflicted",
          "dp": 6,
          "source": "TRG Prime Codex, Part II, source block 2284"
        },
        {
          "label": "Restricted to metal armour; shield damage is split rather than duplicated",
          "dp": -1,
          "source": "TRG Prime Codex, Part II, source block 2284"
        }
      ]
    },
    "crush": {
      "name": "Crush",
      "dp": 16,
      "perProfile": false,
      "basis": "One-action repeatable space-control attack with severe scaling damage, automatic critical injuries, DR bypass, and movement conditions.",
      "source": "TRG Prime Codex, Part II, source block 2295",
      "entries": [
        {
          "label": "One-action repeatable save-based damage profile, averaging approximately 4d10",
          "dp": 10,
          "source": "TRG Prime Codex, Part II, source block 2297"
        },
        {
          "label": "Minor, Serious, or Deadly critical injury on poor save results",
          "dp": 3,
          "source": "TRG Prime Codex, Part II, source block 2297"
        },
        {
          "label": "Damage bypasses all DR",
          "dp": 2,
          "source": "TRG Prime Codex, Part II, source block 2297"
        },
        {
          "label": "Forced movement, Prone, and Immobilised outcomes",
          "dp": 3,
          "source": "TRG Prime Codex, Part II, source block 2297"
        },
        {
          "label": "Requires the target to be at least two sizes smaller and inside the creature's space",
          "dp": -2,
          "source": "TRG Prime Codex, Part II, source block 2297"
        }
      ]
    },
    "detect-magic": {
      "name": "Detect Magic",
      "dp": 6,
      "perProfile": false,
      "basis": "Passive magical detection, +2 Sense Magic, and expanded access to Power Manipulation actions.",
      "source": "TRG Prime Codex, Part II, source block 2295",
      "entries": [
        {
          "label": "Passive detection of active magic as a narrow magical sense",
          "dp": 2,
          "source": "TRG Prime Codex, Part II, source block 2299"
        },
        {
          "label": "+2 racial bonus to Sense Magic checks",
          "dp": 2,
          "source": "TRG Prime Codex, Part II, source block 2299"
        },
        {
          "label": "May develop Power Manipulation without prerequisites and use Sense Power untrained",
          "dp": 2,
          "source": "TRG Prime Codex, Part II, source block 2299"
        }
      ]
    },
    "dispelling-strike": {
      "name": "Dispelling Strike",
      "dp": 9,
      "perProfile": false,
      "basis": "Free 0 PP Dispel attempt whenever a melee Strike hits.",
      "source": "TRG Prime Codex, Part II, source block 2295",
      "entries": [
        {
          "label": "At-will 0 PP Dispel attempt",
          "dp": 7,
          "source": "TRG Prime Codex, Part II, source block 2299"
        },
        {
          "label": "Free automatic delivery after a successful melee Strike",
          "dp": 3,
          "source": "TRG Prime Codex, Part II, source block 2299"
        },
        {
          "label": "Requires a melee hit and a dispellable effect on the target",
          "dp": -1,
          "source": "TRG Prime Codex, Part II, source block 2299"
        }
      ]
    },
    "diving-strike": {
      "name": "Diving Strike",
      "dp": 5,
      "perProfile": false,
      "basis": "Compresses two Fly Strides and one claw Strike into 2 AP and grants +2 to the attack, with strict movement requirements.",
      "source": "TRG Prime Codex, Part II, source block 2295",
      "entries": [
        {
          "label": "One AP of action compression: two Fly Strides plus one Strike for 2 AP",
          "dp": 4,
          "source": "TRG Prime Codex, Part II, source block 2297"
        },
        {
          "label": "+2 circumstance bonus to the claw Strike",
          "dp": 2,
          "source": "TRG Prime Codex, Part II, source block 2297"
        },
        {
          "label": "Straight-line flight, 10-foot descent, Fly Speed, and claw restrictions",
          "dp": -1,
          "source": "TRG Prime Codex, Part II, source block 2297"
        }
      ]
    },
    "double-strike": {
      "name": "Double Strike",
      "dp": 7,
      "perProfile": false,
      "basis": "Two attacks for 1 AP without applying MAP between them, restricted to separate targets and different limbs.",
      "source": "TRG Prime Codex, Part II, source block 2295",
      "entries": [
        {
          "label": "Second Strike included in the same 1 AP action",
          "dp": 4,
          "source": "TRG Prime Codex, Part II, source block 2297"
        },
        {
          "label": "MAP does not apply until both Strikes are resolved",
          "dp": 4,
          "source": "TRG Prime Codex, Part II, source block 2297"
        },
        {
          "label": "Different limbs and separate targets are mandatory",
          "dp": -1,
          "source": "TRG Prime Codex, Part II, source block 2297"
        }
      ]
    },
    "draconic-assault": {
      "name": "Draconic Assault",
      "dp": 6,
      "perProfile": false,
      "basis": "Three fixed natural attacks for 2 AP; ordinary MAP still applies.",
      "source": "TRG Prime Codex, Part II, source block 2295",
      "entries": [
        {
          "label": "Third Strike included in a 2 AP three-attack routine",
          "dp": 5,
          "source": "TRG Prime Codex, Part II, source block 2297"
        },
        {
          "label": "Fixed two-claw-then-other-natural-attack routine",
          "dp": -1,
          "source": "TRG Prime Codex, Part II, source block 2297"
        },
        {
          "label": "Broad value of retaining 1 AP after a full three-attack routine",
          "dp": 2,
          "source": "TRG Prime Codex, Part II, source block 2297"
        }
      ]
    },
    "draconic-roar": {
      "name": "Draconic Roar",
      "dp": 8,
      "perProfile": false,
      "basis": "Once-per-hour breath-weapon damage delivered throughout the Frightful Aura area after a basic Fortitude save.",
      "source": "TRG Prime Codex, Part II, source block 2295",
      "entries": [
        {
          "label": "Area delivery of the creature's existing breath-weapon damage",
          "dp": 8,
          "source": "TRG Prime Codex, Part II, source block 2299"
        },
        {
          "label": "Frightful Aura radius can substantially exceed a normal breath area",
          "dp": 3,
          "source": "TRG Prime Codex, Part II, source block 2299"
        },
        {
          "label": "Once per hour and requires both a breath weapon and Frightful Aura",
          "dp": -3,
          "source": "TRG Prime Codex, Part II, source block 2299"
        }
      ]
    },
    "draconic-shifting": {
      "name": "Draconic Shifting",
      "dp": 4,
      "perProfile": false,
      "basis": "At-will humanoid transformation with retained movement and attack modifiers but reduced attack lethality.",
      "source": "TRG Prime Codex, Part II, source block 2295",
      "entries": [
        {
          "label": "At-will Small or Medium humanoid transformation",
          "dp": 5,
          "source": "TRG Prime Codex, Part II, source block 2299"
        },
        {
          "label": "Retains Speed and Strike modifiers but physical Strikes become subdual unarmed attacks",
          "dp": -1,
          "source": "TRG Prime Codex, Part II, source block 2299"
        }
      ]
    },
    "drink-blood": {
      "name": "Drink Blood",
      "dp": 9,
      "perProfile": false,
      "basis": "One-action Soul Drain 10 and equal healing against a willing, helpless, or controlled adjacent target.",
      "source": "TRG Prime Codex, Part II, source block 2295",
      "entries": [
        {
          "label": "Soul Drain 10 against a qualifying adjacent target",
          "dp": 7,
          "source": "TRG Prime Codex, Part II, source block 2299"
        },
        {
          "label": "Healing equal to the Soul Drain inflicted",
          "dp": 4,
          "source": "TRG Prime Codex, Part II, source block 2299"
        },
        {
          "label": "1 AP, target-state requirement, and Athletics check against a merely Grabbed target",
          "dp": -2,
          "source": "TRG Prime Codex, Part II, source block 2299"
        }
      ]
    },
    "earth-pass": {
      "name": "Earth Pass",
      "dp": 4,
      "perProfile": false,
      "basis": "Upgrades an existing Burrow Speed to full-speed movement through dirt and stone without leaving a tunnel or trace.",
      "source": "TRG Prime Codex, Part II, source block 2295",
      "entries": [
        {
          "label": "Burrow through dirt and stone rather than ordinary loose material",
          "dp": 3,
          "source": "TRG Prime Codex, Part II, source block 2299"
        },
        {
          "label": "Leaves no tunnel or sign of passage",
          "dp": 1,
          "source": "TRG Prime Codex, Part II, source block 2299"
        }
      ]
    },
    "echolocation": {
      "name": "Echolocation",
      "dp": 7,
      "perProfile": false,
      "basis": "Passive Primary auditory sense at half the normal range of a Primary sense.",
      "source": "TRG Prime Codex, Part II, source block 2314",
      "entries": [
        {
          "label": "Primary special sense",
          "dp": 8,
          "source": "TRG Prime Codex, Part II, source block 2316"
        },
        {
          "label": "Range is half the normal Primary-sense range",
          "dp": -1,
          "source": "TRG Prime Codex, Part II, source block 2316"
        }
      ]
    },
    "elemental-grasp": {
      "name": "Elemental Grasp",
      "dp": 8,
      "perProfile": false,
      "basis": "Automatic 3d6 elemental damage to each grabbed target at the beginning of its turn, basic Reflex save.",
      "source": "TRG Prime Codex, Part II, source block 2314",
      "entries": [
        {
          "label": "Automatic repeat 3d6 elemental damage at the start of each grabbed target's turn",
          "dp": 8,
          "source": "TRG Prime Codex, Part II, source block 2316"
        },
        {
          "label": "Can affect every target currently grabbed by the creature",
          "dp": 1,
          "source": "TRG Prime Codex, Part II, source block 2316"
        },
        {
          "label": "Requires Grabbed and permits a basic Reflex save",
          "dp": -1,
          "source": "TRG Prime Codex, Part II, source block 2316"
        }
      ]
    },
    "elemental-aura": {
      "name": "Elemental Aura",
      "dp": 10,
      "perProfile": false,
      "basis": "Toggleable constant 10-foot aura inflicting 2d6 elemental damage with a basic Reflex save.",
      "source": "TRG Prime Codex, Part II, source block 2314",
      "entries": [
        {
          "label": "Constant 20-foot 2d6 basic-save aura anchor",
          "dp": 11,
          "source": "TRG Prime Codex, Part II, source block 2316"
        },
        {
          "label": "Reduced radius: 10 feet rather than 20 feet",
          "dp": -1,
          "source": "TRG Prime Codex, Part II, source block 2316"
        }
      ]
    },
    "elemental-blood": {
      "name": "Elemental Blood",
      "dp": 4,
      "perProfile": false,
      "basis": "Conditional elemental splash damage equal to persistent Bleed suffered by the creature.",
      "source": "TRG Prime Codex, Part II, source block 2314",
      "entries": [
        {
          "label": "Automatic elemental splash equal to the creature's persistent Bleed",
          "dp": 5,
          "source": "TRG Prime Codex, Part II, source block 2316"
        },
        {
          "label": "Only functions while the creature is taking persistent Bleed and may catch allies",
          "dp": -1,
          "source": "TRG Prime Codex, Part II, source block 2316"
        }
      ]
    },
    "elemental-strikes": {
      "name": "Elemental Strikes",
      "dp": 7,
      "perProfile": false,
      "basis": "All physical attacks gain 1d6 secondary elemental damage; existing elemental secondary damage is doubled.",
      "source": "TRG Prime Codex, Part II, source block 2314",
      "entries": [
        {
          "label": "1d6 secondary elemental damage on every physical attack",
          "dp": 6,
          "source": "TRG Prime Codex, Part II, source block 2316"
        },
        {
          "label": "Existing secondary elemental damage is doubled",
          "dp": 1,
          "source": "TRG Prime Codex, Part II, source block 2316"
        }
      ]
    },
    "elusive-movement": {
      "name": "Elusive Movement",
      "dp": 6,
      "perProfile": false,
      "basis": "The creature never provokes reactions caused by movement.",
      "source": "TRG Prime Codex, Part II, source block 2314",
      "entries": [
        {
          "label": "Constant immunity to all reactions triggered by movement",
          "dp": 6,
          "source": "TRG Prime Codex, Part II, source block 2316"
        }
      ]
    },
    "endless-hunger": {
      "name": "Endless Hunger",
      "dp": 0,
      "perProfile": false,
      "basis": "Narrative compulsion without a defined check, condition, starvation schedule, or enforceable combat penalty.",
      "source": "TRG Prime Codex, Part II, source block 2314",
      "entries": [
        {
          "label": "No defined mechanical consequence, compulsory check, action restriction, or starvation interval",
          "dp": 0,
          "source": "TRG Prime Codex, Part II, source block 2318"
        }
      ]
    },
    "entangling-vines": {
      "name": "Entangling Vines",
      "dp": 12,
      "perProfile": false,
      "basis": "At-will 1 AP, 20-foot-radius 4d6 piercing attack; failed saves also impose Grabbed.",
      "source": "TRG Prime Codex, Part II, source block 2314",
      "entries": [
        {
          "label": "At-will 1 AP, 20-foot-radius 4d6 piercing damage with a basic Reflex save",
          "dp": 9,
          "source": "TRG Prime Codex, Part II, source block 2318"
        },
        {
          "label": "Failure also imposes Grabbed",
          "dp": 4,
          "source": "TRG Prime Codex, Part II, source block 2318"
        },
        {
          "label": "Indiscriminate area and requirement for vines to erupt from the earth",
          "dp": -1,
          "source": "TRG Prime Codex, Part II, source block 2318"
        }
      ]
    },
    "eternal-essence": {
      "name": "Eternal Essence",
      "dp": 12,
      "perProfile": false,
      "basis": "Established package: all FDC reduced by 1 and all armour and shield penalties ignored.",
      "source": "TRG Prime Codex, Part II, source block 2314",
      "entries": [
        {
          "label": "Universal reduction of all FDC by 1",
          "dp": 5,
          "source": "TRG Prime Codex, Part II, source block 2318"
        },
        {
          "label": "Ignore ACP, Maximum Dexterity, Speed Penalty, and comparable armour or shield drawbacks",
          "dp": 7,
          "source": "TRG Prime Codex, Part II, source block 2318"
        }
      ]
    },
    "eternal-summons": {
      "name": "Eternal Summons",
      "dp": 27,
      "perProfile": false,
      "basis": "Focus-limited 2 AP summoning of one or several lower-level eternals with independent actions and encounter duration.",
      "source": "TRG Prime Codex, Part II, source block 2314",
      "entries": [
        {
          "label": "Focus version of a scaling Conjure Eternal effect through the PP 20 ceiling",
          "dp": 16,
          "source": "TRG Prime Codex, Part II, source block 2318"
        },
        {
          "label": "No Sustain cost; summoned creatures act independently immediately after the summoner",
          "dp": 4,
          "source": "TRG Prime Codex, Part II, source block 2318"
        },
        {
          "label": "Choice of one level -4, two level -6, or four level -8 allies",
          "dp": 6,
          "source": "TRG Prime Codex, Part II, source block 2318"
        },
        {
          "label": "Encounter-plus duration and placement adjacent within 20 feet",
          "dp": 2,
          "source": "TRG Prime Codex, Part II, source block 2318"
        },
        {
          "label": "2 AP, same-subtype restriction, and summoned creatures cannot repeat the ability",
          "dp": -1,
          "source": "TRG Prime Codex, Part II, source block 2318"
        }
      ]
    },
    "faultless-casting": {
      "name": "Faultless Casting",
      "dp": 3,
      "perProfile": false,
      "basis": "Every spell is defensively cast at its ordinary DC; fumbles and blunders can still provoke.",
      "source": "TRG Prime Codex, Part II, source block 2333",
      "entries": [
        {
          "label": "All spells automatically use Defensive Casting without the normal Very Hard (+5 DC) increase",
          "dp": 3,
          "source": "TRG Prime Codex, Part II, source block 2335"
        }
      ]
    },
    "fear-of-water": {
      "name": "Fear of Water",
      "dp": -1,
      "perProfile": false,
      "basis": "Cannot voluntarily cross running water, but carriage and wooden vessels provide practical bypasses.",
      "source": "TRG Prime Codex, Part II, source block 2333",
      "entries": [
        {
          "label": "Cannot voluntarily cross running water",
          "dp": -2,
          "source": "TRG Prime Codex, Part II, source block 2337"
        },
        {
          "label": "May be carried across or use a wooden vessel",
          "dp": 1,
          "source": "TRG Prime Codex, Part II, source block 2337"
        }
      ]
    },
    "fearful-strength": {
      "name": "Fearful Strength",
      "dp": 2,
      "perProfile": false,
      "basis": "May substitute Strength for Charisma on all Intimidate checks.",
      "source": "TRG Prime Codex, Part II, source block 2333",
      "entries": [
        {
          "label": "Strength may replace Charisma for the complete Intimidate skill",
          "dp": 2,
          "source": "TRG Prime Codex, Part II, source block 2335"
        }
      ]
    },
    "fire-healing": {
      "name": "Fire Healing",
      "dp": 12,
      "perProfile": false,
      "basis": "Fire damage is converted into half-value healing, with recovery and condition-removal benefits.",
      "source": "TRG Prime Codex, Part II, source block 2333",
      "entries": [
        {
          "label": "Fire damage is negated and converted into healing equal to half the incoming damage",
          "dp": 9,
          "source": "TRG Prime Codex, Part II, source block 2335"
        },
        {
          "label": "Natural recovery rate doubles while standing in a fire at least the creature's size",
          "dp": 1,
          "source": "TRG Prime Codex, Part II, source block 2335"
        },
        {
          "label": "At full HP, fire exposure may remove Bleeding 2 or reduce another condition by 1",
          "dp": 2,
          "source": "TRG Prime Codex, Part II, source block 2335"
        }
      ]
    },
    "flyby-attack": {
      "name": "Flyby Attack",
      "dp": 4,
      "perProfile": false,
      "basis": "Compresses one Fly Stride and two claw Strikes into 2 AP, with attacks during movement and separate targets.",
      "source": "TRG Prime Codex, Part II, source block 2333",
      "entries": [
        {
          "label": "One AP of compression: one Fly Stride and two claw Strikes are completed for 2 AP",
          "dp": 4,
          "source": "TRG Prime Codex, Part II, source block 2335"
        },
        {
          "label": "The attacks may occur at any points during the movement",
          "dp": 1,
          "source": "TRG Prime Codex, Part II, source block 2335"
        },
        {
          "label": "Requires Fly Speed and claws, and the attacks must target separate creatures",
          "dp": -1,
          "source": "TRG Prime Codex, Part II, source block 2335"
        }
      ]
    },
    "frightful-aura": {
      "name": "Frightful Aura",
      "dp": 18,
      "perProfile": false,
      "basis": "Free scaling fear aura with severe results through fleeing and collapse at 0 HP; one-minute target immunity.",
      "source": "TRG Prime Codex, Part II, source block 2333",
      "entries": [
        {
          "label": "Level-based fear effect ranging from Frightened 1 to fleeing or collapse at 0 HP",
          "dp": 16,
          "source": "TRG Prime Codex, Part II, source block 2337"
        },
        {
          "label": "Radius scales at 5 feet per creature level",
          "dp": 3,
          "source": "TRG Prime Codex, Part II, source block 2337"
        },
        {
          "label": "Free activation or maintenance",
          "dp": 1,
          "source": "TRG Prime Codex, Part II, source block 2337"
        },
        {
          "label": "Each target becomes immune for 1 minute after its save",
          "dp": -2,
          "source": "TRG Prime Codex, Part II, source block 2337"
        }
      ]
    },
    "gallop": {
      "name": "Gallop",
      "dp": 3,
      "perProfile": false,
      "basis": "Each of two consecutive Strides gains 10 feet of movement.",
      "source": "TRG Prime Codex, Part II, source block 2333",
      "entries": [
        {
          "label": "+10 feet to each of two consecutive Stride actions",
          "dp": 4,
          "source": "TRG Prime Codex, Part II, source block 2337"
        },
        {
          "label": "Only applies when two Strides are taken consecutively in the same turn",
          "dp": -1,
          "source": "TRG Prime Codex, Part II, source block 2337"
        }
      ]
    },
    "garlic-repulsion": {
      "name": "Garlic Repulsion",
      "dp": -3,
      "perProfile": false,
      "basis": "Garlic odour imposes Sickened 1 or 2 and bypasses immunity or resistance to Sickened.",
      "source": "TRG Prime Codex, Part II, source block 2333",
      "entries": [
        {
          "label": "Sickened 1 within garlic odour and Sickened 2 within 5 feet, overriding immunity or resistance",
          "dp": -4,
          "source": "TRG Prime Codex, Part II, source block 2337"
        },
        {
          "label": "Situational physical trigger that can usually be avoided by distance",
          "dp": 1,
          "source": "TRG Prime Codex, Part II, source block 2337"
        }
      ]
    },
    "grave-touched-presence": {
      "name": "Grave-Touched Presence",
      "dp": 2,
      "perProfile": false,
      "basis": "Two narrow +2 skill bonuses, offset by a broad but concealable attitude penalty.",
      "source": "TRG Prime Codex, Part II, source block 2333",
      "entries": [
        {
          "label": "+2 Intimidate against undead",
          "dp": 2,
          "source": "TRG Prime Codex, Part II, source block 2337"
        },
        {
          "label": "+2 Sense Motive against undead",
          "dp": 2,
          "source": "TRG Prime Codex, Part II, source block 2337"
        },
        {
          "label": "Living humanoids and intelligent undead begin one attitude step worse unless nature is concealed; listed exceptions apply",
          "dp": -2,
          "source": "TRG Prime Codex, Part II, source block 2337"
        }
      ]
    },
    "hold-breath": {
      "name": "Hold Breath",
      "dp": 1,
      "perProfile": false,
      "basis": "Can hold its breath for ten times the ordinary duration.",
      "source": "TRG Prime Codex, Part II, source block 2333",
      "entries": [
        {
          "label": "Breath-holding duration multiplied by ten",
          "dp": 1,
          "source": "TRG Prime Codex, Part II, source block 2337"
        }
      ]
    },
    "hover": {
      "name": "Hover",
      "dp": 5,
      "perProfile": false,
      "basis": "Removes the recurring AP expenditure needed to remain airborne, but requires an existing Fly Speed.",
      "source": "TRG Prime Codex, Part II, source block 2353",
      "entries": [
        {
          "label": "Removes the recurring 1 AP cost required to remain airborne",
          "dp": 6,
          "source": "TRG Prime Codex, Part II, source block 2355"
        },
        {
          "label": "Functions only while using an independently purchased Fly Speed",
          "dp": -1,
          "source": "TRG Prime Codex, Part II, source block 2355"
        }
      ]
    },
    "howl": {
      "name": "Howl",
      "dp": 8,
      "perProfile": false,
      "basis": "One-action 30-foot fear effect with results through Frightened 3 and fleeing; each target then gains 10-minute immunity.",
      "source": "TRG Prime Codex, Part II, source block 2353",
      "entries": [
        {
          "label": "30-foot multi-target Will effect with results through Frightened 3 and fleeing for 1 round",
          "dp": 11,
          "source": "TRG Prime Codex, Part II, source block 2355"
        },
        {
          "label": "Requires 1 AP to activate",
          "dp": -1,
          "source": "TRG Prime Codex, Part II, source block 2355"
        },
        {
          "label": "Each target becomes immune for 10 minutes after attempting the save",
          "dp": -2,
          "source": "TRG Prime Codex, Part II, source block 2355"
        }
      ]
    },
    "ice-climb": {
      "name": "Ice Climb",
      "dp": 5,
      "perProfile": false,
      "basis": "Uses full land Speed as a Climb Speed on ice and ignores snow- and ice-based difficult or formidable terrain.",
      "source": "TRG Prime Codex, Part II, source block 2353",
      "entries": [
        {
          "label": "May use full land Speed as a Climb Speed across icy terrain",
          "dp": 4,
          "source": "TRG Prime Codex, Part II, source block 2355"
        },
        {
          "label": "Ignores difficult and formidable terrain caused by snow and ice",
          "dp": 2,
          "source": "TRG Prime Codex, Part II, source block 2355"
        },
        {
          "label": "Both benefits are restricted to icy or snow-covered terrain",
          "dp": -1,
          "source": "TRG Prime Codex, Part II, source block 2355"
        }
      ]
    },
    "ice-stride": {
      "name": "Ice Stride",
      "dp": 2,
      "perProfile": false,
      "basis": "Ignores snow- and ice-based difficult terrain and removes balance checks on slippery ice.",
      "source": "TRG Prime Codex, Part II, source block 2353",
      "entries": [
        {
          "label": "Ignores difficult terrain caused by snow or ice",
          "dp": 1,
          "source": "TRG Prime Codex, Part II, source block 2355"
        },
        {
          "label": "No Acrobatics checks are required to avoid falling on slippery ice",
          "dp": 1,
          "source": "TRG Prime Codex, Part II, source block 2355"
        }
      ]
    },
    "infestation": {
      "name": "Infestation",
      "dp": 8,
      "perProfile": false,
      "basis": "Constant repeating 5-foot 1d6 poison aura with a basic Fortitude save.",
      "source": "TRG Prime Codex, Part II, source block 2353",
      "entries": [
        {
          "label": "Constant close-range poison-damage aura with repeat exposure",
          "dp": 7,
          "source": "TRG Prime Codex, Part II, source block 2355"
        },
        {
          "label": "Targets beginning their turns within the aura make a basic Fortitude save against 1d6 poison damage",
          "dp": 2,
          "source": "TRG Prime Codex, Part II, source block 2355"
        },
        {
          "label": "Only a 5-foot emanation and applies indiscriminately to anything in range",
          "dp": -1,
          "source": "TRG Prime Codex, Part II, source block 2355"
        }
      ]
    },
    "keen-sense": {
      "name": "Keen Sense",
      "dp": 4,
      "perProfile": false,
      "basis": "+2 racial bonus to the complete Perception skill.",
      "source": "TRG Prime Codex, Part II, source block 2353",
      "entries": [
        {
          "label": "+2 racial bonus to the complete Perception skill",
          "dp": 4,
          "source": "TRG Prime Codex, Part II, source block 2357"
        }
      ]
    },
    "life-drain": {
      "name": "Life Drain",
      "dp": 12,
      "perProfile": false,
      "basis": "Every damaging unarmed hit heals 3 HP and can inflict accumulating Soul Drain after a Fortitude save.",
      "source": "TRG Prime Codex, Part II, source block 2353",
      "entries": [
        {
          "label": "Automatic healing of 3 HP whenever a qualifying unarmed attack damages a living target",
          "dp": 4,
          "source": "TRG Prime Codex, Part II, source block 2357"
        },
        {
          "label": "Failed Fortitude save inflicts Soul Drain 5",
          "dp": 6,
          "source": "TRG Prime Codex, Part II, source block 2357"
        },
        {
          "label": "Further qualifying damage increases the accumulated Soul Drain by 5",
          "dp": 3,
          "source": "TRG Prime Codex, Part II, source block 2357"
        },
        {
          "label": "Restricted to living targets damaged by unarmed attacks",
          "dp": -1,
          "source": "TRG Prime Codex, Part II, source block 2357"
        }
      ]
    },
    "life-sense": {
      "name": "Life Sense",
      "dp": 8,
      "perProfile": false,
      "basis": "Primary special sense that distinguishes living and undead vital essence.",
      "source": "TRG Prime Codex, Part II, source block 2353",
      "entries": [
        {
          "label": "Primary special sense detecting and distinguishing living and undead vital essence",
          "dp": 8,
          "source": "TRG Prime Codex, Part II, source block 2357"
        }
      ]
    },
    "magic-dispelling": {
      "name": "Magic Dispelling",
      "dp": 5,
      "perProfile": false,
      "basis": "Three ordinary Dispel attempts per day without spending PP.",
      "source": "TRG Prime Codex, Part II, source block 2353",
      "entries": [
        {
          "label": "Three Dispel actions per day without PP expenditure",
          "dp": 5,
          "source": "TRG Prime Codex, Part II, source block 2357"
        }
      ]
    },
    "monstrous-grab": {
      "name": "Monstrous Grab",
      "dp": 9,
      "perProfile": false,
      "basis": "+4 racial bonus to Grapple and Grapple attempts ignore multiple attack penalty.",
      "source": "TRG Prime Codex, Part II, source block 2353",
      "entries": [
        {
          "label": "+4 racial bonus to the Grapple action",
          "dp": 4,
          "source": "TRG Prime Codex, Part II, source block 2359"
        },
        {
          "label": "Grapple attempts are never penalised by multiple attack penalty",
          "dp": 5,
          "source": "TRG Prime Codex, Part II, source block 2359"
        }
      ]
    },
    "monstrous-knockdown": {
      "name": "Monstrous Knockdown",
      "dp": 9,
      "perProfile": false,
      "basis": "+4 racial bonus to Trip and Trip attempts ignore multiple attack penalty.",
      "source": "TRG Prime Codex, Part II, source block 2373",
      "entries": [
        {
          "label": "+4 racial bonus to the Trip action",
          "dp": 4,
          "source": "TRG Prime Codex, Part II, source block 2375"
        },
        {
          "label": "Trip attempts are never penalised by multiple attack penalty",
          "dp": 5,
          "source": "TRG Prime Codex, Part II, source block 2375"
        }
      ]
    },
    "natural-camouflage": {
      "name": "Natural Camouflage",
      "dp": 2,
      "perProfile": false,
      "basis": "Advantage on Hide checks in natural terrain.",
      "source": "TRG Prime Codex, Part II, source block 2373",
      "entries": [
        {
          "label": "Advantage on the broadly useful Hide action",
          "dp": 3,
          "source": "TRG Prime Codex, Part II, source block 2375"
        },
        {
          "label": "Restricted to areas of natural terrain",
          "dp": -1,
          "source": "TRG Prime Codex, Part II, source block 2375"
        }
      ]
    },
    "natural-leaper": {
      "name": "Natural Leaper",
      "dp": 7,
      "perProfile": false,
      "basis": "Automatic extended jumps, no running-start penalty, and one action-free Long Jump as part of movement.",
      "source": "TRG Prime Codex, Part II, source block 2373",
      "entries": [
        {
          "label": "High Jump up to half land Speed without a check",
          "dp": 2,
          "source": "TRG Prime Codex, Part II, source block 2375"
        },
        {
          "label": "Long Jump up to land Speed without a check",
          "dp": 2,
          "source": "TRG Prime Codex, Part II, source block 2375"
        },
        {
          "label": "One Long Jump may be folded into movement without spending a separate AP",
          "dp": 3,
          "source": "TRG Prime Codex, Part II, source block 2375"
        },
        {
          "label": "Ignores the running-start penalty for jumping",
          "dp": 1,
          "source": "TRG Prime Codex, Part II, source block 2375"
        },
        {
          "label": "Benefits remain limited by the creature's existing land Speed and jump geometry",
          "dp": -1,
          "source": "TRG Prime Codex, Part II, source block 2375"
        }
      ]
    },
    "pack-attack": {
      "name": "Pack Attack",
      "dp": 4,
      "perProfile": false,
      "basis": "All attacks gain 1d6 precision damage while the target is within reach of at least two allies.",
      "source": "TRG Prime Codex, Part II, source block 2373",
      "entries": [
        {
          "label": "1d6 additional damage on every qualifying attack",
          "dp": 6,
          "source": "TRG Prime Codex, Part II, source block 2375"
        },
        {
          "label": "Precision damage and requirement for at least two allies within reach of the target",
          "dp": -2,
          "source": "TRG Prime Codex, Part II, source block 2375"
        }
      ]
    },
    "paralysing-gaze": {
      "name": "Paralysing Gaze",
      "dp": 22,
      "perProfile": false,
      "basis": "At-will 1 AP, 30-foot multi-target control effect ranging from Stunned 1 to one-minute Paralysis.",
      "source": "TRG Prime Codex, Part II, source block 2373",
      "entries": [
        {
          "label": "At-will 30-foot multi-target Fortitude effect",
          "dp": 10,
          "source": "TRG Prime Codex, Part II, source block 2377"
        },
        {
          "label": "A Success still imposes Stunned 1",
          "dp": 2,
          "source": "TRG Prime Codex, Part II, source block 2377"
        },
        {
          "label": "Partial imposes Paralysed for 1 round",
          "dp": 4,
          "source": "TRG Prime Codex, Part II, source block 2377"
        },
        {
          "label": "Failure imposes Paralysed for 1 minute with repeat saves",
          "dp": 5,
          "source": "TRG Prime Codex, Part II, source block 2377"
        },
        {
          "label": "Fumble removes the repeat-save escape",
          "dp": 2,
          "source": "TRG Prime Codex, Part II, source block 2377"
        },
        {
          "label": "No immunity period; eligible targets may be affected repeatedly",
          "dp": 2,
          "source": "TRG Prime Codex, Part II, source block 2377"
        },
        {
          "label": "Costs 1 AP, requires mutual sight, and may affect allies in the area",
          "dp": -3,
          "source": "TRG Prime Codex, Part II, source block 2377"
        }
      ]
    },
    "penetrating-breath": {
      "name": "Penetrating Breath",
      "dp": 5,
      "perProfile": false,
      "basis": "An existing breath weapon bypasses all DR and ignores Energy Resistance.",
      "source": "TRG Prime Codex, Part II, source block 2373",
      "entries": [
        {
          "label": "Existing breath weapon bypasses all DR",
          "dp": 2,
          "source": "TRG Prime Codex, Part II, source block 2377"
        },
        {
          "label": "Existing breath weapon ignores Energy Resistance",
          "dp": 3,
          "source": "TRG Prime Codex, Part II, source block 2377"
        }
      ]
    },
    "penetrating-strikes": {
      "name": "Penetrating Strikes",
      "dp": 3,
      "perProfile": false,
      "basis": "The indicated physical attack package treats all DR as half.",
      "source": "TRG Prime Codex, Part II, source block 2373",
      "entries": [
        {
          "label": "The indicated physical attack package treats all DR as half",
          "dp": 3,
          "source": "TRG Prime Codex, Part II, source block 2377"
        }
      ]
    },
    "persistent": {
      "name": "Persistent",
      "dp": 2,
      "perProfile": true,
      "basis": "Each affected attack or ability converts qualifying critical-injury persistence into its own damage type.",
      "source": "TRG Prime Codex, Part II, source block 2373",
      "entries": [
        {
          "label": "Each affected attack or ability converts qualifying critical-injury persistence into its own damage type.",
          "dp": 2,
          "source": "TRG Prime Codex, Part II, source block 2373"
        }
      ]
    },
    "plant-resistance": {
      "name": "Plant Resistance",
      "dp": 5,
      "perProfile": false,
      "basis": "Established anatomical filtering of critical injuries while retaining damage, Bleed, and persistent damage.",
      "source": "TRG Prime Codex, Part II, source block 2373",
      "entries": [
        {
          "label": "Partial anatomical filtering of critical injuries",
          "dp": 5,
          "source": "TRG Prime Codex, Part II, source block 2379"
        }
      ]
    },
    "pouncing-assault": {
      "name": "Pouncing Assault",
      "dp": 7,
      "perProfile": false,
      "basis": "Jump plus two claw Strikes for 2 AP, with -4 to attacks made against the creature during the movement.",
      "source": "TRG Prime Codex, Part II, source block 2373",
      "entries": [
        {
          "label": "One AP of compression: Jump plus two claw Strikes for 2 AP",
          "dp": 4,
          "source": "TRG Prime Codex, Part II, source block 2379"
        },
        {
          "label": "Both claw Strikes may be made during the movement and may focus on one target",
          "dp": 2,
          "source": "TRG Prime Codex, Part II, source block 2379"
        },
        {
          "label": "Attacks against the creature during the action suffer -4 circumstance",
          "dp": 2,
          "source": "TRG Prime Codex, Part II, source block 2379"
        },
        {
          "label": "Requires a Jump check and two claw attacks; ordinary MAP applies in sequence",
          "dp": -1,
          "source": "TRG Prime Codex, Part II, source block 2379"
        }
      ]
    },
    "powerful-charge": {
      "name": "Powerful Charge",
      "dp": 7,
      "perProfile": false,
      "basis": "Two Strides and a gore Strike for 2 AP, with +2 to the attack and one additional base-damage die.",
      "source": "TRG Prime Codex, Part II, source block 2394",
      "entries": [
        {
          "label": "One AP of compression: two Strides and one gore Strike are completed for 2 AP",
          "dp": 4,
          "source": "TRG Prime Codex, Part II, source block 2396"
        },
        {
          "label": "+2 circumstance bonus to the gore Strike",
          "dp": 2,
          "source": "TRG Prime Codex, Part II, source block 2396"
        },
        {
          "label": "One additional base-damage die",
          "dp": 2,
          "source": "TRG Prime Codex, Part II, source block 2396"
        },
        {
          "label": "Requires two Strides and an existing gore attack",
          "dp": -1,
          "source": "TRG Prime Codex, Part II, source block 2396"
        }
      ]
    },
    "reactive-disarm": {
      "name": "Reactive Disarm",
      "dp": 4,
      "perProfile": false,
      "basis": "Once per round, a fumbled weapon Strike permits a reaction Disarm that ignores MAP.",
      "source": "TRG Prime Codex, Part II, source block 2394",
      "entries": [
        {
          "label": "Reaction Disarm following a fumbled weapon Strike",
          "dp": 4,
          "source": "TRG Prime Codex, Part II, source block 2396"
        },
        {
          "label": "The Disarm attempt ignores multiple attack penalty",
          "dp": 2,
          "source": "TRG Prime Codex, Part II, source block 2396"
        },
        {
          "label": "Once per round and dependent upon a rare enemy fumble with a weapon",
          "dp": -2,
          "source": "TRG Prime Codex, Part II, source block 2396"
        }
      ]
    },
    "reflective-scales": {
      "name": "Reflective Scales",
      "dp": 14,
      "perProfile": false,
      "basis": "Reaction Dispel against a targeted spell; a critical Dispel reflects the spell upon its caster.",
      "source": "TRG Prime Codex, Part II, source block 2394",
      "entries": [
        {
          "label": "PP-free reaction Dispel against an incoming targeted spell",
          "dp": 10,
          "source": "TRG Prime Codex, Part II, source block 2396"
        },
        {
          "label": "A critical Dispel reflects the spell upon its caster",
          "dp": 5,
          "source": "TRG Prime Codex, Part II, source block 2396"
        },
        {
          "label": "Consumes a reaction and does not apply to spells that do not target the creature",
          "dp": -1,
          "source": "TRG Prime Codex, Part II, source block 2396"
        }
      ]
    },
    "regeneration": {
      "name": "Regeneration",
      "dp": 20,
      "perProfile": false,
      "basis": "Start-turn healing equal to level, protection from death while active, and rapid injury recovery, subject to a bypass.",
      "source": "TRG Prime Codex, Part II, source block 2394",
      "entries": [
        {
          "label": "Recovers HP equal to creature level at the beginning of every turn while active",
          "dp": 12,
          "source": "TRG Prime Codex, Part II, source block 2398"
        },
        {
          "label": "Cannot die while regeneration remains active unless its physical form is destroyed",
          "dp": 8,
          "source": "TRG Prime Codex, Part II, source block 2398"
        },
        {
          "label": "Reduces the Injured condition by its regeneration value every hour",
          "dp": 3,
          "source": "TRG Prime Codex, Part II, source block 2398"
        },
        {
          "label": "A specified bypass damage type can suppress the ability for one turn after sufficient damage",
          "dp": -3,
          "source": "TRG Prime Codex, Part II, source block 2398"
        }
      ]
    },
    "rend": {
      "name": "Rend",
      "dp": 8,
      "perProfile": false,
      "basis": "After two qualifying hits, the creature automatically inflicts one additional instance of the listed attack damage.",
      "source": "TRG Prime Codex, Part II, source block 2394",
      "entries": [
        {
          "label": "Automatic additional damage equal to the listed attack after two qualifying hits",
          "dp": 10,
          "source": "TRG Prime Codex, Part II, source block 2398"
        },
        {
          "label": "Requires two hits against the same target with the listed attack type",
          "dp": -2,
          "source": "TRG Prime Codex, Part II, source block 2398"
        }
      ]
    },
    "secondary-critical": {
      "name": "Secondary Critical",
      "dp": 4,
      "perProfile": true,
      "basis": "A qualifying critical also inflicts a second critical injury one severity lower using the secondary damage type.",
      "source": "TRG Prime Codex, Part II, source block 2394",
      "entries": [
        {
          "label": "A qualifying critical also inflicts a second critical injury one severity lower using the secondary damage type.",
          "dp": 4,
          "source": "TRG Prime Codex, Part II, source block 2394"
        }
      ]
    },
    "shadow-breath": {
      "name": "Shadow Breath",
      "dp": 9,
      "perProfile": false,
      "basis": "Breath-weapon damage carries a free Blindness rider using the original saving throw.",
      "source": "TRG Prime Codex, Part II, source block 2394",
      "entries": [
        {
          "label": "Free multi-target Blindness rider using the breath weapon's original save result",
          "dp": 11,
          "source": "TRG Prime Codex, Part II, source block 2400"
        },
        {
          "label": "Only triggers against targets damaged by an existing breath weapon",
          "dp": -2,
          "source": "TRG Prime Codex, Part II, source block 2400"
        }
      ]
    },
    "shadow-hand": {
      "name": "Shadow Hand",
      "dp": 5,
      "perProfile": true,
      "basis": "A critical soul-touch Strike can inflict 1d6 or 2d6 Soul Drain after a Fortitude save.",
      "source": "TRG Prime Codex, Part II, source block 2394",
      "entries": [
        {
          "label": "A critical soul-touch Strike can inflict 1d6 or 2d6 Soul Drain after a Fortitude save.",
          "dp": 5,
          "source": "TRG Prime Codex, Part II, source block 2394"
        }
      ]
    },
    "shadowy": {
      "name": "Shadowy",
      "dp": 5,
      "perProfile": false,
      "basis": "The creature is continuously Concealed while the prevailing light level is Twilight or darker.",
      "source": "TRG Prime Codex, Part II, source block 2394",
      "entries": [
        {
          "label": "Continuous Concealed condition while light level is Twilight or lower",
          "dp": 7,
          "source": "TRG Prime Codex, Part II, source block 2402"
        },
        {
          "label": "Benefit is lost in brighter light",
          "dp": -2,
          "source": "TRG Prime Codex, Part II, source block 2402"
        }
      ]
    },
    "skewering-strikes": {
      "name": "Skewering Strikes",
      "dp": 2,
      "perProfile": false,
      "basis": "Spear criticals increase qualifying persistent Bleed by the severity of the critical.",
      "source": "TRG Prime Codex, Part II, source block 2394",
      "entries": [
        {
          "label": "Persistent Bleed increases by 1 per critical severity",
          "dp": 3,
          "source": "TRG Prime Codex, Part II, source block 2402"
        },
        {
          "label": "Requires a spear-group Strike that already inflicts persistent Bleed",
          "dp": -1,
          "source": "TRG Prime Codex, Part II, source block 2402"
        }
      ]
    },
    "slow-i": {
      "name": "Slow I",
      "dp": -8,
      "perProfile": false,
      "basis": "Permanent loss of one or two of the creature's three AP each turn.",
      "source": "TRG Prime Codex, Part II, source block 2417",
      "entries": [
        {
          "label": "Permanently reduces the creature from 3 AP to 2 AP each turn",
          "dp": -8,
          "source": "TRG Prime Codex, Part II, source block 2419"
        }
      ]
    },
    "slow-ii": {
      "name": "Slow II",
      "dp": -15,
      "perProfile": false,
      "basis": "Permanent loss of one or two of the creature's three AP each turn.",
      "source": "TRG Prime Codex, Part II, source block 2417",
      "entries": [
        {
          "label": "Permanently reduces the creature from 3 AP to 1 AP each turn",
          "dp": -15,
          "source": "TRG Prime Codex, Part II, source block 2419"
        }
      ]
    },
    "slowing-breath": {
      "name": "Slowing Breath",
      "dp": 10,
      "perProfile": false,
      "basis": "Free breath-weapon rider imposing Slowed 1 or 2 after a Fortitude save.",
      "source": "TRG Prime Codex, Part II, source block 2417",
      "entries": [
        {
          "label": "Free multi-target rider that can impose Slowed 1 for a round or one minute, or Slowed 2 for one minute",
          "dp": 13,
          "source": "TRG Prime Codex, Part II, source block 2419"
        },
        {
          "label": "Requires an existing breath weapon to damage the target and permits a separate Fortitude save",
          "dp": -3,
          "source": "TRG Prime Codex, Part II, source block 2419"
        }
      ]
    },
    "smoke-form": {
      "name": "Smoke Form",
      "dp": 6,
      "perProfile": false,
      "basis": "May share occupied spaces and avoids movement reactions when moving its full Speed in one action.",
      "source": "TRG Prime Codex, Part II, source block 2417",
      "entries": [
        {
          "label": "May occupy the same space as another creature",
          "dp": 2,
          "source": "TRG Prime Codex, Part II, source block 2421"
        },
        {
          "label": "Does not provoke movement reactions when it moves its full Speed in one action",
          "dp": 4,
          "source": "TRG Prime Codex, Part II, source block 2421"
        }
      ]
    },
    "smokevision": {
      "name": "Smokevision",
      "dp": 3,
      "perProfile": false,
      "basis": "Ignores visual impairment and concealment produced by smoke or fog.",
      "source": "TRG Prime Codex, Part II, source block 2417",
      "entries": [
        {
          "label": "Ignores smoke- and fog-based visual impairment and concealment",
          "dp": 3,
          "source": "TRG Prime Codex, Part II, source block 2421"
        }
      ]
    },
    "snowvision": {
      "name": "Snowvision",
      "dp": 2,
      "perProfile": false,
      "basis": "Ignores concealment and other visual penalties caused by snowfall.",
      "source": "TRG Prime Codex, Part II, source block 2417",
      "entries": [
        {
          "label": "Ignores snowfall-based concealment and other visual bonuses",
          "dp": 2,
          "source": "TRG Prime Codex, Part II, source block 2421"
        }
      ]
    },
    "sonar-sense": {
      "name": "Sonar Sense",
      "dp": 6,
      "perProfile": false,
      "basis": "Full-range Primary auditory sense requiring 1 AP to emit and update.",
      "source": "TRG Prime Codex, Part II, source block 2417",
      "entries": [
        {
          "label": "Primary auditory sense with the same range as vision",
          "dp": 8,
          "source": "TRG Prime Codex, Part II, source block 2421"
        },
        {
          "label": "Requires 1 AP to emit and obtain or update the sensory picture",
          "dp": -2,
          "source": "TRG Prime Codex, Part II, source block 2421"
        }
      ]
    },
    "sonic-moan": {
      "name": "Sonic Moan",
      "dp": 9,
      "perProfile": false,
      "basis": "Focus, 2 AP, 30-foot 3d6 sonic effect with a basic Will save and an obscured source.",
      "source": "TRG Prime Codex, Part II, source block 2417",
      "entries": [
        {
          "label": "Thirty-foot 3d6 sonic area effect with a basic Will save",
          "dp": 5,
          "source": "TRG Prime Codex, Part II, source block 2423"
        },
        {
          "label": "Focus availability without ordinary PP expenditure",
          "dp": 3,
          "source": "TRG Prime Codex, Part II, source block 2423"
        },
        {
          "label": "Infrasonic delivery can conceal the source from unaware humanoids",
          "dp": 1,
          "source": "TRG Prime Codex, Part II, source block 2423"
        }
      ]
    },
    "souldrinker": {
      "name": "Souldrinker",
      "dp": 10,
      "perProfile": false,
      "basis": "Free level-scaled Cure or Restoration recovery after killing a qualifying living creature.",
      "source": "TRG Prime Codex, Part II, source block 2417",
      "entries": [
        {
          "label": "Level-scaled Cure or Restoration recovery delivered as a Free action",
          "dp": 13,
          "source": "TRG Prime Codex, Part II, source block 2423"
        },
        {
          "label": "Triggers only after killing a living creature no more than four levels lower",
          "dp": -3,
          "source": "TRG Prime Codex, Part II, source block 2423"
        }
      ]
    },
    "soulless-aura": {
      "name": "Soulless Aura",
      "dp": 10,
      "perProfile": false,
      "basis": "Ten-foot entry aura inflicting Soul Drain 5 after a level-based Fortitude save.",
      "source": "TRG Prime Codex, Part II, source block 2417",
      "entries": [
        {
          "label": "Constant ten-foot entry aura capable of inflicting Soul Drain 5",
          "dp": 11,
          "source": "TRG Prime Codex, Part II, source block 2423"
        },
        {
          "label": "Level-based Fortitude save; a successful target becomes immune for 24 hours",
          "dp": -1,
          "source": "TRG Prime Codex, Part II, source block 2423"
        }
      ]
    },
    "spell-resilience": {
      "name": "Spell Resilience",
      "dp": 18,
      "perProfile": false,
      "basis": "Class-Bonus racial bonus to all saves and DB against magical attacks.",
      "source": "TRG Prime Codex, Part II, source block 2417",
      "entries": [
        {
          "label": "Scaling racial bonus equal to Class Bonus on all saving throws against magical attacks",
          "dp": 10,
          "source": "TRG Prime Codex, Part II, source block 2425"
        },
        {
          "label": "The same scaling racial bonus applies to DB against magical attacks",
          "dp": 8,
          "source": "TRG Prime Codex, Part II, source block 2425"
        }
      ]
    },
    "stench": {
      "name": "Stench",
      "dp": 7,
      "perProfile": false,
      "basis": "Ten-foot living-creature aura causing Sickened 1, with Slowed 1 on a fumble and one-minute immunity after a save.",
      "source": "TRG Prime Codex, Part II, source block 2439",
      "entries": [
        {
          "label": "Constant ten-foot aura; failed Fortitude save imposes Sickened 1",
          "dp": 7,
          "source": "TRG Prime Codex, Part II, source block 2441"
        },
        {
          "label": "Fumble also imposes Slowed 1 for the duration of Sickened",
          "dp": 2,
          "source": "TRG Prime Codex, Part II, source block 2441"
        },
        {
          "label": "Living targets only; any save grants one minute of immunity",
          "dp": -2,
          "source": "TRG Prime Codex, Part II, source block 2441"
        }
      ]
    },
    "sunlight-vulnerability": {
      "name": "Sunlight Vulnerability",
      "dp": -15,
      "perProfile": false,
      "basis": "Sunlight Weakness plus 2 essence damage per level each turn and loss of healing while exposed.",
      "source": "TRG Prime Codex, Part II, source block 2439",
      "entries": [
        {
          "label": "Includes the complete Sunlight Weakness drawback",
          "dp": -7,
          "source": "TRG Prime Codex, Part II, source block 2441"
        },
        {
          "label": "Takes 2 essence damage per level at the beginning of each turn in sunlight",
          "dp": -6,
          "source": "TRG Prime Codex, Part II, source block 2441"
        },
        {
          "label": "Cannot heal while exposed to sunlight",
          "dp": -2,
          "source": "TRG Prime Codex, Part II, source block 2441"
        }
      ]
    },
    "sunlight-weakness": {
      "name": "Sunlight Weakness",
      "dp": -7,
      "perProfile": false,
      "basis": "Injured 2 and Slowed 2 for as long as the creature remains in sunlight.",
      "source": "TRG Prime Codex, Part II, source block 2439",
      "entries": [
        {
          "label": "Slowed 2 while exposed to sunlight",
          "dp": -5,
          "source": "TRG Prime Codex, Part II, source block 2441"
        },
        {
          "label": "Injured 2 while exposed to sunlight",
          "dp": -2,
          "source": "TRG Prime Codex, Part II, source block 2441"
        }
      ]
    },
    "surge-of-speed": {
      "name": "Surge of Speed",
      "dp": 3,
      "perProfile": false,
      "basis": "One AP to Stride twice, usable once every ten minutes.",
      "source": "TRG Prime Codex, Part II, source block 2439",
      "entries": [
        {
          "label": "Gains one additional Stride within a 1 AP action",
          "dp": 5,
          "source": "TRG Prime Codex, Part II, source block 2443"
        },
        {
          "label": "Usable only once every ten minutes",
          "dp": -2,
          "source": "TRG Prime Codex, Part II, source block 2443"
        }
      ]
    },
    "survival-instinct": {
      "name": "Survival Instinct",
      "dp": 20,
      "perProfile": false,
      "basis": "Static Natural DR bonus equal to level; the vague circumstantial failure clause grants no discount.",
      "source": "TRG Prime Codex, Part II, source block 2439",
      "entries": [
        {
          "label": "Scaling static Natural DR bonus equal to creature level",
          "dp": 20,
          "source": "TRG Prime Codex, Part II, source block 2443"
        },
        {
          "label": "Circumstances in which the ability fails are not defined and therefore provide no refund",
          "dp": 0,
          "source": "TRG Prime Codex, Part II, source block 2443"
        }
      ]
    },
    "swallow": {
      "name": "Swallow",
      "dp": 15,
      "perProfile": false,
      "basis": "One-action conversion of a grabbed smaller target into ongoing containment, conditions, and double-bite acid damage.",
      "source": "TRG Prime Codex, Part II, source block 2439",
      "entries": [
        {
          "label": "One-action containment of a qualifying grabbed target after Athletics versus Reflex DC",
          "dp": 4,
          "source": "TRG Prime Codex, Part II, source block 2445"
        },
        {
          "label": "Initial and recurring acid damage equal to twice the bite attack, resisted by a Very Hard basic Fortitude save",
          "dp": 8,
          "source": "TRG Prime Codex, Part II, source block 2445"
        },
        {
          "label": "Target is Grabbed, Slowed 1, must hold its breath, and is constrained to Escape or cutting free",
          "dp": 6,
          "source": "TRG Prime Codex, Part II, source block 2445"
        },
        {
          "label": "Requires a pre-existing Grab, a smaller target, and permits escape or internal damage to cut free",
          "dp": -3,
          "source": "TRG Prime Codex, Part II, source block 2445"
        }
      ]
    },
    "swimby-attack": {
      "name": "Swimby Attack",
      "dp": 4,
      "perProfile": false,
      "basis": "Two bite attacks against separate targets during one Swim Stride for 2 AP.",
      "source": "TRG Prime Codex, Part II, source block 2439",
      "entries": [
        {
          "label": "Swim Stride and two bite attacks against separate targets for 2 AP",
          "dp": 6,
          "source": "TRG Prime Codex, Part II, source block 2445"
        },
        {
          "label": "Requires an existing Swim Speed and two different targets; ordinary MAP applies",
          "dp": -2,
          "source": "TRG Prime Codex, Part II, source block 2445"
        }
      ]
    },
    "tear-flesh": {
      "name": "Tear Flesh",
      "dp": 8,
      "perProfile": false,
      "basis": "One-action automatic repeat of a bite that damaged the target on the immediately preceding action.",
      "source": "TRG Prime Codex, Part II, source block 2439",
      "entries": [
        {
          "label": "Automatically repeats the previous bite result, including damage and critical determination, without a new attack roll",
          "dp": 11,
          "source": "TRG Prime Codex, Part II, source block 2447"
        },
        {
          "label": "Costs 1 AP and requires the immediately preceding action to have inflicted bite damage",
          "dp": -3,
          "source": "TRG Prime Codex, Part II, source block 2447"
        }
      ]
    },
    "telepathy": {
      "name": "Telepathy",
      "dp": 2,
      "perProfile": false,
      "basis": "One-hundred-foot mental communication with sensed sentient creatures sharing a language.",
      "source": "TRG Prime Codex, Part II, source block 2439",
      "entries": [
        {
          "label": "Mental communication with sensed sentient creatures within 100 feet",
          "dp": 3,
          "source": "TRG Prime Codex, Part II, source block 2447"
        },
        {
          "label": "A shared language is still required for understanding",
          "dp": -1,
          "source": "TRG Prime Codex, Part II, source block 2447"
        }
      ]
    },
    "torrent-of-strikes": {
      "name": "Torrent of Strikes",
      "dp": 20,
      "perProfile": false,
      "basis": "Six adjacent-target attacks for 3 AP, each resolved at a fixed -2 multiple attack penalty.",
      "source": "TRG Prime Codex, Part II, source block 2439",
      "entries": [
        {
          "label": "Six separate attacks for 3 AP, allowing all attacks to focus on one adjacent target",
          "dp": 12,
          "source": "TRG Prime Codex, Part II, source block 2447"
        },
        {
          "label": "Every attack is resolved at a fixed -2 MAP instead of escalating through the normal sequence",
          "dp": 8,
          "source": "TRG Prime Codex, Part II, source block 2447"
        }
      ]
    },
    "trample": {
      "name": "Trample",
      "dp": 10,
      "perProfile": false,
      "basis": "Three-AP double-Speed movement damaging every smaller target crossed, with +1 base die and no movement reactions.",
      "source": "TRG Prime Codex, Part II, source block 2461",
      "entries": [
        {
          "label": "Moves up to twice Speed and can damage every qualifying target whose space is crossed",
          "dp": 8,
          "source": "TRG Prime Codex, Part II, source block 2463"
        },
        {
          "label": "Each target suffers the appropriate attack damage with one additional base die",
          "dp": 3,
          "source": "TRG Prime Codex, Part II, source block 2463"
        },
        {
          "label": "Movement does not provoke reactions",
          "dp": 2,
          "source": "TRG Prime Codex, Part II, source block 2463"
        },
        {
          "label": "Costs all 3 AP, affects only targets at least one size smaller, and permits a basic Reflex save",
          "dp": -3,
          "source": "TRG Prime Codex, Part II, source block 2463"
        }
      ]
    },
    "true-caster": {
      "name": "True Caster",
      "dp": 12,
      "perProfile": false,
      "basis": "Access to spells from all four traditions while casting them through the creature's primary tradition.",
      "source": "TRG Prime Codex, Part II, source block 2461",
      "entries": [
        {
          "label": "Three additional simultaneously accessible magical traditions at +4 DP each",
          "dp": 12,
          "source": "TRG Prime Codex, Part II, source block 2463"
        },
        {
          "label": "All selected spells are cast through the creature's primary tradition",
          "dp": 0,
          "source": "TRG Prime Codex, Part II, source block 2463"
        }
      ]
    },
    "undead-fortitude": {
      "name": "Undead Fortitude",
      "dp": 12,
      "perProfile": false,
      "basis": "No-action opposed Fortitude save to remain at 1 HP whenever qualifying damage would reduce the creature to 0 HP.",
      "source": "TRG Prime Codex, Part II, source block 2461",
      "entries": [
        {
          "label": "No-action chance to remain at 1 HP whenever reduced to 0 HP",
          "dp": 15,
          "source": "TRG Prime Codex, Part II, source block 2465"
        },
        {
          "label": "Requires an opposed level-based Fortitude success and is bypassed by essence or weakness damage",
          "dp": -3,
          "source": "TRG Prime Codex, Part II, source block 2465"
        }
      ]
    },
    "undead-spawn": {
      "name": "Undead Spawn",
      "dp": 6,
      "perProfile": false,
      "basis": "Delayed creation of a weakened undead Spawn after a qualifying Soul Drain natural-attack kill, without automatic control.",
      "source": "TRG Prime Codex, Part II, source block 2461",
      "entries": [
        {
          "label": "Creates a lasting undead creature from a slain qualifying target",
          "dp": 10,
          "source": "TRG Prime Codex, Part II, source block 2465"
        },
        {
          "label": "Requires a natural attack that inflicts Soul Drain and the transformation is delayed until the following dusk",
          "dp": -2,
          "source": "TRG Prime Codex, Part II, source block 2465"
        },
        {
          "label": "The GM determines the resulting undead, it gains Spawn and Injured 10, and the creator gains no automatic control",
          "dp": -2,
          "source": "TRG Prime Codex, Part II, source block 2465"
        }
      ]
    },
    "vibration-sense": {
      "name": "Vibration Sense",
      "dp": 8,
      "perProfile": false,
      "basis": "Blindsight-equivalent Primary non-visual sense using vibration and air currents.",
      "source": "TRG Prime Codex, Part II, source block 2461",
      "entries": [
        {
          "label": "Blindsight or equivalent Primary non-visual sense",
          "dp": 8,
          "source": "TRG Prime Codex, Part II, source block 2467"
        }
      ]
    },
    "vorpal-weapons": {
      "name": "Vorpal Weapons",
      "dp": 10,
      "perProfile": false,
      "basis": "Every melee weapon forces stronger head critical results and applies a severity-based minimum injury result.",
      "source": "TRG Prime Codex, Part II, source block 2461",
      "entries": [
        {
          "label": "A melee critical is shifted to the next available head injury result",
          "dp": 5,
          "source": "TRG Prime Codex, Part II, source block 2467"
        },
        {
          "label": "The final injury result cannot fall below the minimum established by the critical's severity",
          "dp": 5,
          "source": "TRG Prime Codex, Part II, source block 2467"
        }
      ]
    },
    "water-glide": {
      "name": "Water Glide",
      "dp": 3,
      "perProfile": false,
      "basis": "Moves across water at half Swim Speed and treats the surface as solid for High Jump and Long Jump.",
      "source": "TRG Prime Codex, Part II, source block 2461",
      "entries": [
        {
          "label": "Gains water-surface movement at half the creature's existing Swim Speed",
          "dp": 2,
          "source": "TRG Prime Codex, Part II, source block 2467"
        },
        {
          "label": "May use the water surface as solid ground for High Jump and Long Jump",
          "dp": 1,
          "source": "TRG Prime Codex, Part II, source block 2467"
        }
      ]
    },
    "whirlpool": {
      "name": "Whirlpool",
      "dp": 8,
      "perProfile": false,
      "basis": "Constant difficult-terrain aura with a radius of 5 feet per level, excluding creatures with the Water trait.",
      "source": "TRG Prime Codex, Part II, source block 2461",
      "entries": [
        {
          "label": "Constant difficult-terrain emanation scaling at 5 feet per creature level",
          "dp": 10,
          "source": "TRG Prime Codex, Part II, source block 2469"
        },
        {
          "label": "Does not hinder Water-trait creatures and otherwise affects allies and enemies alike",
          "dp": -2,
          "source": "TRG Prime Codex, Part II, source block 2469"
        }
      ]
    },
    "whirlwind": {
      "name": "Whirlwind",
      "dp": 6,
      "perProfile": false,
      "basis": "Constant 20-foot difficult-terrain aura, excluding creatures with the Air trait.",
      "source": "TRG Prime Codex, Part II, source block 2461",
      "entries": [
        {
          "label": "Constant 20-foot difficult-terrain emanation",
          "dp": 7,
          "source": "TRG Prime Codex, Part II, source block 2469"
        },
        {
          "label": "Does not hinder Air-trait creatures and otherwise affects allies and enemies alike",
          "dp": -1,
          "source": "TRG Prime Codex, Part II, source block 2469"
        }
      ]
    },
    "whispers-of-the-grave": {
      "name": "Whispers of the Grave",
      "dp": 2,
      "perProfile": false,
      "basis": "Risky one-minute opposed check to communicate with spirits or sentient undead without sharing a language.",
      "source": "TRG Prime Codex, Part II, source block 2461",
      "entries": [
        {
          "label": "Can communicate with spirits or sentient undead without a shared language",
          "dp": 5,
          "source": "TRG Prime Codex, Part II, source block 2469"
        },
        {
          "label": "Requires a one-minute opposed Meditation check and each target becomes immune for 24 hours",
          "dp": -2,
          "source": "TRG Prime Codex, Part II, source block 2469"
        },
        {
          "label": "Carries an exhaustion check and a blunder can allow the target to dominate the user",
          "dp": -1,
          "source": "TRG Prime Codex, Part II, source block 2469"
        }
      ]
    },
    "wing-buffet": {
      "name": "Wing Buffet",
      "dp": 13,
      "perProfile": false,
      "basis": "Two-AP 30-foot cone using a level-based Reflex save to inflict wing damage, forced movement, Prone, altitude loss, and Stunned 1 at the worst result.",
      "source": "TRG Prime Codex, Part II, source block 2482",
      "entries": [
        {
          "label": "Thirty-foot cone can affect every creature in the area with one activation",
          "dp": 4,
          "source": "TRG Prime Codex, Part II, source block 2484"
        },
        {
          "label": "Wing-attack damage on Partial or worse, doubled on Fumble or Blunder",
          "dp": 5,
          "source": "TRG Prime Codex, Part II, source block 2484"
        },
        {
          "label": "Forced movement of 5–20 feet that does not provoke reactions",
          "dp": 3,
          "source": "TRG Prime Codex, Part II, source block 2484"
        },
        {
          "label": "Prone on Failure or worse, altitude loss against flying targets, and Stunned 1 on Blunder",
          "dp": 3,
          "source": "TRG Prime Codex, Part II, source block 2484"
        },
        {
          "label": "Costs 2 AP, permits a level-based Reflex save, and creatures two sizes larger improve the result",
          "dp": -2,
          "source": "TRG Prime Codex, Part II, source block 2484"
        }
      ]
    },
    "wingless-flight": {
      "name": "Wingless Flight",
      "dp": 6,
      "perProfile": false,
      "basis": "Magical flight package granting Hover and wing-free manoeuvring; the existing Fly Speed is lost while magic is suppressed.",
      "source": "TRG Prime Codex, Part II, source block 2482",
      "entries": [
        {
          "label": "Includes the complete Hover ability",
          "dp": 5,
          "source": "TRG Prime Codex, Part II, source block 2484"
        },
        {
          "label": "Does not require wing clearance or visible wing movement",
          "dp": 2,
          "source": "TRG Prime Codex, Part II, source block 2484"
        },
        {
          "label": "Loses the Fly Speed whenever the creature’s magic is suppressed",
          "dp": -1,
          "source": "TRG Prime Codex, Part II, source block 2484"
        }
      ]
    }
  },
  "sizes": {
    "diminutive": {
      "name": "Diminutive",
      "hp": 0,
      "strength": -3,
      "dexterity": 3,
      "reach": 0,
      "printedReach": 5,
      "reachRuling": "Graham, 18 Nov 2026 (RD-02): reach 0, as the core size table has it.",
      "printed": -4,
      "residual": -6,
      "source": "TRG Prime Codex, Part II, source block 2212"
    },
    "tiny": {
      "name": "Tiny",
      "hp": 10,
      "strength": -2,
      "dexterity": 2,
      "reach": 0,
      "printedReach": 5,
      "reachRuling": "Graham, 18 Nov 2026 (RD-02): reach 0, as the core size table has it.",
      "printed": -4,
      "residual": -4,
      "source": "TRG Prime Codex, Part II, source block 2212"
    },
    "small": {
      "name": "Small",
      "hp": 20,
      "strength": -1,
      "dexterity": 1,
      "reach": 5,
      "printed": -3,
      "residual": -2,
      "source": "TRG Prime Codex, Part II, source block 2212"
    },
    "medium": {
      "name": "Medium",
      "hp": 30,
      "strength": 0,
      "dexterity": 0,
      "reach": 5,
      "printed": 0,
      "residual": 0,
      "source": "TRG Prime Codex, Part II, source block 2212"
    },
    "large": {
      "name": "Large",
      "hp": 50,
      "strength": 1,
      "dexterity": -1,
      "reach": 10,
      "printed": 11,
      "residual": 2,
      "source": "TRG Prime Codex, Part II, source block 2212"
    },
    "huge": {
      "name": "Huge",
      "hp": 80,
      "strength": 2,
      "dexterity": -2,
      "reach": 15,
      "printed": 26,
      "residual": 4,
      "source": "TRG Prime Codex, Part II, source block 2212"
    },
    "gargantuan": {
      "name": "Gargantuan",
      "hp": 120,
      "strength": 3,
      "dexterity": -3,
      "reach": 20,
      "printed": 44,
      "residual": 6,
      "source": "TRG Prime Codex, Part II, source block 2212"
    },
    "colossal": {
      "name": "Colossal",
      "hp": 250,
      "strength": 4,
      "dexterity": -4,
      "reach": 25,
      "printed": 81,
      "residual": 8,
      "source": "TRG Prime Codex, Part II, source block 2212"
    }
  },
  "attacks": {
    "bite": {
      "name": "Bite",
      "damage": "1d8",
      "size": "medium",
      "dp": 4,
      "source": "TRG Prime Codex, Part II, source block 2240"
    },
    "claw": {
      "name": "Claw",
      "damage": "1d6",
      "size": "small",
      "dp": 4.5,
      "source": "TRG Prime Codex, Part II, source block 2240"
    },
    "gore": {
      "name": "Gore",
      "damage": "1d8",
      "size": "medium",
      "dp": 4,
      "source": "TRG Prime Codex, Part II, source block 2240"
    },
    "hoof": {
      "name": "Hoof",
      "damage": "1d6",
      "size": "small",
      "dp": 3,
      "source": "TRG Prime Codex, Part II, source block 2240"
    },
    "slam": {
      "name": "Slam",
      "damage": "1d8",
      "size": "medium",
      "dp": 5,
      "source": "TRG Prime Codex, Part II, source block 2240"
    },
    "sting": {
      "name": "Sting",
      "damage": "1d6",
      "size": "medium",
      "dp": 4,
      "source": "TRG Prime Codex, Part II, source block 2240"
    },
    "tail-slap": {
      "name": "Tail Slap",
      "damage": "1d8",
      "size": "medium",
      "dp": 5,
      "source": "TRG Prime Codex, Part II, source block 2240"
    },
    "tentacle": {
      "name": "Tentacle",
      "damage": "1d6",
      "size": "small",
      "dp": 3,
      "source": "TRG Prime Codex, Part II, source block 2240"
    },
    "unarmed-strike": {
      "name": "Unarmed Strike",
      "damage": "1d4",
      "size": "small",
      "dp": 3,
      "source": "TRG Prime Codex, Part II, source block 2240"
    },
    "wings": {
      "name": "Wings",
      "damage": "1d6",
      "size": "small",
      "dp": 3,
      "source": "TRG Prime Codex, Part II, source block 2240"
    }
  },
  "catalog": {
    "creature-types": [
      {
        "id": "Cap5JpyYAp5i2pWQ",
        "name": "Undead",
        "type": "creature-type",
        "uuid": "Compendium.trg-prime.creature-types.Item.Cap5JpyYAp5i2pWQ",
        "validId": true,
        "category": "",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 2,
          "flags": []
        }
      },
      {
        "id": "IDJOcFJ2eT65ydsy",
        "name": "Aberration",
        "type": "creature-type",
        "uuid": "Compendium.trg-prime.creature-types.Item.IDJOcFJ2eT65ydsy",
        "validId": true,
        "category": "",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 2,
          "flags": []
        }
      },
      {
        "id": "IMPERJhb9IkCEH3h",
        "name": "Plant",
        "type": "creature-type",
        "uuid": "Compendium.trg-prime.creature-types.Item.IMPERJhb9IkCEH3h",
        "validId": true,
        "category": "",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 2,
          "flags": []
        }
      },
      {
        "id": "NyzlUF4cecNopgB7",
        "name": "Fey",
        "type": "creature-type",
        "uuid": "Compendium.trg-prime.creature-types.Item.NyzlUF4cecNopgB7",
        "validId": true,
        "category": "",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 2,
          "flags": []
        }
      },
      {
        "id": "SdkUz03hNIpUOq6v",
        "name": "Humanoid",
        "type": "creature-type",
        "uuid": "Compendium.trg-prime.creature-types.Item.SdkUz03hNIpUOq6v",
        "validId": true,
        "category": "",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "em4VCTaMSNABzJUW",
        "name": "Construct",
        "type": "creature-type",
        "uuid": "Compendium.trg-prime.creature-types.Item.em4VCTaMSNABzJUW",
        "validId": true,
        "category": "",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "i2ETBYn0nBBJ8f1H",
        "name": "Eternal",
        "type": "creature-type",
        "uuid": "Compendium.trg-prime.creature-types.Item.i2ETBYn0nBBJ8f1H",
        "validId": true,
        "category": "",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "i3DOTXdXKDpcp5ar",
        "name": "Elemental",
        "type": "creature-type",
        "uuid": "Compendium.trg-prime.creature-types.Item.i3DOTXdXKDpcp5ar",
        "validId": true,
        "category": "",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "ieHTIyiyoAMNAafs",
        "name": "Ooze",
        "type": "creature-type",
        "uuid": "Compendium.trg-prime.creature-types.Item.ieHTIyiyoAMNAafs",
        "validId": true,
        "category": "",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 3,
          "flags": []
        }
      },
      {
        "id": "koL4tsE1bB5ZzhWB",
        "name": "Wyrm",
        "type": "creature-type",
        "uuid": "Compendium.trg-prime.creature-types.Item.koL4tsE1bB5ZzhWB",
        "validId": true,
        "category": "",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 2,
          "flags": []
        }
      },
      {
        "id": "mPL66kLfblihIAMM",
        "name": "Beast",
        "type": "creature-type",
        "uuid": "Compendium.trg-prime.creature-types.Item.mPL66kLfblihIAMM",
        "validId": true,
        "category": "",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 2,
          "flags": []
        }
      },
      {
        "id": "rUZsPtbOIHoWEKgq",
        "name": "Animal",
        "type": "creature-type",
        "uuid": "Compendium.trg-prime.creature-types.Item.rUZsPtbOIHoWEKgq",
        "validId": true,
        "category": "",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 3,
          "flags": []
        }
      }
    ],
    "creature-classes": [
      {
        "id": "4jj5a0DMJjNqZVND",
        "name": "Beast (Creature Class)",
        "type": "class",
        "uuid": "Compendium.trg-prime.creature-classes.Item.4jj5a0DMJjNqZVND",
        "validId": true,
        "category": "",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureClass"
          ]
        }
      },
      {
        "id": "8gKRcPKHGnAUNmKc",
        "name": "Undead (Creature Class)",
        "type": "class",
        "uuid": "Compendium.trg-prime.creature-classes.Item.8gKRcPKHGnAUNmKc",
        "validId": true,
        "category": "",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureClass"
          ]
        }
      },
      {
        "id": "AWSUWlUqEmh1QpHv",
        "name": "Eternal (Creature Class)",
        "type": "class",
        "uuid": "Compendium.trg-prime.creature-classes.Item.AWSUWlUqEmh1QpHv",
        "validId": true,
        "category": "",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureClass"
          ]
        }
      },
      {
        "id": "Co4Oh0OzeWhi8Wbi",
        "name": "Ooze (Creature Class)",
        "type": "class",
        "uuid": "Compendium.trg-prime.creature-classes.Item.Co4Oh0OzeWhi8Wbi",
        "validId": true,
        "category": "",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureClass"
          ]
        }
      },
      {
        "id": "HKcKRTzDHRVeGmzX",
        "name": "Sneak (Creature Class)",
        "type": "class",
        "uuid": "Compendium.trg-prime.creature-classes.Item.HKcKRTzDHRVeGmzX",
        "validId": true,
        "category": "",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureClass"
          ]
        }
      },
      {
        "id": "IFITdqkX7sLjWiUG",
        "name": "Aberration (Creature Class)",
        "type": "class",
        "uuid": "Compendium.trg-prime.creature-classes.Item.IFITdqkX7sLjWiUG",
        "validId": true,
        "category": "",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureClass"
          ]
        }
      },
      {
        "id": "IoFNBVxRXWxbogdF",
        "name": "Construct (Creature Class)",
        "type": "class",
        "uuid": "Compendium.trg-prime.creature-classes.Item.IoFNBVxRXWxbogdF",
        "validId": true,
        "category": "",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureClass"
          ]
        }
      },
      {
        "id": "Ogk8BCNDazG1m6hP",
        "name": "Plant (Creature Class)",
        "type": "class",
        "uuid": "Compendium.trg-prime.creature-classes.Item.Ogk8BCNDazG1m6hP",
        "validId": true,
        "category": "",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureClass"
          ]
        }
      },
      {
        "id": "Ta1Imrd3mlfLThze",
        "name": "Animal (Creature Class)",
        "type": "class",
        "uuid": "Compendium.trg-prime.creature-classes.Item.Ta1Imrd3mlfLThze",
        "validId": true,
        "category": "",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureClass"
          ]
        }
      },
      {
        "id": "XzAkOALzmi46o9Sl",
        "name": "Fey (Creature Class)",
        "type": "class",
        "uuid": "Compendium.trg-prime.creature-classes.Item.XzAkOALzmi46o9Sl",
        "validId": true,
        "category": "",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureClass"
          ]
        }
      },
      {
        "id": "cnnLioj7zyj3AKzi",
        "name": "Humanoid (Creature Class)",
        "type": "class",
        "uuid": "Compendium.trg-prime.creature-classes.Item.cnnLioj7zyj3AKzi",
        "validId": true,
        "category": "",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureClass"
          ]
        }
      },
      {
        "id": "dF9QyL2wkjtIWSDJ",
        "name": "Caster (Creature Class)",
        "type": "class",
        "uuid": "Compendium.trg-prime.creature-classes.Item.dF9QyL2wkjtIWSDJ",
        "validId": true,
        "category": "",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureClass"
          ]
        }
      },
      {
        "id": "fcgEF6ZnJuJSndxb",
        "name": "Hybrid (Creature Class)",
        "type": "class",
        "uuid": "Compendium.trg-prime.creature-classes.Item.fcgEF6ZnJuJSndxb",
        "validId": true,
        "category": "",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureClass"
          ]
        }
      },
      {
        "id": "gg3mPWzigGFbeg0Z",
        "name": "Tough (Creature Class)",
        "type": "class",
        "uuid": "Compendium.trg-prime.creature-classes.Item.gg3mPWzigGFbeg0Z",
        "validId": true,
        "category": "",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureClass"
          ]
        }
      },
      {
        "id": "m5wJYoOpFvyy3cZB",
        "name": "Elemental (Creature Class)",
        "type": "class",
        "uuid": "Compendium.trg-prime.creature-classes.Item.m5wJYoOpFvyy3cZB",
        "validId": true,
        "category": "",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureClass"
          ]
        }
      },
      {
        "id": "yujTGHco3wS11sRF",
        "name": "Wyrm (Creature Class)",
        "type": "class",
        "uuid": "Compendium.trg-prime.creature-classes.Item.yujTGHco3wS11sRF",
        "validId": true,
        "category": "",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureClass"
          ]
        }
      }
    ],
    "creature-attacks": [
      {
        "id": "0xYmOtX2StqEoRkw",
        "name": "Gore",
        "type": "weapon",
        "uuid": "Compendium.trg-prime.creature-attacks.Item.0xYmOtX2StqEoRkw",
        "validId": true,
        "category": "Unarmed",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAttack"
          ]
        }
      },
      {
        "id": "JDDX4IW9DSq0uSKk",
        "name": "Wings",
        "type": "weapon",
        "uuid": "Compendium.trg-prime.creature-attacks.Item.JDDX4IW9DSq0uSKk",
        "validId": true,
        "category": "Unarmed",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAttack"
          ]
        }
      },
      {
        "id": "OPosoEVfbsJSKHzG",
        "name": "Sting",
        "type": "weapon",
        "uuid": "Compendium.trg-prime.creature-attacks.Item.OPosoEVfbsJSKHzG",
        "validId": true,
        "category": "Unarmed",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAttack"
          ]
        }
      },
      {
        "id": "QlUfedrLQVBoECCY",
        "name": "Claw",
        "type": "weapon",
        "uuid": "Compendium.trg-prime.creature-attacks.Item.QlUfedrLQVBoECCY",
        "validId": true,
        "category": "Unarmed",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAttack"
          ]
        }
      },
      {
        "id": "f4IjojEtUH5mCP2i",
        "name": "Hoof",
        "type": "weapon",
        "uuid": "Compendium.trg-prime.creature-attacks.Item.f4IjojEtUH5mCP2i",
        "validId": true,
        "category": "Unarmed",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAttack"
          ]
        }
      },
      {
        "id": "nXvHvZaKN9iL8c2y",
        "name": "Bite",
        "type": "weapon",
        "uuid": "Compendium.trg-prime.creature-attacks.Item.nXvHvZaKN9iL8c2y",
        "validId": true,
        "category": "Unarmed",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAttack"
          ]
        }
      },
      {
        "id": "oE9Z2OR1tCwGhoxX",
        "name": "Slam",
        "type": "weapon",
        "uuid": "Compendium.trg-prime.creature-attacks.Item.oE9Z2OR1tCwGhoxX",
        "validId": true,
        "category": "Unarmed",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAttack"
          ]
        }
      },
      {
        "id": "t3zAw5gJJDKLUNBN",
        "name": "Tentacle",
        "type": "weapon",
        "uuid": "Compendium.trg-prime.creature-attacks.Item.t3zAw5gJJDKLUNBN",
        "validId": true,
        "category": "Unarmed",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAttack"
          ]
        }
      },
      {
        "id": "xpNh8NxccDmvOr69",
        "name": "Tail Slap",
        "type": "weapon",
        "uuid": "Compendium.trg-prime.creature-attacks.Item.xpNh8NxccDmvOr69",
        "validId": true,
        "category": "Unarmed",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAttack"
          ]
        }
      },
      {
        "id": "xuAF2Adk5cOLdiJh",
        "name": "Unarmed Strike",
        "type": "weapon",
        "uuid": "Compendium.trg-prime.creature-attacks.Item.xuAF2Adk5cOLdiJh",
        "validId": true,
        "category": "Unarmed",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAttack"
          ]
        }
      }
    ],
    "creature-abilities": [
      {
        "id": "0Ollwtn6uCOYIJR5",
        "name": "Fire Healing",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.0Ollwtn6uCOYIJR5",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "0iFrwg4q9yAucPrz",
        "name": "Vibration Sense",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.0iFrwg4q9yAucPrz",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "2lvjXRtMse0wJsXe",
        "name": "Aura of Ruin",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.2lvjXRtMse0wJsXe",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility",
            "auras"
          ]
        }
      },
      {
        "id": "5RDT0UJsvLss8DH6",
        "name": "Aura of Heat",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.5RDT0UJsvLss8DH6",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility",
            "auras"
          ]
        }
      },
      {
        "id": "76ZGOVIrWQh7wLKC",
        "name": "Elemental Blood",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.76ZGOVIrWQh7wLKC",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "7e4ekHoSrzDayWza",
        "name": "Aura of Death",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.7e4ekHoSrzDayWza",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility",
            "auras"
          ]
        }
      },
      {
        "id": "7iQvxGSDFAV4UDQ3",
        "name": "Water Glide",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.7iQvxGSDFAV4UDQ3",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "8N7gjj8PInMdH83Z",
        "name": "Echolocation",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.8N7gjj8PInMdH83Z",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "8mnDAHlfrIpmBprY",
        "name": "Entangling Vines",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.8mnDAHlfrIpmBprY",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "9A8SwSfq6PcjjnMr",
        "name": "Aura of Decay",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.9A8SwSfq6PcjjnMr",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility",
            "auras"
          ]
        }
      },
      {
        "id": "9IS7HCWwsiFe23IV",
        "name": "Double Strike",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.9IS7HCWwsiFe23IV",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "9bts4Fh3CfXoTzKx",
        "name": "Corrode",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.9bts4Fh3CfXoTzKx",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "AMwiksNTBVJpscjE",
        "name": "Swimby Attack",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.AMwiksNTBVJpscjE",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "Arh7Z2rZhaBXFiab",
        "name": "Smokevision",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.Arh7Z2rZhaBXFiab",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "Bl5to0v2uiWLhrk5",
        "name": "Surge of Speed",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.Bl5to0v2uiWLhrk5",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "C64Sf71DvJ1vvPb6",
        "name": "Tear Flesh",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.C64Sf71DvJ1vvPb6",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "CUamcLmJWqRFU4yr",
        "name": "Rend",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.CUamcLmJWqRFU4yr",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "Cdh9ldjrM6cVOeNv",
        "name": "Reactive Disarm",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.Cdh9ldjrM6cVOeNv",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "DncfUvDc3ysrTAbt",
        "name": "Blood Scent",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.DncfUvDc3ysrTAbt",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "E7gtQOEd6kaEmace",
        "name": "Wingless Flight",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.E7gtQOEd6kaEmace",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "Ebw4D458r41Ay3fj",
        "name": "Draconic Shifting",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.Ebw4D458r41Ay3fj",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "EfuvOOxDo5Q5kgCn",
        "name": "Slowing Breath",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.EfuvOOxDo5Q5kgCn",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "Et3aymkUpaOsLTnb",
        "name": "Smoke Form",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.Et3aymkUpaOsLTnb",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "FcdQIHT0dNx0Ft7m",
        "name": "Undead Fortitude",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.FcdQIHT0dNx0Ft7m",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility",
            "deathGuard"
          ]
        }
      },
      {
        "id": "G5gy0nNPdcRwFy3p",
        "name": "Slow",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.G5gy0nNPdcRwFy3p",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "HNlpMWqrYgsDnWTV",
        "name": "Sonar Sense",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.HNlpMWqrYgsDnWTV",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "HnuBVkrs6vrHjQKP",
        "name": "Draconic Assault",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.HnuBVkrs6vrHjQKP",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "I8fnwQcezqlUBLlW",
        "name": "Whispers of the Grave",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.I8fnwQcezqlUBLlW",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "IFauT3tlPXUAA5NB",
        "name": "Crush",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.IFauT3tlPXUAA5NB",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "IdFXVEocq2R3Nr04",
        "name": "Stench",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.IdFXVEocq2R3Nr04",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility",
            "auras"
          ]
        }
      },
      {
        "id": "IftsXROAvEVdueN2",
        "name": "Undead Spawn",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.IftsXROAvEVdueN2",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "JnwZIeuEe2YgoWa8",
        "name": "Endless Hunger",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.JnwZIeuEe2YgoWa8",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "Jr3fwgipV79eeHKj",
        "name": "Sunlight Weakness",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.Jr3fwgipV79eeHKj",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "K2xyAtcEq0D9hffd",
        "name": "Reflective Scales",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.K2xyAtcEq0D9hffd",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "KwAMi3Jhxz1xgIqA",
        "name": "Powerful Charge",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.KwAMi3Jhxz1xgIqA",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "LVEzRoDP22Hm3FVw",
        "name": "Whirlpool",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.LVEzRoDP22Hm3FVw",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility",
            "auras"
          ]
        }
      },
      {
        "id": "MNUCL01Oc668DyJU",
        "name": "Howl",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.MNUCL01Oc668DyJU",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "OlOJZNLF6S9QRCMy",
        "name": "Skewering Strikes",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.OlOJZNLF6S9QRCMy",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "OlX3uNXcLmz3dLTu",
        "name": "Souldrinker",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.OlX3uNXcLmz3dLTu",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "OoD8Eg0Iq25YsjmE",
        "name": "Hover",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.OoD8Eg0Iq25YsjmE",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "P0WlEBQ1Kj11U2vQ",
        "name": "Elemental Aura",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.P0WlEBQ1Kj11U2vQ",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility",
            "auras"
          ]
        }
      },
      {
        "id": "PalHs6maRS2yeoUQ",
        "name": "Natural Camouflage",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.PalHs6maRS2yeoUQ",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility",
            "conditionals"
          ]
        }
      },
      {
        "id": "PcXmeyqI0jNeZ33J",
        "name": "Spell Resilience",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.PcXmeyqI0jNeZ33J",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "Phq6oOYR2guSUpnR",
        "name": "Aura of Confusion",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.Phq6oOYR2guSUpnR",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility",
            "auras"
          ]
        }
      },
      {
        "id": "Pv7k5hlFW5gRKjDV",
        "name": "Drink Blood",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.Pv7k5hlFW5gRKjDV",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "Q1Lw13vIzRJWmjo4",
        "name": "Shadow Hand",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.Q1Lw13vIzRJWmjo4",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility",
            "afterStrikes"
          ]
        }
      },
      {
        "id": "Q7QepNbAzn3BZEeY",
        "name": "Plant Resistance",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.Q7QepNbAzn3BZEeY",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "QOuB9BTPA80qMN59",
        "name": "Garlic Repulsion",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.QOuB9BTPA80qMN59",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "SR2ktGAQpJoddlyL",
        "name": "Absorb Minerals",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.SR2ktGAQpJoddlyL",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "T7WqVj5FRdQm8Apv",
        "name": "Telepathy",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.T7WqVj5FRdQm8Apv",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "TdPVCVWoncsoD9QV",
        "name": "Life Sense",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.TdPVCVWoncsoD9QV",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "Tk5vGW1K3Cle411w",
        "name": "Torrent of Strikes",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.Tk5vGW1K3Cle411w",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "U0IlBCZWdFQCsZGA",
        "name": "Life Drain",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.U0IlBCZWdFQCsZGA",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility",
            "afterStrikes"
          ]
        }
      },
      {
        "id": "W32Nfw6voyvT9526",
        "name": "Clinging Breath",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.W32Nfw6voyvT9526",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "WfRtIFgKFG57kbuv",
        "name": "Survival Instinct",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.WfRtIFgKFG57kbuv",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "Wu0LNerEUb6kig9l",
        "name": "Aura of Tranquility",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.Wu0LNerEUb6kig9l",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility",
            "auras"
          ]
        }
      },
      {
        "id": "XC7AMot9Wdgwd6JA",
        "name": "Grave-Touched Presence",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.XC7AMot9Wdgwd6JA",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility",
            "conditionals"
          ]
        }
      },
      {
        "id": "XP5Vzi3z36TRCOS3",
        "name": "Keen Sense",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.XP5Vzi3z36TRCOS3",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility",
            "conditionals"
          ]
        }
      },
      {
        "id": "YlKnd6iTOwnownIC",
        "name": "Eternal Summons",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.YlKnd6iTOwnownIC",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "ZQU6DChrUdxwrSdy",
        "name": "Pouncing Assault",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.ZQU6DChrUdxwrSdy",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "aLbtk6RaItiC5d2U",
        "name": "Persistent",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.aLbtk6RaItiC5d2U",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "cFab96J9S79siEz5",
        "name": "Elemental Strikes",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.cFab96J9S79siEz5",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "cOay0QjFw9noeze0",
        "name": "Amorphous Split",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.cOay0QjFw9noeze0",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "cRTEtpk0PSFGOmMO",
        "name": "Vorpal Weapons",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.cRTEtpk0PSFGOmMO",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "ff30ScorchBreath",
        "name": "Scorching Breath",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.ff30ScorchBreath",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "ff30WingBuffet01",
        "name": "Wing Buffet",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.ff30WingBuffet01",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "g14kvU6w14WxtRTG",
        "name": "Aura of Fire",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.g14kvU6w14WxtRTG",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility",
            "auras"
          ]
        }
      },
      {
        "id": "hT9kef114H5ssZUg",
        "name": "Faultless Casting",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.hT9kef114H5ssZUg",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility",
            "defensiveCasting"
          ]
        }
      },
      {
        "id": "hWaZBLAlfU0AWfgb",
        "name": "Ashen Aura",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.hWaZBLAlfU0AWfgb",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility",
            "auras"
          ]
        }
      },
      {
        "id": "iMYlwsTPkl2qP1K9",
        "name": "Frightful Aura",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.iMYlwsTPkl2qP1K9",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility",
            "auras"
          ]
        }
      },
      {
        "id": "ilmEJm3Qoi00hxue",
        "name": "Arcadian Caster",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.ilmEJm3Qoi00hxue",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "jMv0ODJcQOqKBKHv",
        "name": "Magic Dispelling",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.jMv0ODJcQOqKBKHv",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "jwH6NtOhqYZeoyZQ",
        "name": "Whirlwind",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.jwH6NtOhqYZeoyZQ",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility",
            "auras"
          ]
        }
      },
      {
        "id": "kJ9rmvQBHycPJDoc",
        "name": "Diving Strike",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.kJ9rmvQBHycPJDoc",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "m4q4Q1h7rYybgC8O",
        "name": "Elemental Grasp",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.m4q4Q1h7rYybgC8O",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "oJE7hwKs2I65jHyy",
        "name": "Fearful Strength",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.oJE7hwKs2I65jHyy",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "pNyoRxvqwLQZ48sw",
        "name": "Sunlight Vulnerability",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.pNyoRxvqwLQZ48sw",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "pRXMnhTBMOBxgWFh",
        "name": "Soulless Aura",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.pRXMnhTBMOBxgWFh",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility",
            "auras"
          ]
        }
      },
      {
        "id": "psf6Tg1tyFGAf2bO",
        "name": "Earth Pass",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.psf6Tg1tyFGAf2bO",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "pw5wsN42sODCIJPx",
        "name": "Shadow Breath",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.pw5wsN42sODCIJPx",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "qdskgmjNnaqTbeAC",
        "name": "Penetrating Breath",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.qdskgmjNnaqTbeAC",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "qgho1U3BE3Jtcio3",
        "name": "Natural Leaper",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.qgho1U3BE3Jtcio3",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "qmywkqu5KuTPHgVn",
        "name": "Dispelling Strike",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.qmywkqu5KuTPHgVn",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility",
            "afterStrikes"
          ]
        }
      },
      {
        "id": "r0E1azI9Ha5GMVpd",
        "name": "All Round Vision",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.r0E1azI9Ha5GMVpd",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "rk1iS0LcYgXD8r3e",
        "name": "True Caster",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.rk1iS0LcYgXD8r3e",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "ruKYdQov2c1HdELQ",
        "name": "Blight Sense",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.ruKYdQov2c1HdELQ",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "s3jnew41fQH30L6c",
        "name": "Penetrating Strikes",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.s3jnew41fQH30L6c",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "sXcOz6XDIdyuMvMr",
        "name": "Draconic Roar",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.sXcOz6XDIdyuMvMr",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "sgXchZT4WeqEgQP7",
        "name": "Ice Climb",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.sgXchZT4WeqEgQP7",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility",
            "ignoresDifficultTerrain"
          ]
        }
      },
      {
        "id": "t4DqZuvx5f40qLlP",
        "name": "Fear of Water",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.t4DqZuvx5f40qLlP",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "tVMy9MgHlPgMI3XO",
        "name": "Ice Stride",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.tVMy9MgHlPgMI3XO",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility",
            "ignoresDifficultTerrain"
          ]
        }
      },
      {
        "id": "uNLGVjpnVB8QJbAf",
        "name": "Alien Mind",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.uNLGVjpnVB8QJbAf",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "uVhHBqwFxiPGmIGa",
        "name": "Aura of Despair",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.uVhHBqwFxiPGmIGa",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility",
            "auras"
          ]
        }
      },
      {
        "id": "vRWsXRENCaaE0K8q",
        "name": "Hold Breath",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.vRWsXRENCaaE0K8q",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "vXJUptew1ba7Oqhq",
        "name": "Flyby Attack",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.vXJUptew1ba7Oqhq",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "vmq0shlnnnnTcquF",
        "name": "Snowvision",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.vmq0shlnnnnTcquF",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "vrIBWZ9xnuf0POuf",
        "name": "Sonic Moan",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.vrIBWZ9xnuf0POuf",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "w4fOuUxqovDj5Wua",
        "name": "Abyssal Healing",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.w4fOuUxqovDj5Wua",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "w6JnSkBnU83AKun8",
        "name": "Elusive Movement",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.w6JnSkBnU83AKun8",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "w7guNEN9aooSkjOh",
        "name": "Shadowy",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.w7guNEN9aooSkjOh",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "xwisA7JRqA1bsVXO",
        "name": "Secondary Critical",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.xwisA7JRqA1bsVXO",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "y4PjvJ9k3C6Ak0Yv",
        "name": "Regeneration",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.y4PjvJ9k3C6Ak0Yv",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "y6pzwRId0ICpLm2C",
        "name": "Swallow",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.y6pzwRId0ICpLm2C",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "zaTgiNk5fJjJvXsO",
        "name": "Infestation",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.zaTgiNk5fJjJvXsO",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility",
            "auras"
          ]
        }
      },
      {
        "id": "zfV8rFpSx8nFnoxD",
        "name": "Paralysing Gaze",
        "type": "ability",
        "uuid": "Compendium.trg-prime.creature-abilities.Item.zfV8rFpSx8nFnoxD",
        "validId": true,
        "category": "Creature",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      }
    ],
    "classes": [
      {
        "id": "1n2N69dMXi8AIEFf",
        "name": "Druid",
        "type": "class",
        "uuid": "Compendium.trg-prime.classes.Item.1n2N69dMXi8AIEFf",
        "validId": true,
        "category": "",
        "ppCost": null,
        "magicalAbility": "constitution",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "abilityLevels",
            "magicalNote",
            "bonusFeatsNote"
          ]
        }
      },
      {
        "id": "Dqes6N7gejkywlAd",
        "name": "Cleric",
        "type": "class",
        "uuid": "Compendium.trg-prime.classes.Item.Dqes6N7gejkywlAd",
        "validId": true,
        "category": "",
        "ppCost": null,
        "magicalAbility": "wisdom",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "abilityLevels",
            "magicalNote",
            "bonusFeatsNote"
          ]
        }
      },
      {
        "id": "F1qHfTncX2Wn3zLP",
        "name": "Fighter",
        "type": "class",
        "uuid": "Compendium.trg-prime.classes.Item.F1qHfTncX2Wn3zLP",
        "validId": true,
        "category": "",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "abilityLevels",
            "magicalNote",
            "bonusFeatsNote"
          ]
        }
      },
      {
        "id": "MWEXU6Gi1VodPSb7",
        "name": "Ranger",
        "type": "class",
        "uuid": "Compendium.trg-prime.classes.Item.MWEXU6Gi1VodPSb7",
        "validId": true,
        "category": "",
        "ppCost": null,
        "magicalAbility": "constitution",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "abilityLevels",
            "magicalNote",
            "bonusFeatsNote"
          ]
        }
      },
      {
        "id": "Z33dXlYDPWusJwYt",
        "name": "Rogue",
        "type": "class",
        "uuid": "Compendium.trg-prime.classes.Item.Z33dXlYDPWusJwYt",
        "validId": true,
        "category": "",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "abilityLevels",
            "magicalNote",
            "bonusFeatsNote"
          ]
        }
      },
      {
        "id": "jXcruOONJIf5IBtI",
        "name": "Wizard",
        "type": "class",
        "uuid": "Compendium.trg-prime.classes.Item.jXcruOONJIf5IBtI",
        "validId": true,
        "category": "",
        "ppCost": null,
        "magicalAbility": "intelligence",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "abilityLevels",
            "magicalNote",
            "bonusFeatsNote"
          ]
        }
      },
      {
        "id": "lEqPLsHSfKcHOMUw",
        "name": "Crusader",
        "type": "class",
        "uuid": "Compendium.trg-prime.classes.Item.lEqPLsHSfKcHOMUw",
        "validId": true,
        "category": "",
        "ppCost": null,
        "magicalAbility": "charisma",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "abilityLevels",
            "magicalNote",
            "bonusFeatsNote",
            "alignmentFeats"
          ]
        }
      },
      {
        "id": "r6ocf02f5KndvTTy",
        "name": "Bard",
        "type": "class",
        "uuid": "Compendium.trg-prime.classes.Item.r6ocf02f5KndvTTy",
        "validId": true,
        "category": "",
        "ppCost": null,
        "magicalAbility": "charisma",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "abilityLevels",
            "magicalNote",
            "bonusFeatsNote"
          ]
        }
      }
    ],
    "races": [
      {
        "id": "1pEhUOxmhqTAfpYx",
        "name": "Halfling",
        "type": "race",
        "uuid": "Compendium.trg-prime.races.Item.1pEhUOxmhqTAfpYx",
        "validId": true,
        "category": "Race",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 2,
          "flags": []
        }
      },
      {
        "id": "C9RQdBPdFhGAn0GG",
        "name": "Human",
        "type": "race",
        "uuid": "Compendium.trg-prime.races.Item.C9RQdBPdFhGAn0GG",
        "validId": true,
        "category": "Race",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "specialistChoice"
          ]
        }
      },
      {
        "id": "IvgNb9f0AwVs0i4C",
        "name": "Gnome",
        "type": "race",
        "uuid": "Compendium.trg-prime.races.Item.IvgNb9f0AwVs0i4C",
        "validId": true,
        "category": "Race",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 2,
          "flags": []
        }
      },
      {
        "id": "PMHmcJwUjA8Ju1uc",
        "name": "Ascendan",
        "type": "race",
        "uuid": "Compendium.trg-prime.races.Item.PMHmcJwUjA8Ju1uc",
        "validId": true,
        "category": "Race",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 2,
          "flags": []
        }
      },
      {
        "id": "diByUDWG28dBvjNF",
        "name": "Elf",
        "type": "race",
        "uuid": "Compendium.trg-prime.races.Item.diByUDWG28dBvjNF",
        "validId": true,
        "category": "Race",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 2,
          "flags": []
        }
      },
      {
        "id": "egkPNeanC7mBJfJD",
        "name": "Kornargon",
        "type": "race",
        "uuid": "Compendium.trg-prime.races.Item.egkPNeanC7mBJfJD",
        "validId": true,
        "category": "Race",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 2,
          "flags": []
        }
      },
      {
        "id": "izGd4A5UGs5TfMJt",
        "name": "Orc",
        "type": "race",
        "uuid": "Compendium.trg-prime.races.Item.izGd4A5UGs5TfMJt",
        "validId": true,
        "category": "Race",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 2,
          "flags": []
        }
      },
      {
        "id": "p95fJ7oroNF3mARr",
        "name": "Dwarf",
        "type": "race",
        "uuid": "Compendium.trg-prime.races.Item.p95fJ7oroNF3mARr",
        "validId": true,
        "category": "Race",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 2,
          "flags": []
        }
      }
    ],
    "heritages": [
      {
        "id": "3Wv3RqGrsrHqi0tO",
        "name": "Osp-Iar",
        "type": "heritage",
        "uuid": "Compendium.trg-prime.heritages.Item.3Wv3RqGrsrHqi0tO",
        "validId": true,
        "category": "Heritage",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "5xrOYUVoffydb2DN",
        "name": "Northman",
        "type": "heritage",
        "uuid": "Compendium.trg-prime.heritages.Item.5xrOYUVoffydb2DN",
        "validId": true,
        "category": "Heritage",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "6fNfNC5ROjbGBPPu",
        "name": "Noble",
        "type": "heritage",
        "uuid": "Compendium.trg-prime.heritages.Item.6fNfNC5ROjbGBPPu",
        "validId": true,
        "category": "Heritage",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "6mRw1kqEPPZ5qOMM",
        "name": "Chronara",
        "type": "heritage",
        "uuid": "Compendium.trg-prime.heritages.Item.6mRw1kqEPPZ5qOMM",
        "validId": true,
        "category": "Heritage",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "6wk1vXo0AC2OHiol",
        "name": "Lys-Fod",
        "type": "heritage",
        "uuid": "Compendium.trg-prime.heritages.Item.6wk1vXo0AC2OHiol",
        "validId": true,
        "category": "Heritage",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 2,
          "flags": []
        }
      },
      {
        "id": "70VbSeTPFqoyVjRa",
        "name": "Dur-Fod",
        "type": "heritage",
        "uuid": "Compendium.trg-prime.heritages.Item.70VbSeTPFqoyVjRa",
        "validId": true,
        "category": "Heritage",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "7DpDcCtegRzTqmbz",
        "name": "Furini",
        "type": "heritage",
        "uuid": "Compendium.trg-prime.heritages.Item.7DpDcCtegRzTqmbz",
        "validId": true,
        "category": "Heritage",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "A4qtTAlGM101VA9l",
        "name": "Pastoral",
        "type": "heritage",
        "uuid": "Compendium.trg-prime.heritages.Item.A4qtTAlGM101VA9l",
        "validId": true,
        "category": "Heritage",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "BRNlqkQws3SMlQtC",
        "name": "Svirni",
        "type": "heritage",
        "uuid": "Compendium.trg-prime.heritages.Item.BRNlqkQws3SMlQtC",
        "validId": true,
        "category": "Heritage",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "BTDvv0EegVr0hTtc",
        "name": "Urloch",
        "type": "heritage",
        "uuid": "Compendium.trg-prime.heritages.Item.BTDvv0EegVr0hTtc",
        "validId": true,
        "category": "Heritage",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 3,
          "flags": []
        }
      },
      {
        "id": "C0q90rAdquW5424R",
        "name": "Sharuk-Xal",
        "type": "heritage",
        "uuid": "Compendium.trg-prime.heritages.Item.C0q90rAdquW5424R",
        "validId": true,
        "category": "Heritage",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "CXMI7zZgbVVuwuCp",
        "name": "Dark",
        "type": "heritage",
        "uuid": "Compendium.trg-prime.heritages.Item.CXMI7zZgbVVuwuCp",
        "validId": true,
        "category": "Heritage",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "CjMUrd1txNel3lE5",
        "name": "Tirvni",
        "type": "heritage",
        "uuid": "Compendium.trg-prime.heritages.Item.CjMUrd1txNel3lE5",
        "validId": true,
        "category": "Heritage",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "Ewh98I4FtyzYjarn",
        "name": "Tribal",
        "type": "heritage",
        "uuid": "Compendium.trg-prime.heritages.Item.Ewh98I4FtyzYjarn",
        "validId": true,
        "category": "Heritage",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "FDyDMn7vDXlnxX2R",
        "name": "Plains",
        "type": "heritage",
        "uuid": "Compendium.trg-prime.heritages.Item.FDyDMn7vDXlnxX2R",
        "validId": true,
        "category": "Heritage",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "Iva5vCodJIHOA0vC",
        "name": "Sharuk-Rin",
        "type": "heritage",
        "uuid": "Compendium.trg-prime.heritages.Item.Iva5vCodJIHOA0vC",
        "validId": true,
        "category": "Heritage",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "LhUhLphnJPc2eh4o",
        "name": "City",
        "type": "heritage",
        "uuid": "Compendium.trg-prime.heritages.Item.LhUhLphnJPc2eh4o",
        "validId": true,
        "category": "Heritage",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "MKvw8pVfz54krUa6",
        "name": "Erui-Iar",
        "type": "heritage",
        "uuid": "Compendium.trg-prime.heritages.Item.MKvw8pVfz54krUa6",
        "validId": true,
        "category": "Heritage",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "ODBvDVFuA8ZgfVaW",
        "name": "Silvarni",
        "type": "heritage",
        "uuid": "Compendium.trg-prime.heritages.Item.ODBvDVFuA8ZgfVaW",
        "validId": true,
        "category": "Heritage",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "conditionals",
            "ignoresDifficultTerrain"
          ]
        }
      },
      {
        "id": "Sgts73YlcWvgg2sG",
        "name": "Arctic",
        "type": "heritage",
        "uuid": "Compendium.trg-prime.heritages.Item.Sgts73YlcWvgg2sG",
        "validId": true,
        "category": "Heritage",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 2,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "T8yYUwE7NmbshhGs",
        "name": "Tolderni",
        "type": "heritage",
        "uuid": "Compendium.trg-prime.heritages.Item.T8yYUwE7NmbshhGs",
        "validId": true,
        "category": "Heritage",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "Uif0QMuSUMFwcnhC",
        "name": "Sorini",
        "type": "heritage",
        "uuid": "Compendium.trg-prime.heritages.Item.Uif0QMuSUMFwcnhC",
        "validId": true,
        "category": "Heritage",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 2,
          "flags": []
        }
      },
      {
        "id": "UvWCTY52yLELtDqj",
        "name": "Fey",
        "type": "heritage",
        "uuid": "Compendium.trg-prime.heritages.Item.UvWCTY52yLELtDqj",
        "validId": true,
        "category": "Heritage",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 2,
          "flags": []
        }
      },
      {
        "id": "VCr2xd9yARsm6Jmy",
        "name": "Elarni",
        "type": "heritage",
        "uuid": "Compendium.trg-prime.heritages.Item.VCr2xd9yARsm6Jmy",
        "validId": true,
        "category": "Heritage",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "bHiqmVqGypioIzYf",
        "name": "Sharuk-Mar",
        "type": "heritage",
        "uuid": "Compendium.trg-prime.heritages.Item.bHiqmVqGypioIzYf",
        "validId": true,
        "category": "Heritage",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "bpxRZ1aizfGYDN6K",
        "name": "Nerini",
        "type": "heritage",
        "uuid": "Compendium.trg-prime.heritages.Item.bpxRZ1aizfGYDN6K",
        "validId": true,
        "category": "Heritage",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 5,
          "flags": [
            "forbiddenTraditions"
          ]
        }
      },
      {
        "id": "cOTb7UlGbMP4s9G6",
        "name": "Sindarni",
        "type": "heritage",
        "uuid": "Compendium.trg-prime.heritages.Item.cOTb7UlGbMP4s9G6",
        "validId": true,
        "category": "Heritage",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "dfgL0CpM0sQFxGAB",
        "name": "Desert",
        "type": "heritage",
        "uuid": "Compendium.trg-prime.heritages.Item.dfgL0CpM0sQFxGAB",
        "validId": true,
        "category": "Heritage",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "dlPYrlJ6O5QMifmg",
        "name": "Drelvarni",
        "type": "heritage",
        "uuid": "Compendium.trg-prime.heritages.Item.dlPYrlJ6O5QMifmg",
        "validId": true,
        "category": "Heritage",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "glvU8D5V7jblputx",
        "name": "Morgar",
        "type": "heritage",
        "uuid": "Compendium.trg-prime.heritages.Item.glvU8D5V7jblputx",
        "validId": true,
        "category": "Heritage",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "hSsh5AsbVmYJsdua",
        "name": "Thengar",
        "type": "heritage",
        "uuid": "Compendium.trg-prime.heritages.Item.hSsh5AsbVmYJsdua",
        "validId": true,
        "category": "Heritage",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "conditionals",
            "defenceDC"
          ]
        }
      },
      {
        "id": "in9wnGTJnO9zsyVk",
        "name": "Storgar",
        "type": "heritage",
        "uuid": "Compendium.trg-prime.heritages.Item.in9wnGTJnO9zsyVk",
        "validId": true,
        "category": "Heritage",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 2,
          "flags": [
            "defenceDC",
            "involuntaryMovementNote"
          ]
        }
      },
      {
        "id": "lbgXR5ym8XWHVauS",
        "name": "Tall-Fyr",
        "type": "heritage",
        "uuid": "Compendium.trg-prime.heritages.Item.lbgXR5ym8XWHVauS",
        "validId": true,
        "category": "Heritage",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "ltM5Q7NdBtgjD0AX",
        "name": "Hill",
        "type": "heritage",
        "uuid": "Compendium.trg-prime.heritages.Item.ltM5Q7NdBtgjD0AX",
        "validId": true,
        "category": "Heritage",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "n2Hiyk3dbsDWFroB",
        "name": "Afele",
        "type": "heritage",
        "uuid": "Compendium.trg-prime.heritages.Item.n2Hiyk3dbsDWFroB",
        "validId": true,
        "category": "Heritage",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "nWsR3PlDtdnOCxBd",
        "name": "Pelora",
        "type": "heritage",
        "uuid": "Compendium.trg-prime.heritages.Item.nWsR3PlDtdnOCxBd",
        "validId": true,
        "category": "Heritage",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "o58LDyzuSafXf9Rd",
        "name": "Gul-Fyr",
        "type": "heritage",
        "uuid": "Compendium.trg-prime.heritages.Item.o58LDyzuSafXf9Rd",
        "validId": true,
        "category": "Heritage",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 2,
          "flags": []
        }
      },
      {
        "id": "ojqfM5YBZeLa7Uvv",
        "name": "Menora",
        "type": "heritage",
        "uuid": "Compendium.trg-prime.heritages.Item.ojqfM5YBZeLa7Uvv",
        "validId": true,
        "category": "Heritage",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "pAUHPebB82wEiOsV",
        "name": "Noldorni",
        "type": "heritage",
        "uuid": "Compendium.trg-prime.heritages.Item.pAUHPebB82wEiOsV",
        "validId": true,
        "category": "Heritage",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "pqxXGe0pgczlgu14",
        "name": "Azgar",
        "type": "heritage",
        "uuid": "Compendium.trg-prime.heritages.Item.pqxXGe0pgczlgu14",
        "validId": true,
        "category": "Heritage",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 2,
          "flags": []
        }
      },
      {
        "id": "r6LlAwZJkDTAdd4C",
        "name": "Dengar",
        "type": "heritage",
        "uuid": "Compendium.trg-prime.heritages.Item.r6LlAwZJkDTAdd4C",
        "validId": true,
        "category": "Heritage",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "rHPAkWGGsCzvXtpH",
        "name": "Stout-Fyr",
        "type": "heritage",
        "uuid": "Compendium.trg-prime.heritages.Item.rHPAkWGGsCzvXtpH",
        "validId": true,
        "category": "Heritage",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "tZYxLXOr6kZA7LMX",
        "name": "Tovon-Iar",
        "type": "heritage",
        "uuid": "Compendium.trg-prime.heritages.Item.tZYxLXOr6kZA7LMX",
        "validId": true,
        "category": "Heritage",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "uWmfvXxtNFjEX6tW",
        "name": "Galad-Iar",
        "type": "heritage",
        "uuid": "Compendium.trg-prime.heritages.Item.uWmfvXxtNFjEX6tW",
        "validId": true,
        "category": "Heritage",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "yXY2NZDerjRi3pVd",
        "name": "Sharuk-Dur",
        "type": "heritage",
        "uuid": "Compendium.trg-prime.heritages.Item.yXY2NZDerjRi3pVd",
        "validId": true,
        "category": "Heritage",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 2,
          "flags": []
        }
      }
    ],
    "backgrounds": [
      {
        "id": "2tSQ3yvDxSLKMQ6L",
        "name": "Highwayman",
        "type": "background",
        "uuid": "Compendium.trg-prime.backgrounds.Item.2tSQ3yvDxSLKMQ6L",
        "validId": true,
        "category": "Background",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "grantedSpecialistSkills",
            "specialistChoice"
          ]
        }
      },
      {
        "id": "540CXMaSc9Y27itY",
        "name": "Charlatan",
        "type": "background",
        "uuid": "Compendium.trg-prime.backgrounds.Item.540CXMaSc9Y27itY",
        "validId": true,
        "category": "Background",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "grantedSpecialistSkills"
          ]
        }
      },
      {
        "id": "6vulkgMWn4leN9v5",
        "name": "Templar",
        "type": "background",
        "uuid": "Compendium.trg-prime.backgrounds.Item.6vulkgMWn4leN9v5",
        "validId": true,
        "category": "Background",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "grantedSpecialistSkills",
            "specialistChoice"
          ]
        }
      },
      {
        "id": "7WCD7OmMe8YX8Qa3",
        "name": "Sailor",
        "type": "background",
        "uuid": "Compendium.trg-prime.backgrounds.Item.7WCD7OmMe8YX8Qa3",
        "validId": true,
        "category": "Background",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "grantedSpecialistSkills"
          ]
        }
      },
      {
        "id": "Bq5xry26YSj70YXF",
        "name": "Labourer",
        "type": "background",
        "uuid": "Compendium.trg-prime.backgrounds.Item.Bq5xry26YSj70YXF",
        "validId": true,
        "category": "Background",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "grantedSpecialistSkills"
          ]
        }
      },
      {
        "id": "Bs4iPA9lFnSzTRkR",
        "name": "Hunter",
        "type": "background",
        "uuid": "Compendium.trg-prime.backgrounds.Item.Bs4iPA9lFnSzTRkR",
        "validId": true,
        "category": "Background",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "grantedSpecialistSkills"
          ]
        }
      },
      {
        "id": "F1mAFcItXmQAiUQP",
        "name": "Cultist",
        "type": "background",
        "uuid": "Compendium.trg-prime.backgrounds.Item.F1mAFcItXmQAiUQP",
        "validId": true,
        "category": "Background",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "grantedSpecialistSkills",
            "specialistChoice"
          ]
        }
      },
      {
        "id": "G7bB2IM3B7d63wN3",
        "name": "Miner",
        "type": "background",
        "uuid": "Compendium.trg-prime.backgrounds.Item.G7bB2IM3B7d63wN3",
        "validId": true,
        "category": "Background",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "grantedSpecialistSkills",
            "featQualifier"
          ]
        }
      },
      {
        "id": "HTzfs7Jg62auAWIc",
        "name": "Merchant",
        "type": "background",
        "uuid": "Compendium.trg-prime.backgrounds.Item.HTzfs7Jg62auAWIc",
        "validId": true,
        "category": "Background",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "grantedSpecialistSkills"
          ]
        }
      },
      {
        "id": "HYq00e71cbYX4SUU",
        "name": "Weaver",
        "type": "background",
        "uuid": "Compendium.trg-prime.backgrounds.Item.HYq00e71cbYX4SUU",
        "validId": true,
        "category": "Background",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "grantedSpecialistSkills",
            "spellChoice"
          ]
        }
      },
      {
        "id": "Hah5xCGM8lNZrXY4",
        "name": "Diplomat",
        "type": "background",
        "uuid": "Compendium.trg-prime.backgrounds.Item.Hah5xCGM8lNZrXY4",
        "validId": true,
        "category": "Background",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "grantedSpecialistSkills"
          ]
        }
      },
      {
        "id": "KE6GUSD4ngh1Nr1g",
        "name": "Gladiator",
        "type": "background",
        "uuid": "Compendium.trg-prime.backgrounds.Item.KE6GUSD4ngh1Nr1g",
        "validId": true,
        "category": "Background",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "grantedSpecialistSkills"
          ]
        }
      },
      {
        "id": "KulayMqZ6tdXQ8j3",
        "name": "Servant Of Nature",
        "type": "background",
        "uuid": "Compendium.trg-prime.backgrounds.Item.KulayMqZ6tdXQ8j3",
        "validId": true,
        "category": "Background",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "grantedSpecialistSkills"
          ]
        }
      },
      {
        "id": "L7INOcyJpCHOp9t8",
        "name": "Scout",
        "type": "background",
        "uuid": "Compendium.trg-prime.backgrounds.Item.L7INOcyJpCHOp9t8",
        "validId": true,
        "category": "Background",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "grantedSpecialistSkills",
            "specialistChoice"
          ]
        }
      },
      {
        "id": "NiMIS1bDzFzHQlKA",
        "name": "Acrobat",
        "type": "background",
        "uuid": "Compendium.trg-prime.backgrounds.Item.NiMIS1bDzFzHQlKA",
        "validId": true,
        "category": "Background",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "grantedSpecialistSkills"
          ]
        }
      },
      {
        "id": "Nlq2ExjQdaIb0jBr",
        "name": "Outrider",
        "type": "background",
        "uuid": "Compendium.trg-prime.backgrounds.Item.Nlq2ExjQdaIb0jBr",
        "validId": true,
        "category": "Background",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "grantedSpecialistSkills"
          ]
        }
      },
      {
        "id": "PCFzVPKeqSapC0ae",
        "name": "Cook",
        "type": "background",
        "uuid": "Compendium.trg-prime.backgrounds.Item.PCFzVPKeqSapC0ae",
        "validId": true,
        "category": "Background",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 2,
          "flags": [
            "grantedSpecialistSkills",
            "conditionals"
          ]
        }
      },
      {
        "id": "U5EHiYSA0z6mysIA",
        "name": "Archaeologist",
        "type": "background",
        "uuid": "Compendium.trg-prime.backgrounds.Item.U5EHiYSA0z6mysIA",
        "validId": true,
        "category": "Background",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "grantedSpecialistSkills",
            "specialistChoice"
          ]
        }
      },
      {
        "id": "W7p1Kaupaidz9ldS",
        "name": "Apprentice",
        "type": "background",
        "uuid": "Compendium.trg-prime.backgrounds.Item.W7p1Kaupaidz9ldS",
        "validId": true,
        "category": "Background",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "grantedSpecialistSkills",
            "specialistChoice"
          ]
        }
      },
      {
        "id": "WUcq1FYwiA8N5GGR",
        "name": "Fortune Teller",
        "type": "background",
        "uuid": "Compendium.trg-prime.backgrounds.Item.WUcq1FYwiA8N5GGR",
        "validId": true,
        "category": "Background",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "grantedSpecialistSkills"
          ]
        }
      },
      {
        "id": "XzdCvQJV5rvJodxH",
        "name": "Animal Friend",
        "type": "background",
        "uuid": "Compendium.trg-prime.backgrounds.Item.XzdCvQJV5rvJodxH",
        "validId": true,
        "category": "Background",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "grantedSpecialistSkills"
          ]
        }
      },
      {
        "id": "aAeG7wkZAaLPKPck",
        "name": "Arcane Apprentice",
        "type": "background",
        "uuid": "Compendium.trg-prime.backgrounds.Item.aAeG7wkZAaLPKPck",
        "validId": true,
        "category": "Background",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "grantedSpecialistSkills"
          ]
        }
      },
      {
        "id": "cQNJ17cm0IOgKMut",
        "name": "Soldier",
        "type": "background",
        "uuid": "Compendium.trg-prime.backgrounds.Item.cQNJ17cm0IOgKMut",
        "validId": true,
        "category": "Background",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "grantedSpecialistSkills"
          ]
        }
      },
      {
        "id": "dqksXRKSz21ZxKBz",
        "name": "Field Medic",
        "type": "background",
        "uuid": "Compendium.trg-prime.backgrounds.Item.dqksXRKSz21ZxKBz",
        "validId": true,
        "category": "Background",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "grantedSpecialistSkills"
          ]
        }
      },
      {
        "id": "e09hR2GNd4uBcbxD",
        "name": "Guard",
        "type": "background",
        "uuid": "Compendium.trg-prime.backgrounds.Item.e09hR2GNd4uBcbxD",
        "validId": true,
        "category": "Background",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "grantedSpecialistSkills"
          ]
        }
      },
      {
        "id": "e5i8qa1iohbawkB8",
        "name": "Criminal",
        "type": "background",
        "uuid": "Compendium.trg-prime.backgrounds.Item.e5i8qa1iohbawkB8",
        "validId": true,
        "category": "Background",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "grantedSpecialistSkills"
          ]
        }
      },
      {
        "id": "f3ZCIclECsDkcwZ6",
        "name": "Scholar",
        "type": "background",
        "uuid": "Compendium.trg-prime.backgrounds.Item.f3ZCIclECsDkcwZ6",
        "validId": true,
        "category": "Background",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "grantedSpecialistSkills",
            "specialistChoice",
            "skillChoice"
          ]
        }
      },
      {
        "id": "h6Ko2zBAt0za8ebL",
        "name": "Gambler",
        "type": "background",
        "uuid": "Compendium.trg-prime.backgrounds.Item.h6Ko2zBAt0za8ebL",
        "validId": true,
        "category": "Background",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "grantedSpecialistSkills"
          ]
        }
      },
      {
        "id": "i5epbuXEq0BHASXZ",
        "name": "Entertainer",
        "type": "background",
        "uuid": "Compendium.trg-prime.backgrounds.Item.i5epbuXEq0BHASXZ",
        "validId": true,
        "category": "Background",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 2,
          "flags": [
            "grantedSpecialistSkills"
          ]
        }
      },
      {
        "id": "jQo7kwecMaEoceEH",
        "name": "Barkeep",
        "type": "background",
        "uuid": "Compendium.trg-prime.backgrounds.Item.jQo7kwecMaEoceEH",
        "validId": true,
        "category": "Background",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "grantedSpecialistSkills"
          ]
        }
      },
      {
        "id": "kHiR0OVTKidGOshr",
        "name": "Acolyte",
        "type": "background",
        "uuid": "Compendium.trg-prime.backgrounds.Item.kHiR0OVTKidGOshr",
        "validId": true,
        "category": "Background",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "grantedSpecialistSkills"
          ]
        }
      },
      {
        "id": "mVvOeZ2L1N7eFwP1",
        "name": "Hermit",
        "type": "background",
        "uuid": "Compendium.trg-prime.backgrounds.Item.mVvOeZ2L1N7eFwP1",
        "validId": true,
        "category": "Background",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "grantedSpecialistSkills",
            "specialistChoice"
          ]
        }
      },
      {
        "id": "nAsUZa5MWmi6JzBz",
        "name": "Barbarian",
        "type": "background",
        "uuid": "Compendium.trg-prime.backgrounds.Item.nAsUZa5MWmi6JzBz",
        "validId": true,
        "category": "Background",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "grantedSpecialistSkills"
          ]
        }
      },
      {
        "id": "nfpFpdLMPLIu3Vbh",
        "name": "Street Urchin",
        "type": "background",
        "uuid": "Compendium.trg-prime.backgrounds.Item.nfpFpdLMPLIu3Vbh",
        "validId": true,
        "category": "Background",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "grantedSpecialistSkills"
          ]
        }
      },
      {
        "id": "oA5AHEFCUSvpAoPK",
        "name": "Lay Healer",
        "type": "background",
        "uuid": "Compendium.trg-prime.backgrounds.Item.oA5AHEFCUSvpAoPK",
        "validId": true,
        "category": "Background",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "grantedSpecialistSkills"
          ]
        }
      },
      {
        "id": "sWZFfljAOwvO8eNC",
        "name": "Squire",
        "type": "background",
        "uuid": "Compendium.trg-prime.backgrounds.Item.sWZFfljAOwvO8eNC",
        "validId": true,
        "category": "Background",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "grantedSpecialistSkills"
          ]
        }
      },
      {
        "id": "uG3HLrkkGvRodosy",
        "name": "Detective",
        "type": "background",
        "uuid": "Compendium.trg-prime.backgrounds.Item.uG3HLrkkGvRodosy",
        "validId": true,
        "category": "Background",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "grantedSpecialistSkills"
          ]
        }
      },
      {
        "id": "v4IQBNbEIZ9N7Jur",
        "name": "Prisoner",
        "type": "background",
        "uuid": "Compendium.trg-prime.backgrounds.Item.v4IQBNbEIZ9N7Jur",
        "validId": true,
        "category": "Background",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "grantedSpecialistSkills"
          ]
        }
      },
      {
        "id": "wPHFQeK89SiHyH4K",
        "name": "Farmhand",
        "type": "background",
        "uuid": "Compendium.trg-prime.backgrounds.Item.wPHFQeK89SiHyH4K",
        "validId": true,
        "category": "Background",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "grantedSpecialistSkills"
          ]
        }
      },
      {
        "id": "y3JNhXE2GmWIef2U",
        "name": "Bounty Hunter",
        "type": "background",
        "uuid": "Compendium.trg-prime.backgrounds.Item.y3JNhXE2GmWIef2U",
        "validId": true,
        "category": "Background",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "grantedSpecialistSkills"
          ]
        }
      },
      {
        "id": "yinfNwHTDjMvXi2q",
        "name": "Martial Artist",
        "type": "background",
        "uuid": "Compendium.trg-prime.backgrounds.Item.yinfNwHTDjMvXi2q",
        "validId": true,
        "category": "Background",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "grantedSpecialistSkills",
            "featQualifier"
          ]
        }
      },
      {
        "id": "zyzB0PuMtV6jFg7H",
        "name": "Herbalist",
        "type": "background",
        "uuid": "Compendium.trg-prime.backgrounds.Item.zyzB0PuMtV6jFg7H",
        "validId": true,
        "category": "Background",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "grantedSpecialistSkills"
          ]
        }
      }
    ],
    "feats": [
      {
        "id": "09du3fc9Gg3LQRBj",
        "name": "Spell Adept",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.09du3fc9Gg3LQRBj",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Non-pure spellcaster, BSB +2",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "0Et8ckco9MdNPzcN",
        "name": "Echoing Performance",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.0Et8ckco9MdNPzcN",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "0IcYx8RXiRGtirPc",
        "name": "Darkened Veil",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.0IcYx8RXiRGtirPc",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "0akP3wkvgYV6cZts",
        "name": "Fire-Like Blood",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.0akP3wkvgYV6cZts",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Azgar heritage or Elarni heritage, Level 10",
        "automation": {
          "effects": 1,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "0d0cfL39ks2NmtBK",
        "name": "Weapon Specialisation",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.0d0cfL39ks2NmtBK",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Weapon Mastery, BAB +8",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "0eb7EzUMmeg3eDua",
        "name": "Variable Success",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.0eb7EzUMmeg3eDua",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "BSB +8",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "0qyTuni6JarJ9FZT",
        "name": "Shadow Sense",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.0qyTuni6JarJ9FZT",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "1Byr7blMxf1ovEwF",
        "name": "Vital Strike",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.1Byr7blMxf1ovEwF",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "BAB +6",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "1Dl4212ZL32YeMEB",
        "name": "Boundless Leaper",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.1Dl4212ZL32YeMEB",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Athletics 5 ranks",
        "automation": {
          "effects": 1,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "1L110GTGjvhnSNZU",
        "name": "Lingering Performance",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.1L110GTGjvhnSNZU",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Perform 4 ranks",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "1iVVNgzGauVUQGBa",
        "name": "Ambush Awareness",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.1iVVNgzGauVUQGBa",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Perception 10 ranks",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "1lKIEDtvBJuh3hwD",
        "name": "Enigma",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.1lKIEDtvBJuh3hwD",
        "validId": true,
        "category": "Archetype",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Pure Learned Caster.",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "1luEKydSEpsHnWFY",
        "name": "Earthbound Might",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.1luEKydSEpsHnWFY",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Level 5",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "1qA13bACM9iOUQ8B",
        "name": "Iron Walker",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.1qA13bACM9iOUQ8B",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "21m69veu7MsWyJDc",
        "name": "Indomitable Resilience",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.21m69veu7MsWyJDc",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Unyielding Tenacity, Level 5",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "25VvhcHXVcMcTEJd",
        "name": "Metamagic Training",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.25VvhcHXVcMcTEJd",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "25cokeg2qP3Me5Bu",
        "name": "Cultural Understanding",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.25cokeg2qP3Me5Bu",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Culture & Linguistics 1 rank",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "29B0TVUimUvV3igJ",
        "name": "Improved Initiative",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.29B0TVUimUvV3igJ",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "2NebeoYjCXEPOFEW",
        "name": "Armour Proficiency, Light",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.2NebeoYjCXEPOFEW",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "2S8b64U0ge9XnNtD",
        "name": "Versatile Channels",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.2S8b64U0ge9XnNtD",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "BSB +8",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "2Sp7d4BMug8X0SOw",
        "name": "Small Folk Rider",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.2Sp7d4BMug8X0SOw",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "2VJG1EIRFBBd1zcH",
        "name": "Familiar",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.2VJG1EIRFBBd1zcH",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "2bxsWu82mkdaOeSR",
        "name": "Weapon Proficient",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.2bxsWu82mkdaOeSR",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "2eoDdbRDumfPkcAR",
        "name": "Escapologist",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.2eoDdbRDumfPkcAR",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Acrobatics 8 ranks",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "3FSxqaZhUrwFVzKy",
        "name": "Point Blank Shot",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.3FSxqaZhUrwFVzKy",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "3MFSdWpkpruCBEaf",
        "name": "More Small Folk Luck",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.3MFSdWpkpruCBEaf",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Luck of the Small Folk",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "3UN5xZCwRiUQj0MO",
        "name": "Voice of the Beast",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.3UN5xZCwRiUQj0MO",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Level 5",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "3UkQ0pA9MmaRKmol",
        "name": "Perfect Flanking",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.3UkQ0pA9MmaRKmol",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Support, Level 14",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "3aWKZrNaWAapiGq0",
        "name": "Superior Juggernaut",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.3aWKZrNaWAapiGq0",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Juggernaut, Athletics 12 ranks",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "3q8NnhD7wB9TfnJj",
        "name": "Unyielding Tenacity",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.3q8NnhD7wB9TfnJj",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "3uXRLRrvCuqGh4lV",
        "name": "Adventurer",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.3uXRLRrvCuqGh4lV",
        "validId": true,
        "category": "Archetype",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "3ynCotaJ5tRRutYf",
        "name": "Shadow Magi",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.3ynCotaJ5tRRutYf",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "44c2xhbp4EIMNy0h",
        "name": "Minor Arcane Caster",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.44c2xhbp4EIMNy0h",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Level 4",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "45G1Ae2QHcHUAZYA",
        "name": "Disrupting Stance",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.45G1Ae2QHcHUAZYA",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "BAB +10",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "4MAKrLk9TJzNo0oh",
        "name": "Widen Spell",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.4MAKrLk9TJzNo0oh",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "4RYy6e1Pn23zeSaD",
        "name": "Fast Aim",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.4RYy6e1Pn23zeSaD",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "4kXMImJhpQQYjg0c",
        "name": "Shield Block",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.4kXMImJhpQQYjg0c",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "4lSDbGaIWF14xKiB",
        "name": "Half-Ogre",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.4lSDbGaIWF14xKiB",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "4qN0aM7KYop9sEPg",
        "name": "Emissary",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.4qN0aM7KYop9sEPg",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "5Az1BMY63Iwy8lDm",
        "name": "Ageless Knowledge",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.5Az1BMY63Iwy8lDm",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "at least 100 years old",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "5JWnlCSeV8YyydA6",
        "name": "Elemental Shape",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.5JWnlCSeV8YyydA6",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Wild Shape, BSB +10",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "5Sii8wdfjOsoq5Hn",
        "name": "Hauler",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.5Sii8wdfjOsoq5Hn",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Athletics 1 rank",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "5p3swhB1Pd5NaiOn",
        "name": "Divine Knight",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.5p3swhB1Pd5NaiOn",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Religion 4 ranks, Wis +3",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "5sFbGKuoD0geolJF",
        "name": "Beastman",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.5sFbGKuoD0geolJF",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Level 1 only",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "5uiSBRGwPA9gj1PV",
        "name": "Physical Might",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.5uiSBRGwPA9gj1PV",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "5xkelgOhkGfeivB5",
        "name": "Underwater Marauder",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.5xkelgOhkGfeivB5",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Athletics skill rank 2",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "5zlLRZXbOfMW9Laz",
        "name": "Professional Specialist",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.5zlLRZXbOfMW9Laz",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "60jIdZPY6ZsDKPkU",
        "name": "Ethereal Trick",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.60jIdZPY6ZsDKPkU",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "6BoEu2rBJ9vJ0d68",
        "name": "Luck of the Small Folk",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.6BoEu2rBJ9vJ0d68",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "6CHRhJLemmGkgSzY",
        "name": "Disarm Stance",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.6CHRhJLemmGkgSzY",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "6DQlGk1J3YkqVhBr",
        "name": "Silver Tongue",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.6DQlGk1J3YkqVhBr",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Deception 5 ranks",
        "automation": {
          "effects": 1,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "6GQ3khbpkZrhb2Gz",
        "name": "Minor Verdant Caster",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.6GQ3khbpkZrhb2Gz",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Level 4",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "6IhW8t28eEbkDkGv",
        "name": "Plant Shape",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.6IhW8t28eEbkDkGv",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Wild Shape, BSB +8",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "6N1XBFXuU6tpA5HS",
        "name": "Gleeman",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.6N1XBFXuU6tpA5HS",
        "validId": true,
        "category": "Archetype",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Perform 2 ranks, Cha +3, Non-Bard",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "6YqN8J5aDFnXFvYf",
        "name": "Medic",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.6YqN8J5aDFnXFvYf",
        "validId": true,
        "category": "Archetype",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Medicine 2 ranks",
        "automation": {
          "effects": 2,
          "flags": []
        }
      },
      {
        "id": "78ZLHWk8C4BcmW5f",
        "name": "Quick Swimmer",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.78ZLHWk8C4BcmW5f",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Athletics 12 ranks",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "7dqtUUPzd872D25V",
        "name": "Priest",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.7dqtUUPzd872D25V",
        "validId": true,
        "category": "Archetype",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Religion 2 ranks, Wis +3, Non-Cleric",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "7h39GRrssIO52hnQ",
        "name": "Great Cleave",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.7h39GRrssIO52hnQ",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Cleave, BAB +10",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "7vnORSVl6tfHebwY",
        "name": "Turn Undead",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.7vnORSVl6tfHebwY",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "8DRSQwauFncEmHwv",
        "name": "Ageless Patience",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.8DRSQwauFncEmHwv",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Level 2",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "8GJQcErvfOnyMTeP",
        "name": "Toughness",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.8GJQcErvfOnyMTeP",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "BAB +4",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "8JTg50tdesRdhcyY",
        "name": "Inspired",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.8JTg50tdesRdhcyY",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "8LlNUPu0cbR9uCGs",
        "name": "Major Ethereal Caster",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.8LlNUPu0cbR9uCGs",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Level 12, Minor Ethereal Caster",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "8nnVIWolIeIgPS1N",
        "name": "Mobile Shot",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.8nnVIWolIeIgPS1N",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "BAB +8",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "8wxqZps8dcKHYeAs",
        "name": "Unusual Magic",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.8wxqZps8dcKHYeAs",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "98iTf9sJSoOGQnXx",
        "name": "Humanoid Shape",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.98iTf9sJSoOGQnXx",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Wild Shape, BSB +4",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "9F79ErfYlICJCXIa",
        "name": "Stormborn",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.9F79ErfYlICJCXIa",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "9H6kmfQ2d5W5BEkD",
        "name": "Surprise Attack",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.9H6kmfQ2d5W5BEkD",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Perception 6 ranks",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "9O5NZoWuOTKmYhH2",
        "name": "Shield Proficiency, Tower",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.9O5NZoWuOTKmYhH2",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "BAB +2, Heavy Shield Proficiency",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "9fF7h03Ly73NyWPc",
        "name": "Selective Spell",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.9fF7h03Ly73NyWPc",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "9iDrlZqjuc0Z4f9p",
        "name": "Warden",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.9iDrlZqjuc0Z4f9p",
        "validId": true,
        "category": "Archetype",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Survival 2 ranks, Dex +3, Non-Ranger",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "9iv5DVrK2eLqvLru",
        "name": "Class Training",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.9iv5DVrK2eLqvLru",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "9utj36L23GBwoVoT",
        "name": "Expert of Aid",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.9utj36L23GBwoVoT",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "9xNTSToq7X2cUIeA",
        "name": "Inner Reserve",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.9xNTSToq7X2cUIeA",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Str +2, Con +2, Mettle, Level 10",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "9zCnxvHB0OFwtkvm",
        "name": "One with the Mountain",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.9zCnxvHB0OFwtkvm",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Stone Wise, Level 5",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "A1jLykENvNC1ehsl",
        "name": "Graceful Step",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.A1jLykENvNC1ehsl",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Level 5",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "A9CeCjB1zhLrteq5",
        "name": "Shield Proficiency, Heavy",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.A9CeCjB1zhLrteq5",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "BAB +1, Light Shield Proficiency",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "AAQWn4mBtJyKeB6J",
        "name": "Animal Voice",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.AAQWn4mBtJyKeB6J",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Burrower Voice, Level 5",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "AKLx9jDdDcWyABhr",
        "name": "Alignment Channel",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.AKLx9jDdDcWyABhr",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "ASoV6cWIXu9MAVlb",
        "name": "Minor Divinity Caster",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.ASoV6cWIXu9MAVlb",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Level 4",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "AfHGvVuKAHTRnu1f",
        "name": "Artificer",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.AfHGvVuKAHTRnu1f",
        "validId": true,
        "category": "Archetype",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Crafting 2 ranks",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "Ao1iJ5aJlRO1PHWg",
        "name": "Blind Fight",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.Ao1iJ5aJlRO1PHWg",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Perception 10 ranks",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "AxLg60OFJYg13tH5",
        "name": "Converse with Master",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.AxLg60OFJYg13tH5",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "AydgmlJ7ZOBiTP6q",
        "name": "Ageless Language",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.AydgmlJ7ZOBiTP6q",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "at least 100 years old, Linguistics 2 ranks",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "B1Y2YpEzrB6Kidwp",
        "name": "Shrouded Demeanour",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.B1Y2YpEzrB6Kidwp",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "BFhEVGcU3JdbRmj7",
        "name": "Dracoris",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.BFhEVGcU3JdbRmj7",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 2,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "BIoPM1EHHBNvpoCY",
        "name": "Magical Crafting",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.BIoPM1EHHBNvpoCY",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Arcana, Nature, Occultism or Religion 2 ranks, BSB +2",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "BNrTAhx0tr8TpG9C",
        "name": "Deadly Training",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.BNrTAhx0tr8TpG9C",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Stealth 8 ranks",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "BPd9lLyYcm67EYOQ",
        "name": "Battle Hardened",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.BPd9lLyYcm67EYOQ",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Toughness I, BAB +10",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "BdetAAuLTED4y5s0",
        "name": "Thief",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.BdetAAuLTED4y5s0",
        "validId": true,
        "category": "Archetype",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Stealth 2 ranks, Dex +3, Non-Rogue",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "BrFg6AqP84A7b3vE",
        "name": "Burrow Voice",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.BrFg6AqP84A7b3vE",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "ByeEmEcxlP77hWy1",
        "name": "Crimson Covenant",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.ByeEmEcxlP77hWy1",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Must have sworn an oath to a demon or sacrificed your own blood for power.",
        "automation": {
          "effects": 0,
          "flags": [
            "conditionals",
            "codexFeat"
          ]
        }
      },
      {
        "id": "C2aGtcfFbeQv7oQh",
        "name": "Linguist",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.C2aGtcfFbeQv7oQh",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Linguistics 5 ranks",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "C5psIz4WaPXIjdv1",
        "name": "Focused Strike",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.C5psIz4WaPXIjdv1",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "CWGV48I7DfZU0xlh",
        "name": "Good Healer",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.CWGV48I7DfZU0xlh",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Medicine 5 ranks",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "CgZn7OQgDMrHm5SF",
        "name": "Mystical Conduit",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.CgZn7OQgDMrHm5SF",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Con +1",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "CiMJr5aAzI8AcGVk",
        "name": "Skilled Artisan",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.CiMJr5aAzI8AcGVk",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Artistry & Crafting 1 rank",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "D4GE9DGw6y8a8Wgb",
        "name": "Elven Scholar",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.D4GE9DGw6y8a8Wgb",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "DSxENflv2A8LyFLj",
        "name": "Weapon Finesse",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.DSxENflv2A8LyFLj",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Dex at least 1 higher than Str",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "DfBzPBUclh43FpMB",
        "name": "Instinctive Defence",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.DfBzPBUclh43FpMB",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Dex +2, Acrobatics 5 ranks",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "DiJ6ykqkjLbyaLlC",
        "name": "Spell Substitution",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.DiJ6ykqkjLbyaLlC",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Meditation 5 ranks, Learned Caster, BSB +5",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "E3gv5Zh5UOcGYIX0",
        "name": "Luck for All",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.E3gv5Zh5UOcGYIX0",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Luck of the Small Folk",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "ECsZQ5wDdWkpQeO0",
        "name": "Sudden Form",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.ECsZQ5wDdWkpQeO0",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Level 10, Hybrid Transformation",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "ELbRwiHyvvNFUdxh",
        "name": "Combat Reflexes, Improved",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.ELbRwiHyvvNFUdxh",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "BAB +10, Dex +2, Combat Reflexes",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "Ebe8WHY7JCGPwIIu",
        "name": "Artistic Expertise",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.Ebe8WHY7JCGPwIIu",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Artistry & Perform 1 rank",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "EcQfDgVVrSAYp41w",
        "name": "Verdant Healing",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.EcQfDgVVrSAYp41w",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "EzUzRSyWtbdF0FIf",
        "name": "Master Verdant Caster",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.EzUzRSyWtbdF0FIf",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Level 18, Major Verdant Caster",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "F1ZtIyxdaQGB1Hil",
        "name": "Critical Resilience, Improved",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.F1ZtIyxdaQGB1Hil",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "BAB +16, Critical Resilience",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "F2QNuyUREsXdCAut",
        "name": "Tough Hide, Supremacy",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.F2QNuyUREsXdCAut",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Level 14",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "F8GnNxxo6xxWM63D",
        "name": "Weapon Mastery",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.F8GnNxxo6xxWM63D",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Weapon Focus, BAB +6",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "FXbAg3e5HIxPfzTQ",
        "name": "Affable",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.FXbAg3e5HIxPfzTQ",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Diplomacy 1 rank",
        "automation": {
          "effects": 1,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "FYQA764aStDnKMYB",
        "name": "Master Tracker",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.FYQA764aStDnKMYB",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "FYUBTloiJggtbGBq",
        "name": "Oddity Assessment",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.FYUBTloiJggtbGBq",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Occultism 1 rank",
        "automation": {
          "effects": 1,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "FhcvFwd1KlBAKFV5",
        "name": "Natural Medicine",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.FhcvFwd1KlBAKFV5",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Survival 1 rank",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "FhlXWpcgm4rBVoXk",
        "name": "Gymnast",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.FhlXWpcgm4rBVoXk",
        "validId": true,
        "category": "Archetype",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Acrobatics 2 ranks, Acrobatics is a class skill",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "Fhoj5F3NagDhzzjj",
        "name": "Natural Defence, Improved",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.Fhoj5F3NagDhzzjj",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Level 8",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "Fx4G55VnRJS4TP7k",
        "name": "Dwarven Scholar",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.Fx4G55VnRJS4TP7k",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "G2Of6UrwdcnedLuG",
        "name": "Constant Guard",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.G2Of6UrwdcnedLuG",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "BAB +12",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "G5B6Czm599VVqa1P",
        "name": "Primal Warrior",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.G5B6Czm599VVqa1P",
        "validId": true,
        "category": "Archetype",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Nature 4 ranks",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "GCTSkuC7NraNfFxO",
        "name": "Furious Focus",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.GCTSkuC7NraNfFxO",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "BAB +8, Power Attack",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "GCvmyBFsUmR8Wcue",
        "name": "Empower Familiar",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.GCvmyBFsUmR8Wcue",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Familiar, Caster Level 2",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "GZy9ZhdYgRG4RdY2",
        "name": "Extra Mercy",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.GZy9ZhdYgRG4RdY2",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "BAB +4",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "GbzgE6kqBgXa99V9",
        "name": "Signature Spell",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.GbzgE6kqBgXa99V9",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "Gr4Sogbg2AjfkPOg",
        "name": "Natural Leader",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.Gr4Sogbg2AjfkPOg",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Diplomacy 1 rank",
        "automation": {
          "effects": 1,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "HBLqsybjvBdg9fmD",
        "name": "Armour Master",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.HBLqsybjvBdg9fmD",
        "validId": true,
        "category": "Archetype",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "BAB +2",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "HGo7vG5hHzOcfZGx",
        "name": "Cleave",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.HGo7vG5hHzOcfZGx",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "BAB +6",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "HNth9hYV7e1BgRM0",
        "name": "Quick Reload",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.HNth9hYV7e1BgRM0",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "BAB +4",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "HoNCLPIQqcavvBdk",
        "name": "Skill Focus",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.HoNCLPIQqcavvBdk",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "1 rank in the skill",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "HvEs9xEaZ8pJolCK",
        "name": "Bardic Lore",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.HvEs9xEaZ8pJolCK",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "HzURKEfexfCRNE5g",
        "name": "Adoptive Race",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.HzURKEfexfCRNE5g",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "I1d1ZDYJ9RrfZ6VJ",
        "name": "Superior Evasion",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.I1d1ZDYJ9RrfZ6VJ",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Evasion, Acrobatics 12 ranks",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "I7xkuRIvTpuyJzXX",
        "name": "Healing Channel",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.I7xkuRIvTpuyJzXX",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "IH5dSC7O2P91uyhH",
        "name": "Tough Hide, Improved",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.IH5dSC7O2P91uyhH",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Level 6",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "IHAvDU6kvc2j4dxk",
        "name": "Shield Focus",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.IHAvDU6kvc2j4dxk",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "IJ1Tuo39QkzbikMB",
        "name": "Temporal Extension",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.IJ1Tuo39QkzbikMB",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "IdlFBe3DBD6RQbGh",
        "name": "Double Shot",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.IdlFBe3DBD6RQbGh",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "BAB +4",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "IkUSlvELFRuT93NK",
        "name": "Juggernaut",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.IkUSlvELFRuT93NK",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Athletics 6 ranks",
        "automation": {
          "effects": 1,
          "flags": [
            "saveReaction"
          ]
        }
      },
      {
        "id": "JBQT9FfOmOEdeDIL",
        "name": "Bestial Resilience",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.JBQT9FfOmOEdeDIL",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Level 5, Con +2",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "JP9CWolVsqu3HwH8",
        "name": "Vanguard",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.JP9CWolVsqu3HwH8",
        "validId": true,
        "category": "Archetype",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "BAB +2",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "JdyxE55zi8I8dapq",
        "name": "Precise Shot",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.JdyxE55zi8I8dapq",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Point Blank Shot",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "JesUMNLV43LbmsDF",
        "name": "Extra Wildshape",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.JesUMNLV43LbmsDF",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "BSB +8",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "JfqDvLPmDGReiVJ9",
        "name": "Visions",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.JfqDvLPmDGReiVJ9",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Meditation & Sense Motive 2 ranks, BSB +4",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "Jhh3zbRGzetY6zha",
        "name": "Canny Smuggler",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.Jhh3zbRGzetY6zha",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Stealth 5 ranks, Underworld",
        "automation": {
          "effects": 1,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "JnjZRa9G3TRyBlxZ",
        "name": "Wyrm Shape",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.JnjZRa9G3TRyBlxZ",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Wild Shape, BSB +12",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "K2eHdSHnjJDRrvmj",
        "name": "Ogre Lore",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.K2eHdSHnjJDRrvmj",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "KCjOaS9TW1NyQzHL",
        "name": "Distracting Strike",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.KCjOaS9TW1NyQzHL",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "KD5aZGS1d8Smc812",
        "name": "Noble Warrior",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.KD5aZGS1d8Smc812",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Occultism 4 ranks, Cha +3",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "KGR8RvfB68McYzgX",
        "name": "Wings of the Wyrm",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.KGR8RvfB68McYzgX",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Level 10, Dracoris",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "KqNdONJ3eAAAt8ke",
        "name": "Shadow Manipulation",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.KqNdONJ3eAAAt8ke",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Level 5",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "KuygHRsDJQC60nvH",
        "name": "Sense Power",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.KuygHRsDJQC60nvH",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Arcane or Ethereal Spell Caster, Sense Motive 10 ranks",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "LGH9jMOUZ0CYtbe0",
        "name": "Duelling Dance",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.LGH9jMOUZ0CYtbe0",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Duelling Parry, BAB +10",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "LIsDk8vM0B4bivHh",
        "name": "Brew Potion",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.LIsDk8vM0B4bivHh",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Arcana, Nature, Occultism or Religion 1 rank",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "LM83wXcrqaY1aPzy",
        "name": "Big Menacing Fella (or Lass)",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.LM83wXcrqaY1aPzy",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "LPGNx8AJGXNarevi",
        "name": "Effortless Spell",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.LPGNx8AJGXNarevi",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "LQHgRccNsPSS1N3W",
        "name": "Animal Sense",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.LQHgRccNsPSS1N3W",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "LZI1VyRPoObkdCDG",
        "name": "Iron Will",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.LZI1VyRPoObkdCDG",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "LcH5Op0FKhpUnpB4",
        "name": "Support",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.LcH5Op0FKhpUnpB4",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "LcsTwYK6LFVLB8Cj",
        "name": "Major Verdant Caster",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.LcsTwYK6LFVLB8Cj",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Level 12, Minor Verdant Caster",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "LiUpNp6yEZ4BwpCZ",
        "name": "Trackless Step",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.LiUpNp6yEZ4BwpCZ",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Survival 5 ranks",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "LzhGDHZ4qKUMaTcm",
        "name": "Aegis",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.LzhGDHZ4qKUMaTcm",
        "validId": true,
        "category": "Archetype",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Shield Block, BAB +2",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "M1bjsqycSxe2qPWF",
        "name": "Master Divinity Caster",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.M1bjsqycSxe2qPWF",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Level 18, Major Divinity Caster",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "M6xvlTCe0kOYcUOr",
        "name": "Natural Defence",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.M6xvlTCe0kOYcUOr",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "M9SvwrqyX3NSGncr",
        "name": "Schooled in Secrets",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.M9SvwrqyX3NSGncr",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Religion 1 rank",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "MGNJpwenfgNzhqTB",
        "name": "Lightning Reflexes",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.MGNJpwenfgNzhqTB",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "MGgJAoqyPfSQ6c7G",
        "name": "Half-Elf",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.MGgJAoqyPfSQ6c7G",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "Mo29KnvOutrd3LwT",
        "name": "Fearsome Glare",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.Mo29KnvOutrd3LwT",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Intimidate 2 ranks",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "MoBiNlQnMBKoAekP",
        "name": "Silent Spell",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.MoBiNlQnMBKoAekP",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "MoWGLLWdoQ7d7FNL",
        "name": "Chance of Redemption",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.MoWGLLWdoQ7d7FNL",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Religion 6 ranks",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "Msr6GiqNssN5qHbx",
        "name": "Faithful Insight",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.Msr6GiqNssN5qHbx",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Meditation & Religion 1 rank",
        "automation": {
          "effects": 1,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "MyPya1dhiGjAlFpc",
        "name": "Ambitious",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.MyPya1dhiGjAlFpc",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "N1sRUhPa1mOegKps",
        "name": "Component Savant",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.N1sRUhPa1mOegKps",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Level 5",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "NOHleJi7U9AjMad9",
        "name": "Wild Stride",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.NOHleJi7U9AjMad9",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "ignoresDifficultTerrain"
          ]
        }
      },
      {
        "id": "NXmtLxcvj47iWvqg",
        "name": "Major Divinity Caster",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.NXmtLxcvj47iWvqg",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Level 12, Minor Divinity Caster",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "Naan9e9ef6PeJwB9",
        "name": "Improved Reposition",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.Naan9e9ef6PeJwB9",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "O7gtArVah9AWrPP9",
        "name": "Void Step",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.O7gtArVah9AWrPP9",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Stealth 12 ranks, Mobility",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "OB56yMXbY7Z90UU5",
        "name": "Incredibly Invested",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.OB56yMXbY7Z90UU5",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Cha +2",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "OCNVCtcAuecLq3aW",
        "name": "Smite Good",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.OCNVCtcAuecLq3aW",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Divine Ally (Blade Ally)",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "OL6VSuW1KKORoH4b",
        "name": "Loremaster",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.OL6VSuW1KKORoH4b",
        "validId": true,
        "category": "Archetype",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "A total of 10 ranks in Arcana, Culture, Linguistics, Nature, Occultism, Planes or Religion",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "OX6KqvjTjLFsClYr",
        "name": "Incredible Tenacity",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.OX6KqvjTjLFsClYr",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Unyielding Tenacity",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "OaReY9wwbJS2siBi",
        "name": "Scribe Scroll",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.OaReY9wwbJS2siBi",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Arcana, Nature, Occultism or Religion 1 rank, BSB +1",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "Ol1ke4ZPcdQvbqSi",
        "name": "Artistic Specialist",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.Ol1ke4ZPcdQvbqSi",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Artistry 5 ranks",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "Opn5YdFAyUkJxr30",
        "name": "Spell Recognition",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.Opn5YdFAyUkJxr30",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Arcana, Nature, Occultism or Religion 1 rank",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "OsBzwchm6tfERaW5",
        "name": "Accomplished Artisan",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.OsBzwchm6tfERaW5",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Any one crafting specialist skill.",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "OxnQTKey4VxbXPIf",
        "name": "Mastermind",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.OxnQTKey4VxbXPIf",
        "validId": true,
        "category": "Archetype",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Either Arcana, Crafting, Culture, Nature, Occultism, Planes or Religion 2 ranks",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "P6Tg8SSGKVjdPJDP",
        "name": "Group Coercion",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.P6Tg8SSGKVjdPJDP",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Intimidate 1 rank",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "PCF4whnQptKvnObk",
        "name": "Critical Resilience",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.PCF4whnQptKvnObk",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "BAB +8",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "PIufhmiL3WguXREf",
        "name": "Kornargon Scholar",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.PIufhmiL3WguXREf",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "PObm6uEpPoZqPrh1",
        "name": "Sure Footed",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.PObm6uEpPoZqPrh1",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "POmaghap8N7j2Ife",
        "name": "Shadowy Guise",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.POmaghap8N7j2Ife",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Level 5",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "PPfsxFE8TdZidEcO",
        "name": "Inventive Crafter",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.PPfsxFE8TdZidEcO",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "5 or more ranks in any skill that has both the create and research actions.",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "PYWFJe7q0BGNH7Tf",
        "name": "Reach Spell",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.PYWFJe7q0BGNH7Tf",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "PniQ0JZJ9wXwVUCj",
        "name": "Tough Hide, Master",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.PniQ0JZJ9wXwVUCj",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Level 10",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "PzytTI418zp5qwPy",
        "name": "Furry Friend",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.PzytTI418zp5qwPy",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "Q3mUKShaids9BIML",
        "name": "Innate Courage",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.Q3mUKShaids9BIML",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "QI8ZpEAOdSqULWUt",
        "name": "Savage Strikes",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.QI8ZpEAOdSqULWUt",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Level 5",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "QgdZnRRtnd6N8tcb",
        "name": "Deific Disruption",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.QgdZnRRtnd6N8tcb",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Caster Level 10",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "QkgnFs4C6HybACbA",
        "name": "Disarm Block",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.QkgnFs4C6HybACbA",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "BAB +4",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "QzN3f6d9ROnfWZJc",
        "name": "Animal Insight",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.QzN3f6d9ROnfWZJc",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Handle Animal 4 ranks, Animal Affinity",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "RgWv8LObJ9AH7jZo",
        "name": "Weapon Focus",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.RgWv8LObJ9AH7jZo",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "BAB +1",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "RrOE1pR5bOjO7NSI",
        "name": "Experienced Tracker",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.RrOE1pR5bOjO7NSI",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Survival 1 rank",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "S9ylxeOhVlUvQcyl",
        "name": "Altered Cantrip",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.S9ylxeOhVlUvQcyl",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "BSB +1",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "SG9f19VQtSPnM3AO",
        "name": "Heighten Spell",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.SG9f19VQtSPnM3AO",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "SWs1P9pazNy9OOJK",
        "name": "Use Magic Device",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.SWs1P9pazNy9OOJK",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "Sg5dk78NaYH3qZWH",
        "name": "Allied Strike",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.Sg5dk78NaYH3qZWH",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Diplomacy 5 ranks, Weapon Focus",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "SpNSZfwibaBu1ppY",
        "name": "Empower Spell",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.SpNSZfwibaBu1ppY",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "Szqb9vstYxgJE2TK",
        "name": "Sure Feet",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.Szqb9vstYxgJE2TK",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Acrobatics 1 rank",
        "automation": {
          "effects": 1,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "TH7bAOLvgEDFKeXc",
        "name": "Combat Grapple",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.TH7bAOLvgEDFKeXc",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "BAB +2",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "TIwOD6bW6rY86zdJ",
        "name": "Skirmish",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.TIwOD6bW6rY86zdJ",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "BAB +4",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "TLcNLBKYwcNHszJc",
        "name": "Animal Affinity",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.TLcNLBKYwcNHszJc",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Handle Animal & Nature 1 rank",
        "automation": {
          "effects": 1,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "TMzyK1VRGRYp1K3g",
        "name": "Skitter",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.TMzyK1VRGRYp1K3g",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Dex +3, Fleet Footed",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "TNSdCb61BvPgleDn",
        "name": "Mountain Strider",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.TNSdCb61BvPgleDn",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "TNijdDNKVRElm7cc",
        "name": "Ascendan Scholar",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.TNijdDNKVRElm7cc",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "TPihVrqVMc9FKyOK",
        "name": "Daring Fortune",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.TPihVrqVMc9FKyOK",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Halfling Luck",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "TshsVGiifgHvOfRV",
        "name": "Survey Wildlife",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.TshsVGiifgHvOfRV",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Nature & Survival 2 ranks",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "U2GhJbO0tXIuf8qp",
        "name": "Half-Orc",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.U2GhJbO0tXIuf8qp",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "UMMiluVpqOrBdrEc",
        "name": "Arcane Knight",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.UMMiluVpqOrBdrEc",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Arcana 4 ranks, Int +3",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "UU2bj2Sdf62ylyWM",
        "name": "Quick Recovery",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.UU2bj2Sdf62ylyWM",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Con +2",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "UXumIoUuyZ3LDbFH",
        "name": "Duelling Riposte",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.UXumIoUuyZ3LDbFH",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Duelling Parry, BAB +6",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "Uj25KYbBEEvAIueu",
        "name": "Accurate Spell",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.Uj25KYbBEEvAIueu",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "UtBhcnsXRVv465Bm",
        "name": "Combat Defence",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.UtBhcnsXRVv465Bm",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Int +1",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "VGKMHrPbtYCFyp67",
        "name": "Unusual Weaponry",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.VGKMHrPbtYCFyp67",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "VIU4NRY0Aj2ec6Lt",
        "name": "Stone-Like Endurance",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.VIU4NRY0Aj2ec6Lt",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Level 5",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "VRdWASbaXotdUf2U",
        "name": "Seasoned",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.VRdWASbaXotdUf2U",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Crafting 1 rank, Cooking Specialty",
        "automation": {
          "effects": 1,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "VZw3o5i4AXByS6Fg",
        "name": "Radiant Blade",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.VZw3o5i4AXByS6Fg",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Divine Ally (Blade Ally), BAB +10",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "VaHfaVuktNucGTJz",
        "name": "Aiding Archery",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.VaHfaVuktNucGTJz",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "Vnp4zFDuXSgwjNs7",
        "name": "Mettle",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.Vnp4zFDuXSgwjNs7",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Con +2",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "VqB8CLLPBrV5q8af",
        "name": "Polyglot Savant",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.VqB8CLLPBrV5q8af",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "W6cfBXNeDjlDpJuA",
        "name": "Animal Magic",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.W6cfBXNeDjlDpJuA",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Level 5",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "WSTemS7p3OpMM5Vi",
        "name": "Reactive Stance",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.WSTemS7p3OpMM5Vi",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "BAB +10",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "WSk8EG448KgsR2Iw",
        "name": "Fast Attack",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.WSk8EG448KgsR2Iw",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "BAB +10",
        "automation": {
          "effects": 2,
          "flags": []
        }
      },
      {
        "id": "WZlAMIMkPL2t8iIJ",
        "name": "Impressive Performance",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.WZlAMIMkPL2t8iIJ",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Perform 1 rank",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "We2Fx60i7QNkW6Uu",
        "name": "Bravery",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.We2Fx60i7QNkW6Uu",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "WkebT7BdT4Dem3Nn",
        "name": "Injury Relief",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.WkebT7BdT4Dem3Nn",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "BSB +2",
        "automation": {
          "effects": 1,
          "flags": [
            "grantInnate"
          ]
        }
      },
      {
        "id": "Wv6jNKrd7FM1MKPn",
        "name": "Exceptional Training",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.Wv6jNKrd7FM1MKPn",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "X1haqE1HVvIkTWbK",
        "name": "Extend Spell",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.X1haqE1HVvIkTWbK",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "X89ERqE6eDit5i7Y",
        "name": "Evasion",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.X89ERqE6eDit5i7Y",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Acrobatics 6 ranks",
        "automation": {
          "effects": 1,
          "flags": [
            "saveReaction"
          ]
        }
      },
      {
        "id": "XIHTK7azHDWMwzsC",
        "name": "Primal Defender",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.XIHTK7azHDWMwzsC",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Nature 4 ranks, Con +3",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "XzfKfocJ9P6f9Ayk",
        "name": "Mercy of Relief",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.XzfKfocJ9P6f9Ayk",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "BAB +5",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "Y6HFQSm4KeShKanf",
        "name": "Lunge",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.Y6HFQSm4KeShKanf",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "BAB +2",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "YABiE9CMW71TbZOz",
        "name": "Striding Charge",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.YABiE9CMW71TbZOz",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Athletics 5 ranks",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "YIq0lqyG14JF56zn",
        "name": "Far Shot",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.YIq0lqyG14JF56zn",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "BAB +4",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "YTxj2HTKyKbhR1wP",
        "name": "Increase Size",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.YTxj2HTKyKbhR1wP",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Level 5",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "YXcBvxPZXFvVj8RG",
        "name": "Master of Aid",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.YXcBvxPZXFvVj8RG",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Expert of Aid, Level 10",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "YYxmrhKEV5Q6r9Jk",
        "name": "Read the Room",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.YYxmrhKEV5Q6r9Jk",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 2,
          "flags": []
        }
      },
      {
        "id": "Z1JUyttaoxEazpF8",
        "name": "Masterful Crafter",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.Z1JUyttaoxEazpF8",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Crafting 10 ranks, Specialist Crafter",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "Z8SDRs62vEqIvdLO",
        "name": "Reverse Strike",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.Z8SDRs62vEqIvdLO",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "BAB +4",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "Zcl9AxDsMaCfAMwi",
        "name": "Throw Anything",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.Zcl9AxDsMaCfAMwi",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "ZjMbwQu8XUKGaGTk",
        "name": "Physician",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.ZjMbwQu8XUKGaGTk",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Medicine 1 rank, BSB +1",
        "automation": {
          "effects": 2,
          "flags": []
        }
      },
      {
        "id": "ZoeGQ2F9LfUeoKPo",
        "name": "Spontaneous Scholar",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.ZoeGQ2F9LfUeoKPo",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Learned Caster, BSB +2, Int +2",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "a3VsaG4zdGj30Pn0",
        "name": "Shielded Stride",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.a3VsaG4zdGj30Pn0",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Shield Block, BAB +4",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "aSGGpxeCiCBIcpS9",
        "name": "Theologian",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.aSGGpxeCiCBIcpS9",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Religion 1 rank",
        "automation": {
          "effects": 1,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "aSMdjh3qdmeLxOXL",
        "name": "Physical Training",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.aSMdjh3qdmeLxOXL",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Athletics 1 rank",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "aj1ZslLZp4k4I5Lq",
        "name": "Charismatic Caster",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.aj1ZslLZp4k4I5Lq",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Cha +2, Level 1 only",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "avafjRZ3PyIdTYlV",
        "name": "Perform Specialist",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.avafjRZ3PyIdTYlV",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Perform 5 ranks",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "b5UdWjGffYzA4fpQ",
        "name": "Monster Lore",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.b5UdWjGffYzA4fpQ",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "b8PMUdp7kcurrYgP",
        "name": "Armour Focus",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.b8PMUdp7kcurrYgP",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "BAB +1, Armour Proficiency",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "bFlqgOFRT9dPWgFS",
        "name": "Deft Hands",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.bFlqgOFRT9dPWgFS",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Thievery 5 ranks",
        "automation": {
          "effects": 1,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "bG69WX35BF5V61WY",
        "name": "Preying Companion",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.bG69WX35BF5V61WY",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Companions master is a Ranger",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "bLi0bn1zbqj4tX71",
        "name": "Tough Hide",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.bLi0bn1zbqj4tX71",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "bO2T0Fe9zWjdByw9",
        "name": "Duelling Parry",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.bO2T0Fe9zWjdByw9",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "BAB +2",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "bPGOPcc8WBgJyRej",
        "name": "Master Arcane Caster",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.bPGOPcc8WBgJyRej",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Level 18, Major Arcane Caster",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "bUpBpuBI9ve42jGg",
        "name": "Armour Proficiency, Heavy",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.bUpBpuBI9ve42jGg",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Armour Proficiency, Medium",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "ba45s0uSvHcUPKrk",
        "name": "Aura of Power",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.ba45s0uSvHcUPKrk",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "bpeVvex1RW4Ukhiq",
        "name": "Orc Scholar",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.bpeVvex1RW4Ukhiq",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "bs6R3NYU7jDaMZyo",
        "name": "Lorist",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.bs6R3NYU7jDaMZyo",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Arcana 5 ranks",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "c0UHmf2cEgKM3hs2",
        "name": "Embrace of Mortality",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.c0UHmf2cEgKM3hs2",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Level 10",
        "automation": {
          "effects": 1,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "cN4Fm3eOIjKdCl8W",
        "name": "Earth Sense",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.cN4Fm3eOIjKdCl8W",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Level 5",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "ccQ2oFlRLo7RwjPl",
        "name": "Combat Casting",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.ccQ2oFlRLo7RwjPl",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "BSB +2",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "ccd6JS7eIeWN9gnp",
        "name": "Howling Kinship",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.ccd6JS7eIeWN9gnp",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Animal Companion, BAB +4",
        "automation": {
          "effects": 0,
          "flags": [
            "conditionals",
            "codexFeat"
          ]
        }
      },
      {
        "id": "cf5Zupa9tDh1yOsC",
        "name": "Natural Casting",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.cf5Zupa9tDh1yOsC",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Wild Shape, BSB +4",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "cpaL3UMsEIah3ufj",
        "name": "Twin Riposte",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.cpaL3UMsEIah3ufj",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Double Stance, BAB +8",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "d47RmOmhsYVtChqJ",
        "name": "Battle Cry",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.d47RmOmhsYVtChqJ",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Intimidate 5 ranks",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "dQe02Yp5Ikk0SjzC",
        "name": "Hybrid Transformation",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.dQe02Yp5Ikk0SjzC",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "dZVO5wb4vOO6ToLp",
        "name": "Smite Evil",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.dZVO5wb4vOO6ToLp",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Divine Ally (Blade Ally)",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "dbJVacTYrqANoSy6",
        "name": "Ascendan Magic",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.dbJVacTYrqANoSy6",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "ddPXD4ZzQWBPsHmb",
        "name": "Diehard",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.ddPXD4ZzQWBPsHmb",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Con +2",
        "automation": {
          "effects": 2,
          "flags": []
        }
      },
      {
        "id": "dlKzNQN2C8qYvyto",
        "name": "Arctic Elf",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.dlKzNQN2C8qYvyto",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Level 10, Tolderni heritage",
        "automation": {
          "effects": 1,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "dxGG6clshyUpOlYe",
        "name": "Versatile Familiar",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.dxGG6clshyUpOlYe",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Empower Familiar, Familiar, BSB +8",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "eDdRj0ZxwdmD8TJn",
        "name": "Natural Defence, Master",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.eDdRj0ZxwdmD8TJn",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Level 12",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "eTeAmVEBL9XkSLd4",
        "name": "Animal Companion",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.eTeAmVEBL9XkSLd4",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "BSB +2",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "ecNkyQkCrIoozUlh",
        "name": "Distant Spell",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.ecNkyQkCrIoozUlh",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "eeVYmTVfPQlscag1",
        "name": "Self Aware",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.eeVYmTVfPQlscag1",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "epUgNPdW4LEUpdVG",
        "name": "Lunging Stance",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.epUgNPdW4LEUpdVG",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "BAB +6, Lunge",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "eqtobUnUIkrrviFD",
        "name": "Intuitive Healer",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.eqtobUnUIkrrviFD",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Medicine & Sense Motive 1 rank",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "fBonXYydEGRXnkhu",
        "name": "Mental Fortress",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.fBonXYydEGRXnkhu",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Mental Focus 5 ranks",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "fBsmxqbsHDEfVUG4",
        "name": "Strike of Retribution",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.fBsmxqbsHDEfVUG4",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Religion 6 ranks",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "fDFruyRHpL6VifOi",
        "name": "Arcane Insight",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.fDFruyRHpL6VifOi",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Arcana & Power Manipulation 1 rank",
        "automation": {
          "effects": 1,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "fTHSpoM78Qg57qBR",
        "name": "Elemental Spell",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.fTHSpoM78Qg57qBR",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "fUtuD9CkWrnWbX2W",
        "name": "Resolve",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.fUtuD9CkWrnWbX2W",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Mental Focus 6 ranks",
        "automation": {
          "effects": 1,
          "flags": [
            "saveReaction"
          ]
        }
      },
      {
        "id": "fVwz2bqmZomHLeZB",
        "name": "Archer",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.fVwz2bqmZomHLeZB",
        "validId": true,
        "category": "Archetype",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "BAB +2, proficient with a bow weapon",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "fW9xqZoY9P2hd5Ay",
        "name": "Assassin",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.fW9xqZoY9P2hd5Ay",
        "validId": true,
        "category": "Archetype",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Perception 4 ranks, Stealth 4 ranks, Dex +3",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "fWRiFgGgsENTJZ2X",
        "name": "Runemage",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.fWRiFgGgsENTJZ2X",
        "validId": true,
        "category": "Archetype",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Linguistics 2 ranks",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "fXCSxf62Bv8EGIO5",
        "name": "Canny Cutpurse",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.fXCSxf62Bv8EGIO5",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Thievery 5 ranks",
        "automation": {
          "effects": 1,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "fmT7Yhu5GvR6UKyP",
        "name": "Enhanced Vision",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.fmT7Yhu5GvR6UKyP",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Any special visual sense (Darkvision, Nightvision etc)",
        "automation": {
          "effects": 0,
          "flags": [
            "conditionals",
            "codexFeat"
          ]
        }
      },
      {
        "id": "ftYzkffsnwmGq5an",
        "name": "Mount",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.ftYzkffsnwmGq5an",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "fxSKJeYDEdEX9afs",
        "name": "Acrobatic Bluff",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.fxSKJeYDEdEX9afs",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "g9I1lARECXW35h5l",
        "name": "Resilience of Stone",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.g9I1lARECXW35h5l",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Level 10",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "gBhJi7r6A5Pf6uy4",
        "name": "Necrotic Resilience",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.gBhJi7r6A5Pf6uy4",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Thengar heritage, Level 10",
        "automation": {
          "effects": 1,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "gPJssthwYTRhxV3a",
        "name": "Second Ally",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.gPJssthwYTRhxV3a",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Divine Ally, BAB +8",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "gQyyyen8K4Q4dqNh",
        "name": "Temporal Grasp",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.gQyyyen8K4Q4dqNh",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Level 5",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "gRx75pxZhbaqU1ku",
        "name": "General Versatility",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.gRx75pxZhbaqU1ku",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "gahYGo12zkRGtgOq",
        "name": "Halfling Scholar",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.gahYGo12zkRGtgOq",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "gd15RYsYIERv7Fkk",
        "name": "Armoured Counter",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.gd15RYsYIERv7Fkk",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Survival 8 ranks, you are wearing medium or heavy armour.",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "gkysVwB7zIZisecx",
        "name": "Specialist Crafter",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.gkysVwB7zIZisecx",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Crafting 2 ranks",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "gtdMroFkdFk6thjg",
        "name": "Mobility",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.gtdMroFkdFk6thjg",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Acrobatics 2 ranks",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "hBMk7XkGpZH0MLQP",
        "name": "Eloquence",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.hBMk7XkGpZH0MLQP",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "hEcyQom9JiJ1YVhr",
        "name": "Animal Ability",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.hEcyQom9JiJ1YVhr",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "hF9SSSeQMwbwEGkK",
        "name": "Champion",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.hF9SSSeQMwbwEGkK",
        "validId": true,
        "category": "Archetype",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Religion skill 2 ranks, Wis +3, Non-Crusader",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "hQTdZzHKJWOf3wsM",
        "name": "Transcend Armour",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.hQTdZzHKJWOf3wsM",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "hScvWGr8WkEUA9cq",
        "name": "Far Throw",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.hScvWGr8WkEUA9cq",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "hSkzefzAED0hA1Sx",
        "name": "Innate Teamwork",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.hSkzefzAED0hA1Sx",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "hjdp06QQssBmPSZP",
        "name": "Dramatic Luck",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.hjdp06QQssBmPSZP",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "hszGXud8UhSMSzcg",
        "name": "Intensified Spell",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.hszGXud8UhSMSzcg",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "iCSe7mZ1M9ByHOdE",
        "name": "Battle Medic",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.iCSe7mZ1M9ByHOdE",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Medicine 2 ranks",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "iIccUz9ipSPoXtoE",
        "name": "Agile Tumbler",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.iIccUz9ipSPoXtoE",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Acrobatics 8 ranks",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "iRPqdHMssDtKLLeB",
        "name": "Planar Insight",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.iRPqdHMssDtKLLeB",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Planes 1 rank",
        "automation": {
          "effects": 1,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "iUtrrsmab3NufEqF",
        "name": "Trampler",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.iUtrrsmab3NufEqF",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Large size or greater",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "iVZixxwBzM6jH0JS",
        "name": "Great Fortitude",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.iVZixxwBzM6jH0JS",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "ie5s1EXXp2OaRs0z",
        "name": "Warrior",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.ie5s1EXXp2OaRs0z",
        "validId": true,
        "category": "Archetype",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Athletics 2 ranks, Str +2, Dex +2, Non-Fighter",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "iiQTTtNpd3rn2ROj",
        "name": "Occult Insight",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.iiQTTtNpd3rn2ROj",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Occultism & Mental Focus 1 rank",
        "automation": {
          "effects": 1,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "imEvas7ed4Z6hdbU",
        "name": "Aligned Spell",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.imEvas7ed4Z6hdbU",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "jBXndSmb59RyBuMY",
        "name": "Swift Stride",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.jBXndSmb59RyBuMY",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "jCjf8pQy3F6obrex",
        "name": "Shadowing",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.jCjf8pQy3F6obrex",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "BAB +4",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "jRhzkQW7xS3QN4pN",
        "name": "Cloistered Priest",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.jRhzkQW7xS3QN4pN",
        "validId": true,
        "category": "Archetype",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "jXqK1Tz8ltiOSDIL",
        "name": "Elven Magic, Greater",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.jXqK1Tz8ltiOSDIL",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Level 5",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "jbOhB0O2WKJPhkix",
        "name": "Beyond Reach",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.jbOhB0O2WKJPhkix",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Acrobatics 10 ranks",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "jgReZktSky1kSYQT",
        "name": "Alertness",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.jgReZktSky1kSYQT",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Perception 10 ranks",
        "automation": {
          "effects": 1,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "jghZcgO1mgrbMWoH",
        "name": "Nimble Dodge",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.jghZcgO1mgrbMWoH",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "jmSpLqKTp6fF9rii",
        "name": "Ferocious Charge",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.jmSpLqKTp6fF9rii",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Level 5, Str +2",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "js3T9LteyvV9hmuF",
        "name": "Pack Instinct",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.js3T9LteyvV9hmuF",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "jyq4MYGUcyXd19iq",
        "name": "Animist",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.jyq4MYGUcyXd19iq",
        "validId": true,
        "category": "Archetype",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Nature 2 ranks, Con +3, Non-Druid",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "k9lgdb5eKWfBgwHa",
        "name": "Cultural",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.k9lgdb5eKWfBgwHa",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "kebvIvtlTsGi5H5k",
        "name": "Self Preservation",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.kebvIvtlTsGi5H5k",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Religion 6 ranks",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "koD5jBhSLWLwri5T",
        "name": "Power Attack",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.koD5jBhSLWLwri5T",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "BAB +6, Str +3",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "kr9wpVbTXD8OcEFM",
        "name": "Quick Draw",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.kr9wpVbTXD8OcEFM",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "BAB +2",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "kziYgB1ex39iupsN",
        "name": "Twin Parry",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.kziYgB1ex39iupsN",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "BAB +4",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "l4cumFLUfYnZ2CEL",
        "name": "Wheeler Dealer",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.l4cumFLUfYnZ2CEL",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Diplomacy skill rank 1",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "lKzdfPGZX02TNL0r",
        "name": "Swipe",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.lKzdfPGZX02TNL0r",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "BAB +4",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "lP7O3TGG3ASxpFKD",
        "name": "Hulking Form",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.lP7O3TGG3ASxpFKD",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Level 10",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "lTeMP3ZrZUZsekER",
        "name": "Ferocious Shape",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.lTeMP3ZrZUZsekER",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Wild Shape, BSB +6",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "lUBQguFzbd4N8Rbe",
        "name": "Defensive Roll, Improved",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.lUBQguFzbd4N8Rbe",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Level 12",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "lZm4xnBd1pJEwhit",
        "name": "Gymnastic Training",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.lZm4xnBd1pJEwhit",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Acrobatics 1 rank",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "la5QYPWDvgLHXkB6",
        "name": "Conductive Healing",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.la5QYPWDvgLHXkB6",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "laaOVLtWrHEWaO13",
        "name": "Elevated Lineage",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.laaOVLtWrHEWaO13",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "leLkwB3aIZmmEykN",
        "name": "Imposing Will",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.leLkwB3aIZmmEykN",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Cha +2",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "ltnmUOxdbokgKws0",
        "name": "Counter Spell",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.ltnmUOxdbokgKws0",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Spell Recognition, BSB +4",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "lv81VaJg34JSbK9v",
        "name": "Cavalier",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.lv81VaJg34JSbK9v",
        "validId": true,
        "category": "Archetype",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Culture 2 ranks, Handle Animal 2 ranks",
        "automation": {
          "effects": 2,
          "flags": []
        }
      },
      {
        "id": "lwJLY38vek5QL8eM",
        "name": "Elven Spirit",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.lwJLY38vek5QL8eM",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "lwaBwGVUVNVVG5mp",
        "name": "Honed Reflexes",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.lwaBwGVUVNVVG5mp",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "BAB +10",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "m1loT4zLrezTyiqe",
        "name": "Economic Spell",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.m1loT4zLrezTyiqe",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "m2x0EZI1eMBkIewc",
        "name": "Moment of Clarity",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.m2x0EZI1eMBkIewc",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Mental Focus 5 ranks, Frenzy",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "mSuXn6dJeNr1YBKj",
        "name": "Shadowborn Agility",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.mSuXn6dJeNr1YBKj",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Level 5",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "mX5YDAWOTk7dBt8J",
        "name": "Enhanced Hearing",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.mX5YDAWOTk7dBt8J",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Any special auditory sense (Echolocation etc)",
        "automation": {
          "effects": 0,
          "flags": [
            "conditionals",
            "codexFeat"
          ]
        }
      },
      {
        "id": "mZnKE8wSnyGewgDV",
        "name": "Improved Critical",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.mZnKE8wSnyGewgDV",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "BAB +8, Weapon Focus",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "mdGOyzOjkZngN3QU",
        "name": "Master Ethereal Caster",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.mdGOyzOjkZngN3QU",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Level 18, Major Ethereal Caster",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "meibaX5gH3J9ORNt",
        "name": "Questionable Source",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.meibaX5gH3J9ORNt",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "One skill with the Recall Knowledge action 1 rank",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "mfpxXXdC3Km4GSp5",
        "name": "Hammerhands",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.mfpxXXdC3Km4GSp5",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "mhnRZmXwTFzdqwvX",
        "name": "Defensive Roll",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.mhnRZmXwTFzdqwvX",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Level 8",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "mx3MVSpwKsOYPftR",
        "name": "Studious",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.mx3MVSpwKsOYPftR",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Int +1, Wis +1",
        "automation": {
          "effects": 1,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "n5mKi8SPzohgxioM",
        "name": "Fast Healer",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.n5mKi8SPzohgxioM",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "nOKUrLSMNUaZ89fv",
        "name": "Quicken Spell",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.nOKUrLSMNUaZ89fv",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "nYdM3aCdAetavCjK",
        "name": "Offensive Parry",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.nYdM3aCdAetavCjK",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Shield Block",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "nZZAZHc3wcsDhkDa",
        "name": "Born to Ride",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.nZZAZHc3wcsDhkDa",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Handle Animal 5 ranks",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "nqvygXQbwK4fIZCb",
        "name": "Arcanist",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.nqvygXQbwK4fIZCb",
        "validId": true,
        "category": "Archetype",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Arcana skill 2 ranks, Int +3, Non-Wizard",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "nvHJqv0Dum8TGgny",
        "name": "Sacred Weapon",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.nvHJqv0Dum8TGgny",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "o1npbglbqxqCE8pX",
        "name": "Aggressive Magic",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.o1npbglbqxqCE8pX",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "oRgn64ZPb6ydbnYl",
        "name": "Guiding Fortune",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.oRgn64ZPb6ydbnYl",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Luck of the Small Folk",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "oT9cYNtfoxNo13no",
        "name": "Breath Control",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.oT9cYNtfoxNo13no",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "oXu5oPETTUapo38g",
        "name": "Quick Identification",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.oXu5oPETTUapo38g",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "BSB +4",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "op9XTXMHC2GCklEn",
        "name": "Split Spell",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.op9XTXMHC2GCklEn",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "pcraDoF1WC9eGHke",
        "name": "Combat Reflexes",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.pcraDoF1WC9eGHke",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 2,
          "flags": []
        }
      },
      {
        "id": "pnIlhG2fGSVm6YsT",
        "name": "Stone Wise",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.pnIlhG2fGSVm6YsT",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "prZZWrRUb8qvVUyb",
        "name": "Natural Defence, Supremacy",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.prZZWrRUb8qvVUyb",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Level 16",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "pzUjbwCDUnG59EqX",
        "name": "Superior Resolve",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.pzUjbwCDUnG59EqX",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Resolve, Mental Focus 12 ranks",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "q79GpET7PNjogFtF",
        "name": "Minor Ethereal Caster",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.q79GpET7PNjogFtF",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Level 4",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "qLlLRFzaB9oN1f1s",
        "name": "Combat Awareness",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.qLlLRFzaB9oN1f1s",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "BAB +5",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "qUffSnMr7MBokDKG",
        "name": "Tusks",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.qUffSnMr7MBokDKG",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Level 1 only",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "qVAKySIfQY7Ec8e4",
        "name": "Enhanced Smell",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.qVAKySIfQY7Ec8e4",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Any special olfactory sense (Scent etc)",
        "automation": {
          "effects": 0,
          "flags": [
            "conditionals",
            "codexFeat"
          ]
        }
      },
      {
        "id": "qasb6Q1xAPv5BjpW",
        "name": "Alchemist",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.qasb6Q1xAPv5BjpW",
        "validId": true,
        "category": "Archetype",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Crafting 2 ranks",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "qhDst77Hj8PURaa5",
        "name": "Verdant Gnome",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.qhDst77Hj8PURaa5",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "qphL2ZSBwVCRLdt6",
        "name": "Sudden Charge",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.qphL2ZSBwVCRLdt6",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Athletics 1 rank",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "r6vtYaNRAPqbMq8y",
        "name": "Assess Target",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.r6vtYaNRAPqbMq8y",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "BAB +2, Warfare",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "rHQ0TkLQ6PJUMzD4",
        "name": "Animal Soul",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.rHQ0TkLQ6PJUMzD4",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Animal Companion",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "rJNRHFMmICRwDs5e",
        "name": "Iron Hide",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.rJNRHFMmICRwDs5e",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "rWBr7RO4dmxs4ZCB",
        "name": "Share Thoughts",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.rWBr7RO4dmxs4ZCB",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "rci9JzkcVU45R7GS",
        "name": "Swift Reflexes",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.rci9JzkcVU45R7GS",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 2,
          "flags": []
        }
      },
      {
        "id": "rrC2byBJXSN3kZXU",
        "name": "Flawless Performance",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.rrC2byBJXSN3kZXU",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Perform 1 rank",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "ruZc8zlnCAV0ty66",
        "name": "Grave Authority",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.ruZc8zlnCAV0ty66",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Undead or Mournkin",
        "automation": {
          "effects": 0,
          "flags": [
            "conditionals",
            "codexFeat"
          ]
        }
      },
      {
        "id": "s7UOpCL195va0Gnr",
        "name": "Proper Hardman",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.s7UOpCL195va0Gnr",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "BAB +10",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "sKaEKd1GjED4CJdd",
        "name": "Armour Proficiency, Medium",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.sKaEKd1GjED4CJdd",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Armour Proficiency, Light",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "sKb4doLEx9EtclVo",
        "name": "Subtle",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.sKb4doLEx9EtclVo",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Stealth 5 ranks",
        "automation": {
          "effects": 1,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "saxAcP4Duv3UM3dQ",
        "name": "Mind Speech",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.saxAcP4Duv3UM3dQ",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Level 10, Share Thoughts",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "sgxAbpLeUa8C15DK",
        "name": "Frenzy",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.sgxAbpLeUa8C15DK",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "spWlYI3R4sikIwpd",
        "name": "Stealthy Strike",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.spWlYI3R4sikIwpd",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Non-Rogue, Stealth 2 ranks",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "tYoAdYkk97X4Pgxc",
        "name": "Worldly",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.tYoAdYkk97X4Pgxc",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "thC3ZXv0gZwFBw3D",
        "name": "The Bigger They Are",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.thC3ZXv0gZwFBw3D",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "tlyJ0bfKW2LS8moa",
        "name": "Favoured Terrain",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.tlyJ0bfKW2LS8moa",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "tpGTajRe15VVGYne",
        "name": "War Priest",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.tpGTajRe15VVGYne",
        "validId": true,
        "category": "Archetype",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 2,
          "flags": []
        }
      },
      {
        "id": "tqp0qORtnsk6737l",
        "name": "Still Spell",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.tqp0qORtnsk6737l",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "trgHerosFortune1",
        "name": "Hero's Fortune",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.trgHerosFortune1",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "trgHerosResolve1",
        "name": "Hero's Resolve",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.trgHerosResolve1",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Hero's Fortune, Level 8",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "trgLuckOfHeroes1",
        "name": "Luck of Heroes",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.trgLuckOfHeroes1",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Hero's Fortune, Level 5",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "tugZdPd0Ikkuhia0",
        "name": "Component Mastery",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.tugZdPd0Ikkuhia0",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "uR9JOGjNgTq4I7ED",
        "name": "Stance Mastery",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.uR9JOGjNgTq4I7ED",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "BAB +12, Reactive Stance",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "uUoCTMyd4LTPk0ZR",
        "name": "Focused Pursuit",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.uUoCTMyd4LTPk0ZR",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "uUyr42I9AWSdn3ln",
        "name": "Extra Channels",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.uUyr42I9AWSdn3ln",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "BSB +4",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "udIKHSzxXnZUgbHQ",
        "name": "Quick Donning",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.udIKHSzxXnZUgbHQ",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Athletics 1 rank, Warfare",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "uic7fcfHr4raumfI",
        "name": "Guardian Defence",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.uic7fcfHr4raumfI",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "ukpguOqazXXvzlsj",
        "name": "Survivalist",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.ukpguOqazXXvzlsj",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Survival 1 rank",
        "automation": {
          "effects": 1,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "v2WgiLG5cl7DHCtA",
        "name": "Agile Strikes",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.v2WgiLG5cl7DHCtA",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "v6fUM5YyWdkvzeRT",
        "name": "Guarded Move",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.v6fUM5YyWdkvzeRT",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "vZB8cuqHCRmFcMDS",
        "name": "Quick Climber",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.vZB8cuqHCRmFcMDS",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Climbing 12 ranks",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "vd5yDBa69F9L2Hfp",
        "name": "Blessed By the Gods",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.vd5yDBa69F9L2Hfp",
        "validId": true,
        "category": "Archetype",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Divinity caster",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "vtHVtXl29kOTFKLU",
        "name": "Masterful Burglar",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.vtHVtXl29kOTFKLU",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Thievery 6 ranks",
        "automation": {
          "effects": 1,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "w6X2KraYgLI8hUK7",
        "name": "Keen Insight",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.w6X2KraYgLI8hUK7",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Diplomacy 1 rank",
        "automation": {
          "effects": 1,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "wQOxJHBGy1VuKR2p",
        "name": "Hidden Emotion",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.wQOxJHBGy1VuKR2p",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "weLTbh3xAi4Ge4DX",
        "name": "Shield Proficiency, Light",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.weLTbh3xAi4Ge4DX",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "BAB +1",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "wmGwarQKdYLeGHoA",
        "name": "Warp Manipulation",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.wmGwarQKdYLeGHoA",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "BSB +10",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "wrJZQT7i9fQCRnkw",
        "name": "Primal Shape",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.wrJZQT7i9fQCRnkw",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Level 5, Hybrid Transformation",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "xHov22ocSe7SQ4nW",
        "name": "Hauling Shadow",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.xHov22ocSe7SQ4nW",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Level 10",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "xJq4lLegjafc74YG",
        "name": "Urban Tracker",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.xJq4lLegjafc74YG",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Perception 4 ranks",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "xMIDNI0V9UiiPxkh",
        "name": "Streetwise",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.xMIDNI0V9UiiPxkh",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Culture 2 ranks",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "xVPLmviPnKB7cNCU",
        "name": "Practised Killer",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.xVPLmviPnKB7cNCU",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Stealth 8 ranks",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "xbgd09zI8gkZSEFd",
        "name": "Feather Step",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.xbgd09zI8gkZSEFd",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Dex +3",
        "automation": {
          "effects": 1,
          "flags": [
            "ignoresDifficultTerrainOn"
          ]
        }
      },
      {
        "id": "xnf3FhTmBMOFgaRM",
        "name": "Shadowy Whispers",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.xnf3FhTmBMOFgaRM",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "xsxxW3x8bRxL4YtO",
        "name": "Fleet Footed",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.xsxxW3x8bRxL4YtO",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Dex +2",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "y5ltl9xIeLLuULa4",
        "name": "Assess Tracks",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.y5ltl9xIeLLuULa4",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Survival 10 ranks",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "ym0AZa54zUIlrsNJ",
        "name": "Alchemical Crafting",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.ym0AZa54zUIlrsNJ",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Crafting or Nature 1 rank",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "z58e7JIfFMYHgTYl",
        "name": "Critical Focus",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.z58e7JIfFMYHgTYl",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "BAB +12",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "zAtDM3ADs1zMMdZx",
        "name": "Magical Discovery",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.zAtDM3ADs1zMMdZx",
        "validId": true,
        "category": "General",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "BSB +2",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "zDYCW2v1ubOpWsDo",
        "name": "Major Arcane Caster",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.zDYCW2v1ubOpWsDo",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Level 12, Minor Arcane Caster",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "zDrAc1pJWWrbo73Q",
        "name": "Ebon Bind",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.zDrAc1pJWWrbo73Q",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "You have summoned or struck a deal with a creature from the shadescape.",
        "automation": {
          "effects": 0,
          "flags": [
            "conditionals",
            "codexFeat"
          ]
        }
      },
      {
        "id": "zK7zlmIEVe6YAD7C",
        "name": "Monstrous Vision",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.zK7zlmIEVe6YAD7C",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "zSrukNNffuS7Hpqm",
        "name": "Specialist Spell",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.zSrukNNffuS7Hpqm",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "zSvDebsSEqa30XSa",
        "name": "Knife Flurry",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.zSvDebsSEqa30XSa",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Deception 5 ranks",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "zU1fGINTajMa4yOz",
        "name": "Fearless",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.zU1fGINTajMa4yOz",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Bravery, BAB +14",
        "automation": {
          "effects": 2,
          "flags": []
        }
      },
      {
        "id": "zWNWEao0IDDdtzSJ",
        "name": "Double Stance",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.zWNWEao0IDDdtzSJ",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "zlZ65l5nSFqRtHsl",
        "name": "Language Master",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.zlZ65l5nSFqRtHsl",
        "validId": true,
        "category": "Archetype",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Linguistics 2 ranks, Int +3",
        "automation": {
          "effects": 2,
          "flags": []
        }
      },
      {
        "id": "zr0BcM5RO3ixhYYq",
        "name": "Elven Magic",
        "type": "feat",
        "uuid": "Compendium.trg-prime.feats.Item.zr0BcM5RO3ixhYYq",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      }
    ],
    "spells": [
      {
        "id": "01FaiUEw7IFkkCrA",
        "name": "Invisible Item",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.01FaiUEw7IFkkCrA",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "02QB5KYILQAsAro2",
        "name": "Eldritch Weapon",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.02QB5KYILQAsAro2",
        "validId": true,
        "category": "utility",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "03dWvYTpNE7cDb46",
        "name": "Stinking Cloud",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.03dWvYTpNE7cDb46",
        "validId": true,
        "category": "save",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "0BdkH4owkUVGIrpk",
        "name": "Jolts",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.0BdkH4owkUVGIrpk",
        "validId": true,
        "category": "save",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "0LQyeybddQwvjKhg",
        "name": "Inspire Courage",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.0LQyeybddQwvjKhg",
        "validId": true,
        "category": "utility",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "0R5gAWYRJNLaNjn0",
        "name": "Speak With Dead",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.0R5gAWYRJNLaNjn0",
        "validId": true,
        "category": "utility",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "0RcF49V9KeQZ2zXo",
        "name": "Moment Of Renewal",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.0RcF49V9KeQZ2zXo",
        "validId": true,
        "category": "utility",
        "ppCost": 16,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "0U9MpEwJIt3Jv9dd",
        "name": "Banishment",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.0U9MpEwJIt3Jv9dd",
        "validId": true,
        "category": "save",
        "ppCost": 10,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "0YwfYbRs0DJUrfcv",
        "name": "Gaseous Form",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.0YwfYbRs0DJUrfcv",
        "validId": true,
        "category": "utility",
        "ppCost": 8,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "0g804d9QsQ0Oy9fs",
        "name": "Eldritch Ball",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.0g804d9QsQ0Oy9fs",
        "validId": true,
        "category": "save",
        "ppCost": 10,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "0v1ZShMZP4ETO11i",
        "name": "Surge Of The Tempest",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.0v1ZShMZP4ETO11i",
        "validId": true,
        "category": "save",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "16QyCFU9XiAXJsp9",
        "name": "Wail Of The Banshee",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.16QyCFU9XiAXJsp9",
        "validId": true,
        "category": "save",
        "ppCost": 20,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "1FTwOMjOK06LFSBG",
        "name": "Earth Bind",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.1FTwOMjOK06LFSBG",
        "validId": true,
        "category": "save",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "1KrwlHKbuyFejd1h",
        "name": "Antipathy",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.1KrwlHKbuyFejd1h",
        "validId": true,
        "category": "save",
        "ppCost": 16,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "1LQjSQqCqb2bBMMm",
        "name": "Stone Tongue",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.1LQjSQqCqb2bBMMm",
        "validId": true,
        "category": "utility",
        "ppCost": 12,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "1jJ7jIVwXUGesMT4",
        "name": "Wall Of Thorns",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.1jJ7jIVwXUGesMT4",
        "validId": true,
        "category": "utility",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "1lWsrk0bYXIXXoDS",
        "name": "Veiled Presence",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.1lWsrk0bYXIXXoDS",
        "validId": true,
        "category": "utility",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "1tJaDKuFRF1e2wIO",
        "name": "Daze",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.1tJaDKuFRF1e2wIO",
        "validId": true,
        "category": "save",
        "ppCost": 0,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "1wHBiy2AueUzhiny",
        "name": "Beast Of Burden",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.1wHBiy2AueUzhiny",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "21Bkycd88WSVKOux",
        "name": "Devotion Blast",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.21Bkycd88WSVKOux",
        "validId": true,
        "category": "save",
        "ppCost": 8,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "24TXFV1tVcPbk6jW",
        "name": "Nexus Of Elemental Energy",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.24TXFV1tVcPbk6jW",
        "validId": true,
        "category": "save",
        "ppCost": 10,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "270fnXfY0fJhRqEU",
        "name": "Warped Terrain",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.270fnXfY0fJhRqEU",
        "validId": true,
        "category": "utility",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "2A8hnvR8j41dUsEK",
        "name": "Vital Beacon",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.2A8hnvR8j41dUsEK",
        "validId": true,
        "category": "utility",
        "ppCost": 8,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "2C9vc4pZ7xuusJnH",
        "name": "Radiant Aegis",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.2C9vc4pZ7xuusJnH",
        "validId": true,
        "category": "utility",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "2JjmC6KxhuPf1bwG",
        "name": "Faith’s Shield",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.2JjmC6KxhuPf1bwG",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "2NdlB6OKpUzGK07Z",
        "name": "Shadow Step",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.2NdlB6OKpUzGK07Z",
        "validId": true,
        "category": "utility",
        "ppCost": 8,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "2OimXIrdCe60e6SY",
        "name": "Sickly Ray",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.2OimXIrdCe60e6SY",
        "validId": true,
        "category": "attack",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "2SmYRclkC7D7qCZz",
        "name": "Regenerate",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.2SmYRclkC7D7qCZz",
        "validId": true,
        "category": "utility",
        "ppCost": 10,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "2aMu3qieYdCYc8pi",
        "name": "Line Of Fire",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.2aMu3qieYdCYc8pi",
        "validId": true,
        "category": "save",
        "ppCost": 8,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "2lfOoqcgnj62490Y",
        "name": "Shadow Walk",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.2lfOoqcgnj62490Y",
        "validId": true,
        "category": "utility",
        "ppCost": 10,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "2s3JVXC6hsw0gEff",
        "name": "Scorching Ray",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.2s3JVXC6hsw0gEff",
        "validId": true,
        "category": "attack",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "31rUc9rmulJT7cKo",
        "name": "Resist Energy",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.31rUc9rmulJT7cKo",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "329eq5tXXhUbwoc1",
        "name": "Counter Perform",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.329eq5tXXhUbwoc1",
        "validId": true,
        "category": "utility",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "38yiErPkuB87XXpn",
        "name": "Harrow",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.38yiErPkuB87XXpn",
        "validId": true,
        "category": "save",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "3EVEQ05b2hJOgVR1",
        "name": "Coercive Retribution",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.3EVEQ05b2hJOgVR1",
        "validId": true,
        "category": "save",
        "ppCost": 7,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "3IbFV5oSXBBEnFnz",
        "name": "Incendiary Cloud",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.3IbFV5oSXBBEnFnz",
        "validId": true,
        "category": "save",
        "ppCost": 16,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "3KXvGobZZyMkNs9b",
        "name": "Disorient",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.3KXvGobZZyMkNs9b",
        "validId": true,
        "category": "save",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "3f37XQP9SdYygNCp",
        "name": "Teleport",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.3f37XQP9SdYygNCp",
        "validId": true,
        "category": "utility",
        "ppCost": 12,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "3h1xLhB7VtsdedM8",
        "name": "Mind Blank",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.3h1xLhB7VtsdedM8",
        "validId": true,
        "category": "utility",
        "ppCost": 16,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "3icClgYwUpWvepCY",
        "name": "Horrid Wilting",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.3icClgYwUpWvepCY",
        "validId": true,
        "category": "save",
        "ppCost": 16,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "3tv2Qz07wmeicCOA",
        "name": "Eldritch Shield",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.3tv2Qz07wmeicCOA",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "3tvFbEZ2BSTbr9qD",
        "name": "Umbral Veil",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.3tvFbEZ2BSTbr9qD",
        "validId": true,
        "category": "utility",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "3zr1JXrc1VVMPAa7",
        "name": "Ghost Sound",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.3zr1JXrc1VVMPAa7",
        "validId": true,
        "category": "utility",
        "ppCost": 0,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "46DWKaSBjVpnXfXP",
        "name": "Cancel Magic",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.46DWKaSBjVpnXfXP",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "47uHv1Phb9IjiqAc",
        "name": "Visage Of Horror",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.47uHv1Phb9IjiqAc",
        "validId": true,
        "category": "save",
        "ppCost": 14,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "4IUTNQFjXIBAfj0O",
        "name": "Frostbound Shadow",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.4IUTNQFjXIBAfj0O",
        "validId": true,
        "category": "attack",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "4aDVl0cq24DX9lVP",
        "name": "Incandescence",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.4aDVl0cq24DX9lVP",
        "validId": true,
        "category": "save",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "4d1ssXjxQTiuajTj",
        "name": "Physical Boost",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.4d1ssXjxQTiuajTj",
        "validId": true,
        "category": "utility",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "4xpPGCE7DT1DLGGa",
        "name": "Foresight",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.4xpPGCE7DT1DLGGa",
        "validId": true,
        "category": "utility",
        "ppCost": 18,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "59rswmlho9sERr8g",
        "name": "Holy Shout",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.59rswmlho9sERr8g",
        "validId": true,
        "category": "save",
        "ppCost": 14,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "5ImYf8bGuSQko3dS",
        "name": "Spectral Hand",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.5ImYf8bGuSQko3dS",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "5ObWheDBjgARhtTf",
        "name": "Smash",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.5ObWheDBjgARhtTf",
        "validId": true,
        "category": "utility",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "5SAp0VAzhxSTYYLn",
        "name": "Sudden Sickening",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.5SAp0VAzhxSTYYLn",
        "validId": true,
        "category": "save",
        "ppCost": 8,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "5Uo5JUbb7AB8mnqP",
        "name": "Luminous Flare",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.5Uo5JUbb7AB8mnqP",
        "validId": true,
        "category": "save",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "5UvqgsNVZSniwjvX",
        "name": "Ramirez Rhythm",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.5UvqgsNVZSniwjvX",
        "validId": true,
        "category": "save",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "5gn2VNCuBbJZ9GO6",
        "name": "Qualm",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.5gn2VNCuBbJZ9GO6",
        "validId": true,
        "category": "save",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "5isAtFs9vSZ0AZI1",
        "name": "Flare",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.5isAtFs9vSZ0AZI1",
        "validId": true,
        "category": "save",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "5lVdgs6jDNziHvKa",
        "name": "Gust",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.5lVdgs6jDNziHvKa",
        "validId": true,
        "category": "save",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "5nPWTT43IBexBVYl",
        "name": "Eldritch Disruption",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.5nPWTT43IBexBVYl",
        "validId": true,
        "category": "save",
        "ppCost": 12,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "5ye53RlARXtYY7U3",
        "name": "Rejoining",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.5ye53RlARXtYY7U3",
        "validId": true,
        "category": "utility",
        "ppCost": 8,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "65c91XuvoVnhdAO2",
        "name": "Levitate",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.65c91XuvoVnhdAO2",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "66KAwH6mrkNSb6ig",
        "name": "Flaming Weapon",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.66KAwH6mrkNSb6ig",
        "validId": true,
        "category": "utility",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "6744sqt04JkyjN9a",
        "name": "Vampiric Touch",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.6744sqt04JkyjN9a",
        "validId": true,
        "category": "save",
        "ppCost": 8,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "67BKwUe3ZwwboUXQ",
        "name": "Passwall",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.67BKwUe3ZwwboUXQ",
        "validId": true,
        "category": "utility",
        "ppCost": 10,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "6BeLHHuumOFRNhRq",
        "name": "Plane Shift",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.6BeLHHuumOFRNhRq",
        "validId": true,
        "category": "utility",
        "ppCost": 14,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "6D0YyQ1Vuxglb4c9",
        "name": "Fire Trap",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.6D0YyQ1Vuxglb4c9",
        "validId": true,
        "category": "save",
        "ppCost": 8,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "6IJzT2hlJzOF68Wv",
        "name": "Dimension Shift",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.6IJzT2hlJzOF68Wv",
        "validId": true,
        "category": "utility",
        "ppCost": 7,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "6MqtZAXfwFkIRO5k",
        "name": "Lifekeeping",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.6MqtZAXfwFkIRO5k",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "6RTXWjyS3QIVq2nT",
        "name": "Alarm",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.6RTXWjyS3QIVq2nT",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "6Tz2jVQCy9xst0fd",
        "name": "False Mire",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.6Tz2jVQCy9xst0fd",
        "validId": true,
        "category": "utility",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "6W3W4iq1GZ8krnjF",
        "name": "Map Of The Root-knit",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.6W3W4iq1GZ8krnjF",
        "validId": true,
        "category": "utility",
        "ppCost": 10,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "6a2Un1o680GwIO0E",
        "name": "Disturbing Tentacles",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.6a2Un1o680GwIO0E",
        "validId": true,
        "category": "save",
        "ppCost": 14,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "6lOp2Ky1YFxBIXie",
        "name": "Disrupt Undead",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.6lOp2Ky1YFxBIXie",
        "validId": true,
        "category": "attack",
        "ppCost": 0,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "6pBpGQmfMLM5Uig2",
        "name": "Grease",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.6pBpGQmfMLM5Uig2",
        "validId": true,
        "category": "save",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "6t4rTCyxsO7HDBLG",
        "name": "Shock Bolt",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.6t4rTCyxsO7HDBLG",
        "validId": true,
        "category": "attack",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "6ximzHtbCvlGcJTi",
        "name": "Nightmare",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.6ximzHtbCvlGcJTi",
        "validId": true,
        "category": "save",
        "ppCost": 8,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "6yRySmmhYRghmfQF",
        "name": "Zealous Conviction",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.6yRySmmhYRghmfQF",
        "validId": true,
        "category": "utility",
        "ppCost": 12,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "70171ePlTWttFURK",
        "name": "Clarity",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.70171ePlTWttFURK",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "72E60hDXtdHTewCD",
        "name": "Aura Of Vitality",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.72E60hDXtdHTewCD",
        "validId": true,
        "category": "utility",
        "ppCost": 12,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "7A9TRYLerboXZxC3",
        "name": "Remove Disease",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.7A9TRYLerboXZxC3",
        "validId": true,
        "category": "utility",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "7NUvxuoarsaDCqZW",
        "name": "Fear",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.7NUvxuoarsaDCqZW",
        "validId": true,
        "category": "save",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "7cjRAEaRJB6lJpho",
        "name": "Gentle Repose",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.7cjRAEaRJB6lJpho",
        "validId": true,
        "category": "utility",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "7drgsbC9i2TDKkSC",
        "name": "Shape Of The Beast",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.7drgsbC9i2TDKkSC",
        "validId": true,
        "category": "utility",
        "ppCost": 12,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "88HDIQgGiMLaTLAj",
        "name": "Aid",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.88HDIQgGiMLaTLAj",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "8B7VVamARIrxJpL0",
        "name": "Healing Earth",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.8B7VVamARIrxJpL0",
        "validId": true,
        "category": "utility",
        "ppCost": 0,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "8CP6lI6MOehf3bK3",
        "name": "Enchanting Utterance",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.8CP6lI6MOehf3bK3",
        "validId": true,
        "category": "save",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "8NCxVpDHdLEwToYE",
        "name": "Natural Animosity",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.8NCxVpDHdLEwToYE",
        "validId": true,
        "category": "save",
        "ppCost": 18,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "8WiohwLBQ60pZq2x",
        "name": "Slay The Soul",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.8WiohwLBQ60pZq2x",
        "validId": true,
        "category": "save",
        "ppCost": 10,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "8f40bujQQffegCmW",
        "name": "Mislead",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.8f40bujQQffegCmW",
        "validId": true,
        "category": "utility",
        "ppCost": 12,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "8gRb3VkucaupKUVj",
        "name": "Resonance Manipulation",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.8gRb3VkucaupKUVj",
        "validId": true,
        "category": "utility",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "8h4mt3Oy2xoTHcwb",
        "name": "Wash Away Sin",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.8h4mt3Oy2xoTHcwb",
        "validId": true,
        "category": "save",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "8hlvbTMRioGNmMxS",
        "name": "Scribers Chant",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.8hlvbTMRioGNmMxS",
        "validId": true,
        "category": "utility",
        "ppCost": 0,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "8i0sLhMAvV31ZEV3",
        "name": "Fire Manifest",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.8i0sLhMAvV31ZEV3",
        "validId": true,
        "category": "save",
        "ppCost": 8,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "8zzO7PEP7ISMQPPV",
        "name": "Sunburst",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.8zzO7PEP7ISMQPPV",
        "validId": true,
        "category": "save",
        "ppCost": 14,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "93wJN50C1trsFEyW",
        "name": "Fly",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.93wJN50C1trsFEyW",
        "validId": true,
        "category": "utility",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "95TKP6ZeVEERgq8D",
        "name": "Command",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.95TKP6ZeVEERgq8D",
        "validId": true,
        "category": "save",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "9AGkX8hJQAbcMT6b",
        "name": "Destructive Roar",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.9AGkX8hJQAbcMT6b",
        "validId": true,
        "category": "save",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "9N58AC8lQWH8a1U5",
        "name": "Restoration",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.9N58AC8lQWH8a1U5",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "9S1h5w2z8ayk5saW",
        "name": "Purify",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.9S1h5w2z8ayk5saW",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "9Z4WYFx2WGL7vrNK",
        "name": "Reaper’s Resonance",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.9Z4WYFx2WGL7vrNK",
        "validId": true,
        "category": "utility",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "9cxKAkKOn5njeP3t",
        "name": "Disgrace",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.9cxKAkKOn5njeP3t",
        "validId": true,
        "category": "utility",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "9hX3xeUp7FoycKfy",
        "name": "Shape Of The Wyrm",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.9hX3xeUp7FoycKfy",
        "validId": true,
        "category": "utility",
        "ppCost": 12,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "9rwNJqqAcHH1Gn1R",
        "name": "Find The Path",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.9rwNJqqAcHH1Gn1R",
        "validId": true,
        "category": "utility",
        "ppCost": 12,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "9snGRdoInXYiSish",
        "name": "Dead Tongue",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.9snGRdoInXYiSish",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "9uFBZxHPAABGJyDV",
        "name": "Time Stop",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.9uFBZxHPAABGJyDV",
        "validId": true,
        "category": "utility",
        "ppCost": 20,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "9zQTDqLTSCLCMMkF",
        "name": "Ghostly Lanterns",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.9zQTDqLTSCLCMMkF",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "A0aPZMu8wPvfTNUD",
        "name": "Flaming Sphere",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.A0aPZMu8wPvfTNUD",
        "validId": true,
        "category": "save",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "A1COmkFfLCQPOTeI",
        "name": "Unity",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.A1COmkFfLCQPOTeI",
        "validId": true,
        "category": "utility",
        "ppCost": 7,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "A3ilq7AiEW1dYl8T",
        "name": "Dulling Cloud",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.A3ilq7AiEW1dYl8T",
        "validId": true,
        "category": "save",
        "ppCost": 10,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "ADdG7dlOxGqRfOiW",
        "name": "Teleportation Circle",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.ADdG7dlOxGqRfOiW",
        "validId": true,
        "category": "utility",
        "ppCost": 14,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "AHYku3JvYNwdwh2R",
        "name": "Portal Maelstrom",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.AHYku3JvYNwdwh2R",
        "validId": true,
        "category": "save",
        "ppCost": 14,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "ALLAUDvEi4Ih91KC",
        "name": "Cold Ball",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.ALLAUDvEi4Ih91KC",
        "validId": true,
        "category": "save",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "AOnH4KZFZpbruIiE",
        "name": "Inner Sanctum",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.AOnH4KZFZpbruIiE",
        "validId": true,
        "category": "utility",
        "ppCost": 10,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "AR7rnF3sySO41P4T",
        "name": "Wall Of Blades",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.AR7rnF3sySO41P4T",
        "validId": true,
        "category": "save",
        "ppCost": 12,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "AZBFsMMchOi7w80I",
        "name": "Sound Burst",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.AZBFsMMchOi7w80I",
        "validId": true,
        "category": "save",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "Ad21gJZYDv9VfxK4",
        "name": "Sympathy",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.Ad21gJZYDv9VfxK4",
        "validId": true,
        "category": "save",
        "ppCost": 16,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "AhyJzFZyhCo351iH",
        "name": "Stone Shield",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.AhyJzFZyhCo351iH",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "An7yIO459sDfw2ZV",
        "name": "Resilient Sphere",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.An7yIO459sDfw2ZV",
        "validId": true,
        "category": "utility",
        "ppCost": 8,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "An8r5fn52bz3xr0g",
        "name": "Trace Location",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.An8r5fn52bz3xr0g",
        "validId": true,
        "category": "utility",
        "ppCost": 16,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "AvqZ6TmCdA9tGHOm",
        "name": "Disintegrate",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.AvqZ6TmCdA9tGHOm",
        "validId": true,
        "category": "save",
        "ppCost": 12,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "Axelg8M67wAwG3Fj",
        "name": "Shifting Form",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.Axelg8M67wAwG3Fj",
        "validId": true,
        "category": "utility",
        "ppCost": 7,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "B9mW0z0qQmY1MtPO",
        "name": "Unwelcome Halo",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.B9mW0z0qQmY1MtPO",
        "validId": true,
        "category": "save",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "BDBKhc4dsC05PGLN",
        "name": "Shrink Item",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.BDBKhc4dsC05PGLN",
        "validId": true,
        "category": "utility",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "BNBY82mwyJBGeQQc",
        "name": "Stunning Glare",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.BNBY82mwyJBGeQQc",
        "validId": true,
        "category": "save",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "BSOBGSuQ0F4oPoAv",
        "name": "Invulnerability",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.BSOBGSuQ0F4oPoAv",
        "validId": true,
        "category": "utility",
        "ppCost": 20,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "BafFhZI7kiPohbXH",
        "name": "Discern Lies",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.BafFhZI7kiPohbXH",
        "validId": true,
        "category": "utility",
        "ppCost": 8,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "Bdh16IdQd54VzxAh",
        "name": "Death’s Defiance",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.Bdh16IdQd54VzxAh",
        "validId": true,
        "category": "utility",
        "ppCost": 7,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "BgXd9WTUqjq3mQLh",
        "name": "Tongues",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.BgXd9WTUqjq3mQLh",
        "validId": true,
        "category": "utility",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "BpfqBSETGPwBbel2",
        "name": "Mage Armour",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.BpfqBSETGPwBbel2",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "BrUVa9DVkklNVicM",
        "name": "Hold Kind",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.BrUVa9DVkklNVicM",
        "validId": true,
        "category": "save",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "BzSpQIS9yoLAcYlI",
        "name": "Status",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.BzSpQIS9yoLAcYlI",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "CGLUDsfKaZd9jqwS",
        "name": "Breeze Strike",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.CGLUDsfKaZd9jqwS",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "CNO7kpk8DWKStkM3",
        "name": "Shifting Step",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.CNO7kpk8DWKStkM3",
        "validId": true,
        "category": "utility",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "CYEgBMtOS4RoryLL",
        "name": "Mind Cleanse",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.CYEgBMtOS4RoryLL",
        "validId": true,
        "category": "utility",
        "ppCost": 16,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "CdbVGFOWdFdAzwKe",
        "name": "Twisted Fate",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.CdbVGFOWdFdAzwKe",
        "validId": true,
        "category": "save",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "CkGLAVU5Ow77jieZ",
        "name": "Scrying",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.CkGLAVU5Ow77jieZ",
        "validId": true,
        "category": "save",
        "ppCost": 12,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "Cm0pieWt3Ah2gEn6",
        "name": "Renewal’s Touch",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.Cm0pieWt3Ah2gEn6",
        "validId": true,
        "category": "utility",
        "ppCost": 7,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "CqfJO3Tl0htBzbsn",
        "name": "Mindlink",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.CqfJO3Tl0htBzbsn",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "CrXNV1a9zrrMc7jR",
        "name": "Zealous Battlecry",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.CrXNV1a9zrrMc7jR",
        "validId": true,
        "category": "utility",
        "ppCost": 7,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "Creyh2hjd6i2dJcS",
        "name": "Forbiddance",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.Creyh2hjd6i2dJcS",
        "validId": true,
        "category": "utility",
        "ppCost": 8,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "CtD0ccnZ15xRLwbQ",
        "name": "Wake",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.CtD0ccnZ15xRLwbQ",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "CyPp59NZGwLhIfHC",
        "name": "Magic Mouth",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.CyPp59NZGwLhIfHC",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "CzDFFocN1FNxCsfb",
        "name": "Shadow Blast",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.CzDFFocN1FNxCsfb",
        "validId": true,
        "category": "save",
        "ppCost": 10,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "D0FBAheO4h6mXrbT",
        "name": "Swift Sonata",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.D0FBAheO4h6mXrbT",
        "validId": true,
        "category": "utility",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "D9CRGkiKFprbbHs4",
        "name": "Magic Jaws",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.D9CRGkiKFprbbHs4",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "DB8Lm8HJOrlSkEqP",
        "name": "Blindness",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.DB8Lm8HJOrlSkEqP",
        "validId": true,
        "category": "save",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "DIY3wGKIW88WFHLH",
        "name": "Unseen Servant",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.DIY3wGKIW88WFHLH",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "DJV8MNDyXjo5XuBi",
        "name": "Stabilise",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.DJV8MNDyXjo5XuBi",
        "validId": true,
        "category": "utility",
        "ppCost": 0,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "DKgYtTPn6c3Dgnk0",
        "name": "Dangerous Vision",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.DKgYtTPn6c3Dgnk0",
        "validId": true,
        "category": "save",
        "ppCost": 14,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "DP7CM9wx60aUj44D",
        "name": "Shatter",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.DP7CM9wx60aUj44D",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "DQKHEa5irpAKAfHS",
        "name": "Planar Contact",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.DQKHEa5irpAKAfHS",
        "validId": true,
        "category": "utility",
        "ppCost": 12,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "DR2G1NXf4lWPoJmy",
        "name": "Deific Enhancement",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.DR2G1NXf4lWPoJmy",
        "validId": true,
        "category": "utility",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "DUPAhWCN9OaPFCIZ",
        "name": "Freedom",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.DUPAhWCN9OaPFCIZ",
        "validId": true,
        "category": "utility",
        "ppCost": 8,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "Dv1GJrwzYAPWy1XU",
        "name": "Spirit Trap",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.Dv1GJrwzYAPWy1XU",
        "validId": true,
        "category": "save",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "E32iFpPVK9VN1QlH",
        "name": "Earth Prison",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.E32iFpPVK9VN1QlH",
        "validId": true,
        "category": "save",
        "ppCost": 20,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "E5lZzKjaEahXdyjs",
        "name": "Shape Wood",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.E5lZzKjaEahXdyjs",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "EAxuIJVCkWYLe2GQ",
        "name": "Command Swarm",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.EAxuIJVCkWYLe2GQ",
        "validId": true,
        "category": "save",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "EPv07lg0MNx5odAM",
        "name": "Resistance",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.EPv07lg0MNx5odAM",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "ERxv8iimvoVIijtk",
        "name": "Spider Climb",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.ERxv8iimvoVIijtk",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "EUtTOKSqFt63G9Cy",
        "name": "Telepathic Demand",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.EUtTOKSqFt63G9Cy",
        "validId": true,
        "category": "save",
        "ppCost": 18,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "EXjq5B3Yldpvp9Ed",
        "name": "Verdant Snare",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.EXjq5B3Yldpvp9Ed",
        "validId": true,
        "category": "utility",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "EZJrlg2LYRkjs94F",
        "name": "Web",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.EZJrlg2LYRkjs94F",
        "validId": true,
        "category": "utility",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "Ea3QL786Lmllgy8S",
        "name": "Bless",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.Ea3QL786Lmllgy8S",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "EbcOqikuFvads1Tj",
        "name": "Acid Bolt",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.EbcOqikuFvads1Tj",
        "validId": true,
        "category": "attack",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "Eh6Smh8ZVmWHZZ3B",
        "name": "Elemental Fury",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.Eh6Smh8ZVmWHZZ3B",
        "validId": true,
        "category": "utility",
        "ppCost": 7,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "EkW7Efpr9HGnCmTl",
        "name": "Quick Time",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.EkW7Efpr9HGnCmTl",
        "validId": true,
        "category": "utility",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "EmBm5hSENdAUQnwN",
        "name": "Iron Body",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.EmBm5hSENdAUQnwN",
        "validId": true,
        "category": "utility",
        "ppCost": 16,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "Ezb1kZbEFcuD9730",
        "name": "Phantasmal Killer",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.Ezb1kZbEFcuD9730",
        "validId": true,
        "category": "save",
        "ppCost": 8,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "F1kNObfPdj4xbMwX",
        "name": "Serenity",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.F1kNObfPdj4xbMwX",
        "validId": true,
        "category": "save",
        "ppCost": 12,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "FBEzRCLwC2ASv1Kp",
        "name": "Awaken Animal",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.FBEzRCLwC2ASv1Kp",
        "validId": true,
        "category": "utility",
        "ppCost": 14,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "FCdpycSSlOSFuGHz",
        "name": "Arc Of Fire",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.FCdpycSSlOSFuGHz",
        "validId": true,
        "category": "attack",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "FHQ3MyBiREY8Y3BY",
        "name": "Delayed Blast Fireball",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.FHQ3MyBiREY8Y3BY",
        "validId": true,
        "category": "save",
        "ppCost": 14,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "FMl8TkNo8SrfFCzD",
        "name": "Call Lightning",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.FMl8TkNo8SrfFCzD",
        "validId": true,
        "category": "save",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "FkYxCKEXPXASc0XJ",
        "name": "Long Sense",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.FkYxCKEXPXASc0XJ",
        "validId": true,
        "category": "utility",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "G9OLfim0VESfo62h",
        "name": "Banish Fatigue",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.G9OLfim0VESfo62h",
        "validId": true,
        "category": "utility",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "GAVkSVKCKR90LwcU",
        "name": "Bless Weapon",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.GAVkSVKCKR90LwcU",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "GFxExF0Q4MQaWcHP",
        "name": "Colour Spray",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.GFxExF0Q4MQaWcHP",
        "validId": true,
        "category": "save",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "GK49fYhZiKJzJRyS",
        "name": "Gustborn Movement",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.GK49fYhZiKJzJRyS",
        "validId": true,
        "category": "utility",
        "ppCost": 7,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "GKBajfOlfoYntS5X",
        "name": "Inspire Heroics",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.GKBajfOlfoYntS5X",
        "validId": true,
        "category": "utility",
        "ppCost": 7,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "GTv9MLQgxIj2Ndil",
        "name": "Sudden Claw",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.GTv9MLQgxIj2Ndil",
        "validId": true,
        "category": "attack",
        "ppCost": 0,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "GxDJosghgDBTxV11",
        "name": "Orb Of Force",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.GxDJosghgDBTxV11",
        "validId": true,
        "category": "attack",
        "ppCost": 0,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "Gylc9LH2Oc7gJooV",
        "name": "Divine Lance",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.Gylc9LH2Oc7gJooV",
        "validId": true,
        "category": "attack",
        "ppCost": 0,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "H09TZlg2TKyYH9ZJ",
        "name": "Tinker",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.H09TZlg2TKyYH9ZJ",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "H50Bw92jcDYAdrKY",
        "name": "Astral Conclave",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.H50Bw92jcDYAdrKY",
        "validId": true,
        "category": "utility",
        "ppCost": 16,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "H6FhU5LfzEIQuEDf",
        "name": "Shape Of The Fey",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.H6FhU5LfzEIQuEDf",
        "validId": true,
        "category": "utility",
        "ppCost": 8,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "H6i0UU67fAYxmIkg",
        "name": "Orb Of Acid",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.H6i0UU67fAYxmIkg",
        "validId": true,
        "category": "attack",
        "ppCost": 0,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "H8VPvAk0C1vEljVF",
        "name": "Sonic Rupture",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.H8VPvAk0C1vEljVF",
        "validId": true,
        "category": "save",
        "ppCost": 20,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "H8fdv8AvugOjgsO6",
        "name": "Invisibility Purge",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.H8fdv8AvugOjgsO6",
        "validId": true,
        "category": "utility",
        "ppCost": 8,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "HAHEP0vfuGU1uWvX",
        "name": "Anticipate Casting",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.HAHEP0vfuGU1uWvX",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "HAXD7XTseKDcXZOo",
        "name": "Animal Staff",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.HAXD7XTseKDcXZOo",
        "validId": true,
        "category": "utility",
        "ppCost": 10,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "HSssetVNQdZYqpbG",
        "name": "Shared Will",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.HSssetVNQdZYqpbG",
        "validId": true,
        "category": "utility",
        "ppCost": 12,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "HtaWzg4u2NZ30ybA",
        "name": "Spike Stones",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.HtaWzg4u2NZ30ybA",
        "validId": true,
        "category": "utility",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "HxbjWl5rt4QA8197",
        "name": "Veiled Secret",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.HxbjWl5rt4QA8197",
        "validId": true,
        "category": "utility",
        "ppCost": 7,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "HzTcLUSppux0O1hJ",
        "name": "Hold Animal",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.HzTcLUSppux0O1hJ",
        "validId": true,
        "category": "save",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "I0jq5uDNTSQZLPzG",
        "name": "Divinity Purge",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.I0jq5uDNTSQZLPzG",
        "validId": true,
        "category": "utility",
        "ppCost": 8,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "I50bP6N1oa2IWs23",
        "name": "Rope Trick",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.I50bP6N1oa2IWs23",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "I7E0XoDp7lCKyoAC",
        "name": "Detect Signature",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.I7E0XoDp7lCKyoAC",
        "validId": true,
        "category": "utility",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "ICWV12BVgZeEH31n",
        "name": "Life Siphon",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.ICWV12BVgZeEH31n",
        "validId": true,
        "category": "utility",
        "ppCost": 7,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "IGkAUAVhBy3f3vnW",
        "name": "Conjure Plant",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.IGkAUAVhBy3f3vnW",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "IJCAvfKhsd4XsaBp",
        "name": "Weapon Surge",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.IJCAvfKhsd4XsaBp",
        "validId": true,
        "category": "utility",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "ILIjBGHKoB18sy3P",
        "name": "Guidance",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.ILIjBGHKoB18sy3P",
        "validId": true,
        "category": "utility",
        "ppCost": 0,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "IOO4pCdQvhxacPnk",
        "name": "Silent Binding",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.IOO4pCdQvhxacPnk",
        "validId": true,
        "category": "save",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "IPUVRg3pYH9OdFWb",
        "name": "Telepathic Bond",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.IPUVRg3pYH9OdFWb",
        "validId": true,
        "category": "utility",
        "ppCost": 12,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "IPgxhROL24cGg6Se",
        "name": "Spell Storing",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.IPgxhROL24cGg6Se",
        "validId": true,
        "category": "utility",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "IRifqyc0C9WzoPA4",
        "name": "Ghostly Weapon",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.IRifqyc0C9WzoPA4",
        "validId": true,
        "category": "utility",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "IU85NcjSbc6HeiB2",
        "name": "Word Of Blinding",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.IU85NcjSbc6HeiB2",
        "validId": true,
        "category": "save",
        "ppCost": 14,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "IWSqsX6brZVgJq89",
        "name": "Delay Pain",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.IWSqsX6brZVgJq89",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "ImAyieo4jAr5S2Nn",
        "name": "Lightning Storm",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.ImAyieo4jAr5S2Nn",
        "validId": true,
        "category": "save",
        "ppCost": 12,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "Iprzhu9HTDUs7rSB",
        "name": "Conjure Elemental",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.Iprzhu9HTDUs7rSB",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "IqfuNNatFlQHWKk4",
        "name": "Haze Of Dreams",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.IqfuNNatFlQHWKk4",
        "validId": true,
        "category": "save",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "Itsv0tWeXV3lSXq3",
        "name": "War Cry",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.Itsv0tWeXV3lSXq3",
        "validId": true,
        "category": "utility",
        "ppCost": 7,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "J4uYxrwwvPVQsleh",
        "name": "Spook",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.J4uYxrwwvPVQsleh",
        "validId": true,
        "category": "utility",
        "ppCost": 0,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "JBPlwIdIljvbgwpS",
        "name": "Mirage Object",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.JBPlwIdIljvbgwpS",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "JU2PlDcolcFCdPmf",
        "name": "Veil Of The Shroud",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.JU2PlDcolcFCdPmf",
        "validId": true,
        "category": "utility",
        "ppCost": 8,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "JW5Vj8uNbdwFjTg7",
        "name": "Self Mirage",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.JW5Vj8uNbdwFjTg7",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "JWRG4TkGm15tlFdn",
        "name": "Divine Wrath",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.JWRG4TkGm15tlFdn",
        "validId": true,
        "category": "save",
        "ppCost": 8,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "JWdWTzDBk01Ccdc3",
        "name": "Protection From Arrows",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.JWdWTzDBk01Ccdc3",
        "validId": true,
        "category": "utility",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "JYNp65U03xE2s8pI",
        "name": "Fluidity",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.JYNp65U03xE2s8pI",
        "validId": true,
        "category": "utility",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "JbLRZfiWTKpk5W9O",
        "name": "Floating Disk",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.JbLRZfiWTKpk5W9O",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "Ji8qrqdlbZwElhz5",
        "name": "Scintillating Pattern",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.Ji8qrqdlbZwElhz5",
        "validId": true,
        "category": "save",
        "ppCost": 16,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "Jp0pyprZe6zAHfuQ",
        "name": "Unliving Vitality",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.Jp0pyprZe6zAHfuQ",
        "validId": true,
        "category": "utility",
        "ppCost": 7,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "JqIHqhqBYYoRxZQI",
        "name": "Fire Seeds",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.JqIHqhqBYYoRxZQI",
        "validId": true,
        "category": "save",
        "ppCost": 12,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "JugsYUFLJjQdtjIN",
        "name": "Windy Escape",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.JugsYUFLJjQdtjIN",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "JwtNthrpgBxHW7R3",
        "name": "Focus Mind",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.JwtNthrpgBxHW7R3",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "K0ZCDTLJRyiQ7jjV",
        "name": "Apocalypse",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.K0ZCDTLJRyiQ7jjV",
        "validId": true,
        "category": "save",
        "ppCost": 18,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "K2NCGttL8Gj0CWnd",
        "name": "Word Of Deafening",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.K2NCGttL8Gj0CWnd",
        "validId": true,
        "category": "save",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "K4hHrrBP5fyLZ8mU",
        "name": "Courage",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.K4hHrrBP5fyLZ8mU",
        "validId": true,
        "category": "utility",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "K6ihw1OjfgvX77NB",
        "name": "Animal Spirit",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.K6ihw1OjfgvX77NB",
        "validId": true,
        "category": "utility",
        "ppCost": 8,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "KDuXZmsu7DnBNlZg",
        "name": "Neutralise Poison",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.KDuXZmsu7DnBNlZg",
        "validId": true,
        "category": "utility",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "KEXvz7bOTEs0t1KX",
        "name": "False Vision",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.KEXvz7bOTEs0t1KX",
        "validId": true,
        "category": "utility",
        "ppCost": 12,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "KGj4patJ28WmlXL7",
        "name": "Mirage Entity",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.KGj4patJ28WmlXL7",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "KJKnVYT5wZG4YtOn",
        "name": "Pass Without Trace",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.KJKnVYT5wZG4YtOn",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "KKcBVCOQzxeGRcVL",
        "name": "Wild Morph",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.KKcBVCOQzxeGRcVL",
        "validId": true,
        "category": "utility",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "KXEvJOwZvqPRmRv9",
        "name": "Invisibility",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.KXEvJOwZvqPRmRv9",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "KYup23Hp426jQIUo",
        "name": "Whispering Wind",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.KYup23Hp426jQIUo",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "KeuHZmNaFEA3fbFq",
        "name": "Wall Of Light",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.KeuHZmNaFEA3fbFq",
        "validId": true,
        "category": "save",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "KgsW7TCVytuxcI80",
        "name": "Conjure Fey",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.KgsW7TCVytuxcI80",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "Kt0NsAfL9enES7Jk",
        "name": "Heightened Awareness",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.Kt0NsAfL9enES7Jk",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "KuAUSuldyanRsVg2",
        "name": "Meld Into Stone",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.KuAUSuldyanRsVg2",
        "validId": true,
        "category": "utility",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "KybGPRolRClZSqdy",
        "name": "Tanglefoot",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.KybGPRolRClZSqdy",
        "validId": true,
        "category": "attack",
        "ppCost": 0,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "L01Wii1yPMRP0xRB",
        "name": "Anticipate Attack",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.L01Wii1yPMRP0xRB",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "LD4uL9TuJGvufDKa",
        "name": "Devastating Might",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.LD4uL9TuJGvufDKa",
        "validId": true,
        "category": "utility",
        "ppCost": 7,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "LFYfxmDnfIBtAQKB",
        "name": "Orb Of The Void",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.LFYfxmDnfIBtAQKB",
        "validId": true,
        "category": "save",
        "ppCost": 16,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "LKD6o3fgtZRxNGjf",
        "name": "Acid Cloud",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.LKD6o3fgtZRxNGjf",
        "validId": true,
        "category": "save",
        "ppCost": 12,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "LLeNyPj0jx7gg1BT",
        "name": "Shape Of The Animal",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.LLeNyPj0jx7gg1BT",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "LLtkRT98lZmJQ2np",
        "name": "Acid Arrow",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.LLtkRT98lZmJQ2np",
        "validId": true,
        "category": "attack",
        "ppCost": 8,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "LVi7ITwedd0kxKUJ",
        "name": "Magic Vestment",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.LVi7ITwedd0kxKUJ",
        "validId": true,
        "category": "utility",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "LcKaz7mkjs3uOlsz",
        "name": "Orb Of Cold",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.LcKaz7mkjs3uOlsz",
        "validId": true,
        "category": "attack",
        "ppCost": 0,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "LqnD3eceytbVlzlU",
        "name": "Wizard Strike",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.LqnD3eceytbVlzlU",
        "validId": true,
        "category": "utility",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "Lt5u7N3ZRgwibycI",
        "name": "Clone",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.Lt5u7N3ZRgwibycI",
        "validId": true,
        "category": "utility",
        "ppCost": 18,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "M3az5fxEhAOVMyqV",
        "name": "Avatar",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.M3az5fxEhAOVMyqV",
        "validId": true,
        "category": "utility",
        "ppCost": 20,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "M4cmP1sq7YMVGaR0",
        "name": "Remove Curse",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.M4cmP1sq7YMVGaR0",
        "validId": true,
        "category": "utility",
        "ppCost": 8,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "M7yItXNC5G0kfM94",
        "name": "Maze",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.M7yItXNC5G0kfM94",
        "validId": true,
        "category": "save",
        "ppCost": 16,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "M9PAaAYA1sjB9W0l",
        "name": "Memory Lapse",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.M9PAaAYA1sjB9W0l",
        "validId": true,
        "category": "save",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "MFsDte7jrsMmaS2Y",
        "name": "Resilient Fortitude",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.MFsDte7jrsMmaS2Y",
        "validId": true,
        "category": "utility",
        "ppCost": 7,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "MNlt918lvXkVtBHS",
        "name": "Haste",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.MNlt918lvXkVtBHS",
        "validId": true,
        "category": "utility",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "MQQUo4Q52uWfY0p5",
        "name": "Shout",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.MQQUo4Q52uWfY0p5",
        "validId": true,
        "category": "save",
        "ppCost": 10,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "MUt8xwbkFbWdjnXX",
        "name": "Hide From Animals",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.MUt8xwbkFbWdjnXX",
        "validId": true,
        "category": "utility",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "MYiqjLwKXpvOr6ME",
        "name": "Spiritual Weapon",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.MYiqjLwKXpvOr6ME",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "Mhpof11zAdu6U2zc",
        "name": "Forget",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.Mhpof11zAdu6U2zc",
        "validId": true,
        "category": "save",
        "ppCost": 18,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "Mhw1EA1xR04v6bef",
        "name": "Stone To Flesh",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.Mhw1EA1xR04v6bef",
        "validId": true,
        "category": "utility",
        "ppCost": 12,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "MnxNGvHwHzcLnhvL",
        "name": "Face Shifting",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.MnxNGvHwHzcLnhvL",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "Mq8g17toefj3p8nK",
        "name": "Seer’s Vision",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.Mq8g17toefj3p8nK",
        "validId": true,
        "category": "utility",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "MsHZtN4BlytdmTu7",
        "name": "Shape Of The Elemental",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.MsHZtN4BlytdmTu7",
        "validId": true,
        "category": "utility",
        "ppCost": 10,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "MuOG49WQgzXrtC8x",
        "name": "Luminance",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.MuOG49WQgzXrtC8x",
        "validId": true,
        "category": "utility",
        "ppCost": 7,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "MvaAQyPilYUR6VQu",
        "name": "Shape Of The Humanoid",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.MvaAQyPilYUR6VQu",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "MypNjvJY1av3meBS",
        "name": "Silence",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.MypNjvJY1av3meBS",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "N5AOp7rgRrBM6sJx",
        "name": "Delayed Respite",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.N5AOp7rgRrBM6sJx",
        "validId": true,
        "category": "utility",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "ND5GVbIAfps1Fu2m",
        "name": "Wall Of Dispelling",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.ND5GVbIAfps1Fu2m",
        "validId": true,
        "category": "utility",
        "ppCost": 10,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "NEQqfAuxcONkFXFD",
        "name": "Dancing Lights",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.NEQqfAuxcONkFXFD",
        "validId": true,
        "category": "utility",
        "ppCost": 0,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "NGE7DuTohnGOISqF",
        "name": "Darkness",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.NGE7DuTohnGOISqF",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "NH7b1HXOACh5eHrj",
        "name": "Reverse Gravity",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.NH7b1HXOACh5eHrj",
        "validId": true,
        "category": "utility",
        "ppCost": 16,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "NHIKEFl0rhkXABTl",
        "name": "Repulsion",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.NHIKEFl0rhkXABTl",
        "validId": true,
        "category": "save",
        "ppCost": 10,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "NIt8Rd41XAaHlVwN",
        "name": "Charm Kind",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.NIt8Rd41XAaHlVwN",
        "validId": true,
        "category": "save",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "NMPil0Zft9n4ei2Q",
        "name": "Time Hop",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.NMPil0Zft9n4ei2Q",
        "validId": true,
        "category": "utility",
        "ppCost": 8,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "Nj4UZot5otFDMBpT",
        "name": "Deathless",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.Nj4UZot5otFDMBpT",
        "validId": true,
        "category": "utility",
        "ppCost": 10,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "Nxxj82DFaEbspYcz",
        "name": "Ethereal Jaunt",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.Nxxj82DFaEbspYcz",
        "validId": true,
        "category": "utility",
        "ppCost": 14,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "O090CMJRbUCoHLLt",
        "name": "Divine Might",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.O090CMJRbUCoHLLt",
        "validId": true,
        "category": "utility",
        "ppCost": 10,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "OEJmoYeJmQ0OFXWf",
        "name": "Foe To Friend",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.OEJmoYeJmQ0OFXWf",
        "validId": true,
        "category": "save",
        "ppCost": 16,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "OIHtUhXBlgVt1v22",
        "name": "Thrall",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.OIHtUhXBlgVt1v22",
        "validId": true,
        "category": "save",
        "ppCost": 18,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "OJLtoivEOXMeOCd1",
        "name": "Rage",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.OJLtoivEOXMeOCd1",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "OOXBHMrjz03UFWT7",
        "name": "Detect Undead",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.OOXBHMrjz03UFWT7",
        "validId": true,
        "category": "utility",
        "ppCost": 0,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "OUKR5Cipi3BMMUUD",
        "name": "Flame Strike",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.OUKR5Cipi3BMMUUD",
        "validId": true,
        "category": "save",
        "ppCost": 10,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "OUSi4n04MwG7wZzS",
        "name": "Deflect Flame",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.OUSi4n04MwG7wZzS",
        "validId": true,
        "category": "utility",
        "ppCost": 7,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "OW6BTKeOCvuluqDW",
        "name": "Hurling",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.OW6BTKeOCvuluqDW",
        "validId": true,
        "category": "attack",
        "ppCost": 0,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "OfYj0rehxqUVKYFL",
        "name": "Control Water",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.OfYj0rehxqUVKYFL",
        "validId": true,
        "category": "utility",
        "ppCost": 10,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "Olk3zBvHNFfCGfEK",
        "name": "Flawless Lies",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.Olk3zBvHNFfCGfEK",
        "validId": true,
        "category": "utility",
        "ppCost": 8,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "OrvG9ypDdRuZ82Mn",
        "name": "Protective Circle",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.OrvG9ypDdRuZ82Mn",
        "validId": true,
        "category": "utility",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "OuR0wqSqqhQYKVYl",
        "name": "Magic Jar",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.OuR0wqSqqhQYKVYl",
        "validId": true,
        "category": "save",
        "ppCost": 12,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "Oy6ihSUEGG939qGK",
        "name": "Shillelagh",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.Oy6ihSUEGG939qGK",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "PPjEcfHPTVjASzjU",
        "name": "Crashing Torrent",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.PPjEcfHPTVjASzjU",
        "validId": true,
        "category": "save",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "PX6SVhqjIgDAdpRB",
        "name": "Physical Surge",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.PX6SVhqjIgDAdpRB",
        "validId": true,
        "category": "utility",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "Pb9MVyTXRiK7FS5B",
        "name": "Tree Walk",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.Pb9MVyTXRiK7FS5B",
        "validId": true,
        "category": "utility",
        "ppCost": 10,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "PciK3KfxsGSoRoj3",
        "name": "Jump",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.PciK3KfxsGSoRoj3",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "PlHukVrzcn85Cpfi",
        "name": "Purge The Unlife",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.PlHukVrzcn85Cpfi",
        "validId": true,
        "category": "save",
        "ppCost": 7,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "PnOMu1Td7O59uIJ5",
        "name": "Acidic Spray",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.PnOMu1Td7O59uIJ5",
        "validId": true,
        "category": "save",
        "ppCost": 10,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "PoykpRFcylevQGxX",
        "name": "Pale Flame",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.PoykpRFcylevQGxX",
        "validId": true,
        "category": "save",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "Ps5KIjXtbViN99UY",
        "name": "Feather Fall",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.Ps5KIjXtbViN99UY",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "Q0OWeNQv1pSVicGX",
        "name": "Idiocy",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.Q0OWeNQv1pSVicGX",
        "validId": true,
        "category": "save",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "Q1b77oMpm7LjS9d4",
        "name": "Talon Strike",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.Q1b77oMpm7LjS9d4",
        "validId": true,
        "category": "utility",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "QIR8J741Q3TIXn7U",
        "name": "Eldritch Touch",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.QIR8J741Q3TIXn7U",
        "validId": true,
        "category": "attack",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "QKpVS7RKgCAuTYQX",
        "name": "Petrification",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.QKpVS7RKgCAuTYQX",
        "validId": true,
        "category": "save",
        "ppCost": 14,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "QKqTxQ2TcgvzrW5Q",
        "name": "Lullaby",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.QKqTxQ2TcgvzrW5Q",
        "validId": true,
        "category": "save",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "QKqbWi9YJGMF88KT",
        "name": "Word Of Distraction",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.QKqbWi9YJGMF88KT",
        "validId": true,
        "category": "save",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "QTYHHdHOcMOKn2gP",
        "name": "Endure Elements",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.QTYHHdHOcMOKn2gP",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "Qdi9jaCqPjfiCI1A",
        "name": "Disjunction",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.Qdi9jaCqPjfiCI1A",
        "validId": true,
        "category": "save",
        "ppCost": 18,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "Qhuaw9WZy7J7JxNM",
        "name": "Polymorph Other",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.Qhuaw9WZy7J7JxNM",
        "validId": true,
        "category": "save",
        "ppCost": 14,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "Qi1ly9NH4Ywh4XCJ",
        "name": "Wall Of Stone",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.Qi1ly9NH4Ywh4XCJ",
        "validId": true,
        "category": "utility",
        "ppCost": 10,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "QklFQ2rHpVDUQ4E3",
        "name": "Prayer",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.QklFQ2rHpVDUQ4E3",
        "validId": true,
        "category": "utility",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "Qvsr90W2vOLvsell",
        "name": "Sanctuary",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.Qvsr90W2vOLvsell",
        "validId": true,
        "category": "save",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "QzuVizXo4whwxer4",
        "name": "Line Of Lightning",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.QzuVizXo4whwxer4",
        "validId": true,
        "category": "save",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "R0fI1IpD1QakHzok",
        "name": "Dark Tendrils",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.R0fI1IpD1QakHzok",
        "validId": true,
        "category": "save",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "R3XE3T9JFpsKrbYg",
        "name": "Augment Conjuration",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.R3XE3T9JFpsKrbYg",
        "validId": true,
        "category": "utility",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "R7EFHUiVyLZQPMxV",
        "name": "Light Feet",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.R7EFHUiVyLZQPMxV",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "R7kwSl6ezM9xYnrs",
        "name": "Turn Undead",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.R7kwSl6ezM9xYnrs",
        "validId": true,
        "category": "save",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "RUPrV0tvgAZSvevu",
        "name": "Soothing Ballad",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.RUPrV0tvgAZSvevu",
        "validId": true,
        "category": "utility",
        "ppCost": 13,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "Rpa9YlyhfXBotJOy",
        "name": "Verbal Abuse",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.Rpa9YlyhfXBotJOy",
        "validId": true,
        "category": "save",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "RqfGOKvFRrPLMm6l",
        "name": "True Seeing",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.RqfGOKvFRrPLMm6l",
        "validId": true,
        "category": "utility",
        "ppCost": 14,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "RwNtwqOMRrGuaLqP",
        "name": "Conjure Swarm",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.RwNtwqOMRrGuaLqP",
        "validId": true,
        "category": "utility",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "S2iD6jkxvax4UCkO",
        "name": "Confounded Imagery",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.S2iD6jkxvax4UCkO",
        "validId": true,
        "category": "save",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "SDH1nvDzvGzBLV0v",
        "name": "Animate Dead",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.SDH1nvDzvGzBLV0v",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "SON6aXOQDbVgxe1t",
        "name": "Dominate",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.SON6aXOQDbVgxe1t",
        "validId": true,
        "category": "save",
        "ppCost": 14,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "SiEVqyrKTo0OMDs6",
        "name": "Spell Turning",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.SiEVqyrKTo0OMDs6",
        "validId": true,
        "category": "utility",
        "ppCost": 14,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "SifdJ1ezTvOGeHvq",
        "name": "Ember Of Devotion",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.SifdJ1ezTvOGeHvq",
        "validId": true,
        "category": "utility",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "Sk6qK4YlmZ2nrNQt",
        "name": "Freezing Weapon",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.Sk6qK4YlmZ2nrNQt",
        "validId": true,
        "category": "utility",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "SkZo3sp6tluAuEZR",
        "name": "Telekinetic Haul",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.SkZo3sp6tluAuEZR",
        "validId": true,
        "category": "utility",
        "ppCost": 10,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "SlXbwidr8lEnqW4T",
        "name": "Magesword",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.SlXbwidr8lEnqW4T",
        "validId": true,
        "category": "attack",
        "ppCost": 14,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "SnBNsaZ9XZdumhuB",
        "name": "Channel The Aspect",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.SnBNsaZ9XZdumhuB",
        "validId": true,
        "category": "utility",
        "ppCost": 8,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "SnNfbtriRCY3tjCw",
        "name": "Dance Macabre",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.SnNfbtriRCY3tjCw",
        "validId": true,
        "category": "save",
        "ppCost": 16,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "SngyIc9DLvI6Av6c",
        "name": "False Health",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.SngyIc9DLvI6Av6c",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "SpxiiK0lgdiEPzJg",
        "name": "Inflict",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.SpxiiK0lgdiEPzJg",
        "validId": true,
        "category": "save",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "SxjKvIH8dMdiKUQS",
        "name": "Haunting Miasma",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.SxjKvIH8dMdiKUQS",
        "validId": true,
        "category": "utility",
        "ppCost": 7,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "SywSzShaLgkMiBXQ",
        "name": "Acidic Eruption",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.SywSzShaLgkMiBXQ",
        "validId": true,
        "category": "save",
        "ppCost": 16,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "T0dEIDHpfPjQk8HC",
        "name": "Mirage Scene",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.T0dEIDHpfPjQk8HC",
        "validId": true,
        "category": "utility",
        "ppCost": 10,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "T2MtzStBdTeSaBFG",
        "name": "Hypercognition",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.T2MtzStBdTeSaBFG",
        "validId": true,
        "category": "utility",
        "ppCost": 14,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "T4Zp7jGESKVmlUDx",
        "name": "Loremasters Edge",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.T4Zp7jGESKVmlUDx",
        "validId": true,
        "category": "utility",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "TEMOnLYG1wqAHLg1",
        "name": "Forbidding Ward",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.TEMOnLYG1wqAHLg1",
        "validId": true,
        "category": "utility",
        "ppCost": 0,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "TIXbtHYzsBKO9TjL",
        "name": "Heal",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.TIXbtHYzsBKO9TjL",
        "validId": true,
        "category": "utility",
        "ppCost": 16,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "TKT592HsQGZOoDuR",
        "name": "Spell Transfer",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.TKT592HsQGZOoDuR",
        "validId": true,
        "category": "utility",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "TX8e5Fe1SdVZr7zi",
        "name": "Death Knell",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.TX8e5Fe1SdVZr7zi",
        "validId": true,
        "category": "save",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "TYDg4EcoB7QveLPP",
        "name": "Guiding Stone",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.TYDg4EcoB7QveLPP",
        "validId": true,
        "category": "attack",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "Tnc3zvldgUC5IqPy",
        "name": "Bungle",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.Tnc3zvldgUC5IqPy",
        "validId": true,
        "category": "save",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "Tv6MwLQp6oQXNZOp",
        "name": "Vigilant Eye",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.Tv6MwLQp6oQXNZOp",
        "validId": true,
        "category": "utility",
        "ppCost": 7,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "U1M94gyiTDQOOWG7",
        "name": "Cloak Of Greying",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.U1M94gyiTDQOOWG7",
        "validId": true,
        "category": "save",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "U2kkP1mxVvwSLn04",
        "name": "Anticipations",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.U2kkP1mxVvwSLn04",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "U9swXtZg4cakXKW8",
        "name": "Punishing Winds",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.U9swXtZg4cakXKW8",
        "validId": true,
        "category": "utility",
        "ppCost": 16,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "UAYnKq5ESFh5KID6",
        "name": "Divine Favour",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.UAYnKq5ESFh5KID6",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "UCEVR7gkSL8rKgSQ",
        "name": "Ventriloquism",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.UCEVR7gkSL8rKgSQ",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "Uj4MBMfezQjXuJSk",
        "name": "Vibrant Thorns",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.Uj4MBMfezQjXuJSk",
        "validId": true,
        "category": "utility",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "UkXDcjcewfJcMqhv",
        "name": "Breeze",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.UkXDcjcewfJcMqhv",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "UseJd4IyMyNdut1K",
        "name": "Cloud Mind",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.UseJd4IyMyNdut1K",
        "validId": true,
        "category": "save",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "UuwUj0jUuHrBpCuX",
        "name": "Dancing Weapon",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.UuwUj0jUuHrBpCuX",
        "validId": true,
        "category": "utility",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "UwdFC0Vxb5kfLlJQ",
        "name": "Planar Ally",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.UwdFC0Vxb5kfLlJQ",
        "validId": true,
        "category": "utility",
        "ppCost": 8,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "V2whesm8Yj9suHx2",
        "name": "Commune",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.V2whesm8Yj9suHx2",
        "validId": true,
        "category": "utility",
        "ppCost": 10,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "VCaQ52kMcm2AluIm",
        "name": "Unremarkable Aura",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.VCaQ52kMcm2AluIm",
        "validId": true,
        "category": "utility",
        "ppCost": 14,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "VDNCgXVa015bUvLm",
        "name": "Lighten Object",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.VDNCgXVa015bUvLm",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "VG8yUQgoQzQXoMdu",
        "name": "Divine Decree",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.VG8yUQgoQzQXoMdu",
        "validId": true,
        "category": "save",
        "ppCost": 14,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "VNy6klqCtdXK3hSV",
        "name": "Telekinetic Manoeuvre",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.VNy6klqCtdXK3hSV",
        "validId": true,
        "category": "attack",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "VQO8Nvx4fEjqVSot",
        "name": "Consecrate",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.VQO8Nvx4fEjqVSot",
        "validId": true,
        "category": "utility",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "VR9OCQ6C0PxDEYWb",
        "name": "Mirage Terrain",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.VR9OCQ6C0PxDEYWb",
        "validId": true,
        "category": "utility",
        "ppCost": 8,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "VVDryfiRVB2MbSSC",
        "name": "Polar Ray",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.VVDryfiRVB2MbSSC",
        "validId": true,
        "category": "attack",
        "ppCost": 16,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "VazVzU3S2kI4z5hR",
        "name": "Inspire Competence",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.VazVzU3S2kI4z5hR",
        "validId": true,
        "category": "utility",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "VdABfFQKaxAeaLyN",
        "name": "Abjurers Strike",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.VdABfFQKaxAeaLyN",
        "validId": true,
        "category": "utility",
        "ppCost": 18,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "VoGxdpC1Gwj30Pn2",
        "name": "Long Arm",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.VoGxdpC1Gwj30Pn2",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "VrRoYfZxwqmNfsVQ",
        "name": "Transmute Rock & Mud",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.VrRoYfZxwqmNfsVQ",
        "validId": true,
        "category": "utility",
        "ppCost": 10,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "VsIBMZnCuIpKqu9B",
        "name": "Charm Undead",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.VsIBMZnCuIpKqu9B",
        "validId": true,
        "category": "save",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "VuadmHk7GUVwAKAy",
        "name": "Iron Wood",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.VuadmHk7GUVwAKAy",
        "validId": true,
        "category": "utility",
        "ppCost": 12,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "VzSuKeENZZRMVbig",
        "name": "Hunter’s Veil",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.VzSuKeENZZRMVbig",
        "validId": true,
        "category": "utility",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "W1yP7TQBXglpFesc",
        "name": "Cognitive Collapse",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.W1yP7TQBXglpFesc",
        "validId": true,
        "category": "save",
        "ppCost": 12,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "W5HvZvNsNyHxgHpW",
        "name": "Metabolism",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.W5HvZvNsNyHxgHpW",
        "validId": true,
        "category": "utility",
        "ppCost": 18,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "W7Q6IoOBdMAeKhPp",
        "name": "Bless Water",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.W7Q6IoOBdMAeKhPp",
        "validId": true,
        "category": "utility",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "WBhDZNJ8Kz28uDLS",
        "name": "Implosion",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.WBhDZNJ8Kz28uDLS",
        "validId": true,
        "category": "save",
        "ppCost": 18,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "WGKtjB9QRBVIywRl",
        "name": "Sleep",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.WGKtjB9QRBVIywRl",
        "validId": true,
        "category": "save",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "WMAGpsiTmRkzWmxf",
        "name": "Calm",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.WMAGpsiTmRkzWmxf",
        "validId": true,
        "category": "save",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "WSWICegk6FSVKkWO",
        "name": "Dimension Door",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.WSWICegk6FSVKkWO",
        "validId": true,
        "category": "utility",
        "ppCost": 8,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "WWvDqwf2PismYade",
        "name": "Spectral Grasp",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.WWvDqwf2PismYade",
        "validId": true,
        "category": "attack",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "Wcn5p0A7ca3o65K5",
        "name": "Defer Fatality",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.Wcn5p0A7ca3o65K5",
        "validId": true,
        "category": "utility",
        "ppCost": 14,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "WdcEGAktYmX0st7R",
        "name": "Cloudkill",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.WdcEGAktYmX0st7R",
        "validId": true,
        "category": "save",
        "ppCost": 10,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "WiV7f8pVkkgEcJbA",
        "name": "Embrace Destiny",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.WiV7f8pVkkgEcJbA",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "WkNI4vlZuWGNLAQr",
        "name": "Revelation Divine",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.WkNI4vlZuWGNLAQr",
        "validId": true,
        "category": "utility",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "Wpm3mmDpGMSiyL3x",
        "name": "Rune Of Warning",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.Wpm3mmDpGMSiyL3x",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "X41BCMn5c1PoM4td",
        "name": "Icy Draft",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.X41BCMn5c1PoM4td",
        "validId": true,
        "category": "save",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "X8T2PTPgIvTOTb4H",
        "name": "Planar Enquiry",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.X8T2PTPgIvTOTb4H",
        "validId": true,
        "category": "utility",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "XFfhqCPZbB7gpNCk",
        "name": "Glyph Of Protection",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.XFfhqCPZbB7gpNCk",
        "validId": true,
        "category": "utility",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "XGkr7AuaHSA1qV2j",
        "name": "Prescience",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.XGkr7AuaHSA1qV2j",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "XNJ4wEM68JB1b4o4",
        "name": "Learned Council",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.XNJ4wEM68JB1b4o4",
        "validId": true,
        "category": "utility",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "XR0khgrlR74zGIwG",
        "name": "Self Healing",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.XR0khgrlR74zGIwG",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "XTb9BhdmAKhgHUEa",
        "name": "Detect Poison",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.XTb9BhdmAKhgHUEa",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "Xn5FfWKVbuQXdXmc",
        "name": "Rapid Repair",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.Xn5FfWKVbuQXdXmc",
        "validId": true,
        "category": "utility",
        "ppCost": 12,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "XrHhA5iIWG3J5bFj",
        "name": "Goodberry",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.XrHhA5iIWG3J5bFj",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "Xv6CwR1EaN43aHQ2",
        "name": "Glimpse",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.Xv6CwR1EaN43aHQ2",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "XwA4h7AXLLBTaBnw",
        "name": "Jam Construct",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.XwA4h7AXLLBTaBnw",
        "validId": true,
        "category": "save",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "Y7eC8WzRALZD04tF",
        "name": "Deific Presence",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.Y7eC8WzRALZD04tF",
        "validId": true,
        "category": "save",
        "ppCost": 18,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "YKizgdLnI4eR6AvS",
        "name": "Eternal Aspect",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.YKizgdLnI4eR6AvS",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "YP34ENtn1qb7E5rX",
        "name": "Umbral Blast",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.YP34ENtn1qb7E5rX",
        "validId": true,
        "category": "save",
        "ppCost": 14,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "YVjohw0b28BDhjMf",
        "name": "Indomitable",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.YVjohw0b28BDhjMf",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "YbawMG1kbfMlYEGl",
        "name": "Conceal Thoughts",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.YbawMG1kbfMlYEGl",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "Ye9edaIOxWzNcbsf",
        "name": "Shape Stone",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.Ye9edaIOxWzNcbsf",
        "validId": true,
        "category": "utility",
        "ppCost": 8,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "YeaBzCTYaPxcgQxT",
        "name": "Barkskin",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.YeaBzCTYaPxcgQxT",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "Yhrmy8oZhCQ9MY6l",
        "name": "Lay On Hands",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.Yhrmy8oZhCQ9MY6l",
        "validId": true,
        "category": "utility",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "ZBTqdX2tr8c0NbDu",
        "name": "Massacre",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.ZBTqdX2tr8c0NbDu",
        "validId": true,
        "category": "save",
        "ppCost": 18,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "ZDYGI8lH58ZmlSVT",
        "name": "Entropic Shield",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.ZDYGI8lH58ZmlSVT",
        "validId": true,
        "category": "save",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "ZOg9NnDj7qRNRoPw",
        "name": "Size Alteration",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.ZOg9NnDj7qRNRoPw",
        "validId": true,
        "category": "utility",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "ZTVoLzddiCfT3LIg",
        "name": "Detect Scrying",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.ZTVoLzddiCfT3LIg",
        "validId": true,
        "category": "utility",
        "ppCost": 8,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "ZUkOctDI4OvSSKHG",
        "name": "Earth Glide",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.ZUkOctDI4OvSSKHG",
        "validId": true,
        "category": "utility",
        "ppCost": 8,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "ZdoAlE95jl11d6Kn",
        "name": "Fireball",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.ZdoAlE95jl11d6Kn",
        "validId": true,
        "category": "save",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "ZoyOsIqJlfZLR8JB",
        "name": "Startle",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.ZoyOsIqJlfZLR8JB",
        "validId": true,
        "category": "save",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "ZvfN1odHCMwowd91",
        "name": "Changing Lungs",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.ZvfN1odHCMwowd91",
        "validId": true,
        "category": "utility",
        "ppCost": 8,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "a0Bxm98wSStLUwk3",
        "name": "Sacrificing Shield",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.a0Bxm98wSStLUwk3",
        "validId": true,
        "category": "utility",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "aGHpzF1iveIk0DDR",
        "name": "Ball Lightning",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.aGHpzF1iveIk0DDR",
        "validId": true,
        "category": "save",
        "ppCost": 16,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "aHjhb6FQTebi8MMU",
        "name": "Grant Spell",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.aHjhb6FQTebi8MMU",
        "validId": true,
        "category": "utility",
        "ppCost": 8,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "aK91Ucsg8UIWnoNE",
        "name": "Displacement",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.aK91Ucsg8UIWnoNE",
        "validId": true,
        "category": "utility",
        "ppCost": 10,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "aZq9YyyfFFpOfngH",
        "name": "Cone Of Death",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.aZq9YyyfFFpOfngH",
        "validId": true,
        "category": "save",
        "ppCost": 12,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "abvWPERJIgyRQaNr",
        "name": "Spirit Mark",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.abvWPERJIgyRQaNr",
        "validId": true,
        "category": "save",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "acprzpcDF2XMU0Mj",
        "name": "Desecrate",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.acprzpcDF2XMU0Mj",
        "validId": true,
        "category": "utility",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "adUMGc90ELL7Mv53",
        "name": "Verdant Retribution",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.adUMGc90ELL7Mv53",
        "validId": true,
        "category": "utility",
        "ppCost": 14,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "ah1PBMaWKQfYQNFI",
        "name": "Shield Of Faith",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.ah1PBMaWKQfYQNFI",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "ahPHYeuqP4bpUakI",
        "name": "Chain Lightning",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.ahPHYeuqP4bpUakI",
        "validId": true,
        "category": "save",
        "ppCost": 12,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "aildiWTyMJBcbNDP",
        "name": "Conjure Entity",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.aildiWTyMJBcbNDP",
        "validId": true,
        "category": "utility",
        "ppCost": 12,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "ajCEZ8xGBJVpQgXw",
        "name": "Continual Light",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.ajCEZ8xGBJVpQgXw",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "ankvBdmXafqMYgg9",
        "name": "Effortless Armour",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.ankvBdmXafqMYgg9",
        "validId": true,
        "category": "utility",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "askO35JQaAsXuYbw",
        "name": "Possession",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.askO35JQaAsXuYbw",
        "validId": true,
        "category": "save",
        "ppCost": 14,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "axHMt8G2V9vwCDF2",
        "name": "Solitude",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.axHMt8G2V9vwCDF2",
        "validId": true,
        "category": "utility",
        "ppCost": 10,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "b0CLkc1ohwG2GCtl",
        "name": "Spoil The Profane",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.b0CLkc1ohwG2GCtl",
        "validId": true,
        "category": "utility",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "b1mrFl5qAqe3mYHt",
        "name": "Create Undead",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.b1mrFl5qAqe3mYHt",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "b3GVjckDmgME42Ck",
        "name": "Reincarnated Embrace",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.b3GVjckDmgME42Ck",
        "validId": true,
        "category": "utility",
        "ppCost": 7,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "b4HWfOwnvuPZubxm",
        "name": "Cold Bolt",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.b4HWfOwnvuPZubxm",
        "validId": true,
        "category": "attack",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "bHStISxO1sm6HRXP",
        "name": "Sleepwalker",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.bHStISxO1sm6HRXP",
        "validId": true,
        "category": "save",
        "ppCost": 14,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "bOB06WumhIE7f7ra",
        "name": "Tree Shape",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.bOB06WumhIE7f7ra",
        "validId": true,
        "category": "utility",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "bcgaLLK9csOijFVp",
        "name": "Spell Prime",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.bcgaLLK9csOijFVp",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "bqrmzohKCsLd9pyq",
        "name": "Gravity Weapon",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.bqrmzohKCsLd9pyq",
        "validId": true,
        "category": "utility",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "bu39yfYlrcDTntyd",
        "name": "Guiding Bolt",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.bu39yfYlrcDTntyd",
        "validId": true,
        "category": "attack",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "bzRLL4X3POcFLlyf",
        "name": "Force Punch",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.bzRLL4X3POcFLlyf",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "c1m82FRda0Akzeyr",
        "name": "Spirit Blast",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.c1m82FRda0Akzeyr",
        "validId": true,
        "category": "save",
        "ppCost": 14,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "c6GLwl5uvlgEJVVG",
        "name": "Long Stride",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.c6GLwl5uvlgEJVVG",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "c9ZIGhfnkHQ6GdzH",
        "name": "Detect Aura",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.c9ZIGhfnkHQ6GdzH",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "c9nehkhtQcQqJdWS",
        "name": "Sending",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.c9nehkhtQcQqJdWS",
        "validId": true,
        "category": "utility",
        "ppCost": 10,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "cCIwJG6XSmB6Q5xs",
        "name": "Ride The Lightning",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.cCIwJG6XSmB6Q5xs",
        "validId": true,
        "category": "utility",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "cL7QBfeAK2A2V792",
        "name": "Cutting Words",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.cL7QBfeAK2A2V792",
        "validId": true,
        "category": "save",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "selfApplying"
          ]
        }
      },
      {
        "id": "cRgeP6RcIwGJa3GD",
        "name": "Draining Burst",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.cRgeP6RcIwGJa3GD",
        "validId": true,
        "category": "save",
        "ppCost": 20,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "cSqG5wkq0JNKBkzJ",
        "name": "Snagging Pit",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.cSqG5wkq0JNKBkzJ",
        "validId": true,
        "category": "save",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "cVjosgbimYKkOQVV",
        "name": "Ray Of Enfeeblement",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.cVjosgbimYKkOQVV",
        "validId": true,
        "category": "save",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "cZuB4Wo2oCLGWSmC",
        "name": "Crushing Despair",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.cZuB4Wo2oCLGWSmC",
        "validId": true,
        "category": "save",
        "ppCost": 10,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "ccxtz6wGwFp56Ndp",
        "name": "Flame Blade",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.ccxtz6wGwFp56Ndp",
        "validId": true,
        "category": "utility",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "ccy6S0Qk1wfJOzwP",
        "name": "Battle’s Call",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.ccy6S0Qk1wfJOzwP",
        "validId": true,
        "category": "utility",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "chuD4Cn9H20jDq6L",
        "name": "Fire Storm",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.chuD4Cn9H20jDq6L",
        "validId": true,
        "category": "save",
        "ppCost": 16,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "ckWwMQJut9rOrTUj",
        "name": "Conjuration Shield",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.ckWwMQJut9rOrTUj",
        "validId": true,
        "category": "save",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "co6aFFqk9ewnSTvz",
        "name": "Fiery Body",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.co6aFFqk9ewnSTvz",
        "validId": true,
        "category": "utility",
        "ppCost": 14,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "cwLtFE3mLCPpswLE",
        "name": "Circle Of Warmth",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.cwLtFE3mLCPpswLE",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "cwd4MS9pi56IOjPG",
        "name": "Augury",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.cwd4MS9pi56IOjPG",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "d8Udnmzootnj3HTY",
        "name": "Earthquake",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.d8Udnmzootnj3HTY",
        "validId": true,
        "category": "save",
        "ppCost": 18,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "dAlNH9FQfEW3NyQ3",
        "name": "Truthful Words",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.dAlNH9FQfEW3NyQ3",
        "validId": true,
        "category": "utility",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "dHZ53tl6LQsKMJI7",
        "name": "Aura",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.dHZ53tl6LQsKMJI7",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "dHaAh56i8RJiCcjR",
        "name": "Volcanic Inferno",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.dHaAh56i8RJiCcjR",
        "validId": true,
        "category": "save",
        "ppCost": 14,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "dPjkoT6IZuMtiJTQ",
        "name": "Enthrall",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.dPjkoT6IZuMtiJTQ",
        "validId": true,
        "category": "save",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "dS7KNYsPsahwcUoR",
        "name": "Deathwatch",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.dS7KNYsPsahwcUoR",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "dj9RBJyyJgyozs8n",
        "name": "Swallow Soul",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.dj9RBJyyJgyozs8n",
        "validId": true,
        "category": "utility",
        "ppCost": 8,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "e2dubL5AxTTXgx02",
        "name": "Searing Ray",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.e2dubL5AxTTXgx02",
        "validId": true,
        "category": "attack",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "eAAh1E4O6F4469NZ",
        "name": "Burning Hands",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.eAAh1E4O6F4469NZ",
        "validId": true,
        "category": "save",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "eDEpK7SaJY8TiuW2",
        "name": "Retrocognition",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.eDEpK7SaJY8TiuW2",
        "validId": true,
        "category": "utility",
        "ppCost": 14,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "eF5sg6lhmomS8XjP",
        "name": "Arcane Barrier",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.eF5sg6lhmomS8XjP",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "eIbaFDd6PE1AOjBy",
        "name": "Spell Immunity",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.eIbaFDd6PE1AOjBy",
        "validId": true,
        "category": "utility",
        "ppCost": 8,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "eJ1qXXPU6MbToS4G",
        "name": "Open/close",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.eJ1qXXPU6MbToS4G",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "ePF3HOG5DQ71aEer",
        "name": "Geas",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.ePF3HOG5DQ71aEer",
        "validId": true,
        "category": "utility",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "eQDTW6gOdCZFxqJ3",
        "name": "Fools Riches",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.eQDTW6gOdCZFxqJ3",
        "validId": true,
        "category": "utility",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "eRjL279wqEFhz8Hj",
        "name": "Water Walk",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.eRjL279wqEFhz8Hj",
        "validId": true,
        "category": "utility",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "eTvVer6CkVDopnS9",
        "name": "Brain Lock",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.eTvVer6CkVDopnS9",
        "validId": true,
        "category": "save",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "eYAqcKY4sybEPEh6",
        "name": "Crackling Tempest",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.eYAqcKY4sybEPEh6",
        "validId": true,
        "category": "save",
        "ppCost": 20,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "f361G8PJLpvAN9Cx",
        "name": "Oasis",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.f361G8PJLpvAN9Cx",
        "validId": true,
        "category": "utility",
        "ppCost": 14,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "fB6hqDEgUQGPAXZi",
        "name": "Wall Of Wind",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.fB6hqDEgUQGPAXZi",
        "validId": true,
        "category": "utility",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "fCwlGazdEsYXijKl",
        "name": "Knock",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.fCwlGazdEsYXijKl",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "fMR5fXa70H6EcFYP",
        "name": "Mind’s Double",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.fMR5fXa70H6EcFYP",
        "validId": true,
        "category": "save",
        "ppCost": 7,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "fdwqibYZrlxKEZgO",
        "name": "Heroism",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.fdwqibYZrlxKEZgO",
        "validId": true,
        "category": "utility",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "fnE6d2brWHNlTIey",
        "name": "Nightvision",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.fnE6d2brWHNlTIey",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "frJtDSWkpOJ64Y9z",
        "name": "Remove Paralysis",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.frJtDSWkpOJ64Y9z",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "g485nLzK7TbC57lh",
        "name": "Air Walk",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.g485nLzK7TbC57lh",
        "validId": true,
        "category": "utility",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "gBx4JnnMtyoA3rP3",
        "name": "Elemental Shield",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.gBx4JnnMtyoA3rP3",
        "validId": true,
        "category": "save",
        "ppCost": 10,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "gFNwBmrFoeEaPyhp",
        "name": "Lightning Bolt",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.gFNwBmrFoeEaPyhp",
        "validId": true,
        "category": "attack",
        "ppCost": 8,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "gFqAC7GsPuY9ah4i",
        "name": "Eldritch Bolt",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.gFqAC7GsPuY9ah4i",
        "validId": true,
        "category": "attack",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "gMg4AAE97A0FSdCP",
        "name": "Fateful Temptation",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.gMg4AAE97A0FSdCP",
        "validId": true,
        "category": "utility",
        "ppCost": 7,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "gZxhOOmW0GtS79VW",
        "name": "Magic Weapon",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.gZxhOOmW0GtS79VW",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "gfHeHKkvgFNoYR1C",
        "name": "Phantasmal Revenge",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.gfHeHKkvgFNoYR1C",
        "validId": true,
        "category": "save",
        "ppCost": 16,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "gkExKBpX5vgxOAae",
        "name": "Shape Of The Plant",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.gkExKBpX5vgxOAae",
        "validId": true,
        "category": "utility",
        "ppCost": 10,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "gkMYuS73Y3zQxdPW",
        "name": "Sonic Bolt",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.gkMYuS73Y3zQxdPW",
        "validId": true,
        "category": "attack",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "gqIMl2fNvYuqdkQn",
        "name": "Line Of Acid",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.gqIMl2fNvYuqdkQn",
        "validId": true,
        "category": "save",
        "ppCost": 8,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "gqXhIUjcbPKeFXdh",
        "name": "Insanity",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.gqXhIUjcbPKeFXdh",
        "validId": true,
        "category": "save",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "hS9Xh5CgbNxWMj7c",
        "name": "Animal Messenger",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.hS9Xh5CgbNxWMj7c",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "hZpFGhClavl25JI2",
        "name": "Mana Drain",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.hZpFGhClavl25JI2",
        "validId": true,
        "category": "save",
        "ppCost": 12,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "hj2W6Dukv0XcEPmI",
        "name": "Hindsight",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.hj2W6Dukv0XcEPmI",
        "validId": true,
        "category": "utility",
        "ppCost": 14,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "hkfrtOVc3Xzznqxo",
        "name": "Bane",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.hkfrtOVc3Xzznqxo",
        "validId": true,
        "category": "save",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "hqAbcATKNYoiDtxO",
        "name": "Inspire Defence",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.hqAbcATKNYoiDtxO",
        "validId": true,
        "category": "utility",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "hrMFkS9300EhGz61",
        "name": "Speak With Animals",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.hrMFkS9300EhGz61",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "i0RBF2O5HVYbmTT9",
        "name": "Obscuring Mist",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.i0RBF2O5HVYbmTT9",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "i1cNQHekvjN1GCFG",
        "name": "Magnificent Dawn",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.i1cNQHekvjN1GCFG",
        "validId": true,
        "category": "save",
        "ppCost": 20,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "i4x525srh0QckgHc",
        "name": "Misty Step",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.i4x525srh0QckgHc",
        "validId": true,
        "category": "utility",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "i6E7ipXMXwTaDEWA",
        "name": "Wind Walk",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.i6E7ipXMXwTaDEWA",
        "validId": true,
        "category": "utility",
        "ppCost": 16,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "iD713ZWAvZqmWQHM",
        "name": "Stone Call",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.iD713ZWAvZqmWQHM",
        "validId": true,
        "category": "save",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "iDI1N6R4BrXN3T8K",
        "name": "Locate",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.iDI1N6R4BrXN3T8K",
        "validId": true,
        "category": "utility",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "iHUKUjijj7VcLPlZ",
        "name": "Decursive Veil",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.iHUKUjijj7VcLPlZ",
        "validId": true,
        "category": "utility",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "iUpgbU5WkqMo69cd",
        "name": "Icy Spray",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.iUpgbU5WkqMo69cd",
        "validId": true,
        "category": "save",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "itHyi4nqsJH4AjVl",
        "name": "Slow",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.itHyi4nqsJH4AjVl",
        "validId": true,
        "category": "save",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "iz0y35TY7hNURjPP",
        "name": "Blur",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.iz0y35TY7hNURjPP",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "iz2OLVKaWaR034Ac",
        "name": "Disrupting Weapon",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.iz2OLVKaWaR034Ac",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "izKCEQuiA7iaPjBm",
        "name": "Missile Storm",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.izKCEQuiA7iaPjBm",
        "validId": true,
        "category": "utility",
        "ppCost": 20,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "j6oIw6XsqShPTUNG",
        "name": "Element Ward",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.j6oIw6XsqShPTUNG",
        "validId": true,
        "category": "utility",
        "ppCost": 7,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "jBscgPj2ndmngJ0g",
        "name": "Rainbow Cloak",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.jBscgPj2ndmngJ0g",
        "validId": true,
        "category": "utility",
        "ppCost": 10,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "jCP0epzMmO8SnLMa",
        "name": "Masterwork Item",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.jCP0epzMmO8SnLMa",
        "validId": true,
        "category": "utility",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "jCe3NJONPtQA0nUO",
        "name": "Shadow Weapon",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.jCe3NJONPtQA0nUO",
        "validId": true,
        "category": "utility",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "jFGAu6EPXzmUGQjV",
        "name": "Wall Of Fire",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.jFGAu6EPXzmUGQjV",
        "validId": true,
        "category": "save",
        "ppCost": 8,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "jFM4yfQhxEUCJ5DZ",
        "name": "Flame Arrow",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.jFM4yfQhxEUCJ5DZ",
        "validId": true,
        "category": "attack",
        "ppCost": 8,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "jSoXqi0pcsWauOOq",
        "name": "Antimagic Field",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.jSoXqi0pcsWauOOq",
        "validId": true,
        "category": "utility",
        "ppCost": 14,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "jWdvJa9qNbUX60td",
        "name": "Painful Rebuke",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.jWdvJa9qNbUX60td",
        "validId": true,
        "category": "save",
        "ppCost": 8,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "jY6rL8zLyDJIM3ja",
        "name": "Invisibility Sphere",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.jY6rL8zLyDJIM3ja",
        "validId": true,
        "category": "utility",
        "ppCost": 8,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "jZcYCm2VBOp7fr7a",
        "name": "Fleeting Speed",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.jZcYCm2VBOp7fr7a",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "jhCLuOgkluzLHTez",
        "name": "Magic Volley",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.jhCLuOgkluzLHTez",
        "validId": true,
        "category": "utility",
        "ppCost": 8,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "jmKpHpq2wEp4pgia",
        "name": "Freezing Touch",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.jmKpHpq2wEp4pgia",
        "validId": true,
        "category": "save",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "jtMLlXGK3PJQoBA4",
        "name": "Light",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.jtMLlXGK3PJQoBA4",
        "validId": true,
        "category": "utility",
        "ppCost": 0,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "jvftmyF10NXOhCAd",
        "name": "Metal To Wood",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.jvftmyF10NXOhCAd",
        "validId": true,
        "category": "utility",
        "ppCost": 16,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "jxOMnuoax3OPgdGA",
        "name": "Doubt",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.jxOMnuoax3OPgdGA",
        "validId": true,
        "category": "save",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "k1MOTNomGUMdbSjy",
        "name": "Adapt Body",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.k1MOTNomGUMdbSjy",
        "validId": true,
        "category": "utility",
        "ppCost": 12,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "kKsRcQMJPbcgJmRb",
        "name": "Identify",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.kKsRcQMJPbcgJmRb",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "kMrVKLuaw8A4jYYl",
        "name": "Project Image",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.kMrVKLuaw8A4jYYl",
        "validId": true,
        "category": "utility",
        "ppCost": 14,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "kPw01yV0VLyjkqVS",
        "name": "False Arrogance",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.kPw01yV0VLyjkqVS",
        "validId": true,
        "category": "save",
        "ppCost": 7,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "kRW2TTcMwuKoty32",
        "name": "Dimensional Lock",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.kRW2TTcMwuKoty32",
        "validId": true,
        "category": "utility",
        "ppCost": 12,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "kXs9rbcEjOKheDBf",
        "name": "Confusion",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.kXs9rbcEjOKheDBf",
        "validId": true,
        "category": "save",
        "ppCost": 8,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "kZImmhixb6PDE9vE",
        "name": "Prying Eye",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.kZImmhixb6PDE9vE",
        "validId": true,
        "category": "utility",
        "ppCost": 10,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "kdC9uahEmDemuSWx",
        "name": "Force Prison",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.kdC9uahEmDemuSWx",
        "validId": true,
        "category": "utility",
        "ppCost": 18,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "kxNlQgk4DPegMpY1",
        "name": "Chill Touch",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.kxNlQgk4DPegMpY1",
        "validId": true,
        "category": "save",
        "ppCost": 0,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "kxR044xkTAH53St7",
        "name": "Storm Of Vengeance",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.kxR044xkTAH53St7",
        "validId": true,
        "category": "save",
        "ppCost": 20,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "l6cw34OKmHq8hKKj",
        "name": "Word Of Biting",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.l6cw34OKmHq8hKKj",
        "validId": true,
        "category": "save",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "lA4CEGZNkEph6JgP",
        "name": "Resurrection",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.lA4CEGZNkEph6JgP",
        "validId": true,
        "category": "utility",
        "ppCost": 12,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "lC8H4tWgb7161YW5",
        "name": "Lay Of The Land",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.lC8H4tWgb7161YW5",
        "validId": true,
        "category": "utility",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "lNEsjn2QC9Q42Odd",
        "name": "Phantom",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.lNEsjn2QC9Q42Odd",
        "validId": true,
        "category": "save",
        "ppCost": 8,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "lOMtAjX9a8lutC3Z",
        "name": "Call Item",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.lOMtAjX9a8lutC3Z",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "lPugck9VdhBQezmj",
        "name": "Globe Of Cancellation",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.lPugck9VdhBQezmj",
        "validId": true,
        "category": "utility",
        "ppCost": 10,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "ld2MiNmXTgrMdjzI",
        "name": "Wall Of Force",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.ld2MiNmXTgrMdjzI",
        "validId": true,
        "category": "utility",
        "ppCost": 12,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "les0AZUed2Cl8szM",
        "name": "Blink",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.les0AZUed2Cl8szM",
        "validId": true,
        "category": "utility",
        "ppCost": 8,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "lfvqm3lbMBMnMxlW",
        "name": "Untamed Journey",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.lfvqm3lbMBMnMxlW",
        "validId": true,
        "category": "utility",
        "ppCost": 14,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "lhGfbLmwBvtZH40v",
        "name": "Control Undead",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.lhGfbLmwBvtZH40v",
        "validId": true,
        "category": "save",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "ljcY0i8Krl5uasR4",
        "name": "Shocking Grasp",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.ljcY0i8Krl5uasR4",
        "validId": true,
        "category": "attack",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "lkEv8RTBRlB6Jqtf",
        "name": "Shape Of The Aberrant",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.lkEv8RTBRlB6Jqtf",
        "validId": true,
        "category": "utility",
        "ppCost": 10,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "lzq8i5og0A5v49wd",
        "name": "Cloak Of Invisibility",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.lzq8i5og0A5v49wd",
        "validId": true,
        "category": "utility",
        "ppCost": 7,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "m3DZaNK0ATkvjj2H",
        "name": "Cure",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.m3DZaNK0ATkvjj2H",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "mHHIVJ1nUZkHfPci",
        "name": "Elude Time",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.mHHIVJ1nUZkHfPci",
        "validId": true,
        "category": "utility",
        "ppCost": 14,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "mHmRRhNnd9aAMWsC",
        "name": "Nondetection",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.mHmRRhNnd9aAMWsC",
        "validId": true,
        "category": "utility",
        "ppCost": 8,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "mVaAoygUZefFpJRt",
        "name": "Drop Dead",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.mVaAoygUZefFpJRt",
        "validId": true,
        "category": "utility",
        "ppCost": 10,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "mbaQTFDXtOBJLAL2",
        "name": "Conjure Giant",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.mbaQTFDXtOBJLAL2",
        "validId": true,
        "category": "utility",
        "ppCost": 10,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "mc7vEgLukxA2Gak4",
        "name": "Hydraulic Torrent",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.mc7vEgLukxA2Gak4",
        "validId": true,
        "category": "save",
        "ppCost": 8,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "mhH6dIdxDjqXd6BG",
        "name": "Click",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.mhH6dIdxDjqXd6BG",
        "validId": true,
        "category": "utility",
        "ppCost": 0,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "min5yZObD4QURmra",
        "name": "Align Weapon",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.min5yZObD4QURmra",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "mjDYamO1UBylykjY",
        "name": "Touch Of Obedience",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.mjDYamO1UBylykjY",
        "validId": true,
        "category": "save",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "mn1YaH9qlyv03YoG",
        "name": "Word Of Stunning",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.mn1YaH9qlyv03YoG",
        "validId": true,
        "category": "save",
        "ppCost": 16,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "mtFADhDfZsFBYHKc",
        "name": "Vigour",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.mtFADhDfZsFBYHKc",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "mv3jexkrBdhK8hcq",
        "name": "Contingency",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.mv3jexkrBdhK8hcq",
        "validId": true,
        "category": "utility",
        "ppCost": 14,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "mzaTfoyWYDyFYXIg",
        "name": "Cone Of Cold",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.mzaTfoyWYDyFYXIg",
        "validId": true,
        "category": "save",
        "ppCost": 10,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "n75APYkEiucA7x0g",
        "name": "Word Of Fatigue",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.n75APYkEiucA7x0g",
        "validId": true,
        "category": "save",
        "ppCost": 10,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "n7nNxFroXMYMXECl",
        "name": "Mark Of Faith",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.n7nNxFroXMYMXECl",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "nEqnWdk80BjxB6Wu",
        "name": "Pariah",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.nEqnWdk80BjxB6Wu",
        "validId": true,
        "category": "save",
        "ppCost": 10,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "nTa1ZoevupD3HJOa",
        "name": "Brawn",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.nTa1ZoevupD3HJOa",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "nWL42H9XxCKPIHep",
        "name": "Word Of Recall",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.nWL42H9XxCKPIHep",
        "validId": true,
        "category": "utility",
        "ppCost": 14,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "nX619juzaISKMAgc",
        "name": "Precious Metals",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.nX619juzaISKMAgc",
        "validId": true,
        "category": "utility",
        "ppCost": 7,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "nXkZZmqTvgLUReaJ",
        "name": "Inspiration",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.nXkZZmqTvgLUReaJ",
        "validId": true,
        "category": "utility",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "nffNk7IJquexfQKG",
        "name": "Stun Relief",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.nffNk7IJquexfQKG",
        "validId": true,
        "category": "utility",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "ng5qGomIiPAg7vx5",
        "name": "Shadow Tether",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.ng5qGomIiPAg7vx5",
        "validId": true,
        "category": "save",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "o1OCNA2i4bb7N2UO",
        "name": "Shapechange",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.o1OCNA2i4bb7N2UO",
        "validId": true,
        "category": "utility",
        "ppCost": 18,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "oPjGY9wvQvuFmSS1",
        "name": "Protector’s Sphere",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.oPjGY9wvQvuFmSS1",
        "validId": true,
        "category": "utility",
        "ppCost": 7,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "oToAlZkylPny2PJv",
        "name": "Deflections",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.oToAlZkylPny2PJv",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "oZRZVzKO9pBGwlve",
        "name": "Read Aura",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.oZRZVzKO9pBGwlve",
        "validId": true,
        "category": "utility",
        "ppCost": 0,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "oaxjFRo1ztawiptE",
        "name": "Hide From Undead",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.oaxjFRo1ztawiptE",
        "validId": true,
        "category": "save",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "p0dCj5nSzbI4lZv3",
        "name": "Divine Vision",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.p0dCj5nSzbI4lZv3",
        "validId": true,
        "category": "utility",
        "ppCost": 8,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "p6gl4AZVGyiWjLXM",
        "name": "Message",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.p6gl4AZVGyiWjLXM",
        "validId": true,
        "category": "utility",
        "ppCost": 0,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "pXIqKKtelrVYb02a",
        "name": "Ice Slick",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.pXIqKKtelrVYb02a",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "pZJWgKFcjfwxFz3e",
        "name": "Rune Of Warding",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.pZJWgKFcjfwxFz3e",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "pZqvGcMCBGVq8Dcf",
        "name": "Inner Focus",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.pZqvGcMCBGVq8Dcf",
        "validId": true,
        "category": "utility",
        "ppCost": 8,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "pal4lf7eQ2UiCb6N",
        "name": "Spirit Of The Hunt",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.pal4lf7eQ2UiCb6N",
        "validId": true,
        "category": "utility",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "peqXUMttMvnWqdsT",
        "name": "Forceful Strike",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.peqXUMttMvnWqdsT",
        "validId": true,
        "category": "utility",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "pfzB1z4Q40u5xEen",
        "name": "Conjuring Control",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.pfzB1z4Q40u5xEen",
        "validId": true,
        "category": "save",
        "ppCost": 10,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "ph4xFNDpCYsLrkzo",
        "name": "Waves Of Fatigue",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.ph4xFNDpCYsLrkzo",
        "validId": true,
        "category": "save",
        "ppCost": 8,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "pqMIafI5INf1LRka",
        "name": "Dareveil",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.pqMIafI5INf1LRka",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "pwSQ7dxlJnH6dznb",
        "name": "Warp Mind",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.pwSQ7dxlJnH6dznb",
        "validId": true,
        "category": "save",
        "ppCost": 14,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "q5xgykQDRPpJMH8s",
        "name": "True Strike",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.q5xgykQDRPpJMH8s",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "q61VUvInFUm7RYE5",
        "name": "Death’s Memory",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.q61VUvInFUm7RYE5",
        "validId": true,
        "category": "utility",
        "ppCost": 12,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "qVee6eoVIAq6iM0T",
        "name": "Flame Prison",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.qVee6eoVIAq6iM0T",
        "validId": true,
        "category": "utility",
        "ppCost": 16,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "qYNnXwAjYbmtD9Wq",
        "name": "Sensory Link",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.qYNnXwAjYbmtD9Wq",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "qb41npsiLIP0wuvI",
        "name": "Spot",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.qb41npsiLIP0wuvI",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "qdYAvMdgZdKk3AcY",
        "name": "Deafness",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.qdYAvMdgZdKk3AcY",
        "validId": true,
        "category": "save",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "qeuQnFwrtM24l0aM",
        "name": "Animal Sense",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.qeuQnFwrtM24l0aM",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "qrRisPjwYS53fQy5",
        "name": "Shape Of The Eternal",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.qrRisPjwYS53fQy5",
        "validId": true,
        "category": "utility",
        "ppCost": 12,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "qrUWuKrLNHSzwk1B",
        "name": "Quench",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.qrUWuKrLNHSzwk1B",
        "validId": true,
        "category": "save",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "qwTPWWunBDwA8gzF",
        "name": "Soul Bind",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.qwTPWWunBDwA8gzF",
        "validId": true,
        "category": "utility",
        "ppCost": 20,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "qyuaJq8xahY3Wz3J",
        "name": "Nature’s Bounty",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.qyuaJq8xahY3Wz3J",
        "validId": true,
        "category": "utility",
        "ppCost": 7,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "r1hmgdjy6uvOn7aV",
        "name": "Reincarnation",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.r1hmgdjy6uvOn7aV",
        "validId": true,
        "category": "utility",
        "ppCost": 10,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "rDudGJuqtqSyu0Vx",
        "name": "Keen Edge",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.rDudGJuqtqSyu0Vx",
        "validId": true,
        "category": "utility",
        "ppCost": 8,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "rHC6vLXNY63bhyMG",
        "name": "Stasis",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.rHC6vLXNY63bhyMG",
        "validId": true,
        "category": "save",
        "ppCost": 7,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "rJEkLmYuKRyW8vcE",
        "name": "Dream Message",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.rJEkLmYuKRyW8vcE",
        "validId": true,
        "category": "utility",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "rKA48oo3KjFhIXhE",
        "name": "Wellspring Of Valour",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.rKA48oo3KjFhIXhE",
        "validId": true,
        "category": "utility",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "rPZo3GfLyNjCLbSg",
        "name": "Speed",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.rPZo3GfLyNjCLbSg",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "rYFbd5mgZ7eyBAim",
        "name": "Protection",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.rYFbd5mgZ7eyBAim",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "raejRwe8BHfaa0Jg",
        "name": "Word Of Death",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.raejRwe8BHfaa0Jg",
        "validId": true,
        "category": "save",
        "ppCost": 20,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "rfQ4BSRIzIEDYCxr",
        "name": "Misdirection",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.rfQ4BSRIzIEDYCxr",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "roo4OdDedaMrtv39",
        "name": "Deific Knowing",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.roo4OdDedaMrtv39",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "rtOYt5JV1TGWZqcs",
        "name": "Natural Defence",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.rtOYt5JV1TGWZqcs",
        "validId": true,
        "category": "utility",
        "ppCost": 0,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "rvfdOEQ3wAXiVyVl",
        "name": "Conjure Animal",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.rvfdOEQ3wAXiVyVl",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "rvmesbZLaf1FvVZJ",
        "name": "Elemental Speech",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.rvmesbZLaf1FvVZJ",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "rwsxRcEJU7dDxud9",
        "name": "Energy Bolt",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.rwsxRcEJU7dDxud9",
        "validId": true,
        "category": "attack",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "ryyL11rlKWm5tmSr",
        "name": "Telepathy",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.ryyL11rlKWm5tmSr",
        "validId": true,
        "category": "utility",
        "ppCost": 8,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "rzkHqXgyCvjeYWgS",
        "name": "Meteor Swarm",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.rzkHqXgyCvjeYWgS",
        "validId": true,
        "category": "save",
        "ppCost": 18,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "s45sMu06HYW05MW9",
        "name": "Unshakable",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.s45sMu06HYW05MW9",
        "validId": true,
        "category": "utility",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "sJIF8j5PKHTYbu5e",
        "name": "Fatigue",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.sJIF8j5PKHTYbu5e",
        "validId": true,
        "category": "save",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "sLmvkgCN8SAwYUKz",
        "name": "Revealing Glance",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.sLmvkgCN8SAwYUKz",
        "validId": true,
        "category": "utility",
        "ppCost": 7,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "sN05PtSu8m9VMJez",
        "name": "See Invisible",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.sN05PtSu8m9VMJez",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "sTQsrNFq3puvRV09",
        "name": "Moment Of Fortune",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.sTQsrNFq3puvRV09",
        "validId": true,
        "category": "utility",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "sXKA8Fx8LBOligeh",
        "name": "Shield",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.sXKA8Fx8LBOligeh",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "sqz3rdiab2GiOmAf",
        "name": "Lucky Break",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.sqz3rdiab2GiOmAf",
        "validId": true,
        "category": "utility",
        "ppCost": 7,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "szAlaIxD22mBd0wI",
        "name": "Orientate",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.szAlaIxD22mBd0wI",
        "validId": true,
        "category": "utility",
        "ppCost": 0,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "tDZtarKDYGuE5N5Q",
        "name": "Unprepared Combatant",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.tDZtarKDYGuE5N5Q",
        "validId": true,
        "category": "save",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "tDcKp8knQRzuwduE",
        "name": "Suggestion",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.tDcKp8knQRzuwduE",
        "validId": true,
        "category": "save",
        "ppCost": 8,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "tJHUg4HlWk47S1LW",
        "name": "Animate Object",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.tJHUg4HlWk47S1LW",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "tY6pBdwftrDnU2EF",
        "name": "Conjure Wyrm",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.tY6pBdwftrDnU2EF",
        "validId": true,
        "category": "utility",
        "ppCost": 10,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "tYvCZhenj7XJNRSn",
        "name": "Shadow Form",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.tYvCZhenj7XJNRSn",
        "validId": true,
        "category": "utility",
        "ppCost": 8,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "tZulObNyDgMauD5u",
        "name": "Animal Healing",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.tZulObNyDgMauD5u",
        "validId": true,
        "category": "utility",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "tfmexM6bWc7X53YX",
        "name": "Protective Ward",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.tfmexM6bWc7X53YX",
        "validId": true,
        "category": "utility",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "tjQIrwPDdpPS2xTy",
        "name": "Charm Animal",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.tjQIrwPDdpPS2xTy",
        "validId": true,
        "category": "save",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "twfXl7SpSlmqu8dh",
        "name": "Calm Animal",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.twfXl7SpSlmqu8dh",
        "validId": true,
        "category": "save",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "u22Z1LHWwxBb16sg",
        "name": "Mirror Image",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.u22Z1LHWwxBb16sg",
        "validId": true,
        "category": "utility",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "u2FGfj8AUimbptR4",
        "name": "Voice Of Healing",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.u2FGfj8AUimbptR4",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "u2eDWrRPTKaOkIpZ",
        "name": "Fairy Fire",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.u2eDWrRPTKaOkIpZ",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "u5dsIHe45x6JJFW0",
        "name": "Mind Reading",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.u5dsIHe45x6JJFW0",
        "validId": true,
        "category": "save",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "u6fkcfTlVAM3hSdZ",
        "name": "Hand Of The Reaper",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.u6fkcfTlVAM3hSdZ",
        "validId": true,
        "category": "save",
        "ppCost": 14,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "u9jMzxYCzhlm6dig",
        "name": "Disappearance",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.u9jMzxYCzhlm6dig",
        "validId": true,
        "category": "utility",
        "ppCost": 18,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "uGP4UQ4tksNn3arV",
        "name": "Divine Grace",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.uGP4UQ4tksNn3arV",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "uPkMZexWzLmjVG94",
        "name": "Soul Bleed",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.uPkMZexWzLmjVG94",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "uWUV8FolXMeyvjoq",
        "name": "Object Prowess",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.uWUV8FolXMeyvjoq",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "uZ5CpytCeXRR1vob",
        "name": "Darkvision",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.uZ5CpytCeXRR1vob",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "v8V3ldupa3fqBHV6",
        "name": "Temporal Stasis",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.v8V3ldupa3fqBHV6",
        "validId": true,
        "category": "save",
        "ppCost": 16,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "vKvGOLtnEnqO6idI",
        "name": "Localised Quake",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.vKvGOLtnEnqO6idI",
        "validId": true,
        "category": "save",
        "ppCost": 7,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "vLu1ow5ypvaka53l",
        "name": "Trade Essence",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.vLu1ow5ypvaka53l",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "vdNVSs0yRhlZ4DIm",
        "name": "Magic Missile",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.vdNVSs0yRhlZ4DIm",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "viAmX2fMkcKUXpK1",
        "name": "Entangle",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.viAmX2fMkcKUXpK1",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "vk6TkgZBNpphWmtr",
        "name": "Orb Of Lightning",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.vk6TkgZBNpphWmtr",
        "validId": true,
        "category": "attack",
        "ppCost": 0,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "vl3DCmTXSNLNpdAA",
        "name": "Concealing Terrain",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.vl3DCmTXSNLNpdAA",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "vsBBnkd4X75xk2jm",
        "name": "Detect Life",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.vsBBnkd4X75xk2jm",
        "validId": true,
        "category": "utility",
        "ppCost": 0,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "vzwdgCJ0JbRhSc67",
        "name": "Force Bolt",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.vzwdgCJ0JbRhSc67",
        "validId": true,
        "category": "attack",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "w0JGYOiplUNiaUC0",
        "name": "Chill Storm",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.w0JGYOiplUNiaUC0",
        "validId": true,
        "category": "save",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "w3SNefGstq5X5mle",
        "name": "Touch Of Undeath",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.w3SNefGstq5X5mle",
        "validId": true,
        "category": "save",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "wBKSkhSw1fi9Cejw",
        "name": "Orb Of Fire",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.wBKSkhSw1fi9Cejw",
        "validId": true,
        "category": "attack",
        "ppCost": 0,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "wInP5ZA7dfWe6n3B",
        "name": "Soothing Words",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.wInP5ZA7dfWe6n3B",
        "validId": true,
        "category": "utility",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "wMCIccEA1GNs3027",
        "name": "Spell Drain",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.wMCIccEA1GNs3027",
        "validId": true,
        "category": "save",
        "ppCost": 14,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "wT9meUPkijKEJNQA",
        "name": "Conjure Eternal",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.wT9meUPkijKEJNQA",
        "validId": true,
        "category": "utility",
        "ppCost": 10,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "wTx7VLkzzeAPUkoG",
        "name": "Phantom Steed",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.wTx7VLkzzeAPUkoG",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "wWzYGLbMvtlIgBNb",
        "name": "Hunters Spirit",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.wWzYGLbMvtlIgBNb",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "wdW5H5IDgRJ2oO1K",
        "name": "Grace",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.wdW5H5IDgRJ2oO1K",
        "validId": true,
        "category": "utility",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "wiC1y13KUt9XOliT",
        "name": "Wits",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.wiC1y13KUt9XOliT",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "x2KXiEzu49wOit6M",
        "name": "Slide",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.x2KXiEzu49wOit6M",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "x4lk71rXViO644mf",
        "name": "Solid Fog",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.x4lk71rXViO644mf",
        "validId": true,
        "category": "utility",
        "ppCost": 8,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "x57DQsHDXGlD7WrO",
        "name": "Fire Bolt",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.x57DQsHDXGlD7WrO",
        "validId": true,
        "category": "attack",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "x6PoUQyZKj1ILOiq",
        "name": "Restore Senses",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.x6PoUQyZKj1ILOiq",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "xAzDAkVmIzZxK78j",
        "name": "Death Ward",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.xAzDAkVmIzZxK78j",
        "validId": true,
        "category": "utility",
        "ppCost": 10,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "xFFnyuEhym4oNcia",
        "name": "Glitterdust",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.xFFnyuEhym4oNcia",
        "validId": true,
        "category": "save",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "xJgajrWbLj2WpjIU",
        "name": "Remove Fear",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.xJgajrWbLj2WpjIU",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "xL7cQ1b6dLseM7O4",
        "name": "Tame",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.xL7cQ1b6dLseM7O4",
        "validId": true,
        "category": "save",
        "ppCost": 0,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "xSh8gGewgvKiAQjS",
        "name": "Soul Destruction",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.xSh8gGewgvKiAQjS",
        "validId": true,
        "category": "save",
        "ppCost": 20,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "xWGGXpJbz0ZORB74",
        "name": "Vision Of Havoc",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.xWGGXpJbz0ZORB74",
        "validId": true,
        "category": "save",
        "ppCost": 12,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "xbBZ8oIbGjsunBe7",
        "name": "Ghoul Touch",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.xbBZ8oIbGjsunBe7",
        "validId": true,
        "category": "save",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "xbDJnnpG06NgQ5e1",
        "name": "Gate",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.xbDJnnpG06NgQ5e1",
        "validId": true,
        "category": "utility",
        "ppCost": 20,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "xd7ozj5IZtLjPGQz",
        "name": "Tangling Creepers",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.xd7ozj5IZtLjPGQz",
        "validId": true,
        "category": "attack",
        "ppCost": 12,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "xk0HaCRkhU3SSDcO",
        "name": "Stoneskin",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.xk0HaCRkhU3SSDcO",
        "validId": true,
        "category": "utility",
        "ppCost": 10,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "xlXxJKcTfM3iYoI4",
        "name": "Speak With Plants",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.xlXxJKcTfM3iYoI4",
        "validId": true,
        "category": "utility",
        "ppCost": 8,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "y0QNYKzswcBcXSja",
        "name": "True Target",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.y0QNYKzswcBcXSja",
        "validId": true,
        "category": "utility",
        "ppCost": 14,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "y3UDWcoOdw50eTtL",
        "name": "Confident Veil",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.y3UDWcoOdw50eTtL",
        "validId": true,
        "category": "utility",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "yDVWVTZKVU13kXMR",
        "name": "Magic Stone",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.yDVWVTZKVU13kXMR",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "yXBgcwbOEAlI4I38",
        "name": "Arrow Of The Wild Hunt",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.yXBgcwbOEAlI4I38",
        "validId": true,
        "category": "utility",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "yXSJQrAwqYJ4sdA0",
        "name": "Animal Growth",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.yXSJQrAwqYJ4sdA0",
        "validId": true,
        "category": "utility",
        "ppCost": 8,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "ybMqAcFqsZvfVW6P",
        "name": "Water Breathing",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.ybMqAcFqsZvfVW6P",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "ykRpwZjRALtanL0R",
        "name": "Echolocation",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.ykRpwZjRALtanL0R",
        "validId": true,
        "category": "utility",
        "ppCost": 10,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "yoxdfS6AMrdN929Q",
        "name": "Lock",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.yoxdfS6AMrdN929Q",
        "validId": true,
        "category": "utility",
        "ppCost": 4,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "yufE6RWGYGtDP9RY",
        "name": "Shroud",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.yufE6RWGYGtDP9RY",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "ywQQbuR13cpF7pmB",
        "name": "Alluring Caress",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.ywQQbuR13cpF7pmB",
        "validId": true,
        "category": "save",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "zA67v4ssb2zKVXY0",
        "name": "Blight Cloud",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.zA67v4ssb2zKVXY0",
        "validId": true,
        "category": "save",
        "ppCost": 12,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "zJS1iowCapfmV8zE",
        "name": "Spirit Lore",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.zJS1iowCapfmV8zE",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "zPagtGRnqDZnf4ED",
        "name": "Song Of Despair",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.zPagtGRnqDZnf4ED",
        "validId": true,
        "category": "utility",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "zPmy0vfocEbWcDCN",
        "name": "Woeful Dread",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.zPmy0vfocEbWcDCN",
        "validId": true,
        "category": "save",
        "ppCost": 18,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "zUaNoHMLucLGn1tK",
        "name": "Mage Hand",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.zUaNoHMLucLGn1tK",
        "validId": true,
        "category": "utility",
        "ppCost": 0,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "zUf3kHy13Lb1RRfP",
        "name": "Dissipate Into Mist",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.zUf3kHy13Lb1RRfP",
        "validId": true,
        "category": "utility",
        "ppCost": 7,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "za2gEm4FgyAbqWir",
        "name": "Power Crystal",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.za2gEm4FgyAbqWir",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "zaqBBjamMbC20eSH",
        "name": "Acidic Storm",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.zaqBBjamMbC20eSH",
        "validId": true,
        "category": "save",
        "ppCost": 10,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "zhoqDb47get5kGKl",
        "name": "Healer’s Grace",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.zhoqDb47get5kGKl",
        "validId": true,
        "category": "utility",
        "ppCost": 1,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "zigO4vqdBKnbLt1J",
        "name": "Enervation",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.zigO4vqdBKnbLt1J",
        "validId": true,
        "category": "save",
        "ppCost": 12,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "zkQfRHOPWwuLsukI",
        "name": "Make Whole",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.zkQfRHOPWwuLsukI",
        "validId": true,
        "category": "utility",
        "ppCost": 6,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "zminp5FFZhbU7DE1",
        "name": "Suspended Unrest",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.zminp5FFZhbU7DE1",
        "validId": true,
        "category": "utility",
        "ppCost": 2,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "zsOOtHRU1kcCEl6n",
        "name": "Wall Of Ice",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.zsOOtHRU1kcCEl6n",
        "validId": true,
        "category": "utility",
        "ppCost": 10,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "zzxd5wrjBY8uEHck",
        "name": "Searing Burst",
        "type": "spell",
        "uuid": "Compendium.trg-prime.spells.Item.zzxd5wrjBY8uEHck",
        "validId": true,
        "category": "save",
        "ppCost": 7,
        "magicalAbility": "",
        "specialist": true,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      }
    ],
    "abilities": [
      {
        "id": "02l3WX6o59gCANHl",
        "name": "Share Spells",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.02l3WX6o59gCANHl",
        "validId": true,
        "category": "",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "0zxD7kiC2tJPODmi",
        "name": "Hunt Prey",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.0zxD7kiC2tJPODmi",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Ranger 1st level",
        "automation": {
          "effects": 0,
          "flags": [
            "classAbility"
          ]
        }
      },
      {
        "id": "2JbfDpEYPpPX2Q8h",
        "name": "Fey Blood",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.2JbfDpEYPpPX2Q8h",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "2Q5z7G36JMdGRfK5",
        "name": "Scoundrel's Luck",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.2Q5z7G36JMdGRfK5",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Rogue 1st level",
        "automation": {
          "effects": 0,
          "flags": [
            "classAbility"
          ]
        }
      },
      {
        "id": "3R1RPNBjXEGFwDq5",
        "name": "Immortal",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.3R1RPNBjXEGFwDq5",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "conditionals",
            "fullRestHours"
          ]
        }
      },
      {
        "id": "4Bjx2vJcgdAuYrBI",
        "name": "Sure Shot",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.4Bjx2vJcgdAuYrBI",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "4vEl7PK7Dd393Tz4",
        "name": "Divine Resolve",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.4vEl7PK7Dd393Tz4",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Crusader 1st level",
        "automation": {
          "effects": 0,
          "flags": [
            "classAbility"
          ]
        }
      },
      {
        "id": "60ZCq4lj7cQjW5YL",
        "name": "Gallop",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.60ZCq4lj7cQjW5YL",
        "validId": true,
        "category": "",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "7JbyZIPagOamfLrn",
        "name": "Song & Dance",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.7JbyZIPagOamfLrn",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Bard 1st level",
        "automation": {
          "effects": 0,
          "flags": [
            "classAbility"
          ]
        }
      },
      {
        "id": "7gjnJtPU7go02naJ",
        "name": "Forbidden Magic",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.7gjnJtPU7go02naJ",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "conditionals",
            "forbiddenTraditions",
            "beneficialTraditionSave"
          ]
        }
      },
      {
        "id": "89zCaWsMbIhzZVpb",
        "name": "Constrict",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.89zCaWsMbIhzZVpb",
        "validId": true,
        "category": "",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "92gz86OYqrVBpd5f",
        "name": "Armour Exemplar",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.92gz86OYqrVBpd5f",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Fighter 3rd level",
        "automation": {
          "effects": 0,
          "flags": [
            "classAbility"
          ]
        }
      },
      {
        "id": "9Nu1GU1jAUWLfs2s",
        "name": "Blindsight",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.9Nu1GU1jAUWLfs2s",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "9bG8iZ5vYmgFAN3b",
        "name": "Monstrous Grab",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.9bG8iZ5vYmgFAN3b",
        "validId": true,
        "category": "",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "conditionals",
            "creatureAbility"
          ]
        }
      },
      {
        "id": "BDoEkBZWDExdy8kM",
        "name": "Pounce",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.BDoEkBZWDExdy8kM",
        "validId": true,
        "category": "",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "CSiQuCrrCLL6VIZi",
        "name": "Sneak Attack",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.CSiQuCrrCLL6VIZi",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Rogue 1st level",
        "automation": {
          "effects": 0,
          "flags": [
            "classAbility"
          ]
        }
      },
      {
        "id": "DZpK3JxYK7sVLh0C",
        "name": "Monstrous Knockdown",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.DZpK3JxYK7sVLh0C",
        "validId": true,
        "category": "",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "conditionals",
            "creatureAbility"
          ]
        }
      },
      {
        "id": "Dkq2b7EZDdPKGzxy",
        "name": "Nightvision",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.Dkq2b7EZDdPKGzxy",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "Dl78aRrcMeAIhAOI",
        "name": "Arcane Knowledge",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.Dl78aRrcMeAIhAOI",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "EKxUzFSTJeLa6rZP",
        "name": "Bonus Feat",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.EKxUzFSTJeLa6rZP",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "ETzD3Cbd1fel44Wo",
        "name": "Lead Boots",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.ETzD3Cbd1fel44Wo",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "GSE9qm9e2FUsauvp",
        "name": "Gnome Resistance",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.GSE9qm9e2FUsauvp",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "saveReaction"
          ]
        }
      },
      {
        "id": "H2mijc9UPGvL1JR3",
        "name": "Ferocious",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.H2mijc9UPGvL1JR3",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 2,
          "flags": []
        }
      },
      {
        "id": "IFCBdCOLKuBF3Mk6",
        "name": "Pack Attack",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.IFCBdCOLKuBF3Mk6",
        "validId": true,
        "category": "",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "IsqKdIFR971hME5G",
        "name": "Death Mark",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.IsqKdIFR971hME5G",
        "validId": true,
        "category": "Archetype",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "JLYd5mr883GgCTKW",
        "name": "Skilled in Shadow",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.JLYd5mr883GgCTKW",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "LGtjjy4UINpHYkDC",
        "name": "Tremorsense",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.LGtjjy4UINpHYkDC",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "MtzZPjFglzdURdo7",
        "name": "Wild Empathy",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.MtzZPjFglzdURdo7",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Druid 1st level",
        "automation": {
          "effects": 0,
          "flags": [
            "classAbility",
            "conditionals"
          ]
        }
      },
      {
        "id": "OKbTJJzwQL0BDFXw",
        "name": "Weapon Supremacy",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.OKbTJJzwQL0BDFXw",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Fighter 13th level",
        "automation": {
          "effects": 0,
          "flags": [
            "classAbility"
          ]
        }
      },
      {
        "id": "OfjAHwJXXt80kdy1",
        "name": "Arcane Bond",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.OfjAHwJXXt80kdy1",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Wizard 1st level",
        "automation": {
          "effects": 0,
          "flags": [
            "classAbility"
          ]
        }
      },
      {
        "id": "OsVADSau5VECpb1J",
        "name": "Swift Pursuit",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.OsVADSau5VECpb1J",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Ranger 6th level",
        "automation": {
          "effects": 0,
          "flags": [
            "classAbility"
          ]
        }
      },
      {
        "id": "Qm2oBZAwE903GR1t",
        "name": "Crusader's Mercy",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.Qm2oBZAwE903GR1t",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Crusader 1st level",
        "automation": {
          "effects": 0,
          "flags": [
            "classAbility"
          ]
        }
      },
      {
        "id": "R4Jxy7bLfWZT2BxC",
        "name": "Battle Readiness",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.R4Jxy7bLfWZT2BxC",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Fighter 2nd level",
        "automation": {
          "effects": 0,
          "flags": [
            "classAbility"
          ]
        }
      },
      {
        "id": "RR89VLnOaBqLZf6p",
        "name": "Terrain Mastery",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.RR89VLnOaBqLZf6p",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Ranger 9th level",
        "automation": {
          "effects": 0,
          "flags": [
            "classAbility"
          ]
        }
      },
      {
        "id": "Rc1xbU0Xgs26EwMb",
        "name": "Warrior's Resolve",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.Rc1xbU0Xgs26EwMb",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Fighter 1st level",
        "automation": {
          "effects": 0,
          "flags": [
            "classAbility"
          ]
        }
      },
      {
        "id": "SEIhPR39mgoykzqY",
        "name": "Archetypal Path",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.SEIhPR39mgoykzqY",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Rogue 1st level",
        "automation": {
          "effects": 0,
          "flags": [
            "classAbility",
            "archetypeChoices"
          ]
        }
      },
      {
        "id": "TVch2kARKsRi0P1w",
        "name": "Trap Finder",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.TVch2kARKsRi0P1w",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Rogue 1st level",
        "automation": {
          "effects": 0,
          "flags": [
            "classAbility",
            "conditionals"
          ]
        }
      },
      {
        "id": "U1TAUhwOgznhhVO4",
        "name": "Agile Display",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.U1TAUhwOgznhhVO4",
        "validId": true,
        "category": "Archetype",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "UGIDj2XjUlhhqs7w",
        "name": "Perfect Darkvision",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.UGIDj2XjUlhhqs7w",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "UUuaevHjxarm5ep5",
        "name": "Ley Blood",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.UUuaevHjxarm5ep5",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "WzQ24jnx5nR8gW9v",
        "name": "Bardic Performance",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.WzQ24jnx5nR8gW9v",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Bard 1st level",
        "automation": {
          "effects": 0,
          "flags": [
            "classAbility"
          ]
        }
      },
      {
        "id": "Wzp82lWUN0rdd15A",
        "name": "Hardy",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.Wzp82lWUN0rdd15A",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "YBrS1NY8MPQaKQB2",
        "name": "Divine Grace",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.YBrS1NY8MPQaKQB2",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Crusader 2nd level",
        "automation": {
          "effects": 0,
          "flags": [
            "classAbility"
          ]
        }
      },
      {
        "id": "Z0xOh37DOfLQHtXY",
        "name": "Devotion",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.Z0xOh37DOfLQHtXY",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Crusader 1st level",
        "automation": {
          "effects": 0,
          "flags": [
            "classAbility"
          ]
        }
      },
      {
        "id": "aGbN2sVzsV3vlP3F",
        "name": "Keen Senses",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.aGbN2sVzsV3vlP3F",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "ajypwNHg082dZJXC",
        "name": "Animal Rage",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.ajypwNHg082dZJXC",
        "validId": true,
        "category": "",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "bAtiT44wSIn9Om0n",
        "name": "Deific Aspect",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.bAtiT44wSIn9Om0n",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Crusader 1st level",
        "automation": {
          "effects": 0,
          "flags": [
            "classAbility",
            "alignmentFeats"
          ]
        }
      },
      {
        "id": "bM0my3y7jTbYZj6n",
        "name": "Opportunist's Strike",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.bM0my3y7jTbYZj6n",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Rogue 3rd level",
        "automation": {
          "effects": 0,
          "flags": [
            "classAbility"
          ]
        }
      },
      {
        "id": "csTjTBcXFG2RfI4Z",
        "name": "Eternal Essence",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.csTjTBcXFG2RfI4Z",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "fGF7NGTdzS5tNWlx",
        "name": "Pattern Disruption",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.fGF7NGTdzS5tNWlx",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Rogue 2nd level",
        "automation": {
          "effects": 0,
          "flags": [
            "classAbility"
          ]
        }
      },
      {
        "id": "fkUHs8PUbRuhfmdu",
        "name": "Martial Training",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.fkUHs8PUbRuhfmdu",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Fighter 1st level",
        "automation": {
          "effects": 0,
          "flags": [
            "classAbility",
            "archetypeChoices"
          ]
        }
      },
      {
        "id": "gae244s4wXIR2Dyh",
        "name": "Hunter's Method",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.gae244s4wXIR2Dyh",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Ranger 1st level",
        "automation": {
          "effects": 0,
          "flags": [
            "classAbility",
            "methodChoices"
          ]
        }
      },
      {
        "id": "gnDD0w96yHR7sVNv",
        "name": "Scent",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.gnDD0w96yHR7sVNv",
        "validId": true,
        "category": "",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "iURMCj3sxQftCisc",
        "name": "Deific Aspect",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.iURMCj3sxQftCisc",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Cleric 1st level",
        "automation": {
          "effects": 0,
          "flags": [
            "classAbility"
          ]
        }
      },
      {
        "id": "iWONNQhfhrqlgnR6",
        "name": "Trample",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.iWONNQhfhrqlgnR6",
        "validId": true,
        "category": "",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "j2LtLNUQNW2Oo0Sx",
        "name": "Unbreakable Resolve",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.j2LtLNUQNW2Oo0Sx",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Fighter 9th level",
        "automation": {
          "effects": 0,
          "flags": [
            "classAbility"
          ]
        }
      },
      {
        "id": "k7Zh4trsVvumJ9b6",
        "name": "Extremely Nimble",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.k7Zh4trsVvumJ9b6",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "l8W1LXiu2X3uh8dE",
        "name": "Priestly Path",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.l8W1LXiu2X3uh8dE",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Cleric 1st level",
        "automation": {
          "effects": 0,
          "flags": [
            "classAbility",
            "archetypeChoices"
          ]
        }
      },
      {
        "id": "lucb5jc5EGGCe3RR",
        "name": "Wild Shape",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.lucb5jc5EGGCe3RR",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Druid 3rd level",
        "automation": {
          "effects": 0,
          "flags": [
            "classAbility"
          ]
        }
      },
      {
        "id": "mduyAxZQeAgySCAn",
        "name": "Channels",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.mduyAxZQeAgySCAn",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Cleric 1st level",
        "automation": {
          "effects": 0,
          "flags": [
            "classAbility",
            "spellChoices"
          ]
        }
      },
      {
        "id": "no0MddBFACVH3CHQ",
        "name": "Sense Weakness",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.no0MddBFACVH3CHQ",
        "validId": true,
        "category": "Archetype",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "nol3bBUIZ1C6YrpQ",
        "name": "Skilled",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.nol3bBUIZ1C6YrpQ",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": []
        }
      },
      {
        "id": "p1S92D6gOSn3r7j3",
        "name": "Returned Essence",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.p1S92D6gOSn3r7j3",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "qLwfybndl5lor0YG",
        "name": "Wizard School",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.qLwfybndl5lor0YG",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Wizard 1st level",
        "automation": {
          "effects": 0,
          "flags": [
            "classAbility",
            "schoolChoices"
          ]
        }
      },
      {
        "id": "qlmtXAYeS8V7qYhr",
        "name": "Book of Notations",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.qlmtXAYeS8V7qYhr",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Bard 1st level",
        "automation": {
          "effects": 0,
          "flags": [
            "classAbility"
          ]
        }
      },
      {
        "id": "rHBi4giHLksNngwT",
        "name": "Acute Sense",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.rHBi4giHLksNngwT",
        "validId": true,
        "category": "",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "rnghdQpIUIKa5F9R",
        "name": "Shadow Stance",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.rnghdQpIUIKa5F9R",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "s0tCJRh20SqxOLEl",
        "name": "Killer's Edge",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.s0tCJRh20SqxOLEl",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Rogue 1st level",
        "automation": {
          "effects": 0,
          "flags": [
            "classAbility"
          ]
        }
      },
      {
        "id": "vCbewmPdYNpHNnHl",
        "name": "Darkvision",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.vCbewmPdYNpHNnHl",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "creatureAbility"
          ]
        }
      },
      {
        "id": "vrcMVEwB0MOKmcVN",
        "name": "Druidic Code",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.vrcMVEwB0MOKmcVN",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Druid 1st level",
        "automation": {
          "effects": 0,
          "flags": [
            "classAbility"
          ]
        }
      },
      {
        "id": "w2t7STZhdADEtSFi",
        "name": "Versatile",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.w2t7STZhdADEtSFi",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 0,
          "flags": []
        }
      },
      {
        "id": "w8RyKS6CFd8yN5Yi",
        "name": "Press the Advantage",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.w8RyKS6CFd8yN5Yi",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Fighter 4th level",
        "automation": {
          "effects": 0,
          "flags": [
            "classAbility"
          ]
        }
      },
      {
        "id": "wTgD77fcNPlWCvp9",
        "name": "Trap Finder",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.wTgD77fcNPlWCvp9",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Ranger 1st level",
        "automation": {
          "effects": 0,
          "flags": [
            "classAbility",
            "conditionals"
          ]
        }
      },
      {
        "id": "wxwIO3sXS6oXGR1O",
        "name": "Divine Ally",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.wxwIO3sXS6oXGR1O",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Crusader 4th level",
        "automation": {
          "effects": 0,
          "flags": [
            "classAbility",
            "allyChoices"
          ]
        }
      },
      {
        "id": "xNOKGYTdKVAvsfwP",
        "name": "Foolhardy",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.xNOKGYTdKVAvsfwP",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "conditionals"
          ]
        }
      },
      {
        "id": "ygquXzqKrtaP4wt2",
        "name": "Roguish Skill",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.ygquXzqKrtaP4wt2",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Rogue 1st level",
        "automation": {
          "effects": 0,
          "flags": [
            "classAbility",
            "skillChoices"
          ]
        }
      },
      {
        "id": "zH0K1Oe1YrtDuknL",
        "name": "Detect Magic",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.zH0K1Oe1YrtDuknL",
        "validId": true,
        "category": "Racial",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "",
        "automation": {
          "effects": 1,
          "flags": [
            "conditionals",
            "untrainedActions"
          ]
        }
      },
      {
        "id": "zoFPdhgCYUfCJf3V",
        "name": "Weapon Exemplar",
        "type": "ability",
        "uuid": "Compendium.trg-prime.abilities.Item.zoFPdhgCYUfCJf3V",
        "validId": true,
        "category": "Class",
        "ppCost": null,
        "magicalAbility": "",
        "specialist": false,
        "prerequisites": "Fighter 4th level",
        "automation": {
          "effects": 0,
          "flags": [
            "classAbility"
          ]
        }
      }
    ]
  }
};
