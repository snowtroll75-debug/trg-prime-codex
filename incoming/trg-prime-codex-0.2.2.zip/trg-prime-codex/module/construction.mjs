import { RULES } from '../data/rules.mjs';
import { creatureLedger, isSpellcaster, keyOf, SIZES } from './dp.mjs';
import { NATIVE_CONTENT } from '../data/native-content.mjs';

export const MODULE_ID = 'trg-prime-codex';
export const ATTRIBUTES = ['strength', 'dexterity', 'constitution', 'intelligence', 'wisdom', 'charisma'];
export function newDesign() {
  return {
    schemaVersion: 1, kind: 'creature', name: 'New creature', description: '', level: 1,
    typeKey: 'undead', classKey: 'undead', size: 'medium', caster: false,
    magicalTradition: 'ethereal', magicalAbility: 'intelligence', languages: '', ethics: '',
    movement: { land: 25, climb: 0, swim: 0, burrow: 0, fly: 0 },
    attributes: Object.fromEntries(ATTRIBUTES.map(key => [key, 1])),
    attacks: ['bite'], abilities: [], feats: [], spells: [], innateAvailability: '1/day', profileCounts: {},
    regenerationBypass: '', regenerationBypassFrequency: 'normal',
    raceUuid: '', heritageUuid: '', adjustments: []
  };
}

export function validateDesign(design) {
  if (design.schemaVersion !== 1) throw new Error('Unsupported construction schema. Preserve the project and migrate it explicitly.');
  if (!String(design.name ?? '').trim()) throw new Error('Enter a creature name.');
  if (!Number.isInteger(design.level) || design.level < 1 || design.level > 20) throw new Error('Choose an actual level from 1 to 20.');
  if (!RULES.types[design.typeKey] || !SIZES.includes(design.size)) throw new Error('Choose a supported creature type and size.');
  for (const key of ATTRIBUTES) {
    const value = design.attributes?.[key];
    if (!Number.isInteger(value) || value < -10 || value > 20) throw new Error(`${key} must be an integer between -10 and 20.`);
  }
  const dependencies = {
    hover: 'fly', 'wingless-flight': 'fly', 'earth-pass': 'burrow', 'water-glide': 'swim',
    'flyby-attack': 'fly', 'diving-strike': 'fly', 'swimby-attack': 'swim'
  };
  for (const [ability, mode] of Object.entries(dependencies)) {
    if (design.abilities.includes(ability) && !design.movement?.[mode]) throw new Error(`${RULES.abilities[ability].name} requires an existing ${mode} Speed.`);
  }
  const attackDependencies = { 'wing-buffet': 'wings', 'powerful-charge': 'gore', 'tear-flesh': 'bite', 'life-drain': 'unarmed-strike' };
  for (const [ability, attack] of Object.entries(attackDependencies)) {
    if (design.abilities.includes(ability) && !design.attacks.includes(attack)) throw new Error(`${RULES.abilities[ability].name} requires ${RULES.attacks[attack].name}.`);
  }
  const ledger = creatureLedger(design);
  for (const [layer, uuid] of [['race', design.raceUuid], ['heritage', design.heritageUuid]]) {
    if (uuid && !design.adjustments.some(entry => entry.layer === layer)) {
      ledger.unresolved.push({ label: layer, reason: 'Record this selected package’s component ledger before quoting complete DP.' });
      ledger.complete = false; ledger.total = null; ledger.metrics = null;
    }
  }
  return ledger;
}

export function findAbilityDocument(name) {
  const document = NATIVE_CONTENT['creature-abilities'].find(entry => keyOf(entry.name) === keyOf(name));
  return document ? { ...document, uuid: `Compendium.${MODULE_ID}.creature-abilities.Item.${document._id}`, validId: true } : null;
}

function nativeReference(pack, name) {
  const document = NATIVE_CONTENT[pack].find(entry => keyOf(entry.name) === keyOf(name));
  if (!document) throw new Error(`Missing module content ${pack}/${name}`);
  return `Compendium.${MODULE_ID}.${pack}.Item.${document._id}`;
}

export function resolveNative(uuid) {
  for (const [pack, documents] of Object.entries(NATIVE_CONTENT)) {
    const document = documents.find(entry => uuid === `Compendium.${MODULE_ID}.${pack}.Item.${entry._id}`);
    if (document) return structuredClone(document);
  }
  return null;
}

export function documentSelections(design) {
  const type = RULES.catalog['creature-types'].find(entry => keyOf(entry.name) === design.typeKey);
  const cls = RULES.classes[design.classKey];
  const pc = RULES.catalog.classes.find(entry => keyOf(entry.name) === design.classKey);
  const selections = [{ key: 'type', uuid: nativeReference('creature-types', type.name) },
    { key: 'class', uuid: cls ? nativeReference('creature-classes', cls.coreName) : pc?.uuid }];
  for (const attack of new Set(design.attacks)) {
    const record = RULES.catalog['creature-attacks'].find(entry => keyOf(entry.name) === attack);
    if (!record) throw new Error(`The core is missing ${attack}.`);
    selections.push({ key: `attack-${attack}`, uuid: nativeReference('creature-attacks', record.name) });
  }
  for (const ability of new Set(design.abilities)) {
    const record = findAbilityDocument(RULES.abilities[ability].name);
    if (!record) throw new Error(`The core has no usable document for ${ability}.`);
    if (!record.validId) throw new Error(`${record.name} has an invalid core compendium ID. A core data repair is required.`);
    selections.push({ key: `ability-${ability}`, uuid: record.uuid });
  }
  for (const [key, uuid] of [['race', design.raceUuid], ['heritage', design.heritageUuid]]) if (uuid) selections.push({ key, uuid });
  for (const uuid of new Set(design.feats ?? [])) selections.push({ key: `feat-${uuid}`, uuid });
  for (const uuid of new Set(design.spells ?? [])) selections.push({ key: `spell-${uuid}`, uuid });
  if (selections.some(selection => !selection.uuid)) throw new Error('The selected class has no core document.');
  return selections;
}

function cleanSource(document) {
  const source = structuredClone(document.toObject ? document.toObject() : document);
  delete source._id; delete source._key; delete source.folder; delete source.ownership;
  delete source._stats;
  if (source.effects?.some(effect => typeof effect !== 'object')) throw new Error('Embedded effects must be materialised before actor construction.');
  return source;
}

export async function actorSource(design, resolve) {
  const ledger = validateDesign(design);
  // A VARIANT OF A PUBLISHED CREATURE (0.2.0, CX-03) keeps components the
  // Codex cannot value (its unique abilities, its race). Its ledger is stored
  // as provisional rather than blocking the edit; a Codex-built design still
  // needs a complete valuation.
  if (!ledger.complete && !design.imported) throw new Error('Resolve all DP components before generating an actor with a final valuation.');
  if (!ledger.complete) ledger.provisional = true;
  const items = [];
  for (const selection of documentSelections(design)) {
    const document = await resolve(selection.uuid);
    if (!document || document.id === null) throw new Error(`Cannot resolve valid core document ${selection.uuid}.`);
    const item = cleanSource(document);
    item.flags ??= {};
    item.flags[MODULE_ID] = { schemaVersion: 1, componentKey: selection.key, sourceUuid: selection.uuid };
    if (selection.key === 'class') {
      const classRule = RULES.classes[design.classKey];
      const isNPCSpellcaster = ['adept-npc', 'hybrid-npc'].includes(design.classKey);
      if (classRule && (!design.caster && !isNPCSpellcaster)) {
        item.system.magicalAbility = '';
        item.system.progression = item.system.progression.map(row => ({ ...row, pp: 0, bsb: 0, casterLevel: 0 }));
      } else if (classRule) {
        item.system.magicalTradition = design.magicalTradition;
        item.system.magicalAbility = design.magicalAbility;
      }
    }
    if (selection.key === 'ability-slow-i' || selection.key === 'ability-slow-ii') {
      item.name = selection.key === 'ability-slow-i' ? 'Slow (I)' : 'Slow (II)';
      item.flags['trg-prime'].creatureAbility.derives.apPenalty = selection.key === 'ability-slow-i' ? 1 : 2;
    }
    if (selection.key.startsWith('spell-')) {
      const isCaster = isSpellcaster(design);
      const baseTraits = String(item.system.traits ?? '');
      item.system.innate = !isCaster;
      item.system.usesPerDay = '';
      item.system.usesValue = 0;
      if (!isCaster) {
        // A blank count plus the Focus trait invokes the native one-use rule.
        const usage = { '1/day': '1', '2/day': '2', '3/day': '3', focus: '', 'at-will': 'at will', constant: 'constant' }[design.innateAvailability];
        item.system.usesPerDay = usage;
        item.system.usesValue = /^\d+$/.test(usage) ? Number(usage) : 1;
        if (design.innateAvailability === 'focus' && !baseTraits.split(',').some(t => t.trim().toLowerCase() === 'focus')) item.system.traits = `${item.system.traits ?? ''}, Focus`;
      }
      item.flags[MODULE_ID].spellConfiguration = { baseTraits, addedFocus: !isCaster && design.innateAvailability === 'focus' && !baseTraits.split(',').some(t => t.trim().toLowerCase() === 'focus'), spentUses: 0, remainingAtEdit: item.system.usesValue };
    }
    if (selection.key === 'ability-regeneration') {
      item.flags['trg-prime'].creatureAbility.derives.turnStart.negatedBy = String(design.regenerationBypass ?? '')
        .split(',').map(value => value.trim().toLowerCase()).filter(Boolean);
    }
    items.push(item);
  }
  const size = RULES.sizes[design.size];
  const space = { diminutive: 0.2, tiny: 0.5, small: 1, medium: 1, large: 2, huge: 3, gargantuan: 4, colossal: 5 }[design.size];
  return {
    name: design.name.trim(), type: 'npc', img: 'icons/svg/mystery-man.svg',
    prototypeToken: { name: design.name.trim(), actorLink: true, width: space, height: space, disposition: -1 },
    system: {
      identity: { level: design.level, size: design.size, languages: design.languages, ethics: design.ethics },
      details: { biography: design.description },
      attributes: Object.fromEntries(ATTRIBUTES.map(key => [key, { base: design.attributes[key] }])),
      resources: { hp: { value: size.hp, other: 0 } },
      combat: { movement: Object.fromEntries(['land', 'climb', 'swim', 'burrow', 'fly'].map(mode => [mode, { base: design.movement[mode] }])) }
    },
    items,
    flags: { [MODULE_ID]: { schemaVersion: 1, design: structuredClone(design), ledger, sourceCoreVersion: RULES.coreVersion } }
  };
}
