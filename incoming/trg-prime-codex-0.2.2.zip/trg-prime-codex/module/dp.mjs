import { RULES } from '../data/rules.mjs';

export const BENCHMARKS = Object.freeze({ preclass: 40, class: 208, complete: 250 });
export const SIZES = Object.keys(RULES.sizes);
const source = section => `TRG Prime Codex, Part II, ${section}`;
export const keyOf = value => String(value).trim().toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');

// Decimal input is converted to fractions before any threshold comparison.
// In particular, a displayed rounded 110.00% never decides the XPM band.
function fraction(value) {
  if (typeof value === 'number' && !Number.isFinite(value)) throw new Error('A finite decimal is required.');
  const match = /^([+-]?)(\d+)(?:\.(\d+))?(?:e([+-]?\d+))?$/i.exec(String(value));
  if (!match) throw new Error(`Invalid decimal ${value}`);
  const scale = (match[3]?.length ?? 0) - Number(match[4] ?? 0);
  if (Math.abs(scale) > 30) throw new Error('Decimal precision exceeds 30 places.');
  const sign = match[1] === '-' ? -1n : 1n;
  const numerator = BigInt(match[2] + (match[3] ?? '')) * sign;
  return scale >= 0 ? [numerator, 10n ** BigInt(scale)] : [numerator * 10n ** BigInt(-scale), 1n];
}
const valueOf = ([numerator, denominator]) => Number(numerator) / Number(denominator);
const add = ([a, b], [c, d]) => [a * d + c * b, b * d];
const multiply = ([a, b], [c, d]) => [a * c, b * d];
const ceiling = (n, d) => (n + d - 1n) / d;
const finite = value => valueOf(fraction(value));
function integer(value, label, minimum = 0) {
  const number = finite(value);
  if (!Number.isSafeInteger(number) || number < minimum) throw new Error(`${label} must be an integer of at least ${minimum}.`);
  return number;
}

export function xpMetrics(actualDP, level, { complete = true, benchmark = 250 } = {}) {
  if (!complete) return null;
  const [points, denominator] = fraction(actualDP);
  const [base, baseDenominator] = fraction(benchmark);
  if (base <= 0n) throw new Error('The benchmark must be positive.');
  const scaled = points * baseDenominator * 100n;
  const divisor = denominator * base;
  let steps = 0n;
  if (scaled > 110n * divisor) steps = ceiling(scaled - 110n * divisor, 20n * divisor);
  else if (scaled < 90n * divisor) steps = -ceiling(90n * divisor - scaled, 20n * divisor);
  // The printed below-10% band stops at -0.5, while its formula can
  // continue for negative totals. Ask for a ruling for that disagreement.
  if (steps < -5n) throw new Error('Negative complete DP falls outside the consistent XPM schedule; a rules ruling is required.');
  const actualLevel = integer(level, 'Actual level');
  const factorTenths = 10n + steps;
  const effectiveLevel = Number(BigInt(actualLevel) * factorTenths / 10n);
  return {
    actualDP: finite(actualDP), benchmark: finite(benchmark), percentage: valueOf([scaled, divisor]),
    xpm: Number(steps) / 10, xpFactor: Number(factorTenths) / 10,
    xpPerLevel: Number(1000n * factorTenths),
    equivalentXP: Number(BigInt(actualLevel) * 1000n * factorTenths),
    effectiveLevel: Math.max(0, effectiveLevel), actualLevel,
    source: source('Chapter 9, §§1–6')
  };
}

export function pcLevel(xp, actualDP) {
  const metrics = xpMetrics(actualDP, 0);
  const [n, d] = fraction(xp);
  if (n < 0n) throw new Error('Accumulated XP must not be negative.');
  return Number(n / (d * BigInt(metrics.xpPerLevel)));
}

export function abilityModifierCost(modifier) {
  const costs = { '-4': -9, '-3': -7, '-2': -5, '-1': -3, 0: 0, 1: 4, 2: 9, 3: 15, 4: 22 };
  if (!Object.hasOwn(costs, modifier)) throw new Error('Ability modifiers outside -4 to +4 need an approved valuation.');
  return costs[modifier];
}

export function spellCost({ pp, specialist = false, innate = false, availability = '1/day' }) {
  const powerPoints = integer(pp, 'Spell PP');
  if (powerPoints > 20 || (!specialist && powerPoints === 1)) throw new Error('This PP value has no published spell anchor.');
  const cantrips = { spellcraft: 4, '1/day': 4, '2/day': 4.5, '3/day': 5, focus: 5, 'at-will': 6, constant: 8 };
  const premiums = { '1/day': 1, '2/day': 2, '3/day': 2.5, focus: 3, 'at-will': 5, constant: 7 };
  if (powerPoints === 0) {
    const cost = cantrips[innate ? availability : 'spellcraft'];
    if (cost === undefined) throw new Error('Unlisted innate availability requires an approved assessment.');
    return cost;
  }
  let cost = specialist ? 4 + Math.ceil(powerPoints / 2) : 3 + Math.floor(powerPoints / 2);
  if (innate) {
    if (premiums[availability] === undefined) throw new Error('Unlisted innate availability requires an approved assessment.');
    cost += premiums[availability] - (specialist ? 1 : 0);
  }
  return cost;
}

export function naturalAttackCost(name, size) {
  const attack = RULES.attacks[keyOf(name)];
  if (!attack || !SIZES.includes(size)) throw new Error('Unknown natural attack or size.');
  return Math.max(1, attack.dp + SIZES.indexOf(size) - SIZES.indexOf(attack.size));
}

export function sizeLedger(size) {
  const entry = RULES.sizes[size];
  if (!entry) throw new Error('Unknown creature size.');
  const components = [
    ['Residual size interaction', entry.residual], ['Base HP relative to Medium', (entry.hp - 30) / 5],
    ['Size Strength', abilityModifierCost(entry.strength)], ['Size Dexterity', abilityModifierCost(entry.dexterity)],
    // RD-02 (0.2.1): Tiny and Diminutive reach is 0, as in core. "Beyond five
    // feet" prices only reach above 5, so the size ledgers are unchanged.
    ['Reach beyond five feet', 4 * Math.max(0, entry.reach - 5) / 5]
  ];
  return components.map(([label, dp], i) => ({ id: `size-${i}`, label, dp, layer: 'size', source: entry.source }));
}

export const ANCHORS = Object.freeze({
  fixedHP: { label: 'Fixed HP', rate: 0.2, source: 'Chapter 2 §2' },
  hpPerLevel: { label: 'Additional HP per level', rate: 2, source: 'Chapter 2 §2' },
  language: { label: 'Additional starting language', rate: 0.5, source: 'Chapter 2 §3' },
  specialistSkill: { label: 'Additional specialist skill', rate: 1, source: 'Chapter 2 §3' },
  actionBonus: { label: 'Bonus to one named skill action', rate: 1, source: 'Chapter 2 §4' },
  skillBonus: { label: 'Bonus to a complete skill', rate: 2, source: 'Chapter 2 §4' },
  flexibleSkillPoint: { label: 'Flexible Skill Point per level outside a class', rate: 4, source: 'Chapter 2 §4' },
  narrowAdvantage: { label: 'Advantage on a narrow action', rate: 2, source: 'Chapter 2 §4' },
  broadActionAdvantage: { label: 'Advantage on a broadly useful action', rate: 3, source: 'Chapter 2 §4' },
  skillAdvantage: { label: 'Advantage on every action of one skill', rate: 5, source: 'Chapter 2 §4' },
  contextualAdvantage: { label: 'Advantage on a contextual group', rate: 4, source: 'Chapter 2 §4' },
  smallSize: { label: 'PC Small size interaction', rate: -2, source: 'Chapter 2 §2' },
  abilityModifier: { label: 'Modifier to one ability (−4 through +4)', rate: null, source: 'Chapter 2 §1; Chapter 8 §17' },
  generalFeat: { label: 'Additional General feat', rate: 4, source: 'Chapter 2 §5' },
  racialFeat: { label: 'Additional Racial feat', rate: 5, source: 'Chapter 2 §5' },
  classFeat: { label: 'Additional Class feat', rate: 6, source: 'Chapter 2 §5' },
  archetypeFeat: { label: 'Bonus Archetype feat', rate: 8, source: 'Chapter 2 §5' },
  weapon: { label: 'Specific weapon proficiency', rate: 1, source: 'Chapter 2 §6' },
  weaponGroup: { label: 'Weapon group proficiency', rate: 2, source: 'Chapter 2 §6' },
  simpleWeapons: { label: 'All Simple weapons', rate: 4, source: 'Chapter 2 §6' },
  martialWeapons: { label: 'All Martial weapons', rate: 6, source: 'Chapter 2 §6' },
  armourTier: { label: 'Armour proficiency tier', rate: 2, source: 'Chapter 2 §6' },
  shieldTier: { label: 'Shield proficiency tier', rate: 2, source: 'Chapter 2 §6' },
  resistance: { label: 'Resistance to one damage type', rate: 4, source: 'Chapter 2 §7' },
  immunity: { label: 'Immunity to one damage type', rate: 5, source: 'Chapter 2 §7' },
  weakness: { label: 'Weakness to one damage type', rate: -3, source: 'Chapter 2 §7' },
  staticDR: { label: 'Static DR', rate: 3, source: 'Chapter 2 §7' },
  baseDR: { label: 'Base DR', rate: 5, source: 'Chapter 2 §7' },
  criticalResistance: { label: 'Critical Resistance', rate: 2.5, source: 'Chapter 2 §7' },
  deathState: { label: 'Death State change', rate: 2, source: 'Chapter 2 §7' },
  traditionProhibition: { label: 'Prohibited tradition', rate: -2, source: 'Chapter 2 §7' },
  fumbleTen: { label: 'Additional ten spell-fumble points', rate: -3, source: 'Chapter 2 §7' },
  fixedPP: { label: 'Fixed PP', rate: 0.5, source: 'Chapter 4 §5' },
  ppPerLevel: { label: 'Additional PP per level', rate: 4, source: 'Chapter 4 §5' },
  negativePPPerLevel: { label: 'Removed PP per level', rate: -2, source: 'Chapter 4 §5' },
  classType: { label: 'Additional mechanical class type', rate: 2, source: 'Chapter 5 §3' },
  classSkill: { label: 'Class Skill', rate: 2, source: 'Chapter 5 §5' },
  classSkillPoint: { label: 'Class Skill Point per level above four', rate: 2, source: 'Chapter 5 §6' },
  classHP: { label: 'Class HP per level above four', rate: 2, source: 'Chapter 5 §4' },
  constitutionCasting: { label: 'Constitution casting', rate: 4, source: 'Chapter 5 §8' },
  tradition: { label: 'Additional simultaneously usable tradition', rate: 4, source: 'Chapter 6 §2' },
  etherealSelfLearning: { label: 'Ethereal self-learning', rate: 2, source: 'Chapter 6 §2' },
  fullCommonList: { label: 'Full common Divinity or Verdant list', rate: 16, source: 'Chapter 6 §2' },
  library: { label: 'Learned library entry', rate: 0.5, source: 'Chapter 6 §4' },
  memorised: { label: 'Memorised capacity', rate: 1, source: 'Chapter 6 §4' },
  repertoire: { label: 'Instinctive repertoire spell', rate: 1.5, source: 'Chapter 6 §4' },
  cantrip: { label: 'Class Spellcraft cantrip', rate: 4, source: 'Chapter 6 §5' },
  nightvision: { label: 'Nightvision', rate: 2, source: 'Chapter 8 §20' },
  darkvision: { label: 'Darkvision', rate: 4, source: 'Chapter 8 §20' },
  blindsight: { label: 'Blindsight', rate: 8, source: 'Chapter 8 §20' },
  fixedRanks: { label: 'Fixed named-skill rank per level', rate: 1.5, source: 'Chapter 8 §9' }
});

export function anchorEntry(anchor, quantity = 1, options = {}) {
  const rule = ANCHORS[anchor];
  if (!rule) throw new Error(`Unlisted anchor ${anchor}`);
  const amount = finite(quantity);
  if (['ppPerLevel', 'negativePPPerLevel', 'classHP'].includes(anchor) && amount < 0) throw new Error('Use the specific drawback or replacement rule for this negative quantity.');
  if (anchor === 'criticalResistance' && (amount < 0 || amount > 4)) throw new Error('CR outside 0–4 requires individual assessment.');
  return { ...options, id: options.id ?? `${anchor}-${options.subject ?? ''}`, label: options.label ?? rule.label,
    dp: anchor === 'abilityModifier' ? abilityModifierCost(amount) : valueOf(multiply(fraction(rule.rate), fraction(amount))), quantity: amount,
    source: source(rule.source), anchor, subject: options.subject ?? '', provenance: 'published-anchor' };
}

export function choiceCost(values, { mixedFeatCategories = false } = {}) {
  if (!Array.isArray(values) || !values.length) throw new Error('A choice must contain at least one costed option.');
  const numbers = values.map(finite);
  if (mixedFeatCategories) return Math.max(...numbers);
  const total = values.reduce((sum, value) => add(sum, fraction(value)), [0n, 1n]);
  return Math.round(valueOf([total[0], total[1] * BigInt(values.length)]));
}

export function protectionCost(kind, scope) {
  const schedule = {
    weaponGroup: [3, 4, -2], damageType: [4, 5, -3], relatedPair: [7, 9, -5],
    mundaneAttacks: [8, 12, -6], physicalDamage: [10, 15, -7.5]
  };
  const index = ['resistance', 'immunity', 'weakness'].indexOf(kind);
  if (index < 0 || !schedule[scope]) throw new Error('This defensive scope requires an approved valuation.');
  return schedule[scope][index];
}

export function senseCost(sense, range = 'standard') {
  const schedule = { nightvision: 2, darkvision: 4, perfectDarkvision: 6, scent: 4, tremorsense: 5, blindsight: 8, lifeSense: 8, sonar: 10 };
  const adjustments = { half: -1, standard: 0, double: 1, quadruple: 2 };
  if (!Object.hasOwn(schedule, sense) || !Object.hasOwn(adjustments, range)) throw new Error('This sense or range needs an approved valuation.');
  return schedule[sense] + adjustments[range];
}

function overlapKey(entry) {
  if (entry.anchor === 'immunity') return `immunity-${keyOf(entry.subject)}`;
  if (['nightvision', 'darkvision', 'blindsight'].includes(entry.anchor)) return entry.anchor;
  return entry.semantic ?? null;
}

export function evaluateLedger(entries, { complete = true } = {}) {
  const ids = new Set();
  const rows = entries.map(entry => {
    if (!entry.id || ids.has(entry.id)) throw new Error('Ledger component IDs must be unique.');
    ids.add(entry.id);
    const unresolved = entry.dp === null || entry.dp === undefined;
    if (!unresolved && !entry.source) throw new Error(`Missing rule source for ${entry.label}`);
    return { ...entry, baseDP: unresolved ? null : finite(entry.dp),
      finalDP: entry.includedBy ? 0 : unresolved ? null : finite(entry.dp), absorbedBy: entry.includedBy ?? null };
  });
  for (const row of rows.filter(entry => !entry.includedBy)) {
    for (const target of row.replaces ?? []) {
      const previous = rows.find(entry => entry.id === target);
      if (!previous || previous === row) throw new Error('Replacement must identify a different component in the ledger.');
      if (previous.absorbedBy) throw new Error('A replaced component cannot be replaced twice.');
      previous.finalDP = 0; previous.absorbedBy = row.id;
    }
  }
  // Explicit replacement cycles are invalid, rather than zero-valued packages.
  for (const row of rows) {
    const visited = new Set([row.id]); let current = row;
    while (current.absorbedBy && !current.includedBy) {
      if (visited.has(current.absorbedBy)) throw new Error('Cyclic replacement.');
      visited.add(current.absorbedBy); current = rows.find(entry => entry.id === current.absorbedBy);
    }
  }
  for (const row of rows.filter(entry => !entry.absorbedBy)) {
    const semantic = overlapKey(row);
    const broader = rows.find(other => other.id !== row.id && !other.absorbedBy &&
      ((semantic && other.covers?.includes(semantic)) ||
        (semantic && overlapKey(other) === semantic && (other.baseDP > row.baseDP || (other.baseDP === row.baseDP && rows.indexOf(other) < rows.indexOf(row))))));
    if (broader) { row.finalDP = 0; row.absorbedBy = broader.id; }
  }
  let total = [0n, 1n]; const layers = {};
  for (const row of rows) {
    row.adjustment = row.finalDP === null || row.baseDP === null ? null : valueOf(add(fraction(row.finalDP), multiply(fraction(row.baseDP), [-1n, 1n])));
    if (row.finalDP === null) continue;
    total = add(total, fraction(row.finalDP));
    const layer = row.layer ?? 'unassigned';
    layers[layer] = valueOf(add(fraction(layers[layer] ?? 0), fraction(row.finalDP)));
  }
  const unresolved = rows.filter(row => row.finalDP === null && !row.absorbedBy);
  return { rows, subtotal: valueOf(total), total: unresolved.length ? null : valueOf(total), layers, unresolved,
    complete: complete && !unresolved.length };
}

const CLASS_PROGRESSION = {
  bab: [0, 7, 15], bdb: [0, 5, 11], bsb: [0, 5, 11],
  fortitude: [0, 3, 6], reflex: [0, 3, 6], will: [0, 3, 6], casterLevel: [0, 4, 10]
};
export function progressionEntry(statistic, rank) {
  const index = ['tertiary', 'secondary', 'primary'].indexOf(rank);
  if (index < 0 || !CLASS_PROGRESSION[statistic]) throw new Error('Unknown progression rank or statistic.');
  return { id: `progression-${statistic}`, label: `${statistic}: ${rank}`, dp: CLASS_PROGRESSION[statistic][index], source: source('Chapter 5 §7'), layer: 'class' };
}

export function classIndex(dp) {
  const index = finite(dp) / 208 * 100;
  const band = index < 90 ? 'low-outlier' : index < 95 ? 'acceptable-lower' : index <= 105 ? 'preferred' : index <= 110 ? 'acceptable-upper' : 'high-outlier';
  return { index, band, benchmark: 208 };
}

export function preclassBand(dp) {
  const value = finite(dp);
  if (value < 34) return 'major-low-outlier';
  if (value < 36) return 'low-review';
  if (value < 38) return 'acceptable-lower';
  if (value <= 42) return 'preferred';
  if (value <= 44) return 'acceptable-upper';
  if (value <= 46) return 'high-review';
  return 'major-high-outlier';
}

function typeRows(typeKey) {
  const type = RULES.types[typeKey];
  if (!type) throw new Error('Unknown creature type.');
  const covers = [];
  if (typeKey === 'eternal') covers.push('ability-eternal-essence');
  if (typeKey === 'plant') covers.push('ability-plant-resistance');
  return type.entries.map((entry, i) => {
    const covered = [...(i === 0 ? covers : [])];
    if (/Darkvision and Nightvision/.test(entry.label)) covered.push('darkvision', 'nightvision');
    if (entry.label === 'Darkvision') covered.push('darkvision');
    if (entry.label === 'Nightvision') covered.push('nightvision');
    if (entry.label === 'Poison immunity') covered.push('immunity-poison');
    if (entry.label.includes('Cannot be Flanked')) covered.push('ability-all-round-vision');
    return { ...entry, layer: 'type', covers: covered };
  });
}

const ABILITY_COVERS = {
  'wingless-flight': ['ability-hover'], 'ice-climb': ['ability-ice-stride'],
  'sunlight-vulnerability': ['ability-sunlight-weakness'], 'fire-healing': ['immunity-fire']
};

export function isSpellcaster(design) {
  const pc = RULES.catalog.classes.find(entry => keyOf(entry.name) === design.classKey);
  if (pc) return !!pc.magicalAbility;
  const required = ['adept-npc', 'hybrid-npc'].includes(design.classKey);
  if (design.caster && !required && !RULES.classes[design.classKey]?.optionalMagic) {
    throw new Error('This class does not support optional casting. Choose a supported casting class.');
  }
  return !!(required || (design.caster && RULES.classes[design.classKey]?.optionalMagic));
}

export function creatureLedger(design) {
  // AN IMPORTED PUBLISHED CREATURE (0.2.0, CX-05): its type, class or casting
  // may have no Codex ledger. Those become unresolved rows (from the adapter)
  // instead of refusing the whole valuation; a Codex-built design is unchanged.
  const imported = !!design.imported;
  let casts = false;
  const importNotes = [];
  try { casts = isSpellcaster(design); }
  catch (error) {
    if (!imported) throw error;
    importNotes.push({ id: 'unresolved-class-casting', label: 'Class casting', dp: null, layer: 'class', source: 'Imported creature', reason: error.message });
  }
  const entries = [...(imported && !RULES.types[design.typeKey] ? [] : typeRows(design.typeKey)), ...sizeLedger(design.size), ...importNotes];
  for (const [attribute, base] of Object.entries(design.attributes ?? {})) {
    // The creature baseline is 1 (Part II Chapter 2 §1). An imported published
    // creature records its own base as its baseline: its level-based increases
    // are progression, and its racial modifiers are priced on the race layer.
    const modifier = base - (design.attributeBaseline?.[attribute] ?? 1);
    if (!modifier) continue;
    let dp = null;
    try { dp = abilityModifierCost(modifier); } catch { /* The ledger carries the unresolved assessment. */ }
    entries.push({ id: `base-${attribute}`, label: `${attribute} relative to the creature baseline of 1`, dp,
      layer: 'attributes', source: source('Chapter 2 §1; Chapter 8 §17'), reason: dp === null ? 'This modifier needs an approved valuation.' : undefined });
  }
  const cls = RULES.classes[design.classKey];
  const pc = RULES.pcClasses[design.classKey];
  if (!cls && !pc && !imported) throw new Error('Choose exactly one default, NPC or PC class.');
  if (cls) {
    entries.push(...cls.entries.map(entry => ({ ...entry, layer: 'class' })));
    if (design.caster && cls.optionalMagic) entries.push({ id: 'class-magic', label: `${cls.name} casting infrastructure`, dp: cls.magicDP, source: cls.source, layer: 'class' });
  } else if (pc) entries.push({ id: 'pc-class', label: `${pc.name} published complete class`, dp: pc.dp, source: pc.source, layer: 'class' });
  // Published complete PC class totals already include their fixed casting.
  if (cls && casts && design.magicalAbility === 'constitution') entries.push(anchorEntry('constitutionCasting', 1, { layer: 'class' }));
  for (const [id, label, dp] of [['npc-ab', 'Half-level final Attack Bonus', 15], ['npc-db', 'Half-level final Defence', 11], ['npc-status', 'Class Bonus −2 status Defence', 6]]) {
    entries.push({ id, label, dp, layer: 'npc-combat', source: source('Chapter 8 §18') });
  }
  const land = finite(design.movement?.land ?? 25);
  if (land < 0) throw new Error('Land Speed must be nonnegative.');
  entries.push({ id: 'land', label: `${land}-foot land Speed`, dp: 2 * (land - 25) / 5, layer: 'movement', source: source('Chapter 2 §2') });
  for (const [mode, premium] of [['climb', 4], ['swim', 4], ['burrow', 6], ['fly', 8]]) {
    const speed = finite(design.movement?.[mode] ?? 0);
    if (speed < 0) throw new Error('Movement Speeds must be nonnegative.');
    if (speed) entries.push({ id: mode, label: `${speed}-foot ${mode} Speed`, dp: premium + speed / 5, layer: 'movement', source: source('Chapter 8 §19') });
  }
  for (const attack of new Set(design.attacks ?? [])) {
    const profile = RULES.attacks[attack];
    if (!profile) throw new Error('Unknown natural attack.');
    entries.push({ id: `attack-${attack}`, label: `${profile.name} at ${design.size}`, dp: naturalAttackCost(profile.name, design.size), layer: 'attacks', source: profile.source });
  }
  for (const selected of new Set(design.abilities ?? [])) {
    const ability = RULES.abilities[selected];
    if (!ability) throw new Error('Unknown ability valuation.');
    const profiles = design.profileCounts?.[selected];
    const quantity = ability.perProfile ? profiles : 1;
    if (ability.perProfile && (!Number.isInteger(quantity) || quantity < 1)) {
      entries.push({ id: `ability-${selected}`, label: ability.name, dp: null, layer: 'abilities', source: ability.source, reason: 'Select the distinct affected profiles.' }); continue;
    }
    for (const [i, component] of ability.entries.entries()) entries.push({
      id: `ability-${selected}-${i}`, label: `${ability.name}: ${component.label}`, dp: component.dp * quantity,
      layer: 'abilities', source: component.source,
      semantic: ability.entries.length === 1 ? `ability-${selected}` : null,
      covers: i === 0 ? ABILITY_COVERS[selected] ?? [] : []
    });
    // One group token covers the complete nested ledger, including its restrictions.
    const bundle = entries.filter(entry => entry.id.startsWith(`ability-${selected}-`));
    for (const row of bundle) row.bundle = `ability-${selected}`;
    if (selected === 'regeneration') {
      const adjustment = !String(design.regenerationBypass ?? '').trim() ? 5 : design.regenerationBypassFrequency === 'common' ? -2 : 0;
      if (adjustment) entries.push({ id: 'regeneration-bypass-adjustment', label: 'Regeneration bypass availability', dp: adjustment,
        layer: 'abilities', source: source('Chapter 8 §32, source block 2407') });
    }
  }
  // Remove complete overlapping bundles rather than just their positive lines.
  const covered = new Map();
  for (const row of entries) for (const token of row.covers ?? []) covered.set(token, row.id);
  const resolved = entries.map(row => covered.has(row.bundle) ? { ...row, includedBy: covered.get(row.bundle), overlapExplanation: `Included by ${covered.get(row.bundle)}` } : row);
  for (const value of design.adjustments ?? []) resolved.push(value);
  for (const uuid of new Set(design.feats ?? [])) {
    const feat = RULES.catalog.feats.find(entry => entry.uuid === uuid);
    const cost = { general: 4, racial: 5, class: 6, archetype: 8 }[feat?.category?.toLowerCase()];
    resolved.push({ id: `feat-${uuid}`, label: feat?.name ?? 'Unknown feat', dp: cost ?? null, layer: 'feats',
      source: source('Chapter 2 §5'), reason: cost === undefined ? 'This feat category needs a valuation.' : undefined });
  }
  for (const uuid of new Set(design.spells ?? [])) {
    const spell = RULES.catalog.spells.find(entry => entry.uuid === uuid);
    let cost = null;
    if (spell) {
      if (casts && !spell.specialist) cost = spell.ppCost === 0 ? 4 : 1.5;
      else cost = spellCost({ pp: spell.ppCost, specialist: spell.specialist, innate: !casts, availability: design.innateAvailability ?? '1/day' });
    }
    resolved.push({ id: `spell-${uuid}`, label: spell?.name ?? 'Unknown spell', dp: cost, layer: 'spells',
      source: source(casts ? 'Chapter 6 §§4–6' : 'Chapter 4 §§1–4') });
  }
  const ledger = evaluateLedger(resolved);
  let metrics = null;
  if (ledger.complete) {
    try { metrics = xpMetrics(ledger.total, design.level); }
    catch (error) { ledger.unresolved.push({ label: 'XP Multiplier', reason: error.message }); ledger.complete = false; }
  }
  return { ...ledger, metrics };
}
