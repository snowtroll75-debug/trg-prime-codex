/**
 * FIENDS & FABLES INTEROPERABILITY (0.2.0; joint Codex / Fiends & Fables audit,
 * 18 November 2026). Pure: no Foundry globals, so the batch DP report and the
 * tests run it in Node.
 *
 * Fiends & Fables Prime publishes finished creature Actors. The Codex reads
 * them in two places:
 *
 *   1. The Creature Builder, which may start a VARIANT from a published
 *      creature. The variant is a new world Actor; the compendium Actor is
 *      never written (CX-03).
 *   2. The DP balance report, which values each published creature against the
 *      Codex ledgers (CX-05). Published levels and statistics are never changed
 *      by it; a discrepancy is a finding for review.
 *
 * WHAT IS MAPPED, AND HOW
 *   type        the creature-type item's name -> RULES.types key
 *   class       the class item's name -> a default/NPC class (coreName) or a
 *               PC class; anything else is left unresolved
 *   attacks     natural weapons by base name, with the printed aliases the
 *               published blocks use ("Tail" for Tail Slap, "Wing"/"Wings")
 *   abilities   ability items by base name ("Darkvision (75 ft.)" -> darkvision)
 *   feats       by name against the Codex catalogue (core feats); parameterised
 *               and tiered printings at their base entry's category rate; the
 *               level-progression General feats credited back (RD-07); a
 *               module feat without a catalogue entry is unresolved
 *   spells      by name against the catalogue, valued per spell from its own
 *               innate availability
 *   attributes  the published base values. A Fiends & Fables creature's base
 *               includes the default 1 plus its level-based increases; those
 *               increases are progression, not purchased components, so the
 *               baseline for an imported creature is its own base (no
 *               attribute rows). Racial modifiers live on the race layer.
 *   race and heritage   valued PROVISIONALLY from their declared effects:
 *               ability modifiers (published modifier costs), resistances,
 *               immunities and weaknesses whose scope matches a published
 *               defensive schedule. Anything else on them is unresolved.
 *
 * Every component that cannot be valued is listed with its reason, so a total
 * is either complete or plainly provisional. Nothing here invents a cost.
 */
import { RULES } from '../data/rules.mjs';
import { abilityModifierCost, anchorEntry, keyOf, protectionCost, senseCost, spellCost, SIZES } from './dp.mjs';

export const FIENDS_MODULE_ID = 'fiends-and-fables-prime';
const SOURCE_FIENDS = 'Fiends & Fables Prime (published creature)';

/** Printed natural-attack names that differ from the Codex attack keys. */
export const ATTACK_ALIASES = Object.freeze({
  tail: 'tail-slap', 'tail-slap': 'tail-slap', wing: 'wings', wings: 'wings', claws: 'claw', claw: 'claw',
  bite: 'bite', gore: 'gore', hoof: 'hoof', hooves: 'hoof', slam: 'slam', sting: 'sting', tentacle: 'tentacle',
  tentacles: 'tentacle', 'unarmed-strike': 'unarmed-strike', unarmed: 'unarmed-strike', fist: 'unarmed-strike'
});

/** Printed ability names that differ from the Codex ability keys. */
export const ABILITY_ALIASES = Object.freeze({ 'snow-vision': 'snowvision' });

/** Senses the type ledger already prices; the ability item is a type grant, not a purchase. */
const TYPE_SENSES = new Set(['darkvision', 'nightvision', 'blindsight']);

/** "Weapon Focus (Brawling)" -> "Weapon Focus"; "Toughness II" -> "Toughness". */
export function featBaseName(name) {
  return String(name ?? '').replace(/\s*\([^)]*\)\s*$/, '').replace(/\s+(?:I|II|III|IV|V)$/, '').trim();
}

/** "Darkvision (75 ft.)", "Blindsight 30 ft" -> "darkvision", "blindsight". */
export function baseKey(name) {
  let n = String(name ?? '').trim().toLowerCase();
  n = n.replace(/\s*\(.*?\)\s*$/, '').replace(/\s+\d+\s*ft\.?\s*$/, '');
  return keyOf(n);
}

const MODE = { 2: 'add', 5: 'override' };
function changesOf(effect) {
  const rows = Array.isArray(effect?.system?.changes) && effect.system.changes.length ? effect.system.changes : (effect?.changes ?? []);
  return rows.map(c => ({ key: String(c.key ?? ''), value: c.value, type: c.type ?? MODE[c.mode] ?? 'add' }));
}

export function isFiendsActor(source) {
  return !!source?.flags?.[FIENDS_MODULE_ID] || /fiends-and-fables-prime/.test(String(source?._stats?.compendiumSource ?? ''));
}

function classKeyFor(name) {
  const byCore = Object.entries(RULES.classes).find(([, entry]) => entry.coreName === name)?.[0];
  if (byCore) return byCore;
  const pc = Object.keys(RULES.pcClasses).find(key => keyOf(RULES.pcClasses[key].name) === keyOf(name));
  return pc ?? null;
}

const DEFENCE_SCOPES = {
  // A single damage type ("fire", "cold") is the damageType schedule.
  damage: new Set(['acid', 'cold', 'electricity', 'fire', 'sonic', 'force', 'poison', 'essence', 'bludgeoning', 'piercing', 'slashing', 'coldfire', 'mental']),
  mundane: new Set(['mundane', 'mundane attacks']),
  physical: new Set(['physical', 'physical damage'])
};
/*
 * CONDITION AND EFFECT IMMUNITIES, valued by analogy with the published type
 * ledgers (Part II's Undead, Construct, Ooze and Elemental rows price the same
 * immunities: Bleed 5, Poison 5, Subdual 5, Mental damage 5, Precision 5,
 * Critical 8, Sleep/Disease/Paralysis/Soul Drain/Stunning/Polymorph 3, and each
 * of Doomed/Drained/Fatigued/Sickened/Unconscious 3). Provisional: the type
 * ledger prices them as part of a package.
 */
const CONDITION_IMMUNITY = Object.freeze({
  bleed: 5, bleeding: 5, subdual: 5, nonlethal: 5, precision: 5, 'precision damage': 5, critical: 8, 'critical hits': 8, criticals: 8,
  sleep: 3, disease: 3, paralysis: 3, paralyzed: 3, 'soul drain': 3, stunning: 3, stunned: 3, stun: 3, polymorph: 3,
  doomed: 3, drained: 3, fatigue: 3, fatigued: 3, sickened: 3, unconscious: 3, 'death effects': 3, charm: 3
});

function defenceRow(kind, word, layer, subject, typeLabels = new Set()) {
  const w = String(word ?? '').trim().toLowerCase();
  if (!w) return null;
  // Already priced by the creature type's own ledger ("Bleed immunity").
  const stem = w.replace(/ing$|ed$|ness$/, '').replace(/^paralys.*/, 'paralysis');
  if (kind === 'immunity' && [...typeLabels].some(l => l.startsWith(stem) && l.includes('immunity'))) return null;
  if (kind === 'immunity' && Object.hasOwn(CONDITION_IMMUNITY, w)) {
    return { id: `${layer}-${kind}-${keyOf(w)}`, label: `${subject}: immunity to ${w}`, dp: CONDITION_IMMUNITY[w], layer,
      source: 'TRG Prime Codex, Part II, Chapter 8 type ledgers (analogous immunity)', provenance: 'provisional-from-declaration' };
  }
  let scope = null;
  if (DEFENCE_SCOPES.damage.has(w)) scope = 'damageType';
  else if (DEFENCE_SCOPES.mundane.has(w)) scope = 'mundaneAttacks';
  else if (DEFENCE_SCOPES.physical.has(w)) scope = 'physicalDamage';
  const id = `${layer}-${kind}-${keyOf(w)}`;
  if (!scope) return { id, label: `${subject}: ${kind} to ${w}`, dp: null, layer, source: SOURCE_FIENDS, reason: 'No published schedule for this defensive scope; needs an approved valuation.' };
  const anchor = kind === 'immunity' ? 'immunity' : kind === 'resistance' ? 'resistance' : 'weakness';
  return { id, label: `${subject}: ${kind} to ${w}`, dp: protectionCost(kind, scope), layer, anchor, subject: w,
    source: `TRG Prime Codex, Part II, Chapter 2 §7 (${scope})`, provenance: 'provisional-from-declaration' };
}

/** A race or heritage item's declared effects as provisional ledger rows. */
export function packageRows(item, layer, typeLabels = new Set()) {
  const rows = [];
  if (!item) return rows;
  const subject = `${item.name} (${layer})`;
  const seen = new Set();
  for (const effect of item.effects ?? []) {
    if (effect.disabled) continue;
    for (const change of changesOf(effect)) {
      const ability = /^system\.attributes\.(\w+)\.racial$/.exec(change.key);
      if (ability) {
        const value = Number(change.value);
        let dp = null; let reason;
        try { dp = abilityModifierCost(value); } catch { reason = 'Ability modifiers outside −4 to +4 need an approved valuation.'; }
        rows.push({ id: `${layer}-ability-${ability[1]}`, label: `${subject}: ${ability[1]} ${value >= 0 ? '+' : ''}${value}`, dp, layer,
          source: 'TRG Prime Codex, Part II, Chapter 2 §1', anchor: 'abilityModifier', provenance: 'provisional-from-declaration', ...(reason ? { reason } : {}) });
        continue;
      }
      const defence = /^system\.combat\.(immunities|resistances|weaknesses)$/.exec(change.key);
      if (defence) {
        const kind = { immunities: 'immunity', resistances: 'resistance', weaknesses: 'weakness' }[defence[1]];
        for (const word of String(change.value).split(',').map(s => s.trim()).filter(Boolean)) {
          const row = defenceRow(kind, word, layer, subject, typeLabels);
          if (row && !seen.has(row.id)) { seen.add(row.id); rows.push(row); }
        }
        continue;
      }
      const dr = /^system\.combat\.naturalArmourFlat\.natural$/.exec(change.key);
      if (dr && Number(change.value)) {
        rows.push(anchorEntry('staticDR', Number(change.value), { id: `${layer}-natural-dr`, label: `${subject}: natural DR ${change.value}`, layer, provenance: 'provisional-from-declaration' }));
        continue;
      }
      if (change.key === 'system.resources.hp.other' && Number(change.value)) {
        rows.push(anchorEntry('fixedHP', Number(change.value), { id: `${layer}-fixed-hp`, label: `${subject}: fixed HP ${change.value}`, layer, provenance: 'provisional-from-declaration' }));
        continue;
      }
      // Defence and everything else: no automatic valuation.
      const id = `${layer}-${keyOf(change.key)}`;
      if (seen.has(id)) continue;
      seen.add(id);
      rows.push({ id, label: `${subject}: ${change.key.replace(/^system\./, '')} ${change.value}`, dp: null, layer, source: SOURCE_FIENDS,
        reason: 'Declared package component without an automatic Codex valuation.' });
    }
  }
  return rows;
}

function availabilityOf(spell) {
  const uses = String(spell?.system?.usesPerDay ?? '').trim().toLowerCase();
  const traits = String(spell?.system?.traits ?? '');
  if (/^(unlimited|at[- ]?will)$/.test(uses)) return 'at-will';
  if (/^constant$/.test(uses)) return 'constant';
  if (!uses && /\bfocus\b/i.test(traits)) return 'focus';
  if (/^\d+$/.test(uses)) return `${Number(uses)}/day`;
  return uses || '1/day';
}

/**
 * A Codex design (and its import notes) from a published creature's source.
 *
 * @param {object} source an Actor's toObject(), or a compendium source
 * @returns {{design: object, notes: {unmatched: string[], adjustments: object[], provisional: boolean}}}
 */
export function designFromFiends(source) {
  const items = source?.items ?? [];
  const type = items.find(i => i.type === 'creature-type');
  const typeGrants = new Set(String(type?.system?.grantedAbilities ?? '').split(/[,;]/).map(n => baseKey(n)).filter(Boolean));
  const cls = items.find(i => i.type === 'class');
  const race = items.find(i => i.type === 'race');
  const heritage = items.find(i => i.type === 'heritage');
  const typeKey = keyOf(type?.name ?? '');
  const classKey = cls ? classKeyFor(cls.name) : null;
  const attributes = Object.fromEntries(['strength', 'dexterity', 'constitution', 'intelligence', 'wisdom', 'charisma']
    .map(key => [key, Number(source?.system?.attributes?.[key]?.base ?? 1)]));
  const speed = (mode) => { const v = source?.system?.combat?.movement?.[mode]; return Number(v && typeof v === 'object' ? v.base : v) || 0; };
  const unmatched = [];
  const adjustments = [];

  const attacks = [];
  for (const w of items.filter(i => i.type === 'weapon' && i.system?.natural)) {
    const key = ATTACK_ALIASES[baseKey(w.name)];
    if (key && RULES.attacks[key]) { if (!attacks.includes(key)) attacks.push(key); }
    else unmatched.push(`natural attack: ${w.name}`);
  }
  const abilities = [];
  for (const a of items.filter(i => i.type === 'ability')) {
    const called = /^(caustic|fiery|freezing|shocking|toxic)-(aura|blood|strikes|grasp)$/.exec(baseKey(a.name));
    const key = ABILITY_ALIASES[baseKey(a.name)] ?? (called ? `elemental-${called[2]}` : baseKey(a.name));
    if (RULES.abilities[key]) { if (!abilities.includes(key)) abilities.push(key); continue; }
    if (TYPE_SENSES.has(key)) continue; // priced by the type (or flagged by the type ledger's overlap)
    // GRANTED BY ITS OWN TYPE (0.2.2): an ability the creature type itself
    // grants ("Returned Essence" on every Eternal) is a line of the type
    // ledger, not a purchase. Checked only after the catalogue lookup, so an
    // ability the Codex values on its own is unaffected.
    if (typeGrants.has(key)) continue;
    const sense = { scent: 'scent', tremorsense: 'tremorsense' }[key];
    if (sense) {
      adjustments.push({ id: `sense-${key}`, label: `Sense: ${a.name}`, dp: senseCost(sense, 'standard'), layer: 'senses',
        source: 'TRG Prime Codex, Part II, Chapter 8 §20', provenance: 'provisional-from-declaration' });
      continue;
    }
    if (/^source-stat-calibration/.test(key)) continue; // module bookkeeping, not a mechanic
    unmatched.push(`ability: ${a.name}`);
  }
  // FEATS (0.2.0, CX-07). A printed feat is matched by its exact catalogue
  // name and joins design.feats (the builder manages it on apply). A
  // parameterised or tiered printing — "Weapon Focus (Brawling)", "Toughness
  // II" — is valued at its catalogue entry's category rate as a DP row only:
  // it is never put in design.feats, so an apply cannot replace the printed
  // feat with an unparameterised copy. A creature's own level progression
  // grants a General feat at 1st level and every two levels after (Codex
  // Part I, Feats); Part II prices only ADDITIONAL feats, so that allowance
  // is credited back as one provisional row (rules decision RD-07).
  const feats = [];
  const FEAT_RATE = { general: 4, racial: 5, class: 6, archetype: 8 };
  let generalCount = 0;
  for (const f of items.filter(i => i.type === 'feat')) {
    const hit = RULES.catalog.feats.find(entry => keyOf(entry.name) === keyOf(f.name));
    if (hit) {
      if (String(hit.category).toLowerCase() === 'general') generalCount++;
      if (!feats.includes(hit.uuid)) { feats.push(hit.uuid); continue; }
    }
    const base = featBaseName(f.name);
    const entry = hit ?? RULES.catalog.feats.find(e => keyOf(e.name) === keyOf(base));
    const rate = FEAT_RATE[String(entry?.category ?? '').toLowerCase()];
    if (!entry || rate === undefined) { unmatched.push(`feat: ${f.name}`); continue; }
    if (!hit && String(entry.category).toLowerCase() === 'general') generalCount++;
    adjustments.push({ id: `feat-printed-${keyOf(f.name)}`, label: `Feat: ${f.name} (${entry.category}, as ${entry.name})`, dp: rate, layer: 'feats',
      source: 'TRG Prime Codex, Part II, Chapter 2 §5', provenance: 'provisional-from-declaration' });
  }
  const allowance = Math.min(generalCount, Math.ceil(Math.max(1, Number(source?.system?.identity?.level ?? 1)) / 2));
  if (allowance) adjustments.push({ id: 'feat-level-allowance', label: `General feats from level progression (${allowance})`, dp: -4 * allowance,
    layer: 'feats', source: 'TRG Prime Codex, Part I, Feats; Part II, Chapter 2 §5', provenance: 'provisional-rules-decision-RD-07' });
  for (const s of items.filter(i => i.type === 'spell')) {
    const hit = RULES.catalog.spells.find(entry => keyOf(entry.name) === keyOf(s.name));
    const id = `spell-${keyOf(s.name)}`;
    if (!hit) { adjustments.push({ id, label: `Spell: ${s.name}`, dp: null, layer: 'spells', source: SOURCE_FIENDS, reason: 'Not in the Codex spell catalogue.' }); continue; }
    if (adjustments.some(a => a.id === id)) continue;
    let dp = null; let reason;
    try { dp = spellCost({ pp: hit.ppCost, specialist: !!hit.specialist, innate: true, availability: availabilityOf(s) }); }
    catch (error) { reason = error.message; }
    adjustments.push({ id, label: `Innate spell: ${s.name} (${availabilityOf(s)})`, dp, layer: 'spells',
      source: 'TRG Prime Codex, Part II, Chapter 4 §§1–4', provenance: 'provisional-from-declaration', ...(reason ? { reason } : {}) });
  }
  const typeLabels = new Set((RULES.types[typeKey]?.entries ?? []).map(e => String(e.label).toLowerCase()));
  adjustments.push(...packageRows(race, 'race', typeLabels), ...packageRows(heritage, 'heritage', typeLabels));
  for (const label of unmatched) adjustments.push({ id: `unmatched-${keyOf(label)}`, label, dp: null, layer: 'existing', source: SOURCE_FIENDS,
    reason: 'Creature-specific component without a Codex valuation; preserved unchanged.' });

  const design = {
    schemaVersion: 1, kind: 'creature', name: String(source?.name ?? 'Creature'), description: source?.system?.details?.biography ?? '',
    level: Number(source?.system?.identity?.level ?? 1), typeKey: RULES.types[typeKey] ? typeKey : '',
    classKey: classKey ?? '', size: String(source?.system?.identity?.size ?? 'medium').toLowerCase(),
    caster: !!cls?.system?.magicalAbility, magicalTradition: cls?.system?.magicalTradition || 'ethereal',
    magicalAbility: cls?.system?.magicalAbility || 'intelligence',
    languages: source?.system?.identity?.languages ?? '', ethics: source?.system?.identity?.ethics ?? '',
    movement: { land: speed('land'), climb: speed('climb'), swim: speed('swim'), burrow: speed('burrow'), fly: speed('fly') },
    attributes, attributeBaseline: { ...attributes },
    attacks, abilities, feats, spells: [], innateAvailability: '1/day', profileCounts: {},
    regenerationBypass: '', regenerationBypassFrequency: 'normal',
    raceUuid: '', heritageUuid: '', adjustments,
    imported: { from: FIENDS_MODULE_ID, name: source?.name ?? '', publishedLevel: Number(source?.flags?.[FIENDS_MODULE_ID]?.published?.level ?? source?.system?.identity?.level ?? 0),
      publishedEL: Number(source?.flags?.[FIENDS_MODULE_ID]?.published?.effectiveLevel ?? source?.flags?.[FIENDS_MODULE_ID]?.published?.el ?? NaN) }
  };
  if (!design.typeKey) adjustments.push({ id: 'unresolved-type', label: `Creature type: ${type?.name ?? 'none'}`, dp: null, layer: 'type', source: SOURCE_FIENDS, reason: 'No Codex type ledger.' });
  if (!classKey) adjustments.push({ id: 'unresolved-class', label: `Class: ${cls?.name ?? 'none'}`, dp: null, layer: 'class', source: SOURCE_FIENDS, reason: 'No Codex class ledger for this class.' });
  if (!SIZES.includes(design.size)) adjustments.push({ id: 'unresolved-size', label: `Size: ${design.size}`, dp: null, layer: 'size', source: SOURCE_FIENDS, reason: 'Unknown size.' });
  return { design, notes: { unmatched, adjustments, provisional: true } };
}
