import { actorSource, MODULE_ID, newDesign, resolveNative, ATTRIBUTES } from './construction.mjs';
import { RULES } from '../data/rules.mjs';
import { keyOf } from './dp.mjs';
import { reconcileNativeGrants } from './native-grants.mjs';
import { spellEditPatch } from './spell-edit.mjs';
import { designFromFiends, isFiendsActor, ATTACK_ALIASES, ABILITY_ALIASES, baseKey } from './fiends-adapter.mjs';

async function settleNativeGrants(actor) {
  const core = file => new URL(`/systems/trg-prime/module/${file}.mjs`, window.location.href).href;
  const [numeric, items, aspects] = await Promise.all([
    import(core('feats-workflow')), import(core('grant-autorun')), import(core('aspect-workflow'))
  ]);
  return reconcileNativeGrants(actor, { reconcileAllGrants: numeric.reconcileAllGrants,
    queueGrantPass: items.queueGrantPass, pruneAspectBonusSpells: aspects.pruneAspectBonusSpells });
}

export function requireGM() {
  if (!game.user?.isGM) throw new Error('The Codex Toolkit requires a GM account.');
  if (game.system.id !== 'trg-prime' || game.release.generation !== 14) throw new Error('Requires TRG Prime on Foundry v14.');
}

export async function previewCreature(design) {
  requireGM();
  const source = await actorSource(design, uuid => resolveNative(uuid) ?? fromUuid(uuid));
  const actor = new CONFIG.Actor.documentClass(source);
  const hp = actor.system.resources.hp.max;
  source.system.resources.hp.value = hp;
  const type = actor.items.find(item => item.type === 'creature-type');
  const { hasNoDeathState } = await import(new URL('/systems/trg-prime/module/creature-type-rules.mjs', window.location.href).href);
  const issues = [];
  if (actor.system.combat.reach !== RULES.sizes[design.size].reach) issues.push('The core reach differs from the approved Codex size table. A core extension is required before actor creation for this size.');
  return { source, actor, statistics: {
    level: actor.system.identity.level, hp,
    bab: actor.system.combat.bab.total, bdb: actor.system.combat.bdb.total,
    attack: actor.system.combat.attack.total, defence: actor.system.combat.defence.total,
    saves: Object.fromEntries(Object.entries(actor.system.combat.saves).map(([key, save]) => [key, save.total])),
    pp: actor.system.resources.pp.max, skills: actor.system.skills,
    deathState: hasNoDeathState(type?.system) ? 0 : actor.system.combat.deathState,
    reach: actor.system.combat.reach, immunities: actor.system.combat.immunities, issues
  } };
}

export async function createCreature(design) {
  const { source, statistics } = await previewCreature(design);
  if (statistics.issues.length) throw new Error(statistics.issues.join(' '));
  const actor = await CONFIG.Actor.documentClass.create(source, { renderSheet: false });
  try {
    await settleNativeGrants(actor);
    actor.sheet.render({ force: true });
    return actor;
  } catch (error) {
    try {
      for (const message of game.messages.filter(message => message.speaker.actor === actor.id)) await message.delete();
      await actor.delete();
    } catch (recovery) {
      throw new Error(`${error.message} Creation cleanup needs attention for Actor ${actor.id}: ${recovery.message}`);
    }
    throw new Error(`${error.message} The incomplete actor was removed.`);
  }
}

export function designFromActor(actor) {
  requireGM();
  if (actor.type !== 'npc') throw new Error('Choose an NPC actor.');
  const saved = actor.getFlag(MODULE_ID, 'design');
  if (saved) return structuredClone(saved);
  // A FIENDS & FABLES CREATURE (0.2.0, CX-04): read with its printed attack
  // names, its race and heritage layers and its own base attributes, so an
  // unchanged apply writes back exactly what the creature already has.
  if (isFiendsActor(actor.toObject())) return designFromFiends(actor.toObject()).design;
  const design = newDesign();
  design.name = actor.name;
  design.level = actor.system.identity.level;
  design.size = actor.system.identity.size;
  design.languages = actor.system.identity.languages ?? '';
  design.ethics = actor.system.identity.ethics ?? '';
  design.description = actor.system.details.biography ?? '';
  design.attributes = Object.fromEntries(ATTRIBUTES.map(key => [key, actor._source.system.attributes[key].base]));
  design.movement = Object.fromEntries(['land', 'climb', 'swim', 'burrow', 'fly'].map(mode => [mode, actor._source.system.combat.movement[mode].base]));
  const types = actor.items.filter(item => item.type === 'creature-type');
  const classes = actor.items.filter(item => item.type === 'class');
  if (types.length !== 1 || classes.length !== 1) throw new Error('Resolve the actor’s type/class selection before importing the construction.');
  design.typeKey = keyOf(types[0].name);
  design.classKey = Object.keys(RULES.classes).find(key => RULES.classes[key].coreName === classes[0].name) ?? keyOf(classes[0].name);
  design.caster = !!classes[0].system.magicalAbility;
  design.magicalAbility = classes[0].system.magicalAbility || 'intelligence';
  design.magicalTradition = classes[0].system.magicalTradition || 'ethereal';
  design.attacks = actor.items.filter(item => item.type === 'weapon' && item.system.natural)
    .map(item => keyOf(item.name)).filter(key => RULES.attacks[key]);
  design.abilities = actor.items.filter(item => item.type === 'ability').map(item => keyOf(item.name)).filter(key => RULES.abilities[key]);
  const unmatched = actor.items.filter(item => !['class', 'creature-type'].includes(item.type) &&
    !design.attacks.includes(keyOf(item.name)) && !design.abilities.includes(keyOf(item.name)));
  if (unmatched.length) design.adjustments.push({ id: 'existing-customisations', layer: 'existing',
    label: 'Existing items and customisations', dp: null, reason: `${unmatched.length} items require a component valuation.`, source: 'Existing actor inspection' });
  return design;
}

const editablePaths = [
  'name', 'system.identity.level', 'system.identity.size', 'system.identity.languages', 'system.identity.ethics',
  'system.details.biography', 'prototypeToken.name', 'prototypeToken.width', 'prototypeToken.height',
  ...ATTRIBUTES.map(key => `system.attributes.${key}.base`),
  ...['land', 'climb', 'swim', 'burrow', 'fly'].map(mode => `system.combat.movement.${mode}.base`)
];

export async function applyConstruction(actor, design, baseline) {
  requireGM();
  // A PUBLISHED CREATURE IS NEVER EDITED IN PLACE (0.2.0, CX-03). Start a
  // variant (importCompendiumCreature) and edit that world Actor instead.
  if (actor.pack || actor.compendium) throw new Error('Compendium creatures are read-only. Start a variant from it and edit the variant.');
  if (JSON.stringify(actor.toObject()) !== baseline) throw new Error('The actor changed after it was opened. Reload it and review the current construction.');
  const { source, statistics } = await previewCreature(design);
  if (statistics.issues.length) throw new Error(statistics.issues.join(' '));
  if (JSON.stringify(actor.toObject()) !== baseline) throw new Error('The actor changed after it was opened. Reload it and review the current construction.');
  const previous = actor.toObject();
  const get = (object, path) => path.split('.').reduce((value, key) => value?.[key], object);
  const before = Object.fromEntries(editablePaths.map(path => [path, get(previous, path)]));
  const changes = Object.fromEntries(editablePaths.map(path => [path, get(source, path)]));
  const oldFlag = previous.flags?.[MODULE_ID];
  const created = [], removed = [], updated = [];
  const byKey = new Map(actor.items.filter(item => item.getFlag(MODULE_ID, 'componentKey'))
    .map(item => [item.getFlag(MODULE_ID, 'componentKey'), item]));
  // Previously untracked core type/class documents are the explicit selection.
  for (const [key, type] of [['type', 'creature-type'], ['class', 'class']]) {
    const matches = actor.items.filter(item => item.type === type);
    if (matches.length !== 1) throw new Error('Apply requires exactly one existing type and class.');
    if (!byKey.has(key)) byKey.set(key, matches[0]);
  }
  for (const item of actor.items) {
    // Printed names (0.2.0, CX-04): "Tail" is the Tail Slap, "Acute Sense
    // (Sight)" the Acute Sense — matched as the same component, never added twice.
    const base = baseKey(item.name);
    const attack = ATTACK_ALIASES[base] ?? keyOf(item.name);
    const called = /^(caustic|fiery|freezing|shocking|toxic)-(aura|blood|strikes|grasp)$/.exec(base);
    const ability = ABILITY_ALIASES[base] ?? (called ? `elemental-${called[2]}` : RULES.abilities[keyOf(item.name)] ? keyOf(item.name) : base);
    if (item.type === 'weapon' && item.system.natural && RULES.attacks[attack] && !byKey.has(`attack-${attack}`)) byKey.set(`attack-${attack}`, item);
    if (item.type === 'ability' && RULES.abilities[ability] && !byKey.has(`ability-${ability}`)) byKey.set(`ability-${ability}`, item);
    // A published creature's feats and spells are catalogue documents under
    // their own names; matched so an unchanged apply never adds a second copy.
    if (item.type === 'feat' || item.type === 'spell') {
      const entry = RULES.catalog[item.type === 'feat' ? 'feats' : 'spells'].find(e => keyOf(e.name) === keyOf(item.name));
      const chosen = (item.type === 'feat' ? design.feats : design.spells) ?? [];
      if (entry && chosen.includes(entry.uuid) && !byKey.has(`${item.type}-${entry.uuid}`)) byKey.set(`${item.type}-${entry.uuid}`, item);
    }
  }
  try {
    await actor.update({ ...changes, [`flags.${MODULE_ID}`]: source.flags[MODULE_ID] });
    for (const desired of source.items) {
      const key = desired.flags[MODULE_ID].componentKey;
      const existing = byKey.get(key);
      const sameSource = existing && (existing.getFlag(MODULE_ID, 'sourceUuid') === desired.flags[MODULE_ID].sourceUuid ||
        existing._stats?.compendiumSource === desired.flags[MODULE_ID].sourceUuid || existing.name === desired.name ||
        // A published creature's printed-name copy of the same component (CX-04).
        (key.startsWith('attack-') || key.startsWith('ability-') || key.startsWith('feat-') || (design.imported && key.startsWith('spell-'))));
      if (sameSource) {
        // Preserve the existing item’s manual changes. Only builder-controlled
        // casting configuration and provenance are updated deliberately.
        const patch = { _id: existing.id, [`flags.${MODULE_ID}`]: desired.flags[MODULE_ID] };
        if (key === 'class' && !design.imported) {
          patch['system.magicalAbility'] = desired.system.magicalAbility;
          patch['system.magicalTradition'] = desired.system.magicalTradition;
          patch['system.progression'] = desired.system.progression;
        }
        if (key.startsWith('spell-')) {
          const { itemUsesMax, itemUsesRemaining, usesPoolItem } = await import(new URL('/systems/trg-prime/module/uses-workflow.mjs', window.location.href).href);
          const spellPatch = spellEditPatch(existing, desired, previous.flags?.[MODULE_ID]?.design, system => {
            // Read a proposed configuration without mutating the live document.
            // Retain the real actor for native feat/declaration and shared-pool
            // resolution, and repair the legacy literal for this read only.
            const probe = { name: existing.name, type: existing.type, actor: existing.actor,
              system: { ...system, usesPerDay: String(system.usesPerDay).trim().toLowerCase() === 'focus' ? '' : system.usesPerDay } };
            return { max: itemUsesMax(probe), remaining: itemUsesRemaining(probe), shared: usesPoolItem(probe) !== probe };
          });
          patch[`flags.${MODULE_ID}`].spellConfiguration = spellPatch[`flags.${MODULE_ID}.spellConfiguration`];
          delete spellPatch[`flags.${MODULE_ID}.spellConfiguration`];
          Object.assign(patch, spellPatch);
        }
        // ETERNAL'S DEATH STATE (0.2.0, CX-01). Only a type the Codex itself
        // placed takes the Codex's reading. Graham ruled RD-01 on 18 Nov 2026
        // (the Codex table governs: no Death State) and core 3.699.0 and
        // Fiends & Fables 0.46.1 now agree, so the guard changes nothing on
        // a current published creature; it still protects an older copy.
        if (key === 'type' && design.typeKey === 'eternal' && existing.getFlag(MODULE_ID, 'sourceUuid')) patch['system.noDeathState'] = desired.system.noDeathState;
        updated.push(existing.toObject());
        await actor.updateEmbeddedDocuments('Item', [patch]);
        byKey.delete(key);
      } else {
        if (existing) { removed.push(existing.toObject()); await existing.delete(); byKey.delete(key); }
        const documents = await actor.createEmbeddedDocuments('Item', [desired]);
        created.push(...documents.map(document => document.id));
      }
    }
    for (const item of byKey.values()) {
      removed.push(item.toObject()); await item.delete();
    }
    await settleNativeGrants(actor);
  } catch (error) {
    const recoveryErrors = [];
    try {
      const remainingCreated = created.filter(id => actor.items.has(id));
      if (remainingCreated.length) await actor.deleteEmbeddedDocuments('Item', remainingCreated);
      if (updated.length) await actor.updateEmbeddedDocuments('Item', updated.map(item => ({
        ...item, ...(!item.flags?.[MODULE_ID] ? { [`flags.-=${MODULE_ID}`]: null } : {})
      })));
      if (removed.length) await actor.createEmbeddedDocuments('Item', removed, { keepId: true });
      await actor.update({ ...before, [oldFlag ? `flags.${MODULE_ID}` : `flags.-=${MODULE_ID}`]: oldFlag ?? null });
    } catch (recovery) { recoveryErrors.push(recovery.message); }
    throw new Error(`${error.message}${recoveryErrors.length ? ` Recovery needs attention: ${recoveryErrors.join('; ')}` : ' The edited fields were restored.'}`);
  }
  return actor;
}

export async function saveProject(design, existing = null) {
  requireGM();
  const flags = { [MODULE_ID]: { schemaVersion: 1, project: structuredClone(design) } };
  if (existing) return existing.update({ name: `Codex — ${design.name}`, [`flags.${MODULE_ID}`]: flags[MODULE_ID] });
  return JournalEntry.create({ name: `Codex — ${design.name}`, flags, pages: [] });
}


/**
 * START A VARIANT FROM A PUBLISHED CREATURE (0.2.0, CX-03). Copies a
 * compendium Actor (normally Fiends & Fables Prime) into the world as a new
 * Actor with its artwork, description, items and effects intact, records
 * where it came from, and returns it for the builder to edit. The compendium
 * document is only read.
 *
 * @param {string} uuid a Compendium Actor UUID
 * @param {{name?: string, folder?: string|null}} [options]
 */
export async function importCompendiumCreature(uuid, { name = '', folder = null } = {}) {
  requireGM();
  const source = await fromUuid(uuid);
  if (!source || source.documentName !== 'Actor') throw new Error('Choose a compendium creature.');
  if (!source.pack) throw new Error('This creature is already a world Actor; edit it directly.');
  if (source.type !== 'npc') throw new Error('Only NPC creatures can be used as a construction starting point.');
  const data = source.toObject();
  delete data._id;
  data.name = String(name || `${source.name} (variant)`);
  data.folder = folder;
  const { design, notes } = designFromFiends(data);
  data.flags ??= {};
  data.flags[MODULE_ID] = { ...(data.flags[MODULE_ID] ?? {}),
    variantOf: { uuid, name: source.name, module: source.pack.split('.')[0], version: game.modules.get(source.pack.split('.')[0])?.version ?? '' },
    importNotes: { unmatched: notes.unmatched, provisional: true } };
  foundry.utils.setProperty(data, '_stats.compendiumSource', uuid);
  const actor = await CONFIG.Actor.documentClass.create(data, { renderSheet: false });
  return { actor, design: { ...design, name: data.name } };
}

/** Published creatures the builder can start from: every Actor pack of an active module. */
export async function compendiumCreatureChoices() {
  const out = [];
  for (const pack of game.packs.filter(p => p.documentName === 'Actor' && p.metadata.packageType === 'module')) {
    const index = await pack.getIndex({ fields: ['type'] });
    for (const entry of index) if (entry.type === 'npc') out.push({ uuid: entry.uuid ?? `Compendium.${pack.collection}.Actor.${entry._id}`, name: entry.name, pack: pack.metadata.label });
  }
  return out.sort((a, b) => a.name.localeCompare(b.name));
}
