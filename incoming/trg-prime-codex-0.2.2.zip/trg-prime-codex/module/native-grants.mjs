// Await the native queues rather than guessing when asynchronous hooks finish.
// A second pass also covers descendants granted by newly created foundations.
export async function reconcileNativeGrants(actor, { reconcileAllGrants, queueGrantPass, pruneAspectBonusSpells }) {
  for (let pass = 0; pass < 32; pass++) {
    const before = JSON.stringify(actor.toObject());
    await reconcileAllGrants(actor);
    await queueGrantPass(actor);
    await pruneAspectBonusSpells(actor);
    await reconcileAllGrants(actor);
    if (JSON.stringify(actor.toObject()) === before) return actor;
  }
  throw new Error('Native grants did not converge. Review the creature’s grant declarations.');
}
