const tokens = traits => String(traits ?? '').split(',').map(t => t.trim()).filter(Boolean);
const finiteCapacity = system => {
  if (!system.innate) return null;
  const count = String(system.usesPerDay ?? '').trim();
  if (/^\d+$/.test(count)) return Number(count);
  // Also recognise the old Codex literal when repairing a saved spell. Its
  // recorded zero must survive even though the native parser ignored it.
  if ((!count || count.toLowerCase() === 'focus') && tokens(system.traits).some(t => t.toLowerCase() === 'focus')) return 1;
  return null;
};

// Native capacity includes actor feats, declarations and item bonuses. The
// adapter supplies this reader so this arithmetic also remains testable locally.
export function spellEditPatch(existing, desired, previousDesign = {}, readUses) {
  const old = existing.flags?.['trg-prime-codex']?.spellConfiguration;
  const next = desired.flags['trg-prime-codex'].spellConfiguration;
  const baseHasFocus = tokens(next.baseTraits).some(t => t.toLowerCase() === 'focus');
  const previouslyAddedFocus = old?.addedFocus ?? (previousDesign.innateAvailability === 'focus' && !baseHasFocus);
  let traits = tokens(existing.system.traits);
  if (previouslyAddedFocus) traits = traits.filter(t => t.toLowerCase() !== 'focus');
  if (next.addedFocus && !traits.some(t => t.toLowerCase() === 'focus')) traits.push('Focus');
  const system = { ...existing.system, innate: desired.system.innate,
    usesPerDay: desired.system.usesPerDay, traits: traits.join(', ') };
  const resource = value => {
    if (!value.innate) return { max: null };
    if (readUses) return readUses(value);
    const max = finiteCapacity(value);
    return { max, remaining: Math.max(0, Math.min(max ?? Infinity, Number(value.usesValue) || 0)) };
  };
  const current = resource(existing.system), target = resource(system);
  let spent = Number(old?.spentUses ?? 0);
  if (Number.isFinite(current.max)) {
    // The live pool is authoritative after casting, Refocus, daily preparation
    // and bonus changes. Only retain hidden debt from a prior capacity reduction
    // while the pool remains exhausted; an actual restoration clears that debt.
    spent = Math.max(0, current.max - current.remaining,
      current.remaining === 0 && old?.remainingAtEdit === 0 ? spent : 0);
  }
  const remaining = Number.isFinite(target.max) ? Math.max(0, target.max - spent) : desired.system.usesValue;
  return {
    'system.innate': desired.system.innate,
    'system.usesPerDay': desired.system.usesPerDay,
    // A shared member has no counter of its own. Editing it must not write an
    // independent allowance or touch the unmanaged owner.
    ...(!current.shared && !target.shared ? { 'system.usesValue': remaining } : {}),
    'system.traits': traits.join(', '),
    'flags.trg-prime-codex.spellConfiguration': { ...next, spentUses: spent, remainingAtEdit: remaining }
  };
}
