import { RULES } from '../data/rules.mjs';
import { ANCHORS, anchorEntry, classIndex, evaluateLedger, preclassBand, xpMetrics } from './dp.mjs';
import { newDesign, validateDesign, ATTRIBUTES, MODULE_ID } from './construction.mjs';
import { applyConstruction, compendiumCreatureChoices, createCreature, designFromActor, importCompendiumCreature, previewCreature, requireGM, saveProject } from './foundry-adapter.mjs';

const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api;
const baseUrl = new URL('../', import.meta.url).href;
const options = object => Object.entries(object).map(([value, entry]) => ({ value, label: entry.name ?? entry.label ?? value }));
const choices = values => Object.fromEntries(values.map(value => [value, value]));

export class CodexToolkit extends HandlebarsApplicationMixin(ApplicationV2) {
  static DEFAULT_OPTIONS = {
    id: 'trg-prime-codex-toolkit', tag: 'form', classes: ['trg-codex'],
    window: { title: 'TRG Prime Codex Toolkit', icon: 'fa-solid fa-book-skull', resizable: true },
    position: { width: 1120, height: 820 },
    form: { closeOnSubmit: false, handler: CodexToolkit.submit },
    actions: {
      creature: CodexToolkit.showCreature, designer: CodexToolkit.showDesigner, library: CodexToolkit.showLibrary,
      review: CodexToolkit.review, create: CodexToolkit.create, apply: CodexToolkit.apply,
      save: CodexToolkit.save, load: CodexToolkit.load, loadActor: CodexToolkit.loadActor, importCompendium: CodexToolkit.importCompendium,
      addComponent: CodexToolkit.addComponent, removeComponent: CodexToolkit.removeComponent,
      export: CodexToolkit.export, duplicate: CodexToolkit.duplicate,
      useComponents: CodexToolkit.useComponents
    }
  };
  static PARTS = { main: { template: 'modules/trg-prime-codex/templates/toolkit.hbs' } };
  design = newDesign();
  mode = 'creature';
  project = null;
  actor = null;
  baseline = null;
  preview = null;
  packageKind = 'preclass';
  components = [];
  message = '';
  busy = false;
  rulesText = [];

  async _onRender(context, options) {
    await super._onRender(context, options);
    this.element.querySelector('[name="classKey"]')?.addEventListener('change', async () => {
      this.read();
      if (!RULES.classes[this.design.classKey]?.optionalMagic) this.design.caster = false;
      await this.render({ force: true });
    });
  }

  read() {
    if (!this.element) return;
    const form = new FormData(this.element);
    if (this.mode === 'creature') {
      const draft = this.design;
      for (const key of ['name', 'description', 'typeKey', 'classKey', 'size', 'languages', 'ethics', 'magicalTradition', 'magicalAbility', 'innateAvailability', 'raceUuid', 'heritageUuid', 'regenerationBypass', 'regenerationBypassFrequency']) {
        if (form.has(key)) draft[key] = String(form.get(key));
      }
      draft.level = Number(form.get('level'));
      draft.caster = form.has('caster');
      for (const key of ATTRIBUTES) draft.attributes[key] = Number(form.get(`attribute-${key}`));
      for (const key of Object.keys(draft.movement)) draft.movement[key] = Number(form.get(`movement-${key}`));
      for (const key of ['abilities', 'attacks', 'feats', 'spells']) draft[key] = form.getAll(key);
      for (const key of Object.keys(RULES.abilities)) {
        if (form.has(`profiles-${key}`)) draft.profileCounts[key] = Number(form.get(`profiles-${key}`));
      }
      this.preview = null;
    } else if (this.mode === 'designer') {
      this.packageKind = String(form.get('packageKind') ?? this.packageKind);
    }
  }

  async task(callback) {
    if (this.busy) return;
    this.busy = true;
    try { requireGM(); await callback(); }
    catch (error) { this.message = error.message; console.error('TRG Prime Codex', error); }
    finally { this.busy = false; await this.render({ force: true }); }
  }

  async _prepareContext() {
    if (!this.compendiumCreatures) { try { this.compendiumCreatures = await compendiumCreatureChoices(); } catch { this.compendiumCreatures = []; } }
    let ledger = null, assessment = null;
    try {
      ledger = this.mode === 'creature' ? validateDesign(this.design) : evaluateLedger(this.components);
      if (ledger.total !== null) {
        if (this.packageKind === 'class') assessment = classIndex(ledger.total);
        else if (this.packageKind === 'preclass') assessment = { band: preclassBand(ledger.total), benchmark: 40 };
        else if (ledger.complete) assessment = xpMetrics(ledger.total, this.design.level);
      }
    } catch (error) { this.message = error.message; }
    const selected = (entries, values) => entries.map(entry => ({ ...entry, selected: values.includes(entry.value) }));
    const classOptions = [...options(RULES.classes), ...options(RULES.pcClasses)];
    const journalProjects = game.journal.filter(entry => entry.flags?.[MODULE_ID]?.project);
    const classRule = RULES.classes[this.design.classKey];
    return {
      mode: this.mode, isCreature: this.mode === 'creature', isDesigner: this.mode === 'designer', isLibrary: this.mode === 'library',
      draft: this.design, ledger, assessment, message: this.message, preview: this.preview?.statistics,
      canCreate: ledger?.complete && !this.preview?.statistics.issues.length && this.mode === 'creature', editing: !!this.actor, busy: this.busy,
      optionalCastingAllowed: !!classRule?.optionalMagic,
      configurableCasting: !!classRule && (classRule.optionalMagic || ['adept-npc', 'hybrid-npc'].includes(this.design.classKey)),
      castingHint: RULES.pcClasses[this.design.classKey] ? 'This PC class supplies its own casting rules and ability.' : 'This class has no optional casting. Choose a casting class to add it.',
      hasRegeneration: this.design.abilities.includes('regeneration'),
      types: options(RULES.types), classes: classOptions, sizes: options(RULES.sizes),
      attacks: selected(options(RULES.attacks), this.design.attacks),
      abilities: selected(Object.entries(RULES.abilities).map(([value, entry]) => ({ value, label: `${entry.name} (${entry.dp} DP${entry.perProfile ? '/profile' : ''})` })), this.design.abilities),
      profiles: this.design.abilities.filter(key => RULES.abilities[key]?.perProfile).map(key => ({ key, name: RULES.abilities[key].name, count: this.design.profileCounts[key] ?? 0 })),
      attributes: ATTRIBUTES.map(key => ({ key, value: this.design.attributes[key] })),
      movement: Object.entries(this.design.movement).map(([key, value]) => ({ key, value })),
      races: RULES.catalog.races, heritages: RULES.catalog.heritages,
      feats: selected(RULES.catalog.feats.map(entry => ({ value: entry.uuid, label: `${entry.name} — ${entry.category}` })), this.design.feats),
      spells: selected(RULES.catalog.spells.map(entry => ({ value: entry.uuid, label: `${entry.name} (${entry.ppCost} PP)` })), this.design.spells),
      anchors: Object.entries(ANCHORS).map(([value, entry]) => ({ value, label: entry.label })),
      projects: journalProjects.map(entry => ({ id: entry.id, name: entry.name })),
      actors: game.actors.filter(actor => actor.type === 'npc').map(actor => ({ id: actor.id, name: actor.name })),
      compendiumCreatures: this.compendiumCreatures ?? [],
      components: this.components, packageKind: this.packageKind,
      rules: this.rulesText, coreVersion: RULES.coreVersion,
      traditions: choices(['arcane', 'divinity', 'ethereal', 'verdant']),
      magicalAbilities: choices(['intelligence', 'wisdom', 'charisma', 'constitution']),
      availabilities: choices(['1/day', '2/day', '3/day', 'focus', 'at-will', 'constant']),
      packageKinds: { preclass: 'Race + Heritage + Background (40 DP)', class: 'Complete PC class (208 DP)', complete: 'Complete construction (250 DP)' },
      layers: choices(['race', 'heritage', 'background', 'class', 'magic', 'ability', 'adjustment']),
      bypassFrequencies: { normal: 'Reasonably obtainable', common: 'Exceptionally common' }
    };
  }

  static async submit() { this.read(); await this.render({ force: true }); }
  static async showCreature() { this.read(); this.mode = 'creature'; await this.render({ force: true }); }
  static async showDesigner() { this.read(); this.mode = 'designer'; await this.render({ force: true }); }
  static async showLibrary() {
    this.read(); this.mode = 'library';
    if (!this.rulesText.length) {
      const response = await fetch(`${baseUrl}data/source-index.json`);
      if (!response.ok) throw new Error('Unable to load the sourcebook reference.');
      const blocks = await response.json();
      this.rulesText = blocks.map(block => ({ id: block.index,
        text: block.kind === 'table' ? block.rows.map(row => row.join(' | ')).join('\n') : block.text }));
    }
    await this.render({ force: true });
  }
  static async review() {
    this.read();
    await this.task(async () => { this.preview = await previewCreature(this.design); this.message = 'Review the derived statistics and component ledger before creating or applying.'; });
  }
  static async create() {
    this.read();
    await this.task(async () => { const actor = await createCreature(this.design); this.message = `Created ${actor.name}.`; });
  }
  static async apply() {
    this.read();
    await this.task(async () => {
      if (!this.actor) throw new Error('Load an NPC first.');
      await applyConstruction(this.actor, this.design, this.baseline);
      this.baseline = JSON.stringify(this.actor.toObject()); this.message = `Updated ${this.actor.name}.`;
    });
  }
  static async save() {
    this.read();
    await this.task(async () => {
      const design = this.mode === 'designer' ? { schemaVersion: 1, kind: 'package', name: `${this.packageKind} design`, packageKind: this.packageKind, components: this.components } : this.design;
      this.project = await saveProject(design, this.project); this.message = 'Project saved in Journals.';
    });
  }
  static async load() {
    const id = new FormData(this.element).get('projectId');
    await this.task(async () => {
      const project = game.journal.get(id); const saved = project?.getFlag(MODULE_ID, 'project');
      if (!saved || saved.schemaVersion !== 1) throw new Error('Choose a compatible saved project.');
      this.project = project; this.actor = null; this.baseline = null;
      if (saved.kind === 'package') { this.components = structuredClone(saved.components); this.packageKind = saved.packageKind; this.mode = 'designer'; }
      else { this.design = structuredClone(saved); this.mode = 'creature'; }
      this.message = `Loaded ${project.name}.`;
    });
  }
  static async importCompendium() {
    const uuid = new FormData(this.element).get('compendiumUuid');
    await this.task(async () => {
      if (!uuid) throw new Error('Choose a published creature.');
      const { actor, design } = await importCompendiumCreature(uuid);
      this.design = design; this.actor = actor; this.project = null;
      this.baseline = JSON.stringify(actor.toObject()); this.mode = 'creature';
      this.message = `Created ${actor.name} as a world variant. The published creature is unchanged. Components without a Codex valuation are listed as unresolved, so its DP is provisional.`;
    });
  }
  static async loadActor() {
    const id = new FormData(this.element).get('actorId');
    await this.task(async () => {
      const actor = game.actors.get(id); if (!actor) throw new Error('Choose an NPC.');
      this.design = designFromActor(actor); this.actor = actor; this.project = null;
      this.baseline = JSON.stringify(actor.toObject()); this.mode = 'creature';
      this.message = 'Loaded the actor. Unvalued customisations must be resolved before applying a complete construction.';
    });
  }
  static async addComponent() {
    this.read();
    await this.task(async () => {
      const form = new FormData(this.element);
      const anchor = String(form.get('anchor'));
      const component = anchorEntry(anchor, String(form.get('quantity')), {
        id: foundry.utils.randomID(), layer: String(form.get('layer')), subject: String(form.get('subject')),
        label: String(form.get('subject')) || ANCHORS[anchor].label
      });
      this.components.push(component);
    });
  }
  static async removeComponent(event, target) {
    this.components = this.components.filter(component => component.id !== target.dataset.id);
    await this.render({ force: true });
  }
  static async useComponents() {
    this.read();
    await this.task(async () => {
      if (this.components.some(component => !['race', 'heritage', 'adjustment'].includes(component.layer))) {
        throw new Error('Choose race, heritage or adjustment layers for additional creature components. The selected class already has its own ledger.');
      }
      this.design.adjustments = structuredClone(this.components);
      this.mode = 'creature';
      this.message = 'Linked the race, heritage and adjustment components to this construction.';
    });
  }
  static async duplicate() {
    this.read(); this.project = null; this.actor = null; this.baseline = null;
    this.design.name += ' (copy)'; this.message = 'Duplicated as an unsaved project.';
    await this.render({ force: true });
  }
  static async export() {
    this.read();
    const output = this.mode === 'designer' ? { schemaVersion: 1, kind: 'package', packageKind: this.packageKind, components: this.components, ledger: evaluateLedger(this.components) } : { design: this.design, ledger: validateDesign(this.design) };
    const url = URL.createObjectURL(new Blob([JSON.stringify(output, null, 2)], { type: 'application/json' }));
    const link = document.createElement('a'); link.href = url; link.download = 'trg-prime-codex-project.json'; link.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
}

export function openToolkit() {
  requireGM();
  const app = new CodexToolkit(); app.render({ force: true }); return app;
}
