import { openToolkit } from '../module/toolkit.mjs';
import * as dp from '../module/dp.mjs';
import * as construction from '../module/construction.mjs';
import * as fiends from '../module/fiends-adapter.mjs';
import { importCompendiumCreature, compendiumCreatureChoices } from '../module/foundry-adapter.mjs';

export { openToolkit };

Hooks.once('init', () => {
  game.settings.registerMenu('trg-prime-codex', 'toolkit', {
    name: 'Codex Toolkit', label: 'Open Codex Toolkit', hint: 'Build creatures and inspect Development Point ledgers.',
    icon: 'fa-solid fa-book-skull', restricted: true,
    type: class extends foundry.applications.api.ApplicationV2 {
      render() { return openToolkit(); }
    }
  });
});

Hooks.once('ready', () => {
  game.modules.get('trg-prime-codex').api = Object.freeze({ open: openToolkit, dp, construction, fiends, importCompendiumCreature, compendiumCreatureChoices });
});

Hooks.on('renderActorDirectory', (application, html) => {
  if (!game.user.isGM) return;
  const element = html instanceof HTMLElement ? html : html?.[0];
  if (!element || element.querySelector('[data-codex-toolkit]')) return;
  const button = document.createElement('button');
  button.type = 'button'; button.dataset.codexToolkit = 'true'; button.textContent = 'Codex Creature Builder';
  button.addEventListener('click', openToolkit);
  (element.querySelector('.directory-header') ?? element).append(button);
});
