/**
 * Codex 0.2.0 — joint Codex / Fiends & Fables audit regressions (pure; Node).
 *
 *   node --test tests/joint-audit.test.mjs
 *
 * FF_PACKS=<path to fiends-and-fables-prime/packs> adds the integration cases
 * that read every published creature (needs classic-level; set
 * CLASSIC_LEVEL_ROOT to a folder whose node_modules has it).
 * CODEX_015=<path to an unpacked 0.1.5 module> adds the "a Codex-built design
 * values exactly as before" comparison.
 */
import test from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import { RULES } from '../data/rules.mjs';
import { creatureLedger, xpMetrics, sizeLedger } from '../module/dp.mjs';
import { NATIVE_CONTENT } from '../data/native-content.mjs';
import { designFromFiends, baseKey, ATTACK_ALIASES, packageRows, featBaseName } from '../module/fiends-adapter.mjs';
import { newDesign } from '../module/construction.mjs';

const effect = (changes) => ({ disabled: false, system: { changes } });
const add = (key, value) => ({ key, value, type: 'add' });

test('printed names map to Codex components', () => {
  assert.equal(baseKey('Darkvision (75 ft.)'), 'darkvision');
  assert.equal(baseKey('Blindsight 30 ft'), 'blindsight');
  assert.equal(ATTACK_ALIASES.tail, 'tail-slap');
  assert.equal(ATTACK_ALIASES.wing, 'wings');
  assert.equal(ATTACK_ALIASES.unarmed, 'unarmed-strike');
});

test('a published creature becomes an imported design with its own base attributes', () => {
  const source = {
    name: 'Test Wyrm', flags: { 'fiends-and-fables-prime': { published: { level: 10, effectiveLevel: 9 } } },
    system: { identity: { level: 10, size: 'large' }, details: { biography: '<p>bio</p>' },
      attributes: { strength: { base: 4 }, dexterity: { base: 1 }, constitution: { base: 2 }, intelligence: { base: 1 }, wisdom: { base: 1 }, charisma: { base: 1 } },
      combat: { movement: { land: { base: 40 }, fly: { base: 60 } } } },
    items: [
      { type: 'creature-type', name: 'Wyrm', effects: [] },
      { type: 'class', name: 'Wyrm (Creature Class)', system: {}, effects: [] },
      { type: 'race', name: 'Testling', effects: [effect([add('system.attributes.strength.racial', 2), add('system.combat.immunities', ', fire, bleeding'), add('system.resources.hp.other', 15)])] },
      { type: 'weapon', name: 'Tail', system: { natural: true } },
      { type: 'weapon', name: 'Wing', system: { natural: true } },
      { type: 'weapon', name: 'Soul Blast', system: { natural: true } },
      { type: 'ability', name: 'Freezing Aura', effects: [] },
      { type: 'ability', name: 'Darkvision (60 ft.)', effects: [] },
      { type: 'ability', name: 'Scent', effects: [] },
      { type: 'ability', name: 'Mucus Cloud', effects: [] }
    ]
  };
  const { design, notes } = designFromFiends(source);
  assert.equal(design.typeKey, 'wyrm');
  assert.equal(design.classKey, 'wyrm');
  assert.deepEqual(design.attacks, ['tail-slap', 'wings']);
  assert.ok(design.abilities.includes('elemental-aura'), 'a called aura maps to Elemental Aura');
  assert.equal(design.description, '<p>bio</p>', 'the biography is kept for an unchanged apply');
  assert.deepEqual(design.attributeBaseline, design.attributes, 'level increases are progression, not purchases');
  assert.ok(notes.unmatched.includes('natural attack: Soul Blast'));
  assert.ok(notes.unmatched.includes('ability: Mucus Cloud'));
  const ledger = creatureLedger(design);
  assert.equal(ledger.complete, false, 'unvalued components keep the total provisional');
  assert.ok(ledger.unresolved.some(u => /Mucus Cloud/.test(u.label)));
  assert.ok(!ledger.rows.some(r => r.id.startsWith('base-')), 'no attribute rows for an imported creature');
  assert.ok(ledger.rows.some(r => r.id === 'race-ability-strength' && r.finalDP === 9));
  assert.ok(ledger.rows.some(r => r.id === 'race-immunity-fire' && r.finalDP === 5));
  assert.ok(ledger.rows.some(r => r.id === 'race-immunity-bleeding' && r.finalDP === 5));
  assert.ok(ledger.rows.some(r => r.id === 'race-fixed-hp' && r.finalDP === 3));
  assert.ok(ledger.rows.some(r => r.id === 'sense-scent' && r.finalDP === 4));
});

test('printed feats: parameterised copies valued as DP rows, level-progression General feats credited (CX-07)', () => {
  assert.equal(featBaseName('Weapon Focus (Brawling)'), 'Weapon Focus');
  assert.equal(featBaseName('Toughness II'), 'Toughness');
  const feat = (name) => ({ type: 'feat', name, effects: [] });
  const { design } = designFromFiends({ name: 'F', system: { identity: { level: 5, size: 'medium' }, attributes: {}, combat: { movement: {} } },
    items: [{ type: 'creature-type', name: 'Beast', effects: [] }, { type: 'class', name: 'Beast (Creature Class)', system: {}, effects: [] },
      feat('Iron Will'), feat('Weapon Focus (Brawling)'), feat('Toughness I'), feat('Toughness II'), feat('Not A Real Feat')] });
  const ironWill = RULES.catalog.feats.find(e => e.name === 'Iron Will');
  assert.deepEqual(design.feats, [ironWill.uuid], 'only an exact catalogue match is a managed feat');
  const rows = design.adjustments.filter(a => a.layer === 'feats');
  assert.deepEqual(rows.filter(r => r.dp > 0).map(r => r.id).sort(),
    ['feat-printed-toughness-i', 'feat-printed-toughness-ii', 'feat-printed-weapon-focus-brawling']);
  const allowance = rows.find(r => r.id === 'feat-level-allowance');
  assert.equal(allowance.dp, -12, 'level 5: three General feats from progression (1st, 3rd, 5th)');
  assert.ok(design.adjustments.some(a => a.label === 'feat: Not A Real Feat' && a.dp === null));
  const ledger = creatureLedger(design);
  const featDP = ledger.rows.filter(r => r.layer === 'feats').reduce((t, r) => t + (r.finalDP ?? 0), 0);
  assert.equal(featDP, 4, 'four General feats printed, three from progression: one additional feat at 4 DP');
});

test('an immunity the type already prices is not counted again', () => {
  const typeLabels = new Set(RULES.types.undead.entries.map(e => e.label.toLowerCase()));
  const rows = packageRows({ name: 'Ghoul', effects: [effect([add('system.combat.immunities', ', bleeding, poison, fatigue')])] }, 'race', typeLabels);
  assert.deepEqual(rows.map(r => r.id), ['race-immunity-fatigue']);
});

test('an imported creature with no Codex class ledger is valued provisionally, not refused', () => {
  const { design } = designFromFiends({ name: 'X', system: { identity: { level: 4, size: 'medium' }, attributes: {}, combat: { movement: {} } },
    items: [{ type: 'creature-type', name: 'Eternal', effects: [] }, { type: 'class', name: 'Ethereal Caster (Creature Class)', system: {}, effects: [] }] });
  const ledger = creatureLedger(design);
  assert.equal(ledger.complete, false);
  assert.ok(ledger.unresolved.some(u => /Class: Ethereal Caster/.test(u.label)));
});

test('a Codex-built design is unchanged: same rows and total, refusals intact', () => {
  const design = Object.assign(newDesign(), { level: 5, typeKey: 'undead', classKey: 'undead', attacks: ['bite', 'claw'], abilities: ['regeneration'], regenerationBypass: 'fire',
    attributes: { strength: 3, dexterity: 2, constitution: 1, intelligence: 1, wisdom: 1, charisma: 1 } });
  const ledger = creatureLedger(design);
  assert.equal(ledger.complete, true);
  assert.ok(ledger.rows.some(r => r.id === 'base-strength' && r.finalDP === 9), 'base 3 is +2 over the baseline of 1');
  assert.throws(() => creatureLedger({ ...design, classKey: 'no-such-class' }), /exactly one default/);
  assert.throws(() => creatureLedger({ ...design, classKey: 'construct', caster: true }), /optional casting/);
  assert.equal(xpMetrics(250, 10).xpm, 0);
});

test('0.1.5 and 0.2.0 value Codex-built designs identically', { skip: !process.env.CODEX_015 }, async () => {
  const old = await import(path.join(process.env.CODEX_015, 'module/dp.mjs'));
  const designs = [];
  for (const typeKey of Object.keys(RULES.types)) for (const classKey of [typeKey in RULES.classes ? typeKey : 'martial-npc', 'martial-npc', 'fighter']) {
    designs.push(Object.assign(newDesign(), { typeKey, classKey, level: 7, size: 'large', attacks: ['bite', 'slam'], abilities: ['regeneration', 'stench'], regenerationBypass: 'acid',
      attributes: { strength: 4, dexterity: 1, constitution: 3, intelligence: 1, wisdom: 2, charisma: 1 } }));
  }
  for (const d of designs) {
    let a, b;
    try { a = old.creatureLedger(structuredClone(d)); } catch (e) { a = { error: e.message }; }
    try { b = creatureLedger(structuredClone(d)); } catch (e) { b = { error: e.message }; }
    assert.deepEqual(JSON.parse(JSON.stringify(b)), JSON.parse(JSON.stringify(a)), `${d.typeKey}/${d.classKey}`);
  }
});

test('every published creature imports and values without an error', { skip: !process.env.FF_PACKS }, async () => {
  const { readRaw, assemble } = await import(path.resolve(process.env.FF_PACKS, '../tools/lib/packs.mjs'));
  const { top } = assemble(await readRaw(path.join(process.env.FF_PACKS, 'creatures')));
  const actors = top.filter(t => t.kind === 'actors').map(t => t.doc);
  assert.equal(actors.length, 294);
  for (const a of actors) {
    const { design } = designFromFiends(a);
    const ledger = creatureLedger(design);
    assert.ok(Number.isFinite(ledger.subtotal), a.name);
  }
});

test('rulings of 18 Nov 2026: Tiny/Diminutive reach 0 (RD-02) with unchanged size DP; native Ooze immunities (CO-02, RD-08)', () => {
  for (const size of ['diminutive', 'tiny']) {
    assert.equal(RULES.sizes[size].reach, 0, `${size} reach follows core`);
    const total = sizeLedger(size).reduce((t, r) => t + r.dp, 0);
    assert.equal(total, RULES.sizes[size].printed, `${size} size DP still sums to the printed ${RULES.sizes[size].printed}`);
    assert.equal(sizeLedger(size).find(r => r.label === 'Reach beyond five feet').dp, 0);
  }
  const ooze = NATIVE_CONTENT['creature-types'].find(t => t.name === 'Ooze');
  const words = ooze.effects.find(e => e.name === 'Ooze: immunities').changes.map(c => c.value.replace(/^,\s*/, ''));
  for (const w of ['disease', 'precision', 'mental', 'poison']) assert.ok(words.includes(w), w);
  const eternal = NATIVE_CONTENT['creature-types'].find(t => t.name === 'Eternal');
  assert.equal(eternal.system.noDeathState, true, 'RD-01: Eternal has no Death State, as in core 3.699.0');
});

test('an ability the creature type grants is priced by the type, not unresolved (0.2.2)', () => {
  const { design, notes } = designFromFiends({ name: 'E', system: { identity: { level: 3, size: 'medium' }, attributes: {}, combat: { movement: {} } },
    items: [{ type: 'creature-type', name: 'Eternal', system: { grantedAbilities: 'Darkvision, Nightvision, Eternal Essence, Returned Essence' }, effects: [] },
      { type: 'class', name: 'Eternal (Creature Class)', system: {}, effects: [] },
      { type: 'ability', name: 'Returned Essence', effects: [] }, { type: 'ability', name: 'Mucus Cloud', effects: [] }] });
  assert.ok(!notes.unmatched.includes('ability: Returned Essence'), 'type-granted card is not unresolved');
  assert.ok(notes.unmatched.includes('ability: Mucus Cloud'), 'a genuine unvalued ability still is');
  assert.ok(!design.adjustments.some(a => /Returned Essence/.test(a.label)));
});
